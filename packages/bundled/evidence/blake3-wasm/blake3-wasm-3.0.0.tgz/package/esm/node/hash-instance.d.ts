/// <reference types="node" />
/// <reference types="node" />
import { HashInput, HashRaw, IBaseHashOptions, IHasher } from '@c4312/blake3-internal';
import { Transform, TransformCallback } from 'stream';
export interface INodeHash extends IHasher<Buffer> {
    /**
     * @inheritdoc
     * @override
     */
    update(data: HashInput, encoding?: BufferEncoding): this;
    /**
     * @inheritdoc
     * @override
     */
    digest(options?: IBaseHashOptions): Buffer;
    /**
     * Returns a digest of the hash with the given set of hash options.
     */
    digest(encoding: undefined, options: IBaseHashOptions): Buffer;
    /**
     * Returns a digest of the hash with the given encoding.
     */
    digest(encoding: BufferEncoding, options?: IBaseHashOptions): string;
}
/**
 * @inheritdoc
 */
export declare class NodeHash extends Transform implements IHasher<Buffer> {
    private readonly hash;
    constructor(wasmModule: any, hasher: HashRaw);
    /**
     * @reader
     */
    reader(): import("@c4312/blake3-internal").IHashReader<Buffer>;
    /**
     * @inheritdoc
     */
    update(data: HashInput, encoding?: BufferEncoding): this;
    /**
     * @inheritdoc
     */
    dispose(): void;
    /**
     * @inheritdoc
     */
    digest(encoding?: IBaseHashOptions): Buffer;
    digest(encoding: undefined, options: IBaseHashOptions): Buffer;
    digest(encoding: BufferEncoding, options?: IBaseHashOptions): string;
    /**
     * @inheritdoc
     * @hidden
     */
    _transform(chunk: Buffer | string, encoding: string, callback: TransformCallback): void;
    /**
     * @inheritdoc
     * @hidden
     */
    _flush(callback: TransformCallback): void;
}
/**
 * A Node.js crypto-like createHash method.
 */
export declare const createHash: () => NodeHash;
/**
 * Construct a new Hasher for the keyed hash function.
 */
export declare const createKeyed: (key: HashInput) => NodeHash;
/**
 * Construct a new Hasher for the key derivation function.
 */
export declare const createDeriveKey: (context: HashInput) => NodeHash;
