export * from '@c4312/blake3-internal';
export { deriveKey, hash, keyedHash } from './hash-fn.js';
export * from './hash-instance.js';
/** Loads the WebAssembly hashing code. This *must* be called before any hashing methods. */
export declare const load: () => Promise<void>;
