import { HashInput, IBaseHashOptions, WasmHasher } from '@c4312/blake3-internal';
import { BrowserEncoding } from './encoding.js';
import { Hash } from './hash.js';
/**
 * @inheritdoc
 */
export declare class BrowserHasher extends WasmHasher<Hash> {
    protected alloc(n: number): Hash;
    /**
     * @inheritdoc
     * @override
     */
    update(data: HashInput): this;
    /**
     * Returns a digest of the hash with the given encoding.
     */
    digest(options?: IBaseHashOptions): Hash;
    digest(encoding: undefined, options: IBaseHashOptions): Hash;
    digest(encoding: BrowserEncoding, options?: IBaseHashOptions): string;
}
/**
 * A Node.js crypto-like createHash method.
 */
export declare const createHash: () => BrowserHasher;
/**
 * A Node.js crypto-like createHash method.
 */
export declare const createKeyed: (key: HashInput) => BrowserHasher;
/**
 * Construct a new Hasher for the key derivation function.
 */
export declare const createDeriveKey: (context: HashInput) => BrowserHasher;
