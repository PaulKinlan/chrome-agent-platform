/**
 * Small wrappers over native WebCrypto.
 * @module
 */
import { type Cipher, type CipherDef, type CipherFactory } from './ciphers-abstract.ts';
import { type HashDef, type HashInstance, type HashState, type HashStream, type OutputOpts, type HashBatchOpts } from './hashes-abstract.ts';
import type { Pbkdf2Opts } from './kdf.ts';
import { type Asyncify, type KDFInput, type TArg, type TRet } from './utils.ts';
export type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, Asyncify, Cipher, CipherDef, };
type WebHash<Opts = any> = TRet<HashInstance<Opts>> & {
    isSupported: () => Promise<boolean>;
    webCryptoName: string;
};
type WebCipher = TRet<CipherFactory> & {
    isSupported: () => Promise<boolean>;
};
/**
 * WebCrypto SHA1 legacy hash function from RFC 3174.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha1 } from '@awasm/noble/webcrypto.js';
 * if (await sha1.isSupported()) await sha1.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha1: TRet<WebHash>;
/**
 * WebCrypto SHA2-224 hash function from RFC 6234.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha224 } from '@awasm/noble/webcrypto.js';
 * if (await sha224.isSupported()) await sha224.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha224: TRet<WebHash>;
/**
 * WebCrypto SHA2-256 hash function from RFC 4634.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble/webcrypto.js';
 * if (await sha256.isSupported()) await sha256.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha256: TRet<WebHash>;
/**
 * WebCrypto SHA2-384 hash function from RFC 4634.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha384 } from '@awasm/noble/webcrypto.js';
 * if (await sha384.isSupported()) await sha384.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha384: TRet<WebHash>;
/**
 * WebCrypto SHA2-512 hash function from RFC 4634.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512 } from '@awasm/noble/webcrypto.js';
 * if (await sha512.isSupported()) await sha512.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512: TRet<WebHash>;
/**
 * WebCrypto SHA3-256 hash function.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_256 } from '@awasm/noble/webcrypto.js';
 * if (await sha3_256.isSupported()) await sha3_256.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_256: TRet<WebHash>;
/**
 * WebCrypto SHA3-384 hash function.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_384 } from '@awasm/noble/webcrypto.js';
 * if (await sha3_384.isSupported()) await sha3_384.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_384: TRet<WebHash>;
/**
 * WebCrypto SHA3-512 hash function.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash output configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_512 } from '@awasm/noble/webcrypto.js';
 * if (await sha3_512.isSupported()) await sha3_512.async(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_512: TRet<WebHash>;
/**
 * WebCrypto HMAC message authentication code from RFC 2104.
 * @param hash - hash function definition.
 * @param key - secret MAC key bytes.
 * @param message - message to authenticate.
 * @returns Authentication tag bytes.
 * @example
 * ```ts
 * import { hmac, sha256 } from '@awasm/noble/webcrypto.js';
 * if (await sha256.isSupported())
 *   await hmac(sha256, new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6]));
 * ```
 */
export declare const hmac: TRet<{
    (hash: TArg<HashInstance<any>>, key: TArg<Uint8Array>, message: TArg<Uint8Array>): Promise<TRet<Uint8Array>>;
    create(hash: TArg<HashInstance<any>>, key: TArg<Uint8Array>): never;
}>;
/**
 * WebCrypto HKDF extract-and-expand key derivation from RFC 5869.
 * @param hash - hash function definition.
 * @param ikm - input keying material.
 * @param salt - optional salt bytes.
 * @param info - optional context bytes.
 * @param length - requested output length in bytes.
 * @throws If WebCrypto is unavailable or the requested algorithm is unsupported. {@link Error}
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { hkdf, sha256 } from '@awasm/noble/webcrypto.js';
 * if (await sha256.isSupported())
 *   await hkdf(sha256, new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6]), new Uint8Array([7]), 16);
 * ```
 */
export declare const hkdf: (hash: TArg<HashInstance<any>>, ikm: TArg<Uint8Array>, salt: TArg<Uint8Array | undefined>, info: TArg<Uint8Array | undefined>, length: number) => Promise<TRet<Uint8Array>>;
type WebPbkdf2 = (hash: TArg<HashInstance<any>>) => {
    (password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Pbkdf2Opts>): never;
    async: (password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Pbkdf2Opts>) => Promise<TRet<Uint8Array>>;
};
/**
 * WebCrypto PBKDF2-HMAC key-derivation factory from RFC 8018.
 * @param hash - hash function definition.
 * @returns One-shot PBKDF2 helper with async support.
 * @example
 * ```ts
 * import { pbkdf2, sha256 } from '@awasm/noble/webcrypto.js';
 * if (await sha256.isSupported())
 *   await pbkdf2(sha256).async(new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6]), { c: 10, dkLen: 16 });
 * ```
 */
export declare const pbkdf2: TRet<WebPbkdf2>;
/** Internal WebCrypto AES hooks; properties stay mutable so runtimes can replace encrypt/decrypt. */
export declare const utils: {
    encrypt: (key: TArg<Uint8Array>, keyParams: any, cryptParams: any, plaintext: TArg<Uint8Array>) => Promise<TRet<Uint8Array>>;
    decrypt: (key: TArg<Uint8Array>, keyParams: any, cryptParams: any, ciphertext: TArg<Uint8Array>) => Promise<TRet<Uint8Array>>;
};
/**
 * WebCrypto AES-CBC cipher from NIST SP 800-38A.
 * Callers must supply an unpredictable 16-byte IV and authenticate ciphertext separately.
 * @param key - secret key bytes.
 * @param args - cipher arguments such as 16-byte IV bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cbc } from '@awasm/noble/webcrypto.js';
 * if (await cbc.isSupported())
 *   await cbc(new Uint8Array(16), new Uint8Array(16)).encrypt.async(new Uint8Array(16));
 * ```
 */
export declare const cbc: TRet<WebCipher>;
/**
 * WebCrypto AES-CTR mode from NIST SP 800-38A.
 * Callers must supply a unique 16-byte initial counter block per key and authenticate ciphertext separately.
 * @param key - secret key bytes.
 * @param args - cipher arguments such as 16-byte initial counter block bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ctr } from '@awasm/noble/webcrypto.js';
 * if (await ctr.isSupported())
 *   await ctr(new Uint8Array(16), new Uint8Array(16)).encrypt.async(new Uint8Array(16));
 * ```
 */
export declare const ctr: TRet<WebCipher>;
/**
 * WebCrypto AES-GCM authenticated cipher from NIST SP 800-38D.
 * Returns ciphertext with a 16-byte tag, requires unique IVs per key, and leaves
 * nonce-shape enforcement beyond raw bytes to the backend.
 * @param key - secret key bytes.
 * @param args - cipher arguments such as nonce and AAD bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcm } from '@awasm/noble/webcrypto.js';
 * if (await gcm.isSupported())
 *   await gcm(new Uint8Array(16), new Uint8Array(12), new Uint8Array([1, 2, 3])).encrypt.async(new Uint8Array(16));
 * ```
 */
export declare const gcm: TRet<WebCipher>;
//# sourceMappingURL=webcrypto.d.ts.map