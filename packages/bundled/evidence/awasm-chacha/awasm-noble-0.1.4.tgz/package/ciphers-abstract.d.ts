/**
 * Abstract logic for ciphers.
 * @module
 */
import { type TArg, type TRet } from './utils.ts';
/** Configured cipher instance with one-shot encrypt/decrypt helpers. */
export type Cipher = {
    /**
     * Encrypt plaintext bytes and optionally write into the provided output buffer.
     * @param plaintext - plaintext bytes to encrypt.
     * @param output - optional destination buffer for ciphertext bytes.
     * @returns Ciphertext bytes.
     */
    encrypt(plaintext: TArg<Uint8Array>, output?: TArg<Uint8Array>): TRet<Uint8Array>;
    /**
     * Decrypt ciphertext bytes and optionally write into the provided output buffer.
     * @param ciphertext - ciphertext bytes to decrypt.
     * @param output - optional destination buffer for plaintext bytes.
     * @returns Plaintext bytes.
     */
    decrypt(ciphertext: TArg<Uint8Array>, output?: TArg<Uint8Array>): TRet<Uint8Array>;
};
/** Cipher constructor plus metadata exposed on public wrappers. */
export type CipherFactory = ((key: TArg<Uint8Array>, ...args: unknown[]) => TRet<Cipher>) & {
    blockSize: number;
    blockLen: number;
    nonceLength?: number;
    tagLength?: number;
    withAAD?: true;
    varSizeNonce?: boolean;
    getPlatform: () => string | undefined;
    getDefinition: () => CipherDef<any>;
    isSupported?: () => boolean | Promise<boolean>;
};
type InstallOpts = {
    onlyMissing?: boolean;
};
/** Installable cipher stub used by the `stub` platform. */
export type CipherStub = {
    /**
     * Install a branded cipher implementation into this stub.
     * @param impl - Cipher implementation created by an awasm cipher constructor.
     * @param opts - {@link InstallOpts}; `onlyMissing` leaves an existing implementation unchanged.
     */
    install: (impl: CipherFactory, opts?: InstallOpts) => void;
};
export type CipherParams = {
    blockSize?: number;
    blockLen: number;
    nonceLength?: number;
    tagLength?: number;
    withAAD?: true;
    varSizeNonce?: boolean;
};
export type CipherOpts = {
    disablePadding?: boolean;
};
export type CipherStream = {
    update(data: TArg<Uint8Array>, output?: TArg<Uint8Array>): TRet<Uint8Array>;
    finish(tag?: TArg<Uint8Array>): {
        data: TRet<Uint8Array>;
        tag?: TRet<Uint8Array>;
    };
    destroy(): void;
    _cloneInto(to?: CipherStream): CipherStream;
    clone(): CipherStream;
    saveState(): TRet<Uint8Array>;
    restoreState(state: TArg<Uint8Array>): void;
};
type Dir = 'encrypt' | 'decrypt';
type CipherMod = {
    readonly segments: {
        readonly buffer: Uint8Array;
        readonly state: Uint8Array;
    };
    reset(maxWritten: number): void;
    encryptBlocks(blocks: number, isLast: number, left: number, round?: number): void;
    decryptBlocks(blocks: number, isLast: number, left: number, round?: number): void;
    aadBlocks?(blocks: number, isLast: number, left: number): void;
    macBlocks?(blocks: number, isLast: number, left: number): void;
    tagInit?(): void;
    addPadding?(take: number, left: number, blockLen: number): number;
    verifyPadding?(take: number, blockLen: number): number;
};
/** Low-level cipher definition consumed by {@link mkCipher}. */
export type CipherDef<Mod> = CipherParams & {
    tagLeft?: boolean;
    dataOffset?: number;
    exactOutput?: boolean;
    paddingLeft?: number;
    padding?: boolean;
    padFull?: boolean;
    multiPass?: number;
    multiPassResult?: boolean | {
        encrypt?: boolean;
        decrypt?: boolean;
    };
    multiPassOut?: {
        encrypt?: number;
        decrypt?: number;
    };
    tagError?: string;
    lengthError?: string;
    lengthErrorEnc?: string;
    lengthErrorDec?: string;
    lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
    lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
    padError?: string;
    emptyError?: string;
    noOverlap?: boolean;
    noOutput?: boolean;
    noStream?: boolean;
    twoPass?: boolean;
    validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
    init: (mod: Mod, dir: Dir, key: TArg<Uint8Array>, ...args: unknown[]) => void | {
        disablePadding?: boolean;
    };
    getTag?: (mod: Mod) => TRet<Uint8Array>;
};
export declare const mkCipher: <Mod extends CipherMod>(modFn: () => Mod, def_: TArg<CipherDef<Mod>>, platform?: string) => TRet<CipherFactory>;
type AsyncCipherImpl = {
    encrypt: (data: Uint8Array) => Promise<TRet<Uint8Array>>;
    decrypt: (data: Uint8Array) => Promise<TRet<Uint8Array>>;
};
export declare const mkCipherNoble: <Mod extends CipherMod>(def_: TArg<CipherDef<Mod>>, init_: TArg<(key: TArg<Uint8Array>, ...args: unknown[]) => Cipher>, platform?: string) => TRet<CipherFactory>;
export declare const mkCipherAsync: <Mod extends CipherMod>(def_: TArg<CipherDef<Mod>>, init_: TArg<(key: Uint8Array, ...args: unknown[]) => AsyncCipherImpl>, platform?: string, isSupported?: () => boolean | Promise<boolean>) => TRet<CipherFactory>;
export declare function mkCipherStub<Mod extends CipherMod>(def_: TArg<CipherDef<Mod>>): TRet<CipherFactory & CipherStub>;
export {};
//# sourceMappingURL=ciphers-abstract.d.ts.map