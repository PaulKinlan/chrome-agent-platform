export * from './wasm.ts';
//# sourceMappingURL=index.d.ts.map