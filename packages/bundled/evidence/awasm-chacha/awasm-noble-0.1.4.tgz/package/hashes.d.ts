import { type HashDef } from './hashes-abstract.ts';
import { mkArgon2d, mkArgon2i, mkArgon2id, mkScrypt } from './kdf.ts';
import type * as TYPES from './targets/types.ts';
import { type TArg, type TRet } from './utils.ts';
export declare const sha3_224: TRet<HashDef<TYPES.KECCAK24>>;
export declare const sha3_256: TRet<HashDef<TYPES.KECCAK24>>;
export declare const sha3_384: TRet<HashDef<TYPES.KECCAK24>>;
export declare const sha3_512: TRet<HashDef<TYPES.KECCAK24>>;
export declare const keccak_224: TRet<HashDef<TYPES.KECCAK24>>;
export declare const keccak_256: TRet<HashDef<TYPES.KECCAK24>>;
export declare const keccak_384: TRet<HashDef<TYPES.KECCAK24>>;
export declare const keccak_512: TRet<HashDef<TYPES.KECCAK24>>;
export declare const shake128: TRet<HashDef<TYPES.KECCAK24>>;
export declare const shake256: TRet<HashDef<TYPES.KECCAK24>>;
export declare const shake128_32: TRet<HashDef<TYPES.KECCAK24>>;
export declare const shake256_64: TRet<HashDef<TYPES.KECCAK24>>;
export declare const sha256: TRet<HashDef<TYPES.SHA256>>;
export declare const sha224: TRet<HashDef<TYPES.SHA256>>;
export declare const sha512: TRet<HashDef<TYPES.SHA512>>;
export declare const sha384: TRet<HashDef<TYPES.SHA512>>;
export declare const sha512_224: TRet<HashDef<TYPES.SHA512>>;
export declare const sha512_256: TRet<HashDef<TYPES.SHA512>>;
export declare const sha1: TRet<HashDef<TYPES.SHA1>>;
export declare const ripemd160: TRet<HashDef<TYPES.RIPEMD160>>;
export declare const md5: TRet<HashDef<TYPES.MD5>>;
/** Blake1 options. Basically just "salt" */
export type BlakeOpts = {
    /** Optional salt bytes mixed into the Blake1 initialization state. */
    salt?: TArg<Uint8Array>;
};
export declare const blake256: TRet<HashDef<TYPES.BLAKE256, BlakeOpts>>;
export declare const blake224: TRet<HashDef<TYPES.BLAKE256, BlakeOpts>>;
export declare const blake384: TRet<HashDef<TYPES.BLAKE512, BlakeOpts>>;
export declare const blake512: TRet<HashDef<TYPES.BLAKE512, BlakeOpts>>;
/**
 * Blake2 hash options.
 * dkLen is output length. key is used in MAC mode. salt is used in KDF mode.
 */
export type Blake2Opts = {
    /** Requested digest length in bytes. */
    dkLen?: number;
    /** Optional MAC key bytes for keyed BLAKE2 mode. */
    key?: TArg<Uint8Array>;
    /** Optional salt bytes mixed into the initialization state. */
    salt?: TArg<Uint8Array>;
    /** Optional personalization bytes mixed into the initialization state. */
    personalization?: TArg<Uint8Array>;
};
export declare const blake2s: TRet<HashDef<TYPES.BLAKE2S, Blake2Opts>>;
export declare const blake2b: TRet<HashDef<TYPES.BLAKE2B, Blake2Opts>>;
/**
 * Ensure to use EITHER `key` OR `context`, not both.
 *
 * * `key`: 32-byte MAC key.
 * * `context`: string for KDF. Should be hardcoded, globally unique, and application - specific.
 *   A good default format for the context string is "[application] [commit timestamp] [purpose]".
 */
export type Blake3Opts = {
    /** Requested digest length in bytes. */
    dkLen?: number;
    /** Optional 32-byte key for keyed BLAKE3 / MAC mode. */
    key?: Uint8Array;
    /** Optional context string bytes for derive-key mode. */
    context?: Uint8Array;
    /** Internal flag selecting the derive-key context initialization path. */
    _keyContext?: boolean;
};
export declare const blake3: TRet<HashDef<TYPES.BLAKE3, Blake3Opts>>;
type MACOpts = {
    key: TArg<Uint8Array>;
} | TArg<Uint8Array>;
export declare const poly1305: TRet<HashDef<TYPES.POLY1305, MACOpts>>;
export declare const cmac: TRet<HashDef<TYPES.CMAC, MACOpts>>;
export declare const ghash: TRet<HashDef<TYPES.GHASH, MACOpts>>;
export declare const polyval: TRet<HashDef<TYPES.POLYVAL, MACOpts>>;
export declare const Definitions: {
    readonly sha3_224: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha3_256: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha3_384: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha3_512: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly keccak_224: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly keccak_256: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly keccak_384: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly keccak_512: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly shake128: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly shake256: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly shake128_32: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly shake256_64: {
        mod: "keccak24";
        def: HashDef<TYPES.KECCAK24> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.KECCAK24, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.KECCAK24>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha224: {
        mod: "sha256";
        def: HashDef<TYPES.SHA256> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA256, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA256>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha256: {
        mod: "sha256";
        def: HashDef<TYPES.SHA256> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA256, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA256>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha384: {
        mod: "sha512";
        def: HashDef<TYPES.SHA512> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA512, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha512: {
        mod: "sha512";
        def: HashDef<TYPES.SHA512> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA512, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha512_224: {
        mod: "sha512";
        def: HashDef<TYPES.SHA512> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA512, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha512_256: {
        mod: "sha512";
        def: HashDef<TYPES.SHA512> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA512, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly sha1: {
        mod: "sha1";
        def: HashDef<TYPES.SHA1> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.SHA1, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.SHA1>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly ripemd160: {
        mod: "ripemd160";
        def: HashDef<TYPES.RIPEMD160> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.RIPEMD160, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.RIPEMD160>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly md5: {
        mod: "md5";
        def: HashDef<TYPES.MD5> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.MD5, hash: import("./hashes-abstract.ts").HashInstance<undefined>, opts: import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.MD5>, hash: TArg<import("./hashes-abstract.ts").HashInstance<undefined>>, opts: TArg<import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake224: {
        mod: "blake256";
        def: HashDef<TYPES.BLAKE256, BlakeOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE256, hash: import("./hashes-abstract.ts").HashInstance<BlakeOpts>, opts: BlakeOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE256>, hash: TArg<import("./hashes-abstract.ts").HashInstance<BlakeOpts>>, opts: TArg<BlakeOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake256: {
        mod: "blake256";
        def: HashDef<TYPES.BLAKE256, BlakeOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE256, hash: import("./hashes-abstract.ts").HashInstance<BlakeOpts>, opts: BlakeOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE256>, hash: TArg<import("./hashes-abstract.ts").HashInstance<BlakeOpts>>, opts: TArg<BlakeOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake384: {
        mod: "blake512";
        def: HashDef<TYPES.BLAKE512, BlakeOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE512, hash: import("./hashes-abstract.ts").HashInstance<BlakeOpts>, opts: BlakeOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<BlakeOpts>>, opts: TArg<BlakeOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake512: {
        mod: "blake512";
        def: HashDef<TYPES.BLAKE512, BlakeOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE512, hash: import("./hashes-abstract.ts").HashInstance<BlakeOpts>, opts: BlakeOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE512>, hash: TArg<import("./hashes-abstract.ts").HashInstance<BlakeOpts>>, opts: TArg<BlakeOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake2s: {
        mod: "blake2s";
        def: HashDef<TYPES.BLAKE2S, Blake2Opts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE2S, hash: import("./hashes-abstract.ts").HashInstance<Blake2Opts>, opts: Blake2Opts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE2S>, hash: TArg<import("./hashes-abstract.ts").HashInstance<Blake2Opts>>, opts: TArg<Blake2Opts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake2b: {
        mod: "blake2b";
        def: HashDef<TYPES.BLAKE2B, Blake2Opts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE2B, hash: import("./hashes-abstract.ts").HashInstance<Blake2Opts>, opts: Blake2Opts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE2B>, hash: TArg<import("./hashes-abstract.ts").HashInstance<Blake2Opts>>, opts: TArg<Blake2Opts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly blake3: {
        mod: "blake3";
        def: HashDef<TYPES.BLAKE3, Blake3Opts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.BLAKE3, hash: import("./hashes-abstract.ts").HashInstance<Blake3Opts>, opts: Blake3Opts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.BLAKE3>, hash: TArg<import("./hashes-abstract.ts").HashInstance<Blake3Opts>>, opts: TArg<Blake3Opts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly poly1305: {
        mod: "poly1305";
        def: HashDef<TYPES.POLY1305, MACOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.POLY1305, hash: import("./hashes-abstract.ts").HashInstance<MACOpts>, opts: MACOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.POLY1305>, hash: TArg<import("./hashes-abstract.ts").HashInstance<MACOpts>>, opts: TArg<MACOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly ghash: {
        mod: "ghash";
        def: HashDef<TYPES.GHASH, MACOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.GHASH, hash: import("./hashes-abstract.ts").HashInstance<MACOpts>, opts: MACOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.GHASH>, hash: TArg<import("./hashes-abstract.ts").HashInstance<MACOpts>>, opts: TArg<MACOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly polyval: {
        mod: "polyval";
        def: HashDef<TYPES.POLYVAL, MACOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.POLYVAL, hash: import("./hashes-abstract.ts").HashInstance<MACOpts>, opts: MACOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.POLYVAL>, hash: TArg<import("./hashes-abstract.ts").HashInstance<MACOpts>>, opts: TArg<MACOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
    readonly cmac: {
        mod: "cmac";
        def: HashDef<TYPES.CMAC, MACOpts> & {
            suffix?: number | undefined;
            chunks?: number | undefined;
            blockLen: number;
            outputBlockLen?: number | undefined;
            outputLen: number;
            canXOF?: boolean | undefined;
            oid?: TRet<Uint8Array> | undefined;
            init?: (((batchPos: number, maxBlocks: number, mod: TYPES.CMAC, hash: import("./hashes-abstract.ts").HashInstance<MACOpts>, opts: MACOpts & import("./hashes-abstract.ts").OutputOpts) => void | {
                blocks?: number;
                outputLen?: number;
            }) & ((batchPos: number, maxBlocks: number, mod: TArg<TYPES.CMAC>, hash: TArg<import("./hashes-abstract.ts").HashInstance<MACOpts>>, opts: TArg<MACOpts & import("./hashes-abstract.ts").OutputOpts>) => void | ({
                blocks?: number;
                outputLen?: number;
            } & {
                blocks?: number | undefined;
                outputLen?: number | undefined;
            })) & {}) | undefined;
        };
    };
};
export declare const scrypt: typeof mkScrypt;
export declare const argon2d: typeof mkArgon2d;
export declare const argon2i: typeof mkArgon2i;
export declare const argon2id: typeof mkArgon2id;
export declare const GenericDefinitions: {
    scrypt: {
        mod: string;
        deps: string[];
        stub: {
            path: string;
            fn: string;
        };
    };
    argon2d: {
        mod: string;
        deps: string[];
        stub: {
            path: string;
            fn: string;
        };
    };
    argon2i: {
        mod: string;
        deps: string[];
        stub: {
            path: string;
            fn: string;
        };
    };
    argon2id: {
        mod: string;
        deps: string[];
        stub: {
            path: string;
            fn: string;
        };
    };
};
export {};
//# sourceMappingURL=hashes.d.ts.map