export * from './targets/js/index.ts';
//# sourceMappingURL=js.d.ts.map