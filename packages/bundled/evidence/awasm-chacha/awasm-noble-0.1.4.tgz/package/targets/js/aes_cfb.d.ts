export default function aes_cfb(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_cfb.d.ts.map