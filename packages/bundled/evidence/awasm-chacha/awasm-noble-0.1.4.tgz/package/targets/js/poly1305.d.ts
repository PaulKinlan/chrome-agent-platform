export default function poly1305(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=poly1305.d.ts.map