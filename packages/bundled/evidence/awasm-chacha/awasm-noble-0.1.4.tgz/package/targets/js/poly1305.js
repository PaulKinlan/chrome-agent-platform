// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    const __buf = new ArrayBuffer(2622320);
    if (!(__buf instanceof ArrayBuffer))
        throw new Error('wrong buffer');
    const memory = new Uint8Array(__buf);
    const memory_i32 = new Int32Array(__buf);
    function macBlocksAt(v0, v1, v2, v3, v4) {
        const v5 = memory_i32[(((((320 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v6 = memory_i32[(((((328 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v7 = memory_i32[(((((336 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v8 = memory_i32[(((((344 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v9 = memory_i32[(((((352 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v10 = memory_i32[(((((360 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v11 = memory_i32[(((((368 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v12 = memory_i32[(((((376 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v13 = memory_i32[(((((384 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v14 = memory_i32[(((((392 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v15 = memory_i32[(((((648 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v16 = memory_i32[(((((656 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v17 = memory_i32[(((((664 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v18 = memory_i32[(((((672 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v19 = memory_i32[(((((680 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v20 = memory_i32[(((((688 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v21 = memory_i32[(((((696 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v22 = memory_i32[(((((704 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v23 = memory_i32[(((((712 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        L0: {
            if (((((((((v2) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            const v24 = memory_i32[(((((720 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v25 = memory_i32[(((((728 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v26 = memory_i32[(((((736 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v27 = memory_i32[(((((744 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v28 = memory_i32[(((((752 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v29 = memory_i32[(((((760 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v30 = memory_i32[(((((768 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v31 = memory_i32[(((((776 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v32 = memory_i32[(((((784 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            const v33 = memory_i32[(((((792 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
            let s0 = 0, s1 = v24, s2 = v25, s3 = v26, s4 = v27, s5 = v28, s6 = v29, s7 = v30, s8 = v31, s9 = v32, s10 = v33;
            L1: {
                const v34 = s0;
                const v35 = s1;
                const v36 = s2;
                const v37 = s3;
                const v38 = s4;
                const v39 = s5;
                const v40 = s6;
                const v41 = s7;
                const v42 = s8;
                const v43 = s9;
                const v44 = s10;
                let s11 = v34, s12 = v35, s13 = v36, s14 = v37, s15 = v38, s16 = v39, s17 = v40, s18 = v41, s19 = v42, s20 = v43, s21 = v44;
                L2: for (;;) {
                    const v45 = s11;
                    const v46 = s12;
                    const v47 = s13;
                    const v48 = s14;
                    const v49 = s15;
                    const v50 = s16;
                    const v51 = s17;
                    const v52 = s18;
                    const v53 = s19;
                    const v54 = s20;
                    const v55 = s21;
                    const v56 = ((1 + v45) | 0);
                    const v57 = ((880 + (((v45 + (v1 >>> 4)) | 0) << 4)) | 0);
                    const v58 = memory_i32[(((v57) >>> 0) + 0) >>> 2];
                    const v59 = ((4 + v57) | 0);
                    const v60 = memory_i32[(((v59) >>> 0) + 0) >>> 2];
                    const v61 = ((4 + v59) | 0);
                    const v62 = memory_i32[(((v61) >>> 0) + 0) >>> 2];
                    const v63 = memory_i32[(((((4 + v61) | 0)) >>> 0) + 0) >>> 2];
                    memory_i32[(((v57) >>> 0) + 0) >>> 2] = 0;
                    const v64 = ((4 + v57) | 0);
                    memory_i32[(((v64) >>> 0) + 0) >>> 2] = 0;
                    const v65 = ((4 + v64) | 0);
                    memory_i32[(((v65) >>> 0) + 0) >>> 2] = 0;
                    memory_i32[(((((4 + v65) | 0)) >>> 0) + 0) >>> 2] = 0;
                    const v66 = (((8191 & (v58 >>> 0)) + v46) | 0);
                    const v67 = (((8191 & ((v60 << 19) | (v58 >>> 13))) + v47) | 0);
                    const v68 = (((8191 & ((v60 << 6) | (v58 >>> 26))) + v48) | 0);
                    const v69 = (((8191 & ((v62 << 25) | (v60 >>> 7))) + v49) | 0);
                    const v70 = (((8191 & ((v62 << 12) | (v60 >>> 20))) + v50) | 0);
                    const v71 = (((8191 & ((v63 << 31) | (v62 >>> 1))) + v51) | 0);
                    const v72 = (((8191 & ((v63 << 18) | (v62 >>> 14))) + v52) | 0);
                    const v73 = (((8191 & ((v63 << 5) | (v62 >>> 27))) + v53) | 0);
                    const v74 = (((8191 & (v63 >>> 8)) + v54) | 0);
                    const v75 = (((8191 & (((((((((v4) | 0) !== ((0) | 0)) | 0) & ((((((1 + v45) | 0)) | 0) === ((v2) | 0)) | 0)) & v3)) ? (0) : (2048)) | (v63 >>> 21))) + v55) | 0);
                    const v76 = ((Math.imul(v20, v70) + ((Math.imul(v21, v69) + ((Math.imul(v22, v68) + ((Math.imul(v23, v67) + Math.imul(v5, v66)) | 0)) | 0)) | 0)) | 0);
                    const v77 = ((((Math.imul(v15, v75) + ((Math.imul(v16, v74) + ((Math.imul(v17, v73) + ((Math.imul(v18, v72) + Math.imul(v19, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v76)) | 0);
                    const v78 = ((((Math.imul(v21, v70) + ((Math.imul(v22, v69) + ((Math.imul(v23, v68) + ((Math.imul(v5, v67) + Math.imul(v6, v66)) | 0)) | 0)) | 0)) | 0) + (((v77 >>> 13) + (v76 >>> 13)) | 0)) | 0);
                    const v79 = ((((Math.imul(v16, v75) + ((Math.imul(v17, v74) + ((Math.imul(v18, v73) + ((Math.imul(v19, v72) + Math.imul(v20, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v78)) | 0);
                    const v80 = ((((Math.imul(v22, v70) + ((Math.imul(v23, v69) + ((Math.imul(v5, v68) + ((Math.imul(v6, v67) + Math.imul(v7, v66)) | 0)) | 0)) | 0)) | 0) + (((v79 >>> 13) + (v78 >>> 13)) | 0)) | 0);
                    const v81 = ((((Math.imul(v17, v75) + ((Math.imul(v18, v74) + ((Math.imul(v19, v73) + ((Math.imul(v20, v72) + Math.imul(v21, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v80)) | 0);
                    const v82 = (8191 & v81);
                    const v83 = ((((Math.imul(v23, v70) + ((Math.imul(v5, v69) + ((Math.imul(v6, v68) + ((Math.imul(v7, v67) + Math.imul(v8, v66)) | 0)) | 0)) | 0)) | 0) + (((v81 >>> 13) + (v80 >>> 13)) | 0)) | 0);
                    const v84 = ((((Math.imul(v18, v75) + ((Math.imul(v19, v74) + ((Math.imul(v20, v73) + ((Math.imul(v21, v72) + Math.imul(v22, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v83)) | 0);
                    const v85 = (8191 & v84);
                    const v86 = ((((Math.imul(v5, v70) + ((Math.imul(v6, v69) + ((Math.imul(v7, v68) + ((Math.imul(v8, v67) + Math.imul(v9, v66)) | 0)) | 0)) | 0)) | 0) + (((v84 >>> 13) + (v83 >>> 13)) | 0)) | 0);
                    const v87 = ((((Math.imul(v19, v75) + ((Math.imul(v20, v74) + ((Math.imul(v21, v73) + ((Math.imul(v22, v72) + Math.imul(v23, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v86)) | 0);
                    const v88 = (8191 & v87);
                    const v89 = ((((Math.imul(v6, v70) + ((Math.imul(v7, v69) + ((Math.imul(v8, v68) + ((Math.imul(v9, v67) + Math.imul(v10, v66)) | 0)) | 0)) | 0)) | 0) + (((v87 >>> 13) + (v86 >>> 13)) | 0)) | 0);
                    const v90 = ((((Math.imul(v20, v75) + ((Math.imul(v21, v74) + ((Math.imul(v22, v73) + ((Math.imul(v23, v72) + Math.imul(v5, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v89)) | 0);
                    const v91 = (8191 & v90);
                    const v92 = ((((Math.imul(v7, v70) + ((Math.imul(v8, v69) + ((Math.imul(v9, v68) + ((Math.imul(v10, v67) + Math.imul(v11, v66)) | 0)) | 0)) | 0)) | 0) + (((v90 >>> 13) + (v89 >>> 13)) | 0)) | 0);
                    const v93 = ((((Math.imul(v21, v75) + ((Math.imul(v22, v74) + ((Math.imul(v23, v73) + ((Math.imul(v5, v72) + Math.imul(v6, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v92)) | 0);
                    const v94 = (8191 & v93);
                    const v95 = ((((Math.imul(v8, v70) + ((Math.imul(v9, v69) + ((Math.imul(v10, v68) + ((Math.imul(v11, v67) + Math.imul(v12, v66)) | 0)) | 0)) | 0)) | 0) + (((v93 >>> 13) + (v92 >>> 13)) | 0)) | 0);
                    const v96 = ((((Math.imul(v22, v75) + ((Math.imul(v23, v74) + ((Math.imul(v5, v73) + ((Math.imul(v6, v72) + Math.imul(v7, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v95)) | 0);
                    const v97 = (8191 & v96);
                    const v98 = ((((Math.imul(v9, v70) + ((Math.imul(v10, v69) + ((Math.imul(v11, v68) + ((Math.imul(v12, v67) + Math.imul(v13, v66)) | 0)) | 0)) | 0)) | 0) + (((v96 >>> 13) + (v95 >>> 13)) | 0)) | 0);
                    const v99 = ((((Math.imul(v23, v75) + ((Math.imul(v5, v74) + ((Math.imul(v6, v73) + ((Math.imul(v7, v72) + Math.imul(v8, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v98)) | 0);
                    const v100 = (8191 & v99);
                    const v101 = ((((Math.imul(v10, v70) + ((Math.imul(v11, v69) + ((Math.imul(v12, v68) + ((Math.imul(v13, v67) + Math.imul(v14, v66)) | 0)) | 0)) | 0)) | 0) + (((v99 >>> 13) + (v98 >>> 13)) | 0)) | 0);
                    const v102 = ((((Math.imul(v5, v75) + ((Math.imul(v6, v74) + ((Math.imul(v7, v73) + ((Math.imul(v8, v72) + Math.imul(v9, v71)) | 0)) | 0)) | 0)) | 0) + (8191 & v101)) | 0);
                    const v103 = (8191 & v102);
                    const v104 = ((Math.imul(5, (((v102 >>> 13) + (v101 >>> 13)) | 0)) + (8191 & v77)) | 0);
                    const v105 = (8191 & v104);
                    const v106 = (((v104 >>> 13) + (8191 & v79)) | 0);
                    if (((((v56) >>> 0) < ((v2) >>> 0)) | 0)) {
                        s11 = v56;
                        s12 = v105;
                        s13 = v106;
                        s14 = v82;
                        s15 = v85;
                        s16 = v88;
                        s17 = v91;
                        s18 = v94;
                        s19 = v97;
                        s20 = v100;
                        s21 = v103;
                        continue L2;
                    }
                    s11 = v56;
                    s12 = v105;
                    s13 = v106;
                    s14 = v82;
                    s15 = v85;
                    s16 = v88;
                    s17 = v91;
                    s18 = v94;
                    s19 = v97;
                    s20 = v100;
                    s21 = v103;
                    break L2;
                }
                const v45 = s11;
                const v46 = s12;
                const v47 = s13;
                const v48 = s14;
                const v49 = s15;
                const v50 = s16;
                const v51 = s17;
                const v52 = s18;
                const v53 = s19;
                const v54 = s20;
                const v55 = s21;
                s0 = v45;
                s1 = v46;
                s2 = v47;
                s3 = v48;
                s4 = v49;
                s5 = v50;
                s6 = v51;
                s7 = v52;
                s8 = v53;
                s9 = v54;
                s10 = v55;
            }
            const v35 = s1;
            const v36 = s2;
            const v37 = s3;
            const v38 = s4;
            const v39 = s5;
            const v40 = s6;
            const v41 = s7;
            const v42 = s8;
            const v43 = s9;
            const v44 = s10;
            memory_i32[(((((720 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v35;
            memory_i32[(((((728 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v36;
            memory_i32[(((((736 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v37;
            memory_i32[(((((744 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v38;
            memory_i32[(((((752 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v39;
            memory_i32[(((((760 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v40;
            memory_i32[(((((768 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v41;
            memory_i32[(((((776 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v42;
            memory_i32[(((((784 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v43;
            memory_i32[(((((792 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v44;
        }
        return;
    }
    function macFinish(v0) {
        const v1 = memory_i32[(((((720 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v2 = memory_i32[(((((728 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v3 = memory_i32[(((((736 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v4 = memory_i32[(((((744 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v5 = memory_i32[(((((752 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v6 = memory_i32[(((((760 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v7 = memory_i32[(((((768 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v8 = memory_i32[(((((776 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v9 = memory_i32[(((((784 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v10 = memory_i32[(((((792 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v11 = (((v2 >>> 13) + v3) | 0);
        const v12 = (((v11 >>> 13) + v4) | 0);
        const v13 = (8191 & v12);
        const v14 = (((v12 >>> 13) + v5) | 0);
        const v15 = (8191 & v14);
        const v16 = (((v14 >>> 13) + v6) | 0);
        const v17 = (8191 & v16);
        const v18 = (((v16 >>> 13) + v7) | 0);
        const v19 = (8191 & v18);
        const v20 = (((v18 >>> 13) + v8) | 0);
        const v21 = (8191 & v20);
        const v22 = (((v20 >>> 13) + v9) | 0);
        const v23 = (8191 & v22);
        const v24 = (((v22 >>> 13) + v10) | 0);
        const v25 = (8191 & v24);
        const v26 = ((Math.imul(5, (v24 >>> 13)) + v1) | 0);
        const v27 = (8191 & v26);
        const v28 = (((v26 >>> 13) + (8191 & v2)) | 0);
        const v29 = (8191 & v28);
        const v30 = (((v28 >>> 13) + (8191 & v11)) | 0);
        const v31 = ((5 + v27) | 0);
        const v32 = (((v31 >>> 13) + v29) | 0);
        const v33 = (((v32 >>> 13) + v30) | 0);
        const v34 = (((v33 >>> 13) + v13) | 0);
        const v35 = (((v34 >>> 13) + v15) | 0);
        const v36 = (((v35 >>> 13) + v17) | 0);
        const v37 = (((v36 >>> 13) + v19) | 0);
        const v38 = (((v37 >>> 13) + v21) | 0);
        const v39 = (((v38 >>> 13) + v23) | 0);
        const v40 = (((((v39 >>> 13) + v25) | 0) - 8192) | 0);
        const v41 = (((v40 >>> 31) - 1) | 0);
        const v42 = (~v41);
        const v43 = ((v41 & (8191 & v33)) | (v42 & v30));
        const v44 = ((v41 & (8191 & v35)) | (v42 & v15));
        const v45 = ((v41 & (8191 & v38)) | (v42 & v21));
        const v46 = memory_i32[(((((800 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v47 = memory_i32[(((((808 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v48 = memory_i32[(((((816 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v49 = memory_i32[(((((824 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2];
        const v50 = ((v43 << 26) | ((((v41 & (8191 & v32)) | (v42 & v29)) << 13) | ((v41 & (8191 & v31)) | (v42 & v27))));
        const v51 = ((v46 + v50) | 0);
        memory_i32[(((((864 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v51;
        const v52 = ((v44 << 20) | ((((v41 & (8191 & v34)) | (v42 & v13)) << 7) | (v43 >>> 6)));
        const v53 = ((v47 + v52) | 0);
        const v54 = ((((((-1 ^ v51) & (v46 | v50)) | (v46 & v50)) >>> 31) + v53) | 0);
        memory_i32[(((((868 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v54;
        const v55 = ((v45 << 27) | ((((v41 & (8191 & v37)) | (v42 & v19)) << 14) | ((((v41 & (8191 & v36)) | (v42 & v17)) << 1) | (v44 >>> 12))));
        const v56 = ((((((-1 ^ v54) & (((((-1 ^ v51) & (v46 | v50)) | (v46 & v50)) >>> 31) | v53)) | (((((-1 ^ v51) & (v46 | v50)) | (v46 & v50)) >>> 31) & v53)) >>> 31) + ((((-1 ^ v53) & (v47 | v52)) | (v47 & v52)) >>> 31)) | 0);
        const v57 = ((v48 + v55) | 0);
        const v58 = ((v56 + v57) | 0);
        memory_i32[(((((872 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v58;
        memory_i32[(((((876 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = ((((((((-1 ^ v58) & (v56 | v57)) | (v56 & v57)) >>> 31) + ((((-1 ^ v57) & (v48 | v55)) | (v48 & v55)) >>> 31)) | 0) + ((v49 + ((((v41 & v40) | (v42 & v25)) << 21) | ((((v41 & (8191 & v39)) | (v42 & v23)) << 8) | (v45 >>> 5)))) | 0)) | 0);
        return;
    }
    function macInit(v0) {
        const v1 = memory[((((65 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v2 = memory[((((66 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v3 = memory[((((67 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v4 = memory[((((64 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v5 = memory[((((69 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v6 = memory[((((70 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v7 = memory[((((71 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v8 = memory[((((68 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v9 = memory[((((73 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v10 = memory[((((74 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v11 = memory[((((75 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v12 = memory[((((72 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v13 = memory[((((77 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v14 = memory[((((78 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v15 = memory[((((79 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v16 = memory[((((76 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v17 = memory[((((51 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v18 = memory[((((55 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v19 = memory[((((59 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v20 = memory[((((63 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v21 = memory[((((52 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v22 = memory[((((56 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v23 = memory[((((60 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v24 = memory[((((49 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v25 = memory[((((50 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v26 = memory[((((48 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v27 = (((15 & (255 & v17)) << 24) | ((((255 & v25) << 16) | ((255 & v24) << 8)) | (255 & v26)));
        const v28 = memory[((((53 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v29 = memory[((((54 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v30 = (((15 & (255 & v18)) << 24) | ((((255 & v29) << 16) | ((255 & v28) << 8)) | (252 & (255 & v21))));
        const v31 = memory[((((57 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v32 = memory[((((58 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v33 = (((15 & (255 & v19)) << 24) | ((((255 & v32) << 16) | ((255 & v31) << 8)) | (252 & (255 & v22))));
        const v34 = memory[((((61 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v35 = memory[((((62 + Math.imul(880, v0)) | 0)) >>> 0) + 0];
        const v36 = (((15 & (255 & v20)) << 24) | ((((255 & v35) << 16) | ((255 & v34) << 8)) | (252 & (255 & v23))));
        const v37 = (8191 & (v27 >>> 0));
        const v38 = (8191 & ((v30 << 19) | (v27 >>> 13)));
        const v39 = (8191 & ((v30 << 6) | (v27 >>> 26)));
        const v40 = (8191 & ((v33 << 25) | (v30 >>> 7)));
        const v41 = (8191 & ((v33 << 12) | (v30 >>> 20)));
        const v42 = (8191 & ((v36 << 31) | (v33 >>> 1)));
        const v43 = (8191 & ((v36 << 18) | (v33 >>> 14)));
        const v44 = (8191 & ((v36 << 5) | (v33 >>> 27)));
        const v45 = (8191 & (v36 >>> 8));
        const v46 = (8191 & (v36 >>> 21));
        memory_i32[(((((320 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v37;
        memory_i32[(((((324 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((328 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v38;
        memory_i32[(((((332 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((336 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v39;
        memory_i32[(((((340 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((344 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v40;
        memory_i32[(((((348 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((352 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v41;
        memory_i32[(((((356 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((360 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v42;
        memory_i32[(((((364 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((368 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v43;
        memory_i32[(((((372 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((376 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v44;
        memory_i32[(((((380 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((384 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v45;
        memory_i32[(((((388 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((392 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = v46;
        memory_i32[(((((396 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((640 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v37);
        memory_i32[(((((644 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((648 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v38);
        memory_i32[(((((652 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((656 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v39);
        memory_i32[(((((660 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((664 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v40);
        memory_i32[(((((668 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((672 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v41);
        memory_i32[(((((676 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((680 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v42);
        memory_i32[(((((684 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((688 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v43);
        memory_i32[(((((692 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((696 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v44);
        memory_i32[(((((700 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((704 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v45);
        memory_i32[(((((708 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((712 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = Math.imul(5, v46);
        memory_i32[(((((716 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((800 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v3) << 24) | ((255 & v2) << 16)) | ((255 & v1) << 8)) | (255 & v4));
        memory_i32[(((((804 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((808 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v7) << 24) | ((255 & v6) << 16)) | ((255 & v5) << 8)) | (255 & v8));
        memory_i32[(((((812 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((816 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v11) << 24) | ((255 & v10) << 16)) | ((255 & v9) << 8)) | (255 & v12));
        memory_i32[(((((820 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory_i32[(((((824 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v15) << 24) | ((255 & v14) << 16)) | ((255 & v13) << 8)) | (255 & v16));
        memory_i32[(((((828 + Math.imul(880, v0)) | 0)) >>> 0) + 0) >>> 2] = 0;
        memory.fill(0, ((((720 + Math.imul(880, v0)) | 0)) >>> 0), ((((720 + Math.imul(880, v0)) | 0)) >>> 0) + 80);
        return;
    }
    function macPadAt(v0, v1, v2) {
        L0: {
            if (((((((((v2) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            const v3 = ((v1 + v0) | 0);
            memory[((((880 + v3) | 0)) >>> 0) + 0] = 1;
            const v4 = ((1 + v3) | 0);
            const v5 = memory[((((880 + v4) | 0)) >>> 0) + 0];
            memory[((((880 + v4) | 0)) >>> 0) + 0] = ((((((1) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v5));
            const v6 = ((2 + v3) | 0);
            const v7 = memory[((((880 + v6) | 0)) >>> 0) + 0];
            memory[((((880 + v6) | 0)) >>> 0) + 0] = ((((((2) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v7));
            const v8 = ((3 + v3) | 0);
            const v9 = memory[((((880 + v8) | 0)) >>> 0) + 0];
            memory[((((880 + v8) | 0)) >>> 0) + 0] = ((((((3) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v9));
            const v10 = ((4 + v3) | 0);
            const v11 = memory[((((880 + v10) | 0)) >>> 0) + 0];
            memory[((((880 + v10) | 0)) >>> 0) + 0] = ((((((4) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v11));
            const v12 = ((5 + v3) | 0);
            const v13 = memory[((((880 + v12) | 0)) >>> 0) + 0];
            memory[((((880 + v12) | 0)) >>> 0) + 0] = ((((((5) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v13));
            const v14 = ((6 + v3) | 0);
            const v15 = memory[((((880 + v14) | 0)) >>> 0) + 0];
            memory[((((880 + v14) | 0)) >>> 0) + 0] = ((((((6) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v15));
            const v16 = ((7 + v3) | 0);
            const v17 = memory[((((880 + v16) | 0)) >>> 0) + 0];
            memory[((((880 + v16) | 0)) >>> 0) + 0] = ((((((7) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v17));
            const v18 = ((8 + v3) | 0);
            const v19 = memory[((((880 + v18) | 0)) >>> 0) + 0];
            memory[((((880 + v18) | 0)) >>> 0) + 0] = ((((((8) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v19));
            const v20 = ((9 + v3) | 0);
            const v21 = memory[((((880 + v20) | 0)) >>> 0) + 0];
            memory[((((880 + v20) | 0)) >>> 0) + 0] = ((((((9) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v21));
            const v22 = ((10 + v3) | 0);
            const v23 = memory[((((880 + v22) | 0)) >>> 0) + 0];
            memory[((((880 + v22) | 0)) >>> 0) + 0] = ((((((10) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v23));
            const v24 = ((11 + v3) | 0);
            const v25 = memory[((((880 + v24) | 0)) >>> 0) + 0];
            memory[((((880 + v24) | 0)) >>> 0) + 0] = ((((((11) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v25));
            const v26 = ((12 + v3) | 0);
            const v27 = memory[((((880 + v26) | 0)) >>> 0) + 0];
            memory[((((880 + v26) | 0)) >>> 0) + 0] = ((((((12) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v27));
            const v28 = ((13 + v3) | 0);
            const v29 = memory[((((880 + v28) | 0)) >>> 0) + 0];
            memory[((((880 + v28) | 0)) >>> 0) + 0] = ((((((13) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v29));
            const v30 = ((14 + v3) | 0);
            const v31 = memory[((((880 + v30) | 0)) >>> 0) + 0];
            memory[((((880 + v30) | 0)) >>> 0) + 0] = ((((((14) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v31));
            const v32 = ((15 + v3) | 0);
            const v33 = memory[((((880 + v32) | 0)) >>> 0) + 0];
            memory[((((880 + v32) | 0)) >>> 0) + 0] = ((((((15) >>> 0) < ((v2) >>> 0)) | 0)) ? (0) : (v33));
        }
        return;
    }
    function padding(v0, v1, v2, v3, v4, v5) {
        macPadAt(Math.imul(Math.imul(v4, v2), v0), v1, v3);
        const v6 = ((((((v1) | 0) === ((0) | 0)) | 0)) ? (1) : (0));
        return v6;
    }
    function processBlocks(v0, v1, v2, v3, v4, v5, v6, v7) {
        let s0 = 0;
        L0: {
            const v8 = s0;
            if (((((((((v8) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v8;
                break L0;
            }
            let s1 = v8;
            L1: {
                const v9 = s1;
                let s2 = v9;
                L2: for (;;) {
                    const v10 = s2;
                    let s3 = v10;
                    L3: {
                        const v11 = s3;
                        const v12 = ((v11 + v0) | 0);
                        const v13 = ((v2 - v7) | 0);
                        let s4 = 0;
                        L4: {
                            const v14 = s4;
                            if (((((((((v14) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                s4 = v14;
                                break L4;
                            }
                            let s5 = v14;
                            L5: {
                                const v15 = s5;
                                let s6 = v15;
                                L6: for (;;) {
                                    const v16 = s6;
                                    let s7 = v16;
                                    L7: {
                                        const v17 = s7;
                                        const v18 = ((v17 + v12) | 0);
                                        macBlocksAt(v18, Math.imul(Math.imul(v4, v3), v18), v13, v5, v6);
                                        s7 = v17;
                                    }
                                    const v17 = s7;
                                    const v19 = ((1 + v17) | 0);
                                    if (((((v19) >>> 0) < ((1) >>> 0)) | 0)) {
                                        s6 = v19;
                                        continue L6;
                                    }
                                    s6 = v19;
                                    break L6;
                                }
                                const v16 = s6;
                                s5 = v16;
                            }
                            const v15 = s5;
                            s4 = v15;
                        }
                        s3 = v11;
                    }
                    const v11 = s3;
                    const v20 = ((1 + v11) | 0);
                    if (((((v20) >>> 0) < ((v1) >>> 0)) | 0)) {
                        s2 = v20;
                        continue L2;
                    }
                    s2 = v20;
                    break L2;
                }
                const v10 = s2;
                s1 = v10;
            }
            const v9 = s1;
            s0 = v9;
        }
        return;
    }
    function processOutBlocks(v0, v1, v2, v3, v4, v5) {
        let s0 = 0;
        L0: {
            const v6 = s0;
            if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v6;
                break L0;
            }
            let s1 = v6;
            L1: {
                const v7 = s1;
                let s2 = v7;
                L2: for (;;) {
                    const v8 = s2;
                    let s3 = v8;
                    L3: {
                        const v9 = s3;
                        const v10 = ((v9 + v0) | 0);
                        let s4 = 0;
                        L4: {
                            const v11 = s4;
                            if (((((((((v11) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                s4 = v11;
                                break L4;
                            }
                            let s5 = v11;
                            L5: {
                                const v12 = s5;
                                let s6 = v12;
                                L6: for (;;) {
                                    const v13 = s6;
                                    let s7 = v13;
                                    L7: {
                                        const v14 = s7;
                                        const v15 = ((v14 + v10) | 0);
                                        macFinish(v15);
                                        const v16 = memory_i32[(((((864 + Math.imul(880, v15)) | 0)) >>> 0) + 0) >>> 2];
                                        const v17 = memory_i32[(((((868 + Math.imul(880, v15)) | 0)) >>> 0) + 0) >>> 2];
                                        const v18 = memory_i32[(((((872 + Math.imul(880, v15)) | 0)) >>> 0) + 0) >>> 2];
                                        const v19 = memory_i32[(((((876 + Math.imul(880, v15)) | 0)) >>> 0) + 0) >>> 2];
                                        let s8 = 0;
                                        L8: {
                                            const v20 = s8;
                                            if (((((((((v20) >>> 0) < ((v2) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                                s8 = v20;
                                                break L8;
                                            }
                                            let s9 = v20;
                                            L9: {
                                                const v21 = s9;
                                                let s10 = v21;
                                                L10: for (;;) {
                                                    const v22 = s10;
                                                    let s11 = v22;
                                                    L11: {
                                                        const v23 = s11;
                                                        const v24 = ((((880 + (v23 << 4)) | 0) + (Math.imul(v3, v15) << 4)) | 0);
                                                        memory_i32[(((v24) >>> 0) + 0) >>> 2] = v16;
                                                        const v25 = ((4 + v24) | 0);
                                                        memory_i32[(((v25) >>> 0) + 0) >>> 2] = v17;
                                                        const v26 = ((4 + v25) | 0);
                                                        memory_i32[(((v26) >>> 0) + 0) >>> 2] = v18;
                                                        memory_i32[(((((4 + v26) | 0)) >>> 0) + 0) >>> 2] = v19;
                                                        s11 = v23;
                                                    }
                                                    const v23 = s11;
                                                    const v27 = ((1 + v23) | 0);
                                                    if (((((v27) >>> 0) < ((v2) >>> 0)) | 0)) {
                                                        s10 = v27;
                                                        continue L10;
                                                    }
                                                    s10 = v27;
                                                    break L10;
                                                }
                                                const v22 = s10;
                                                s9 = v22;
                                            }
                                            const v21 = s9;
                                            s8 = v21;
                                        }
                                        s7 = v14;
                                    }
                                    const v14 = s7;
                                    const v28 = ((1 + v14) | 0);
                                    if (((((v28) >>> 0) < ((1) >>> 0)) | 0)) {
                                        s6 = v28;
                                        continue L6;
                                    }
                                    s6 = v28;
                                    break L6;
                                }
                                const v13 = s6;
                                s5 = v13;
                            }
                            const v12 = s5;
                            s4 = v12;
                        }
                        s3 = v9;
                    }
                    const v9 = s3;
                    const v29 = ((1 + v9) | 0);
                    if (((((v29) >>> 0) < ((v1) >>> 0)) | 0)) {
                        s2 = v29;
                        continue L2;
                    }
                    s2 = v29;
                    break L2;
                }
                const v8 = s2;
                s1 = v8;
            }
            const v7 = s1;
            s0 = v7;
        }
        return;
    }
    function reset(v0, v1, v2, v3, v4) {
        const v5 = ((((((v3) >>> 0) / (((4) >>> 0)))) >>> 0));
        memory.fill(0, ((Math.imul(880, v0)) >>> 0), ((Math.imul(880, v0)) >>> 0) + ((Math.imul(v1, 880)) >>> 0));
        let s0 = 0;
        L0: {
            const v6 = s0;
            if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v6;
                break L0;
            }
            let s1 = v6;
            L1: {
                const v7 = s1;
                let s2 = v7;
                L2: for (;;) {
                    const v8 = s2;
                    let s3 = v8;
                    L3: {
                        const v9 = s3;
                        memory.fill(0, ((((880 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0), ((((880 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0) + ((v2) >>> 0));
                        s3 = v9;
                    }
                    const v9 = s3;
                    const v10 = ((1 + v9) | 0);
                    if (((((v10) >>> 0) < ((v1) >>> 0)) | 0)) {
                        s2 = v10;
                        continue L2;
                    }
                    s2 = v10;
                    break L2;
                }
                const v8 = s2;
                s1 = v8;
            }
            const v7 = s1;
            s0 = v7;
        }
        return;
    }
    const instance = { exports: { macBlocksAt: macBlocksAt, macFinish: macFinish, macInit: macInit, macPadAt: macPadAt, padding: padding, processBlocks: processBlocks, processOutBlocks: processOutBlocks, reset: reset, memory: { buffer: __buf } } };
    ;
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 2622320);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 880),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 880, 880))),
        "state.state_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 880, 40))),
        "state.poly_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 880, 832))),
        "state.poly.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 880, 32))),
        "state.poly.r_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 80 + i * 880, 320))),
        "state.poly.r5_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 400 + i * 880, 320))),
        "state.poly.h_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 720 + i * 880, 80))),
        "state.poly.pad_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 800 + i * 880, 64))),
        "state.poly.tag_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 864 + i * 880, 16))),
        buffer: new Uint8Array(memoryExport.buffer, 880, 2621440),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 880 + i * 2621440, 2621440)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments });
}
let _cache;
export default function poly1305(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
