export default function aes_ofb(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_ofb.d.ts.map