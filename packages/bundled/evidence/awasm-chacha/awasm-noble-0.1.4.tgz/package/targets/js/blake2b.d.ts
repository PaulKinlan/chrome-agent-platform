export default function blake2(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=blake2b.d.ts.map