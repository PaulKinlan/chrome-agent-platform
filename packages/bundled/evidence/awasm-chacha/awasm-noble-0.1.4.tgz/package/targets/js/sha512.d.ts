export default function sha2(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=sha512.d.ts.map