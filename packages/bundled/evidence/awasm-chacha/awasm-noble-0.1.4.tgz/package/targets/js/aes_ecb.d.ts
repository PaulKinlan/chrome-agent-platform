export default function aes_ecb(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_ecb.d.ts.map