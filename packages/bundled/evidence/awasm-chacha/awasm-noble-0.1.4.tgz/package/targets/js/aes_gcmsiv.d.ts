export default function aes_gcmsiv(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_gcmsiv.d.ts.map