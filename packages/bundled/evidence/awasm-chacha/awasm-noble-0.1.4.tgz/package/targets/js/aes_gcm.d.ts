export default function aes_gcm(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_gcm.d.ts.map