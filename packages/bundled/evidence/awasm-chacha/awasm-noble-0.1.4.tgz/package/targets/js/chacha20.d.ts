export default function chacha(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=chacha20.d.ts.map