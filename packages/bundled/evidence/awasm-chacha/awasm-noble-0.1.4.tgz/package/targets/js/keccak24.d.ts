export default function keccakF24(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=keccak24.d.ts.map