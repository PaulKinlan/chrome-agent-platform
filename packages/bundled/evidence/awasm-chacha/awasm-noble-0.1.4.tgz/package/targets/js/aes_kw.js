// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    const __buf = new ArrayBuffer(5252144);
    if (!(__buf instanceof ArrayBuffer))
        throw new Error('wrong buffer');
    const memory = new Uint8Array(__buf);
    const memory_i32 = new Int32Array(__buf);
    function addPadding(v0, v1, v2) {
        memory_i32[2316] = -1499027802;
        memory_i32[2317] = -1499027802;
        return 0;
    }
    function aesBlockDec(v0, v1, v2, v3) {
        const v4 = memory_i32[128];
        const v5 = memory_i32[8];
        const v6 = memory_i32[9];
        const v7 = memory_i32[10];
        const v8 = memory_i32[11];
        const v9 = ((v4 - 1) | 0);
        let s0 = 0, s1 = (v5 ^ v0), s2 = (v6 ^ v1), s3 = (v7 ^ v2), s4 = (v8 ^ v3);
        L0: {
            const v10 = s0;
            const v11 = s1;
            const v12 = s2;
            const v13 = s3;
            const v14 = s4;
            let s5 = v10, s6 = v11, s7 = v12, s8 = v13, s9 = v14;
            L1: for (;;) {
                const v15 = s5;
                const v16 = s6;
                const v17 = s7;
                const v18 = s8;
                const v19 = s9;
                const v20 = ((1 + v15) | 0);
                const v21 = (((1 + v15) | 0) << 2);
                const v22 = memory_i32[(((((32 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v23 = memory_i32[(((((5136 + ((255 & v16) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v24 = memory_i32[(((((6160 + ((255 & (v19 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v25 = memory_i32[(((((7184 + ((255 & (v18 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v26 = memory_i32[(((((8208 + ((255 & (v17 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v27 = (((v26 ^ v25) ^ (v24 ^ v23)) ^ v22);
                const v28 = memory_i32[(((((32 + (((1 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v29 = memory_i32[(((((5136 + ((255 & v17) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v30 = memory_i32[(((((6160 + ((255 & (v16 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v31 = memory_i32[(((((7184 + ((255 & (v19 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v32 = memory_i32[(((((8208 + ((255 & (v18 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v33 = (((v32 ^ v31) ^ (v30 ^ v29)) ^ v28);
                const v34 = memory_i32[(((((32 + (((2 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v35 = memory_i32[(((((5136 + ((255 & v18) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v36 = memory_i32[(((((6160 + ((255 & (v17 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v37 = memory_i32[(((((7184 + ((255 & (v16 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v38 = memory_i32[(((((8208 + ((255 & (v19 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v39 = (((v38 ^ v37) ^ (v36 ^ v35)) ^ v34);
                const v40 = memory_i32[(((((32 + (((3 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v41 = memory_i32[(((((5136 + ((255 & v19) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v42 = memory_i32[(((((6160 + ((255 & (v18 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v43 = memory_i32[(((((7184 + ((255 & (v17 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v44 = memory_i32[(((((8208 + ((255 & (v16 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v45 = (((v44 ^ v43) ^ (v42 ^ v41)) ^ v40);
                if (((((v20) >>> 0) < ((v9) >>> 0)) | 0)) {
                    s5 = v20;
                    s6 = v27;
                    s7 = v33;
                    s8 = v39;
                    s9 = v45;
                    continue L1;
                }
                s5 = v20;
                s6 = v27;
                s7 = v33;
                s8 = v39;
                s9 = v45;
                break L1;
            }
            const v15 = s5;
            const v16 = s6;
            const v17 = s7;
            const v18 = s8;
            const v19 = s9;
            s0 = v15;
            s1 = v16;
            s2 = v17;
            s3 = v18;
            s4 = v19;
        }
        const v11 = s1;
        const v12 = s2;
        const v13 = s3;
        const v14 = s4;
        const v46 = (v4 << 2);
        const v47 = memory_i32[(((((32 + (v46 << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v48 = memory[((((4880 + (255 & (v14 >>> 8))) | 0)) >>> 0) + 0];
        const v49 = memory[((((4880 + (255 & (v13 >>> 16))) | 0)) >>> 0) + 0];
        const v50 = memory[((((4880 + (255 & (v12 >>> 24))) | 0)) >>> 0) + 0];
        const v51 = memory[((((4880 + (255 & v11)) | 0)) >>> 0) + 0];
        const v52 = memory_i32[(((((32 + (((1 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v53 = memory[((((4880 + (255 & (v11 >>> 8))) | 0)) >>> 0) + 0];
        const v54 = memory[((((4880 + (255 & (v14 >>> 16))) | 0)) >>> 0) + 0];
        const v55 = memory[((((4880 + (255 & (v13 >>> 24))) | 0)) >>> 0) + 0];
        const v56 = memory[((((4880 + (255 & v12)) | 0)) >>> 0) + 0];
        const v57 = memory_i32[(((((32 + (((2 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v58 = memory[((((4880 + (255 & (v12 >>> 8))) | 0)) >>> 0) + 0];
        const v59 = memory[((((4880 + (255 & (v11 >>> 16))) | 0)) >>> 0) + 0];
        const v60 = memory[((((4880 + (255 & (v14 >>> 24))) | 0)) >>> 0) + 0];
        const v61 = memory[((((4880 + (255 & v13)) | 0)) >>> 0) + 0];
        const v62 = memory_i32[(((((32 + (((3 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v63 = memory[((((4880 + (255 & (v13 >>> 8))) | 0)) >>> 0) + 0];
        const v64 = memory[((((4880 + (255 & (v12 >>> 16))) | 0)) >>> 0) + 0];
        const v65 = memory[((((4880 + (255 & (v11 >>> 24))) | 0)) >>> 0) + 0];
        const v66 = memory[((((4880 + (255 & v14)) | 0)) >>> 0) + 0];
        memory_i32[68] = (((((255 & v50) << 24) | ((255 & v49) << 16)) | (((255 & v48) << 8) | (255 & v51))) ^ v47);
        memory_i32[69] = (((((255 & v55) << 24) | ((255 & v54) << 16)) | (((255 & v53) << 8) | (255 & v56))) ^ v52);
        memory_i32[70] = (((((255 & v60) << 24) | ((255 & v59) << 16)) | (((255 & v58) << 8) | (255 & v61))) ^ v57);
        memory_i32[71] = (((((255 & v65) << 24) | ((255 & v64) << 16)) | (((255 & v63) << 8) | (255 & v66))) ^ v62);
        const v67 = memory_i32[68];
        const v68 = memory_i32[69];
        const v69 = memory_i32[70];
        const v70 = memory_i32[71];
        return [v67, v68, v69, v70];
    }
    function aesBlockEnc(v0, v1, v2, v3) {
        const v4 = memory_i32[128];
        const v5 = memory_i32[8];
        const v6 = memory_i32[9];
        const v7 = memory_i32[10];
        const v8 = memory_i32[11];
        const v9 = ((v4 - 1) | 0);
        let s0 = 0, s1 = (v5 ^ v0), s2 = (v6 ^ v1), s3 = (v7 ^ v2), s4 = (v8 ^ v3);
        L0: {
            const v10 = s0;
            const v11 = s1;
            const v12 = s2;
            const v13 = s3;
            const v14 = s4;
            let s5 = v10, s6 = v11, s7 = v12, s8 = v13, s9 = v14;
            L1: for (;;) {
                const v15 = s5;
                const v16 = s6;
                const v17 = s7;
                const v18 = s8;
                const v19 = s9;
                const v20 = ((1 + v15) | 0);
                const v21 = (((1 + v15) | 0) << 2);
                const v22 = memory_i32[(((((32 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v23 = memory_i32[(((((784 + ((255 & v16) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v24 = memory_i32[(((((1808 + ((255 & (v17 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v25 = memory_i32[(((((2832 + ((255 & (v18 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v26 = memory_i32[(((((3856 + ((255 & (v19 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v27 = (((v26 ^ v25) ^ (v24 ^ v23)) ^ v22);
                const v28 = memory_i32[(((((32 + (((1 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v29 = memory_i32[(((((784 + ((255 & v17) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v30 = memory_i32[(((((1808 + ((255 & (v18 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v31 = memory_i32[(((((2832 + ((255 & (v19 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v32 = memory_i32[(((((3856 + ((255 & (v16 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v33 = (((v32 ^ v31) ^ (v30 ^ v29)) ^ v28);
                const v34 = memory_i32[(((((32 + (((2 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v35 = memory_i32[(((((784 + ((255 & v18) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v36 = memory_i32[(((((1808 + ((255 & (v19 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v37 = memory_i32[(((((2832 + ((255 & (v16 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v38 = memory_i32[(((((3856 + ((255 & (v17 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v39 = (((v38 ^ v37) ^ (v36 ^ v35)) ^ v34);
                const v40 = memory_i32[(((((32 + (((3 + v21) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v41 = memory_i32[(((((784 + ((255 & v19) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v42 = memory_i32[(((((1808 + ((255 & (v16 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v43 = memory_i32[(((((2832 + ((255 & (v17 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v44 = memory_i32[(((((3856 + ((255 & (v18 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v45 = (((v44 ^ v43) ^ (v42 ^ v41)) ^ v40);
                if (((((v20) >>> 0) < ((v9) >>> 0)) | 0)) {
                    s5 = v20;
                    s6 = v27;
                    s7 = v33;
                    s8 = v39;
                    s9 = v45;
                    continue L1;
                }
                s5 = v20;
                s6 = v27;
                s7 = v33;
                s8 = v39;
                s9 = v45;
                break L1;
            }
            const v15 = s5;
            const v16 = s6;
            const v17 = s7;
            const v18 = s8;
            const v19 = s9;
            s0 = v15;
            s1 = v16;
            s2 = v17;
            s3 = v18;
            s4 = v19;
        }
        const v11 = s1;
        const v12 = s2;
        const v13 = s3;
        const v14 = s4;
        const v46 = (v4 << 2);
        const v47 = memory_i32[(((((32 + (v46 << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v48 = memory[((((528 + (255 & (v12 >>> 8))) | 0)) >>> 0) + 0];
        const v49 = memory[((((528 + (255 & (v13 >>> 16))) | 0)) >>> 0) + 0];
        const v50 = memory[((((528 + (255 & (v14 >>> 24))) | 0)) >>> 0) + 0];
        const v51 = memory[((((528 + (255 & v11)) | 0)) >>> 0) + 0];
        const v52 = memory_i32[(((((32 + (((1 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v53 = memory[((((528 + (255 & (v13 >>> 8))) | 0)) >>> 0) + 0];
        const v54 = memory[((((528 + (255 & (v14 >>> 16))) | 0)) >>> 0) + 0];
        const v55 = memory[((((528 + (255 & (v11 >>> 24))) | 0)) >>> 0) + 0];
        const v56 = memory[((((528 + (255 & v12)) | 0)) >>> 0) + 0];
        const v57 = memory_i32[(((((32 + (((2 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v58 = memory[((((528 + (255 & (v14 >>> 8))) | 0)) >>> 0) + 0];
        const v59 = memory[((((528 + (255 & (v11 >>> 16))) | 0)) >>> 0) + 0];
        const v60 = memory[((((528 + (255 & (v12 >>> 24))) | 0)) >>> 0) + 0];
        const v61 = memory[((((528 + (255 & v13)) | 0)) >>> 0) + 0];
        const v62 = memory_i32[(((((32 + (((3 + v46) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v63 = memory[((((528 + (255 & (v11 >>> 8))) | 0)) >>> 0) + 0];
        const v64 = memory[((((528 + (255 & (v12 >>> 16))) | 0)) >>> 0) + 0];
        const v65 = memory[((((528 + (255 & (v13 >>> 24))) | 0)) >>> 0) + 0];
        const v66 = memory[((((528 + (255 & v14)) | 0)) >>> 0) + 0];
        memory_i32[68] = (((((255 & v50) << 24) | ((255 & v49) << 16)) | (((255 & v48) << 8) | (255 & v51))) ^ v47);
        memory_i32[69] = (((((255 & v55) << 24) | ((255 & v54) << 16)) | (((255 & v53) << 8) | (255 & v56))) ^ v52);
        memory_i32[70] = (((((255 & v60) << 24) | ((255 & v59) << 16)) | (((255 & v58) << 8) | (255 & v61))) ^ v57);
        memory_i32[71] = (((((255 & v65) << 24) | ((255 & v64) << 16)) | (((255 & v63) << 8) | (255 & v66))) ^ v62);
        const v67 = memory_i32[68];
        const v68 = memory_i32[69];
        const v69 = memory_i32[70];
        const v70 = memory_i32[71];
        return [v67, v68, v69, v70];
    }
    function decryptBlocks(v0, v1, v2, v3) {
        const v4 = ((((v3) | 0) === ((-1) | 0)) | 0);
        const v5 = ((v0 - 1) | 0);
        const v6 = ((v4) ? (Math.imul(v5, 6)) : (v5));
        const v7 = ((v0 - 1) | 0);
        const v8 = memory_i32[2316];
        const v9 = memory_i32[2317];
        let s0 = 0, s1 = v8, s2 = v9, s3 = ((v4) ? (Math.imul(6, v5)) : (v3)), s4 = 0;
        L0: {
            const v10 = s0;
            const v11 = s1;
            const v12 = s2;
            const v13 = s3;
            const v14 = s4;
            let s5 = v10, s6 = v11, s7 = v12, s8 = v13, s9 = v14;
            L1: for (;;) {
                const v15 = s5;
                const v16 = s6;
                const v17 = s7;
                const v18 = s8;
                const v19 = s9;
                const v20 = ((1 + v15) | 0);
                const v21 = ((9264 + (((v7 - v19) | 0) << 3)) | 0);
                const v22 = memory_i32[(((v21) >>> 0) + 0) >>> 2];
                const v23 = memory_i32[(((((4 + v21) | 0)) >>> 0) + 0) >>> 2];
                const r0 = aesBlockDec(v16, ((((v18 >>> 24) | ((16711680 & v18) >>> 8)) | (((65280 & v18) << 8) | ((255 & v18) << 24))) ^ v17), v22, v23);
                const v27 = r0[0];
                const v26 = r0[1];
                const v25 = r0[2];
                const v24 = r0[3];
                memory_i32[(((v21) >>> 0) + 0) >>> 2] = v25;
                memory_i32[(((((4 + v21) | 0)) >>> 0) + 0) >>> 2] = v24;
                const v28 = ((v18 - 1) | 0);
                const v29 = ((1 + v19) | 0);
                const v30 = ((((((v29) | 0) === ((v7) | 0)) | 0)) ? (0) : (v29));
                if (((((v20) >>> 0) < ((v6) >>> 0)) | 0)) {
                    s5 = v20;
                    s6 = v27;
                    s7 = v26;
                    s8 = v28;
                    s9 = v30;
                    continue L1;
                }
                s5 = v20;
                s6 = v27;
                s7 = v26;
                s8 = v28;
                s9 = v30;
                break L1;
            }
            const v15 = s5;
            const v16 = s6;
            const v17 = s7;
            const v18 = s8;
            const v19 = s9;
            s0 = v15;
            s1 = v16;
            s2 = v17;
            s3 = v18;
            s4 = v19;
        }
        const v11 = s1;
        const v12 = s2;
        memory_i32[2316] = v11;
        memory_i32[2317] = v12;
        return;
    }
    function decryptInit(v0) {
        initTables();
        const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
        const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
        const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
        const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
        memory_i32[128] = v4;
        memory_i32[8] = 0;
        memory_i32[9] = 0;
        memory_i32[10] = 0;
        memory_i32[11] = 0;
        memory_i32[12] = 0;
        memory_i32[13] = 0;
        memory_i32[14] = 0;
        memory_i32[15] = 0;
        memory_i32[16] = 0;
        memory_i32[17] = 0;
        memory_i32[18] = 0;
        memory_i32[19] = 0;
        memory_i32[20] = 0;
        memory_i32[21] = 0;
        memory_i32[22] = 0;
        memory_i32[23] = 0;
        memory_i32[24] = 0;
        memory_i32[25] = 0;
        memory_i32[26] = 0;
        memory_i32[27] = 0;
        memory_i32[28] = 0;
        memory_i32[29] = 0;
        memory_i32[30] = 0;
        memory_i32[31] = 0;
        memory_i32[32] = 0;
        memory_i32[33] = 0;
        memory_i32[34] = 0;
        memory_i32[35] = 0;
        memory_i32[36] = 0;
        memory_i32[37] = 0;
        memory_i32[38] = 0;
        memory_i32[39] = 0;
        memory_i32[40] = 0;
        memory_i32[41] = 0;
        memory_i32[42] = 0;
        memory_i32[43] = 0;
        memory_i32[44] = 0;
        memory_i32[45] = 0;
        memory_i32[46] = 0;
        memory_i32[47] = 0;
        memory_i32[48] = 0;
        memory_i32[49] = 0;
        memory_i32[50] = 0;
        memory_i32[51] = 0;
        memory_i32[52] = 0;
        memory_i32[53] = 0;
        memory_i32[54] = 0;
        memory_i32[55] = 0;
        memory_i32[56] = 0;
        memory_i32[57] = 0;
        memory_i32[58] = 0;
        memory_i32[59] = 0;
        memory_i32[60] = 0;
        memory_i32[61] = 0;
        memory_i32[62] = 0;
        memory_i32[63] = 0;
        memory_i32[64] = 0;
        memory_i32[65] = 0;
        memory_i32[66] = 0;
        memory_i32[67] = 0;
        let s0 = 0;
        L0: {
            const v5 = s0;
            if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v5;
                break L0;
            }
            let s1 = v5;
            L1: {
                const v6 = s1;
                let s2 = v6;
                L2: for (;;) {
                    const v7 = s2;
                    let s3 = v7;
                    L3: {
                        const v8 = s3;
                        const v9 = (v8 << 2);
                        const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
                        const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
                        const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
                        const v13 = memory[((v9) >>> 0) + 0];
                        memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
                        s3 = v8;
                    }
                    const v8 = s3;
                    const v14 = ((1 + v8) | 0);
                    if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
                        s2 = v14;
                        continue L2;
                    }
                    s2 = v14;
                    break L2;
                }
                const v7 = s2;
                s1 = v7;
            }
            const v6 = s1;
            s0 = v6;
        }
        const v15 = (((1 + v4) | 0) << 2);
        const v16 = ((v15 - v3) | 0);
        let s4 = 0;
        L4: {
            const v17 = s4;
            if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s4 = v17;
                break L4;
            }
            let s5 = v17;
            L5: {
                const v18 = s5;
                let s6 = v18;
                L6: for (;;) {
                    const v19 = s6;
                    let s7 = v19;
                    L7: {
                        const v20 = s7;
                        const v21 = ((v3 + v20) | 0);
                        const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v23 = ((((((v21) >>> 0) % (((v3) >>> 0)))) >>> 0));
                        const v24 = ((v22 >>> 8) | (v22 << 24));
                        const v25 = memory[((((528 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
                        const v26 = memory[((((528 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
                        const v27 = memory[((((528 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
                        const v28 = memory[((((528 + (255 & v24)) | 0)) >>> 0) + 0];
                        const v29 = memory[((((9232 + ((((((((v21) >>> 0) / (((v3) >>> 0)))) >>> 0)) - 1) | 0)) | 0)) >>> 0) + 0];
                        const v30 = memory[((((528 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
                        const v31 = memory[((((528 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
                        const v32 = memory[((((528 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
                        const v33 = memory[((((528 + (255 & v22)) | 0)) >>> 0) + 0];
                        const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
                        s7 = v20;
                    }
                    const v20 = s7;
                    const v35 = ((1 + v20) | 0);
                    if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
                        s6 = v35;
                        continue L6;
                    }
                    s6 = v35;
                    break L6;
                }
                const v19 = s6;
                s5 = v19;
            }
            const v18 = s5;
            s4 = v18;
        }
        let s8 = 0;
        L8: {
            const v36 = s8;
            if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s8 = v36;
                break L8;
            }
            let s9 = v36;
            L9: {
                const v37 = s9;
                let s10 = v37;
                L10: for (;;) {
                    const v38 = s10;
                    let s11 = v38;
                    L11: {
                        const v39 = s11;
                        const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
                        s11 = v39;
                    }
                    const v39 = s11;
                    const v41 = ((1 + v39) | 0);
                    if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
                        s10 = v41;
                        continue L10;
                    }
                    s10 = v41;
                    break L10;
                }
                const v38 = s10;
                s9 = v38;
            }
            const v37 = s9;
            s8 = v37;
        }
        let s12 = 0;
        L12: {
            const v42 = s12;
            if (((((((((v42) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s12 = v42;
                break L12;
            }
            let s13 = v42;
            L13: {
                const v43 = s13;
                let s14 = v43;
                L14: for (;;) {
                    const v44 = s14;
                    let s15 = v44;
                    L15: {
                        const v45 = s15;
                        const v46 = memory_i32[(((((32 + (v45 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((272 + (v45 << 2)) | 0)) >>> 0) + 0) >>> 2] = v46;
                        s15 = v45;
                    }
                    const v45 = s15;
                    const v47 = ((1 + v45) | 0);
                    if (((((v47) >>> 0) < ((v15) >>> 0)) | 0)) {
                        s14 = v47;
                        continue L14;
                    }
                    s14 = v47;
                    break L14;
                }
                const v44 = s14;
                s13 = v44;
            }
            const v43 = s13;
            s12 = v43;
        }
        const v48 = memory_i32[128];
        const v49 = ((1 + v48) | 0);
        let s16 = 0;
        L16: {
            const v50 = s16;
            if (((((((((v50) >>> 0) < ((v49) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s16 = v50;
                break L16;
            }
            let s17 = v50;
            L17: {
                const v51 = s17;
                let s18 = v51;
                L18: for (;;) {
                    const v52 = s18;
                    let s19 = v52;
                    L19: {
                        const v53 = s19;
                        const v54 = (((((v49 - 1) | 0) - v53) | 0) << 2);
                        const v55 = memory_i32[(((((272 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v56 = (v53 << 2);
                        memory_i32[(((((32 + (v56 << 2)) | 0)) >>> 0) + 0) >>> 2] = v55;
                        const v57 = memory_i32[(((((272 + (((1 + v54) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (((1 + v56) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2] = v57;
                        const v58 = memory_i32[(((((272 + (((2 + v54) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (((2 + v56) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2] = v58;
                        const v59 = memory_i32[(((((272 + (((3 + v54) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (((3 + v56) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2] = v59;
                        s19 = v53;
                    }
                    const v53 = s19;
                    const v60 = ((1 + v53) | 0);
                    if (((((v60) >>> 0) < ((v49) >>> 0)) | 0)) {
                        s18 = v60;
                        continue L18;
                    }
                    s18 = v60;
                    break L18;
                }
                const v52 = s18;
                s17 = v52;
            }
            const v51 = s17;
            s16 = v51;
        }
        const v61 = ((v15 - 8) | 0);
        let s20 = 0;
        L20: {
            const v62 = s20;
            if (((((((((v62) >>> 0) < ((v61) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s20 = v62;
                break L20;
            }
            let s21 = v62;
            L21: {
                const v63 = s21;
                let s22 = v63;
                L22: for (;;) {
                    const v64 = s22;
                    let s23 = v64;
                    L23: {
                        const v65 = s23;
                        const v66 = ((4 + v65) | 0);
                        const v67 = memory_i32[(((((32 + (v66 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v68 = memory[((((528 + (255 & (v67 >>> 8))) | 0)) >>> 0) + 0];
                        const v69 = memory[((((528 + (255 & (v67 >>> 16))) | 0)) >>> 0) + 0];
                        const v70 = memory[((((528 + (255 & (v67 >>> 24))) | 0)) >>> 0) + 0];
                        const v71 = memory[((((528 + (255 & v67)) | 0)) >>> 0) + 0];
                        const v72 = ((((255 & v70) << 24) | ((255 & v69) << 16)) | (((255 & v68) << 8) | (255 & v71)));
                        const v73 = memory_i32[(((((5136 + ((255 & (v72 >>> 0)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v74 = memory_i32[(((((6160 + ((255 & (v72 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v75 = memory_i32[(((((7184 + ((255 & (v72 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v76 = memory_i32[(((((8208 + ((255 & (v72 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (v66 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v76 ^ v75) ^ (v74 ^ v73));
                        s23 = v65;
                    }
                    const v65 = s23;
                    const v77 = ((1 + v65) | 0);
                    if (((((v77) >>> 0) < ((v61) >>> 0)) | 0)) {
                        s22 = v77;
                        continue L22;
                    }
                    s22 = v77;
                    break L22;
                }
                const v64 = s22;
                s21 = v64;
            }
            const v63 = s21;
            s20 = v63;
        }
        return;
    }
    function encryptBlocks(v0, v1, v2, v3) {
        const v4 = ((((v3) | 0) === ((-1) | 0)) | 0);
        const v5 = ((v0 - 1) | 0);
        const v6 = ((v4) ? (Math.imul(v5, 6)) : (v5));
        const v7 = ((v0 - 1) | 0);
        const v8 = memory_i32[2316];
        const v9 = memory_i32[2317];
        let s0 = 0, s1 = v8, s2 = v9, s3 = ((v4) ? (1) : (v3)), s4 = 0;
        L0: {
            const v10 = s0;
            const v11 = s1;
            const v12 = s2;
            const v13 = s3;
            const v14 = s4;
            let s5 = v10, s6 = v11, s7 = v12, s8 = v13, s9 = v14;
            L1: for (;;) {
                const v15 = s5;
                const v16 = s6;
                const v17 = s7;
                const v18 = s8;
                const v19 = s9;
                const v20 = ((1 + v15) | 0);
                const v21 = ((9264 + (((1 + v19) | 0) << 3)) | 0);
                const v22 = memory_i32[(((v21) >>> 0) + 0) >>> 2];
                const v23 = memory_i32[(((((4 + v21) | 0)) >>> 0) + 0) >>> 2];
                const r0 = aesBlockEnc(v16, v17, v22, v23);
                const v27 = r0[0];
                const v26 = r0[1];
                const v25 = r0[2];
                const v24 = r0[3];
                memory_i32[(((v21) >>> 0) + 0) >>> 2] = v25;
                memory_i32[(((((4 + v21) | 0)) >>> 0) + 0) >>> 2] = v24;
                const v28 = ((((v18 >>> 24) | ((16711680 & v18) >>> 8)) | (((65280 & v18) << 8) | ((255 & v18) << 24))) ^ v26);
                const v29 = ((1 + v18) | 0);
                const v30 = ((1 + v19) | 0);
                const v31 = ((((((v30) | 0) === ((v7) | 0)) | 0)) ? (0) : (v30));
                if (((((v20) >>> 0) < ((v6) >>> 0)) | 0)) {
                    s5 = v20;
                    s6 = v27;
                    s7 = v28;
                    s8 = v29;
                    s9 = v31;
                    continue L1;
                }
                s5 = v20;
                s6 = v27;
                s7 = v28;
                s8 = v29;
                s9 = v31;
                break L1;
            }
            const v15 = s5;
            const v16 = s6;
            const v17 = s7;
            const v18 = s8;
            const v19 = s9;
            s0 = v15;
            s1 = v16;
            s2 = v17;
            s3 = v18;
            s4 = v19;
        }
        const v11 = s1;
        const v12 = s2;
        memory_i32[2316] = v11;
        memory_i32[2317] = v12;
        return;
    }
    function encryptInit(v0) {
        initTables();
        const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
        const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
        const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
        const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
        memory_i32[128] = v4;
        memory_i32[8] = 0;
        memory_i32[9] = 0;
        memory_i32[10] = 0;
        memory_i32[11] = 0;
        memory_i32[12] = 0;
        memory_i32[13] = 0;
        memory_i32[14] = 0;
        memory_i32[15] = 0;
        memory_i32[16] = 0;
        memory_i32[17] = 0;
        memory_i32[18] = 0;
        memory_i32[19] = 0;
        memory_i32[20] = 0;
        memory_i32[21] = 0;
        memory_i32[22] = 0;
        memory_i32[23] = 0;
        memory_i32[24] = 0;
        memory_i32[25] = 0;
        memory_i32[26] = 0;
        memory_i32[27] = 0;
        memory_i32[28] = 0;
        memory_i32[29] = 0;
        memory_i32[30] = 0;
        memory_i32[31] = 0;
        memory_i32[32] = 0;
        memory_i32[33] = 0;
        memory_i32[34] = 0;
        memory_i32[35] = 0;
        memory_i32[36] = 0;
        memory_i32[37] = 0;
        memory_i32[38] = 0;
        memory_i32[39] = 0;
        memory_i32[40] = 0;
        memory_i32[41] = 0;
        memory_i32[42] = 0;
        memory_i32[43] = 0;
        memory_i32[44] = 0;
        memory_i32[45] = 0;
        memory_i32[46] = 0;
        memory_i32[47] = 0;
        memory_i32[48] = 0;
        memory_i32[49] = 0;
        memory_i32[50] = 0;
        memory_i32[51] = 0;
        memory_i32[52] = 0;
        memory_i32[53] = 0;
        memory_i32[54] = 0;
        memory_i32[55] = 0;
        memory_i32[56] = 0;
        memory_i32[57] = 0;
        memory_i32[58] = 0;
        memory_i32[59] = 0;
        memory_i32[60] = 0;
        memory_i32[61] = 0;
        memory_i32[62] = 0;
        memory_i32[63] = 0;
        memory_i32[64] = 0;
        memory_i32[65] = 0;
        memory_i32[66] = 0;
        memory_i32[67] = 0;
        let s0 = 0;
        L0: {
            const v5 = s0;
            if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v5;
                break L0;
            }
            let s1 = v5;
            L1: {
                const v6 = s1;
                let s2 = v6;
                L2: for (;;) {
                    const v7 = s2;
                    let s3 = v7;
                    L3: {
                        const v8 = s3;
                        const v9 = (v8 << 2);
                        const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
                        const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
                        const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
                        const v13 = memory[((v9) >>> 0) + 0];
                        memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
                        s3 = v8;
                    }
                    const v8 = s3;
                    const v14 = ((1 + v8) | 0);
                    if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
                        s2 = v14;
                        continue L2;
                    }
                    s2 = v14;
                    break L2;
                }
                const v7 = s2;
                s1 = v7;
            }
            const v6 = s1;
            s0 = v6;
        }
        const v15 = (((1 + v4) | 0) << 2);
        const v16 = ((v15 - v3) | 0);
        let s4 = 0;
        L4: {
            const v17 = s4;
            if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s4 = v17;
                break L4;
            }
            let s5 = v17;
            L5: {
                const v18 = s5;
                let s6 = v18;
                L6: for (;;) {
                    const v19 = s6;
                    let s7 = v19;
                    L7: {
                        const v20 = s7;
                        const v21 = ((v3 + v20) | 0);
                        const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v23 = ((((((v21) >>> 0) % (((v3) >>> 0)))) >>> 0));
                        const v24 = ((v22 >>> 8) | (v22 << 24));
                        const v25 = memory[((((528 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
                        const v26 = memory[((((528 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
                        const v27 = memory[((((528 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
                        const v28 = memory[((((528 + (255 & v24)) | 0)) >>> 0) + 0];
                        const v29 = memory[((((9232 + ((((((((v21) >>> 0) / (((v3) >>> 0)))) >>> 0)) - 1) | 0)) | 0)) >>> 0) + 0];
                        const v30 = memory[((((528 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
                        const v31 = memory[((((528 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
                        const v32 = memory[((((528 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
                        const v33 = memory[((((528 + (255 & v22)) | 0)) >>> 0) + 0];
                        const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
                        s7 = v20;
                    }
                    const v20 = s7;
                    const v35 = ((1 + v20) | 0);
                    if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
                        s6 = v35;
                        continue L6;
                    }
                    s6 = v35;
                    break L6;
                }
                const v19 = s6;
                s5 = v19;
            }
            const v18 = s5;
            s4 = v18;
        }
        let s8 = 0;
        L8: {
            const v36 = s8;
            if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s8 = v36;
                break L8;
            }
            let s9 = v36;
            L9: {
                const v37 = s9;
                let s10 = v37;
                L10: for (;;) {
                    const v38 = s10;
                    let s11 = v38;
                    L11: {
                        const v39 = s11;
                        const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
                        s11 = v39;
                    }
                    const v39 = s11;
                    const v41 = ((1 + v39) | 0);
                    if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
                        s10 = v41;
                        continue L10;
                    }
                    s10 = v41;
                    break L10;
                }
                const v38 = s10;
                s9 = v38;
            }
            const v37 = s9;
            s8 = v37;
        }
        return;
    }
    function initTables() {
        const v0 = memory_i32[2312];
        L0: {
            if (((((((((v0) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            let s0 = 0, s1 = 1;
            L1: {
                const v1 = s0;
                const v2 = s1;
                let s2 = v1, s3 = v2;
                L2: for (;;) {
                    const v3 = s2;
                    const v4 = s3;
                    const v5 = ((1 + v3) | 0);
                    const v6 = ((255 & (Math.imul(27, (1 & (v4 >>> 7))) ^ (v4 << 1))) ^ v4);
                    memory[((((784 + v3) | 0)) >>> 0) + 0] = (255 & v4);
                    if (((((v5) >>> 0) < ((256) >>> 0)) | 0)) {
                        s2 = v5;
                        s3 = v6;
                        continue L2;
                    }
                    s2 = v5;
                    s3 = v6;
                    break L2;
                }
                const v3 = s2;
                const v4 = s3;
                s0 = v3;
                s1 = v4;
            }
            memory[528] = (255 & 99);
            let s4 = 0;
            L3: {
                const v7 = s4;
                if (((((((((v7) >>> 0) < ((255) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s4 = v7;
                    break L3;
                }
                let s5 = v7;
                L4: {
                    const v8 = s5;
                    let s6 = v8;
                    L5: for (;;) {
                        const v9 = s6;
                        let s7 = v9;
                        L6: {
                            const v10 = s7;
                            const v11 = memory[((((784 + ((255 - v10) | 0)) | 0)) >>> 0) + 0];
                            const v12 = (255 & v11);
                            const v13 = ((v12 << 8) | v12);
                            const v14 = memory[((((784 + v10) | 0)) >>> 0) + 0];
                            memory[((((528 + (255 & v14)) | 0)) >>> 0) + 0] = (255 & (255 & (99 ^ ((v13 >>> 7) ^ ((v13 >>> 6) ^ ((v13 >>> 5) ^ ((v13 >>> 4) ^ v13)))))));
                            s7 = v10;
                        }
                        const v10 = s7;
                        const v15 = ((1 + v10) | 0);
                        if (((((v15) >>> 0) < ((255) >>> 0)) | 0)) {
                            s6 = v15;
                            continue L5;
                        }
                        s6 = v15;
                        break L5;
                    }
                    const v9 = s6;
                    s5 = v9;
                }
                const v8 = s5;
                s4 = v8;
            }
            let s8 = 0;
            L7: {
                const v16 = s8;
                if (((((((((v16) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s8 = v16;
                    break L7;
                }
                let s9 = v16;
                L8: {
                    const v17 = s9;
                    let s10 = v17;
                    L9: for (;;) {
                        const v18 = s10;
                        let s11 = v18;
                        L10: {
                            const v19 = s11;
                            memory[((((4880 + v19) | 0)) >>> 0) + 0] = (255 & 0);
                            s11 = v19;
                        }
                        const v19 = s11;
                        const v20 = ((1 + v19) | 0);
                        if (((((v20) >>> 0) < ((256) >>> 0)) | 0)) {
                            s10 = v20;
                            continue L9;
                        }
                        s10 = v20;
                        break L9;
                    }
                    const v18 = s10;
                    s9 = v18;
                }
                const v17 = s9;
                s8 = v17;
            }
            let s12 = 0;
            L11: {
                const v21 = s12;
                if (((((((((v21) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s12 = v21;
                    break L11;
                }
                let s13 = v21;
                L12: {
                    const v22 = s13;
                    let s14 = v22;
                    L13: for (;;) {
                        const v23 = s14;
                        let s15 = v23;
                        L14: {
                            const v24 = s15;
                            const v25 = memory[((((528 + v24) | 0)) >>> 0) + 0];
                            memory[((((4880 + (255 & v25)) | 0)) >>> 0) + 0] = (255 & v24);
                            s15 = v24;
                        }
                        const v24 = s15;
                        const v26 = ((1 + v24) | 0);
                        if (((((v26) >>> 0) < ((256) >>> 0)) | 0)) {
                            s14 = v26;
                            continue L13;
                        }
                        s14 = v26;
                        break L13;
                    }
                    const v23 = s14;
                    s13 = v23;
                }
                const v22 = s13;
                s12 = v22;
            }
            let s16 = 0, s17 = 1;
            L15: {
                const v27 = s16;
                const v28 = s17;
                let s18 = v27, s19 = v28;
                L16: for (;;) {
                    const v29 = s18;
                    const v30 = s19;
                    const v31 = ((1 + v29) | 0);
                    const v32 = (255 & (Math.imul(27, (1 & (v30 >>> 7))) ^ (v30 << 1)));
                    memory[((((9232 + v29) | 0)) >>> 0) + 0] = (255 & v30);
                    if (((((v31) >>> 0) < ((16) >>> 0)) | 0)) {
                        s18 = v31;
                        s19 = v32;
                        continue L16;
                    }
                    s18 = v31;
                    s19 = v32;
                    break L16;
                }
                const v29 = s18;
                const v30 = s19;
                s16 = v29;
                s17 = v30;
            }
            let s20 = 0;
            L17: {
                const v33 = s20;
                if (((((((((v33) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s20 = v33;
                    break L17;
                }
                let s21 = v33;
                L18: {
                    const v34 = s21;
                    let s22 = v34;
                    L19: for (;;) {
                        const v35 = s22;
                        let s23 = v35;
                        L20: {
                            const v36 = s23;
                            const v37 = memory[((((528 + v36) | 0)) >>> 0) + 0];
                            const v38 = (255 & v37);
                            const v39 = memory[((((4880 + v36) | 0)) >>> 0) + 0];
                            const v40 = (255 & v39);
                            const v41 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
                            const v42 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
                            const v43 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
                            const v44 = (255 & (Math.imul(27, (1 & (v43 >>> 7))) ^ (v43 << 1)));
                            const v45 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
                            const v46 = (255 & (Math.imul(27, (1 & (v45 >>> 7))) ^ (v45 << 1)));
                            const v47 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
                            const v48 = (255 & (Math.imul(27, (1 & (v47 >>> 7))) ^ (v47 << 1)));
                            memory_i32[(((((784 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) | (v38 << 8)) | (v38 << 16)) | (((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) ^ v38) << 24));
                            memory_i32[(((((5136 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & (Math.imul(27, (1 & (v48 >>> 7))) ^ (v48 << 1))) ^ (v48 ^ v47)) | (((255 & (Math.imul(27, (1 & (v42 >>> 7))) ^ (v42 << 1))) ^ v40) << 8)) | (((255 & (Math.imul(27, (1 & (v46 >>> 7))) ^ (v46 << 1))) ^ (v46 ^ v40)) << 16)) | (((255 & (Math.imul(27, (1 & (v44 >>> 7))) ^ (v44 << 1))) ^ (v43 ^ v40)) << 24));
                            s23 = v36;
                        }
                        const v36 = s23;
                        const v49 = ((1 + v36) | 0);
                        if (((((v49) >>> 0) < ((256) >>> 0)) | 0)) {
                            s22 = v49;
                            continue L19;
                        }
                        s22 = v49;
                        break L19;
                    }
                    const v35 = s22;
                    s21 = v35;
                }
                const v34 = s21;
                s20 = v34;
            }
            let s24 = 0;
            L21: {
                const v50 = s24;
                if (((((((((v50) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s24 = v50;
                    break L21;
                }
                let s25 = v50;
                L22: {
                    const v51 = s25;
                    let s26 = v51;
                    L23: for (;;) {
                        const v52 = s26;
                        let s27 = v52;
                        L24: {
                            const v53 = s27;
                            const v54 = memory_i32[(((((784 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
                            const v55 = ((v54 << 8) | ((v54 >>> (32 - 8)) >>> 0));
                            const v56 = ((v55 << 8) | ((v55 >>> (32 - 8)) >>> 0));
                            memory_i32[(((((1808 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v55;
                            memory_i32[(((((2832 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v56;
                            memory_i32[(((((3856 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v56 << 8) | ((v56 >>> (32 - 8)) >>> 0));
                            const v57 = memory_i32[(((((5136 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
                            const v58 = ((v57 << 8) | ((v57 >>> (32 - 8)) >>> 0));
                            const v59 = ((v58 << 8) | ((v58 >>> (32 - 8)) >>> 0));
                            memory_i32[(((((6160 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v58;
                            memory_i32[(((((7184 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v59;
                            memory_i32[(((((8208 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v59 << 8) | ((v59 >>> (32 - 8)) >>> 0));
                            s27 = v53;
                        }
                        const v53 = s27;
                        const v60 = ((1 + v53) | 0);
                        if (((((v60) >>> 0) < ((256) >>> 0)) | 0)) {
                            s26 = v60;
                            continue L23;
                        }
                        s26 = v60;
                        break L23;
                    }
                    const v52 = s26;
                    s25 = v52;
                }
                const v51 = s25;
                s24 = v51;
            }
            memory_i32[2312] = 1;
        }
        return;
    }
    function reset(v0) {
        memory.fill(0, 0, 0 + 516);
        memory.fill(0, 9264, 9264 + ((v0) >>> 0));
        return;
    }
    function verifyPadding(v0, v1) {
        const v2 = memory_i32[2316];
        const v3 = memory_i32[2317];
        const v4 = (((((((v3) | 0) !== ((-1499027802) | 0)) | 0) | ((((v2) | 0) !== ((-1499027802) | 0)) | 0))) ? (((1 + v1) | 0)) : (0));
        return v4;
    }
    const instance = { exports: { addPadding: addPadding, aesBlockDec: aesBlockDec, aesBlockEnc: aesBlockEnc, decryptBlocks: decryptBlocks, decryptInit: decryptInit, encryptBlocks: encryptBlocks, encryptInit: encryptInit, initTables: initTables, reset: reset, verifyPadding: verifyPadding, memory: { buffer: __buf } } };
    ;
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 5252144);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 516),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 516, 516))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 272 + i * 240, 240))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 512 + i * 4, 4))),
        constants: new Uint8Array(memoryExport.buffer, 528, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 528, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 528, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 784, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 784 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1808, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1808 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2832, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2832 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3856, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3856 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 4880, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4880, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5136, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5136 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6160, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6160 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7184, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7184 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8208, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8208 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9232, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9232 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9248, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9248 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9264, 5242880),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9264 + i * 5242880, 5242880)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments });
}
let _cache;
export default function aes_kw(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
