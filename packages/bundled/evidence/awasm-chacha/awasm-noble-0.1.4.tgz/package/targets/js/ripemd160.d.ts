export default function ripemd(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=ripemd160.d.ts.map