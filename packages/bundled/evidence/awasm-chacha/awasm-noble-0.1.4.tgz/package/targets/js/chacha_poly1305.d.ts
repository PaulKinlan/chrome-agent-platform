export default function arx(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=chacha_poly1305.d.ts.map