export default function blake3(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=blake3.d.ts.map