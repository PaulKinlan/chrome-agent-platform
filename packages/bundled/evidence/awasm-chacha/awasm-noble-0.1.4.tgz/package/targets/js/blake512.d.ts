export default function blake1(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=blake512.d.ts.map