export default function blake2(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=blake2s.d.ts.map