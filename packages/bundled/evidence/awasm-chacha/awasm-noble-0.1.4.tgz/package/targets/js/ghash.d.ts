export default function ghash(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=ghash.d.ts.map