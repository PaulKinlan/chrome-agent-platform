export default function scrypt(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=scrypt.d.ts.map