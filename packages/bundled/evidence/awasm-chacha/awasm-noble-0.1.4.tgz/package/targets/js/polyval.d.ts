export default function polyval(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=polyval.d.ts.map