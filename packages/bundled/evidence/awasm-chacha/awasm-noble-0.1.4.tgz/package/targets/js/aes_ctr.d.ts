export default function aes_ctr(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_ctr.d.ts.map