export default function aes_kwp(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_kwp.d.ts.map