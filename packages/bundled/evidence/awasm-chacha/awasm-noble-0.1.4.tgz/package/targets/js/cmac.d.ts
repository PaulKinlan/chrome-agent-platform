export default function cmac(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=cmac.d.ts.map