export default function aes_siv(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_siv.d.ts.map