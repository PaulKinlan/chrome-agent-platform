// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    const __buf = new ArrayBuffer(10495648);
    if (!(__buf instanceof ArrayBuffer))
        throw new Error('wrong buffer');
    const memory = new Uint8Array(__buf);
    const memory_i32 = new Int32Array(__buf);
    function aadBlocks(v0, v1, v2) {
        const v3 = memory_i32[256];
        const v4 = (((((v0) | 0) === ((0) | 0)) | 0) & v1);
        const v5 = ((v4) ? (1) : (v0));
        const v6 = ((v4) ? (16) : (v2));
        L0: {
            if (((((v4) | 0) === 0) | 0)) {
                break L0;
            }
            memory[9888] = (255 & 128);
            memory.fill(0, 9889, 9889 + 16);
        }
        const v7 = ((v5 - 1) | 0);
        const v8 = (((((v5) | 0) !== ((0) | 0)) | 0) & v1);
        L1: {
            if ((((((((((v6) | 0) !== ((0) | 0)) | 0) & v1)) | 0) === 0) | 0)) {
                break L1;
            }
            const v9 = (((v5 << 4) - v6) | 0);
            memory[((((9888 + v9) | 0)) >>> 0) + 0] = (255 & 128);
            memory.fill(0, ((((9888 + ((1 + v9) | 0)) | 0)) >>> 0), ((((9888 + ((1 + v9) | 0)) | 0)) >>> 0) + ((((v6 + v9) | 0)) >>> 0));
        }
        let s0 = 0;
        L2: {
            const v10 = s0;
            if (((((((((v10) >>> 0) < ((v5) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v10;
                break L2;
            }
            let s1 = v10;
            L3: {
                const v11 = s1;
                let s2 = v11;
                L4: for (;;) {
                    const v12 = s2;
                    let s3 = v12;
                    L5: {
                        const v13 = s3;
                        const v14 = (((((v13) | 0) === ((v7) | 0)) | 0) & v8);
                        const v15 = (((((v6) | 0) !== ((0) | 0)) | 0) & v14);
                        const v16 = ((9888 + (v13 << 4)) | 0);
                        const v17 = memory_i32[(((v16) >>> 0) + 0) >>> 2];
                        const v18 = ((4 + v16) | 0);
                        const v19 = memory_i32[(((v18) >>> 0) + 0) >>> 2];
                        const v20 = ((4 + v18) | 0);
                        const v21 = memory_i32[(((v20) >>> 0) + 0) >>> 2];
                        const v22 = memory_i32[(((((4 + v20) | 0)) >>> 0) + 0) >>> 2];
                        const v23 = memory_i32[268];
                        const v24 = memory_i32[269];
                        const v25 = memory_i32[270];
                        const v26 = memory_i32[271];
                        const v27 = memory_i32[260];
                        const v28 = memory_i32[261];
                        const v29 = memory_i32[262];
                        const v30 = memory_i32[263];
                        const v31 = memory_i32[264];
                        const v32 = memory_i32[265];
                        const v33 = memory_i32[266];
                        const v34 = memory_i32[267];
                        const v35 = memory_i32[76];
                        const v36 = memory_i32[77];
                        const v37 = memory_i32[78];
                        const v38 = memory_i32[79];
                        const v39 = ((v3 - 1) | 0);
                        let s4 = 0, s5 = (v35 ^ (v23 ^ ((v14) ? ((((v15) ? (v31) : (v27)) ^ v17)) : (v17)))), s6 = (v36 ^ (v24 ^ ((v14) ? ((((v15) ? (v32) : (v28)) ^ v19)) : (v19)))), s7 = (v37 ^ (v25 ^ ((v14) ? ((((v15) ? (v33) : (v29)) ^ v21)) : (v21)))), s8 = (v38 ^ (v26 ^ ((v14) ? ((((v15) ? (v34) : (v30)) ^ v22)) : (v22))));
                        L6: {
                            const v40 = s4;
                            const v41 = s5;
                            const v42 = s6;
                            const v43 = s7;
                            const v44 = s8;
                            let s9 = v40, s10 = v41, s11 = v42, s12 = v43, s13 = v44;
                            L7: for (;;) {
                                const v45 = s9;
                                const v46 = s10;
                                const v47 = s11;
                                const v48 = s12;
                                const v49 = s13;
                                const v50 = ((1 + v45) | 0);
                                const v51 = (((1 + v45) | 0) << 2);
                                const v52 = memory_i32[(((((304 + (v51 << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v53 = memory_i32[(((((1408 + ((255 & v46) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v54 = memory_i32[(((((2432 + ((255 & (v47 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v55 = memory_i32[(((((3456 + ((255 & (v48 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v56 = memory_i32[(((((4480 + ((255 & (v49 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v57 = (((v56 ^ v55) ^ (v54 ^ v53)) ^ v52);
                                const v58 = memory_i32[(((((304 + (((1 + v51) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v59 = memory_i32[(((((1408 + ((255 & v47) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v60 = memory_i32[(((((2432 + ((255 & (v48 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v61 = memory_i32[(((((3456 + ((255 & (v49 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v62 = memory_i32[(((((4480 + ((255 & (v46 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v63 = (((v62 ^ v61) ^ (v60 ^ v59)) ^ v58);
                                const v64 = memory_i32[(((((304 + (((2 + v51) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v65 = memory_i32[(((((1408 + ((255 & v48) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v66 = memory_i32[(((((2432 + ((255 & (v49 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v67 = memory_i32[(((((3456 + ((255 & (v46 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v68 = memory_i32[(((((4480 + ((255 & (v47 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v69 = (((v68 ^ v67) ^ (v66 ^ v65)) ^ v64);
                                const v70 = memory_i32[(((((304 + (((3 + v51) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v71 = memory_i32[(((((1408 + ((255 & v49) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v72 = memory_i32[(((((2432 + ((255 & (v46 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v73 = memory_i32[(((((3456 + ((255 & (v47 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v74 = memory_i32[(((((4480 + ((255 & (v48 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v75 = (((v74 ^ v73) ^ (v72 ^ v71)) ^ v70);
                                if (((((v50) >>> 0) < ((v39) >>> 0)) | 0)) {
                                    s9 = v50;
                                    s10 = v57;
                                    s11 = v63;
                                    s12 = v69;
                                    s13 = v75;
                                    continue L7;
                                }
                                s9 = v50;
                                s10 = v57;
                                s11 = v63;
                                s12 = v69;
                                s13 = v75;
                                break L7;
                            }
                            const v45 = s9;
                            const v46 = s10;
                            const v47 = s11;
                            const v48 = s12;
                            const v49 = s13;
                            s4 = v45;
                            s5 = v46;
                            s6 = v47;
                            s7 = v48;
                            s8 = v49;
                        }
                        const v41 = s5;
                        const v42 = s6;
                        const v43 = s7;
                        const v44 = s8;
                        const v76 = (v3 << 2);
                        const v77 = memory_i32[(((((304 + (v76 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v78 = memory[((((1152 + (255 & (v42 >>> 8))) | 0)) >>> 0) + 0];
                        const v79 = memory[((((1152 + (255 & (v43 >>> 16))) | 0)) >>> 0) + 0];
                        const v80 = memory[((((1152 + (255 & (v44 >>> 24))) | 0)) >>> 0) + 0];
                        const v81 = memory[((((1152 + (255 & v41)) | 0)) >>> 0) + 0];
                        const v82 = memory_i32[(((((304 + (((1 + v76) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v83 = memory[((((1152 + (255 & (v43 >>> 8))) | 0)) >>> 0) + 0];
                        const v84 = memory[((((1152 + (255 & (v44 >>> 16))) | 0)) >>> 0) + 0];
                        const v85 = memory[((((1152 + (255 & (v41 >>> 24))) | 0)) >>> 0) + 0];
                        const v86 = memory[((((1152 + (255 & v42)) | 0)) >>> 0) + 0];
                        const v87 = memory_i32[(((((304 + (((2 + v76) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v88 = memory[((((1152 + (255 & (v44 >>> 8))) | 0)) >>> 0) + 0];
                        const v89 = memory[((((1152 + (255 & (v41 >>> 16))) | 0)) >>> 0) + 0];
                        const v90 = memory[((((1152 + (255 & (v42 >>> 24))) | 0)) >>> 0) + 0];
                        const v91 = memory[((((1152 + (255 & v43)) | 0)) >>> 0) + 0];
                        const v92 = memory_i32[(((((304 + (((3 + v76) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v93 = memory[((((1152 + (255 & (v41 >>> 8))) | 0)) >>> 0) + 0];
                        const v94 = memory[((((1152 + (255 & (v42 >>> 16))) | 0)) >>> 0) + 0];
                        const v95 = memory[((((1152 + (255 & (v43 >>> 24))) | 0)) >>> 0) + 0];
                        const v96 = memory[((((1152 + (255 & v44)) | 0)) >>> 0) + 0];
                        memory_i32[268] = (((((255 & v80) << 24) | ((255 & v79) << 16)) | (((255 & v78) << 8) | (255 & v81))) ^ v77);
                        memory_i32[269] = (((((255 & v85) << 24) | ((255 & v84) << 16)) | (((255 & v83) << 8) | (255 & v86))) ^ v82);
                        memory_i32[270] = (((((255 & v90) << 24) | ((255 & v89) << 16)) | (((255 & v88) << 8) | (255 & v91))) ^ v87);
                        memory_i32[271] = (((((255 & v95) << 24) | ((255 & v94) << 16)) | (((255 & v93) << 8) | (255 & v96))) ^ v92);
                        s3 = v13;
                    }
                    const v13 = s3;
                    const v97 = ((1 + v13) | 0);
                    if (((((v97) >>> 0) < ((v5) >>> 0)) | 0)) {
                        s2 = v97;
                        continue L4;
                    }
                    s2 = v97;
                    break L4;
                }
                const v12 = s2;
                s1 = v12;
            }
            const v11 = s1;
            s0 = v11;
        }
        L8: {
            if (((((v1) | 0) === 0) | 0)) {
                break L8;
            }
            let s14 = 0, s15 = 0;
            L9: {
                const v98 = s14;
                const v99 = s15;
                let s16 = v98, s17 = v99;
                L10: for (;;) {
                    const v100 = s16;
                    const v101 = s17;
                    const v102 = ((1 + v100) | 0);
                    const v103 = ((15 - v100) | 0);
                    const v104 = memory[((((1088 + v103) | 0)) >>> 0) + 0];
                    const v105 = (255 & (255 & v104));
                    const v106 = (v105 >>> 7);
                    memory[((((1088 + v103) | 0)) >>> 0) + 0] = (255 & (255 & (v101 | (v105 << 1))));
                    if (((((v102) >>> 0) < ((16) >>> 0)) | 0)) {
                        s16 = v102;
                        s17 = v106;
                        continue L10;
                    }
                    s16 = v102;
                    s17 = v106;
                    break L10;
                }
                const v100 = s16;
                const v101 = s17;
                s14 = v100;
                s15 = v101;
            }
            const v99 = s15;
            const v107 = memory[1103];
            memory[1103] = (255 & ((135 & ((0 - v99) | 0)) ^ (255 & v107)));
            const v108 = memory[1088];
            const v109 = memory[1072];
            const v110 = memory[1089];
            const v111 = memory[1073];
            const v112 = memory[1090];
            const v113 = memory[1074];
            const v114 = memory[1091];
            const v115 = memory[1075];
            const v116 = memory[1092];
            const v117 = memory[1076];
            const v118 = memory[1093];
            const v119 = memory[1077];
            const v120 = memory[1094];
            const v121 = memory[1078];
            const v122 = memory[1095];
            const v123 = memory[1079];
            const v124 = memory[1096];
            const v125 = memory[1080];
            const v126 = memory[1097];
            const v127 = memory[1081];
            const v128 = memory[1098];
            const v129 = memory[1082];
            const v130 = memory[1099];
            const v131 = memory[1083];
            const v132 = memory[1100];
            const v133 = memory[1084];
            const v134 = memory[1101];
            const v135 = memory[1085];
            const v136 = memory[1102];
            const v137 = memory[1086];
            const v138 = memory[1103];
            const v139 = memory[1087];
            memory[1088] = (255 & ((255 & v109) ^ (255 & v108)));
            memory[1089] = (255 & ((255 & v111) ^ (255 & v110)));
            memory[1090] = (255 & ((255 & v113) ^ (255 & v112)));
            memory[1091] = (255 & ((255 & v115) ^ (255 & v114)));
            memory[1092] = (255 & ((255 & v117) ^ (255 & v116)));
            memory[1093] = (255 & ((255 & v119) ^ (255 & v118)));
            memory[1094] = (255 & ((255 & v121) ^ (255 & v120)));
            memory[1095] = (255 & ((255 & v123) ^ (255 & v122)));
            memory[1096] = (255 & ((255 & v125) ^ (255 & v124)));
            memory[1097] = (255 & ((255 & v127) ^ (255 & v126)));
            memory[1098] = (255 & ((255 & v129) ^ (255 & v128)));
            memory[1099] = (255 & ((255 & v131) ^ (255 & v130)));
            memory[1100] = (255 & ((255 & v133) ^ (255 & v132)));
            memory[1101] = (255 & ((255 & v135) ^ (255 & v134)));
            memory[1102] = (255 & ((255 & v137) ^ (255 & v136)));
            memory[1103] = (255 & ((255 & v139) ^ (255 & v138)));
            memory_i32[268] = 0;
            memory_i32[269] = 0;
            memory_i32[270] = 0;
            memory_i32[271] = 0;
        }
        return;
    }
    function decryptBlocks(v0, v1, v2, v3) {
        L0: {
            if (((((((((v3) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            tagInit();
            L1: {
                if (((((((((v0) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                    break L1;
                }
                processBlocks(0, 1, v0, v0);
            }
            let s0 = v0;
            L2: {
                const v4 = s0;
                const v5 = memory[1135];
                const v6 = (((255 & v4) + (255 & v5)) | 0);
                const v7 = (((v6 >>> 8) + (v4 >>> 8)) | 0);
                memory[1135] = (255 & v6);
                if (((((v7) | 0) === ((0) | 0)) | 0)) {
                    s0 = v7;
                    break L2;
                }
                const v8 = memory[1134];
                const v9 = (((255 & v7) + (255 & v8)) | 0);
                const v10 = (((v9 >>> 8) + (v7 >>> 8)) | 0);
                memory[1134] = (255 & v9);
                if (((((v10) | 0) === ((0) | 0)) | 0)) {
                    s0 = v10;
                    break L2;
                }
                const v11 = memory[1133];
                const v12 = (((255 & v10) + (255 & v11)) | 0);
                const v13 = (((v12 >>> 8) + (v10 >>> 8)) | 0);
                memory[1133] = (255 & v12);
                if (((((v13) | 0) === ((0) | 0)) | 0)) {
                    s0 = v13;
                    break L2;
                }
                const v14 = memory[1132];
                const v15 = (((255 & v13) + (255 & v14)) | 0);
                const v16 = (((v15 >>> 8) + (v13 >>> 8)) | 0);
                memory[1132] = (255 & v15);
                if (((((v16) | 0) === ((0) | 0)) | 0)) {
                    s0 = v16;
                    break L2;
                }
                const v17 = memory[1131];
                const v18 = (((255 & v16) + (255 & v17)) | 0);
                const v19 = (((v18 >>> 8) + (v16 >>> 8)) | 0);
                memory[1131] = (255 & v18);
                if (((((v19) | 0) === ((0) | 0)) | 0)) {
                    s0 = v19;
                    break L2;
                }
                const v20 = memory[1130];
                const v21 = (((255 & v19) + (255 & v20)) | 0);
                const v22 = (((v21 >>> 8) + (v19 >>> 8)) | 0);
                memory[1130] = (255 & v21);
                if (((((v22) | 0) === ((0) | 0)) | 0)) {
                    s0 = v22;
                    break L2;
                }
                const v23 = memory[1129];
                const v24 = (((255 & v22) + (255 & v23)) | 0);
                const v25 = (((v24 >>> 8) + (v22 >>> 8)) | 0);
                memory[1129] = (255 & v24);
                if (((((v25) | 0) === ((0) | 0)) | 0)) {
                    s0 = v25;
                    break L2;
                }
                const v26 = memory[1128];
                const v27 = (((255 & v25) + (255 & v26)) | 0);
                const v28 = (((v27 >>> 8) + (v25 >>> 8)) | 0);
                memory[1128] = (255 & v27);
                if (((((v28) | 0) === ((0) | 0)) | 0)) {
                    s0 = v28;
                    break L2;
                }
                const v29 = memory[1127];
                const v30 = (((255 & v28) + (255 & v29)) | 0);
                const v31 = (((v30 >>> 8) + (v28 >>> 8)) | 0);
                memory[1127] = (255 & v30);
                if (((((v31) | 0) === ((0) | 0)) | 0)) {
                    s0 = v31;
                    break L2;
                }
                const v32 = memory[1126];
                const v33 = (((255 & v31) + (255 & v32)) | 0);
                const v34 = (((v33 >>> 8) + (v31 >>> 8)) | 0);
                memory[1126] = (255 & v33);
                if (((((v34) | 0) === ((0) | 0)) | 0)) {
                    s0 = v34;
                    break L2;
                }
                const v35 = memory[1125];
                const v36 = (((255 & v34) + (255 & v35)) | 0);
                const v37 = (((v36 >>> 8) + (v34 >>> 8)) | 0);
                memory[1125] = (255 & v36);
                if (((((v37) | 0) === ((0) | 0)) | 0)) {
                    s0 = v37;
                    break L2;
                }
                const v38 = memory[1124];
                const v39 = (((255 & v37) + (255 & v38)) | 0);
                const v40 = (((v39 >>> 8) + (v37 >>> 8)) | 0);
                memory[1124] = (255 & v39);
                if (((((v40) | 0) === ((0) | 0)) | 0)) {
                    s0 = v40;
                    break L2;
                }
                const v41 = memory[1123];
                const v42 = (((255 & v40) + (255 & v41)) | 0);
                const v43 = (((v42 >>> 8) + (v40 >>> 8)) | 0);
                memory[1123] = (255 & v42);
                if (((((v43) | 0) === ((0) | 0)) | 0)) {
                    s0 = v43;
                    break L2;
                }
                const v44 = memory[1122];
                const v45 = (((255 & v43) + (255 & v44)) | 0);
                const v46 = (((v45 >>> 8) + (v43 >>> 8)) | 0);
                memory[1122] = (255 & v45);
                if (((((v46) | 0) === ((0) | 0)) | 0)) {
                    s0 = v46;
                    break L2;
                }
                const v47 = memory[1121];
                const v48 = (((255 & v46) + (255 & v47)) | 0);
                const v49 = (((v48 >>> 8) + (v46 >>> 8)) | 0);
                memory[1121] = (255 & v48);
                if (((((v49) | 0) === ((0) | 0)) | 0)) {
                    s0 = v49;
                    break L2;
                }
                const v50 = memory[1120];
                const v51 = (((255 & v49) + (255 & v50)) | 0);
                const v52 = (((v51 >>> 8) + (v49 >>> 8)) | 0);
                memory[1120] = (255 & v51);
                if (((((v52) | 0) === ((0) | 0)) | 0)) {
                    s0 = v52;
                    break L2;
                }
                s0 = v52;
            }
        }
        L3: {
            if (((((((((v3) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L3;
            }
            macBlocks(v0, v1, v2);
        }
        return;
    }
    function decryptInit(v0) {
        encryptInit(v0);
        return;
    }
    function encryptBlocks(v0, v1, v2, v3) {
        L0: {
            if (((((((((v3) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            macBlocks(v0, v1, v2);
        }
        L1: {
            if (((((((((v3) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L1;
            }
            tagInit();
            L2: {
                if (((((((((v0) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                    break L2;
                }
                processBlocks(0, 1, v0, v0);
            }
            let s0 = v0;
            L3: {
                const v4 = s0;
                const v5 = memory[1135];
                const v6 = (((255 & v4) + (255 & v5)) | 0);
                const v7 = (((v6 >>> 8) + (v4 >>> 8)) | 0);
                memory[1135] = (255 & v6);
                if (((((v7) | 0) === ((0) | 0)) | 0)) {
                    s0 = v7;
                    break L3;
                }
                const v8 = memory[1134];
                const v9 = (((255 & v7) + (255 & v8)) | 0);
                const v10 = (((v9 >>> 8) + (v7 >>> 8)) | 0);
                memory[1134] = (255 & v9);
                if (((((v10) | 0) === ((0) | 0)) | 0)) {
                    s0 = v10;
                    break L3;
                }
                const v11 = memory[1133];
                const v12 = (((255 & v10) + (255 & v11)) | 0);
                const v13 = (((v12 >>> 8) + (v10 >>> 8)) | 0);
                memory[1133] = (255 & v12);
                if (((((v13) | 0) === ((0) | 0)) | 0)) {
                    s0 = v13;
                    break L3;
                }
                const v14 = memory[1132];
                const v15 = (((255 & v13) + (255 & v14)) | 0);
                const v16 = (((v15 >>> 8) + (v13 >>> 8)) | 0);
                memory[1132] = (255 & v15);
                if (((((v16) | 0) === ((0) | 0)) | 0)) {
                    s0 = v16;
                    break L3;
                }
                const v17 = memory[1131];
                const v18 = (((255 & v16) + (255 & v17)) | 0);
                const v19 = (((v18 >>> 8) + (v16 >>> 8)) | 0);
                memory[1131] = (255 & v18);
                if (((((v19) | 0) === ((0) | 0)) | 0)) {
                    s0 = v19;
                    break L3;
                }
                const v20 = memory[1130];
                const v21 = (((255 & v19) + (255 & v20)) | 0);
                const v22 = (((v21 >>> 8) + (v19 >>> 8)) | 0);
                memory[1130] = (255 & v21);
                if (((((v22) | 0) === ((0) | 0)) | 0)) {
                    s0 = v22;
                    break L3;
                }
                const v23 = memory[1129];
                const v24 = (((255 & v22) + (255 & v23)) | 0);
                const v25 = (((v24 >>> 8) + (v22 >>> 8)) | 0);
                memory[1129] = (255 & v24);
                if (((((v25) | 0) === ((0) | 0)) | 0)) {
                    s0 = v25;
                    break L3;
                }
                const v26 = memory[1128];
                const v27 = (((255 & v25) + (255 & v26)) | 0);
                const v28 = (((v27 >>> 8) + (v25 >>> 8)) | 0);
                memory[1128] = (255 & v27);
                if (((((v28) | 0) === ((0) | 0)) | 0)) {
                    s0 = v28;
                    break L3;
                }
                const v29 = memory[1127];
                const v30 = (((255 & v28) + (255 & v29)) | 0);
                const v31 = (((v30 >>> 8) + (v28 >>> 8)) | 0);
                memory[1127] = (255 & v30);
                if (((((v31) | 0) === ((0) | 0)) | 0)) {
                    s0 = v31;
                    break L3;
                }
                const v32 = memory[1126];
                const v33 = (((255 & v31) + (255 & v32)) | 0);
                const v34 = (((v33 >>> 8) + (v31 >>> 8)) | 0);
                memory[1126] = (255 & v33);
                if (((((v34) | 0) === ((0) | 0)) | 0)) {
                    s0 = v34;
                    break L3;
                }
                const v35 = memory[1125];
                const v36 = (((255 & v34) + (255 & v35)) | 0);
                const v37 = (((v36 >>> 8) + (v34 >>> 8)) | 0);
                memory[1125] = (255 & v36);
                if (((((v37) | 0) === ((0) | 0)) | 0)) {
                    s0 = v37;
                    break L3;
                }
                const v38 = memory[1124];
                const v39 = (((255 & v37) + (255 & v38)) | 0);
                const v40 = (((v39 >>> 8) + (v37 >>> 8)) | 0);
                memory[1124] = (255 & v39);
                if (((((v40) | 0) === ((0) | 0)) | 0)) {
                    s0 = v40;
                    break L3;
                }
                const v41 = memory[1123];
                const v42 = (((255 & v40) + (255 & v41)) | 0);
                const v43 = (((v42 >>> 8) + (v40 >>> 8)) | 0);
                memory[1123] = (255 & v42);
                if (((((v43) | 0) === ((0) | 0)) | 0)) {
                    s0 = v43;
                    break L3;
                }
                const v44 = memory[1122];
                const v45 = (((255 & v43) + (255 & v44)) | 0);
                const v46 = (((v45 >>> 8) + (v43 >>> 8)) | 0);
                memory[1122] = (255 & v45);
                if (((((v46) | 0) === ((0) | 0)) | 0)) {
                    s0 = v46;
                    break L3;
                }
                const v47 = memory[1121];
                const v48 = (((255 & v46) + (255 & v47)) | 0);
                const v49 = (((v48 >>> 8) + (v46 >>> 8)) | 0);
                memory[1121] = (255 & v48);
                if (((((v49) | 0) === ((0) | 0)) | 0)) {
                    s0 = v49;
                    break L3;
                }
                const v50 = memory[1120];
                const v51 = (((255 & v49) + (255 & v50)) | 0);
                const v52 = (((v51 >>> 8) + (v49 >>> 8)) | 0);
                memory[1120] = (255 & v51);
                if (((((v52) | 0) === ((0) | 0)) | 0)) {
                    s0 = v52;
                    break L3;
                }
                s0 = v52;
            }
        }
        return;
    }
    function encryptInit(v0) {
        const v1 = memory_i32[2468];
        L0: {
            if (((((((((v1) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            let s0 = 0, s1 = 1;
            L1: {
                const v2 = s0;
                const v3 = s1;
                let s2 = v2, s3 = v3;
                L2: for (;;) {
                    const v4 = s2;
                    const v5 = s3;
                    const v6 = ((1 + v4) | 0);
                    const v7 = ((255 & (Math.imul(27, (1 & (v5 >>> 7))) ^ (v5 << 1))) ^ v5);
                    memory[((((1408 + v4) | 0)) >>> 0) + 0] = (255 & v5);
                    if (((((v6) >>> 0) < ((256) >>> 0)) | 0)) {
                        s2 = v6;
                        s3 = v7;
                        continue L2;
                    }
                    s2 = v6;
                    s3 = v7;
                    break L2;
                }
                const v4 = s2;
                const v5 = s3;
                s0 = v4;
                s1 = v5;
            }
            memory[1152] = (255 & 99);
            let s4 = 0;
            L3: {
                const v8 = s4;
                if (((((((((v8) >>> 0) < ((255) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s4 = v8;
                    break L3;
                }
                let s5 = v8;
                L4: {
                    const v9 = s5;
                    let s6 = v9;
                    L5: for (;;) {
                        const v10 = s6;
                        let s7 = v10;
                        L6: {
                            const v11 = s7;
                            const v12 = memory[((((1408 + ((255 - v11) | 0)) | 0)) >>> 0) + 0];
                            const v13 = (255 & v12);
                            const v14 = ((v13 << 8) | v13);
                            const v15 = memory[((((1408 + v11) | 0)) >>> 0) + 0];
                            memory[((((1152 + (255 & v15)) | 0)) >>> 0) + 0] = (255 & (255 & (99 ^ ((v14 >>> 7) ^ ((v14 >>> 6) ^ ((v14 >>> 5) ^ ((v14 >>> 4) ^ v14)))))));
                            s7 = v11;
                        }
                        const v11 = s7;
                        const v16 = ((1 + v11) | 0);
                        if (((((v16) >>> 0) < ((255) >>> 0)) | 0)) {
                            s6 = v16;
                            continue L5;
                        }
                        s6 = v16;
                        break L5;
                    }
                    const v10 = s6;
                    s5 = v10;
                }
                const v9 = s5;
                s4 = v9;
            }
            let s8 = 0;
            L7: {
                const v17 = s8;
                if (((((((((v17) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s8 = v17;
                    break L7;
                }
                let s9 = v17;
                L8: {
                    const v18 = s9;
                    let s10 = v18;
                    L9: for (;;) {
                        const v19 = s10;
                        let s11 = v19;
                        L10: {
                            const v20 = s11;
                            memory[((((5504 + v20) | 0)) >>> 0) + 0] = (255 & 0);
                            s11 = v20;
                        }
                        const v20 = s11;
                        const v21 = ((1 + v20) | 0);
                        if (((((v21) >>> 0) < ((256) >>> 0)) | 0)) {
                            s10 = v21;
                            continue L9;
                        }
                        s10 = v21;
                        break L9;
                    }
                    const v19 = s10;
                    s9 = v19;
                }
                const v18 = s9;
                s8 = v18;
            }
            let s12 = 0;
            L11: {
                const v22 = s12;
                if (((((((((v22) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s12 = v22;
                    break L11;
                }
                let s13 = v22;
                L12: {
                    const v23 = s13;
                    let s14 = v23;
                    L13: for (;;) {
                        const v24 = s14;
                        let s15 = v24;
                        L14: {
                            const v25 = s15;
                            const v26 = memory[((((1152 + v25) | 0)) >>> 0) + 0];
                            memory[((((5504 + (255 & v26)) | 0)) >>> 0) + 0] = (255 & v25);
                            s15 = v25;
                        }
                        const v25 = s15;
                        const v27 = ((1 + v25) | 0);
                        if (((((v27) >>> 0) < ((256) >>> 0)) | 0)) {
                            s14 = v27;
                            continue L13;
                        }
                        s14 = v27;
                        break L13;
                    }
                    const v24 = s14;
                    s13 = v24;
                }
                const v23 = s13;
                s12 = v23;
            }
            let s16 = 0, s17 = 1;
            L15: {
                const v28 = s16;
                const v29 = s17;
                let s18 = v28, s19 = v29;
                L16: for (;;) {
                    const v30 = s18;
                    const v31 = s19;
                    const v32 = ((1 + v30) | 0);
                    const v33 = (255 & (Math.imul(27, (1 & (v31 >>> 7))) ^ (v31 << 1)));
                    memory[((((9856 + v30) | 0)) >>> 0) + 0] = (255 & v31);
                    if (((((v32) >>> 0) < ((16) >>> 0)) | 0)) {
                        s18 = v32;
                        s19 = v33;
                        continue L16;
                    }
                    s18 = v32;
                    s19 = v33;
                    break L16;
                }
                const v30 = s18;
                const v31 = s19;
                s16 = v30;
                s17 = v31;
            }
            let s20 = 0;
            L17: {
                const v34 = s20;
                if (((((((((v34) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s20 = v34;
                    break L17;
                }
                let s21 = v34;
                L18: {
                    const v35 = s21;
                    let s22 = v35;
                    L19: for (;;) {
                        const v36 = s22;
                        let s23 = v36;
                        L20: {
                            const v37 = s23;
                            const v38 = memory[((((1152 + v37) | 0)) >>> 0) + 0];
                            const v39 = (255 & v38);
                            const v40 = memory[((((5504 + v37) | 0)) >>> 0) + 0];
                            const v41 = (255 & v40);
                            const v42 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
                            const v43 = (255 & (Math.imul(27, (1 & (v42 >>> 7))) ^ (v42 << 1)));
                            const v44 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
                            const v45 = (255 & (Math.imul(27, (1 & (v44 >>> 7))) ^ (v44 << 1)));
                            const v46 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
                            const v47 = (255 & (Math.imul(27, (1 & (v46 >>> 7))) ^ (v46 << 1)));
                            const v48 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
                            const v49 = (255 & (Math.imul(27, (1 & (v48 >>> 7))) ^ (v48 << 1)));
                            memory_i32[(((((1408 + (v37 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((((255 & (Math.imul(27, (1 & (v39 >>> 7))) ^ (v39 << 1))) | (v39 << 8)) | (v39 << 16)) | (((255 & (Math.imul(27, (1 & (v39 >>> 7))) ^ (v39 << 1))) ^ v39) << 24));
                            memory_i32[(((((5760 + (v37 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & (Math.imul(27, (1 & (v49 >>> 7))) ^ (v49 << 1))) ^ (v49 ^ v48)) | (((255 & (Math.imul(27, (1 & (v43 >>> 7))) ^ (v43 << 1))) ^ v41) << 8)) | (((255 & (Math.imul(27, (1 & (v47 >>> 7))) ^ (v47 << 1))) ^ (v47 ^ v41)) << 16)) | (((255 & (Math.imul(27, (1 & (v45 >>> 7))) ^ (v45 << 1))) ^ (v44 ^ v41)) << 24));
                            s23 = v37;
                        }
                        const v37 = s23;
                        const v50 = ((1 + v37) | 0);
                        if (((((v50) >>> 0) < ((256) >>> 0)) | 0)) {
                            s22 = v50;
                            continue L19;
                        }
                        s22 = v50;
                        break L19;
                    }
                    const v36 = s22;
                    s21 = v36;
                }
                const v35 = s21;
                s20 = v35;
            }
            let s24 = 0;
            L21: {
                const v51 = s24;
                if (((((((((v51) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
                    s24 = v51;
                    break L21;
                }
                let s25 = v51;
                L22: {
                    const v52 = s25;
                    let s26 = v52;
                    L23: for (;;) {
                        const v53 = s26;
                        let s27 = v53;
                        L24: {
                            const v54 = s27;
                            const v55 = memory_i32[(((((1408 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2];
                            const v56 = ((v55 << 8) | ((v55 >>> (32 - 8)) >>> 0));
                            const v57 = ((v56 << 8) | ((v56 >>> (32 - 8)) >>> 0));
                            memory_i32[(((((2432 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = v56;
                            memory_i32[(((((3456 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = v57;
                            memory_i32[(((((4480 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v57 << 8) | ((v57 >>> (32 - 8)) >>> 0));
                            const v58 = memory_i32[(((((5760 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2];
                            const v59 = ((v58 << 8) | ((v58 >>> (32 - 8)) >>> 0));
                            const v60 = ((v59 << 8) | ((v59 >>> (32 - 8)) >>> 0));
                            memory_i32[(((((6784 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = v59;
                            memory_i32[(((((7808 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = v60;
                            memory_i32[(((((8832 + (v54 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v60 << 8) | ((v60 >>> (32 - 8)) >>> 0));
                            s27 = v54;
                        }
                        const v54 = s27;
                        const v61 = ((1 + v54) | 0);
                        if (((((v61) >>> 0) < ((256) >>> 0)) | 0)) {
                            s26 = v61;
                            continue L23;
                        }
                        s26 = v61;
                        break L23;
                    }
                    const v53 = s26;
                    s25 = v53;
                }
                const v52 = s25;
                s24 = v52;
            }
            memory_i32[2468] = 1;
        }
        const v62 = ((((v0) | 0) === ((16) | 0)) | 0);
        const v63 = ((((v0) | 0) === ((24) | 0)) | 0);
        const v64 = ((v62) ? (4) : (((v63) ? (6) : (8))));
        const v65 = ((v62) ? (10) : (((v63) ? (12) : (14))));
        memory_i32[256] = v65;
        memory_i32[76] = 0;
        memory_i32[77] = 0;
        memory_i32[78] = 0;
        memory_i32[79] = 0;
        memory_i32[80] = 0;
        memory_i32[81] = 0;
        memory_i32[82] = 0;
        memory_i32[83] = 0;
        memory_i32[84] = 0;
        memory_i32[85] = 0;
        memory_i32[86] = 0;
        memory_i32[87] = 0;
        memory_i32[88] = 0;
        memory_i32[89] = 0;
        memory_i32[90] = 0;
        memory_i32[91] = 0;
        memory_i32[92] = 0;
        memory_i32[93] = 0;
        memory_i32[94] = 0;
        memory_i32[95] = 0;
        memory_i32[96] = 0;
        memory_i32[97] = 0;
        memory_i32[98] = 0;
        memory_i32[99] = 0;
        memory_i32[100] = 0;
        memory_i32[101] = 0;
        memory_i32[102] = 0;
        memory_i32[103] = 0;
        memory_i32[104] = 0;
        memory_i32[105] = 0;
        memory_i32[106] = 0;
        memory_i32[107] = 0;
        memory_i32[108] = 0;
        memory_i32[109] = 0;
        memory_i32[110] = 0;
        memory_i32[111] = 0;
        memory_i32[112] = 0;
        memory_i32[113] = 0;
        memory_i32[114] = 0;
        memory_i32[115] = 0;
        memory_i32[116] = 0;
        memory_i32[117] = 0;
        memory_i32[118] = 0;
        memory_i32[119] = 0;
        memory_i32[120] = 0;
        memory_i32[121] = 0;
        memory_i32[122] = 0;
        memory_i32[123] = 0;
        memory_i32[124] = 0;
        memory_i32[125] = 0;
        memory_i32[126] = 0;
        memory_i32[127] = 0;
        memory_i32[128] = 0;
        memory_i32[129] = 0;
        memory_i32[130] = 0;
        memory_i32[131] = 0;
        memory_i32[132] = 0;
        memory_i32[133] = 0;
        memory_i32[134] = 0;
        memory_i32[135] = 0;
        let s28 = 0;
        L25: {
            const v66 = s28;
            if (((((((((v66) >>> 0) < ((v64) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s28 = v66;
                break L25;
            }
            let s29 = v66;
            L26: {
                const v67 = s29;
                let s30 = v67;
                L27: for (;;) {
                    const v68 = s30;
                    let s31 = v68;
                    L28: {
                        const v69 = s31;
                        const v70 = (v69 << 2);
                        const v71 = memory[((((1 + v70) | 0)) >>> 0) + 0];
                        const v72 = memory[((((2 + v70) | 0)) >>> 0) + 0];
                        const v73 = memory[((((3 + v70) | 0)) >>> 0) + 0];
                        const v74 = memory[((v70) >>> 0) + 0];
                        memory_i32[(((((544 + (v69 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v73) << 24) | ((255 & v72) << 16)) | ((255 & v71) << 8)) | (255 & v74));
                        s31 = v69;
                    }
                    const v69 = s31;
                    const v75 = ((1 + v69) | 0);
                    if (((((v75) >>> 0) < ((v64) >>> 0)) | 0)) {
                        s30 = v75;
                        continue L27;
                    }
                    s30 = v75;
                    break L27;
                }
                const v68 = s30;
                s29 = v68;
            }
            const v67 = s29;
            s28 = v67;
        }
        const v76 = (((1 + v65) | 0) << 2);
        const v77 = ((v76 - v64) | 0);
        let s32 = 0;
        L29: {
            const v78 = s32;
            if (((((((((v78) >>> 0) < ((v77) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s32 = v78;
                break L29;
            }
            let s33 = v78;
            L30: {
                const v79 = s33;
                let s34 = v79;
                L31: for (;;) {
                    const v80 = s34;
                    let s35 = v80;
                    L32: {
                        const v81 = s35;
                        const v82 = ((v64 + v81) | 0);
                        const v83 = memory_i32[(((((544 + (((v82 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v84 = ((((((v82) >>> 0) % (((v64) >>> 0)))) >>> 0));
                        const v85 = ((v83 >>> 8) | (v83 << 24));
                        const v86 = memory[((((1152 + (255 & (v85 >>> 8))) | 0)) >>> 0) + 0];
                        const v87 = memory[((((1152 + (255 & (v85 >>> 16))) | 0)) >>> 0) + 0];
                        const v88 = memory[((((1152 + (255 & (v85 >>> 24))) | 0)) >>> 0) + 0];
                        const v89 = memory[((((1152 + (255 & v85)) | 0)) >>> 0) + 0];
                        const v90 = memory[((((9856 + ((((((((v82) >>> 0) / (((v64) >>> 0)))) >>> 0)) - 1) | 0)) | 0)) >>> 0) + 0];
                        const v91 = memory[((((1152 + (255 & (v83 >>> 8))) | 0)) >>> 0) + 0];
                        const v92 = memory[((((1152 + (255 & (v83 >>> 16))) | 0)) >>> 0) + 0];
                        const v93 = memory[((((1152 + (255 & (v83 >>> 24))) | 0)) >>> 0) + 0];
                        const v94 = memory[((((1152 + (255 & v83)) | 0)) >>> 0) + 0];
                        const v95 = memory_i32[(((((544 + (((v82 - v64) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((544 + (v82 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v95 ^ (((((((v84) | 0) === ((4) | 0)) | 0) & ((((v64) | 0) === ((8) | 0)) | 0))) ? (((((255 & v93) << 24) | ((255 & v92) << 16)) | (((255 & v91) << 8) | (255 & v94)))) : (((((((v84) | 0) === ((0) | 0)) | 0)) ? (((255 & v90) ^ ((((255 & v88) << 24) | ((255 & v87) << 16)) | (((255 & v86) << 8) | (255 & v89))))) : (v83)))));
                        s35 = v81;
                    }
                    const v81 = s35;
                    const v96 = ((1 + v81) | 0);
                    if (((((v96) >>> 0) < ((v77) >>> 0)) | 0)) {
                        s34 = v96;
                        continue L31;
                    }
                    s34 = v96;
                    break L31;
                }
                const v80 = s34;
                s33 = v80;
            }
            const v79 = s33;
            s32 = v79;
        }
        let s36 = 0;
        L33: {
            const v97 = s36;
            if (((((((((v97) >>> 0) < ((v76) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s36 = v97;
                break L33;
            }
            let s37 = v97;
            L34: {
                const v98 = s37;
                let s38 = v98;
                L35: for (;;) {
                    const v99 = s38;
                    let s39 = v99;
                    L36: {
                        const v100 = s39;
                        const v101 = memory_i32[(((((544 + (v100 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((304 + (v100 << 2)) | 0)) >>> 0) + 0) >>> 2] = v101;
                        s39 = v100;
                    }
                    const v100 = s39;
                    const v102 = ((1 + v100) | 0);
                    if (((((v102) >>> 0) < ((v76) >>> 0)) | 0)) {
                        s38 = v102;
                        continue L35;
                    }
                    s38 = v102;
                    break L35;
                }
                const v99 = s38;
                s37 = v99;
            }
            const v98 = s37;
            s36 = v98;
        }
        const v103 = memory_i32[256];
        const v104 = memory_i32[76];
        const v105 = memory_i32[77];
        const v106 = memory_i32[78];
        const v107 = memory_i32[79];
        const v108 = ((v103 - 1) | 0);
        let s40 = 0, s41 = v104, s42 = v105, s43 = v106, s44 = v107;
        L37: {
            const v109 = s40;
            const v110 = s41;
            const v111 = s42;
            const v112 = s43;
            const v113 = s44;
            let s45 = v109, s46 = v110, s47 = v111, s48 = v112, s49 = v113;
            L38: for (;;) {
                const v114 = s45;
                const v115 = s46;
                const v116 = s47;
                const v117 = s48;
                const v118 = s49;
                const v119 = ((1 + v114) | 0);
                const v120 = (((1 + v114) | 0) << 2);
                const v121 = memory_i32[(((((304 + (v120 << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v122 = memory_i32[(((((1408 + ((255 & v115) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v123 = memory_i32[(((((2432 + ((255 & (v116 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v124 = memory_i32[(((((3456 + ((255 & (v117 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v125 = memory_i32[(((((4480 + ((255 & (v118 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v126 = (((v125 ^ v124) ^ (v123 ^ v122)) ^ v121);
                const v127 = memory_i32[(((((304 + (((1 + v120) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v128 = memory_i32[(((((1408 + ((255 & v116) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v129 = memory_i32[(((((2432 + ((255 & (v117 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v130 = memory_i32[(((((3456 + ((255 & (v118 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v131 = memory_i32[(((((4480 + ((255 & (v115 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v132 = (((v131 ^ v130) ^ (v129 ^ v128)) ^ v127);
                const v133 = memory_i32[(((((304 + (((2 + v120) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v134 = memory_i32[(((((1408 + ((255 & v117) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v135 = memory_i32[(((((2432 + ((255 & (v118 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v136 = memory_i32[(((((3456 + ((255 & (v115 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v137 = memory_i32[(((((4480 + ((255 & (v116 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v138 = (((v137 ^ v136) ^ (v135 ^ v134)) ^ v133);
                const v139 = memory_i32[(((((304 + (((3 + v120) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v140 = memory_i32[(((((1408 + ((255 & v118) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v141 = memory_i32[(((((2432 + ((255 & (v115 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v142 = memory_i32[(((((3456 + ((255 & (v116 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v143 = memory_i32[(((((4480 + ((255 & (v117 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v144 = (((v143 ^ v142) ^ (v141 ^ v140)) ^ v139);
                if (((((v119) >>> 0) < ((v108) >>> 0)) | 0)) {
                    s45 = v119;
                    s46 = v126;
                    s47 = v132;
                    s48 = v138;
                    s49 = v144;
                    continue L38;
                }
                s45 = v119;
                s46 = v126;
                s47 = v132;
                s48 = v138;
                s49 = v144;
                break L38;
            }
            const v114 = s45;
            const v115 = s46;
            const v116 = s47;
            const v117 = s48;
            const v118 = s49;
            s40 = v114;
            s41 = v115;
            s42 = v116;
            s43 = v117;
            s44 = v118;
        }
        const v110 = s41;
        const v111 = s42;
        const v112 = s43;
        const v113 = s44;
        const v145 = (v103 << 2);
        const v146 = memory_i32[(((((304 + (v145 << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v147 = memory[((((1152 + (255 & (v111 >>> 8))) | 0)) >>> 0) + 0];
        const v148 = memory[((((1152 + (255 & (v112 >>> 16))) | 0)) >>> 0) + 0];
        const v149 = memory[((((1152 + (255 & (v113 >>> 24))) | 0)) >>> 0) + 0];
        const v150 = memory[((((1152 + (255 & v110)) | 0)) >>> 0) + 0];
        const v151 = memory_i32[(((((304 + (((1 + v145) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v152 = memory[((((1152 + (255 & (v112 >>> 8))) | 0)) >>> 0) + 0];
        const v153 = memory[((((1152 + (255 & (v113 >>> 16))) | 0)) >>> 0) + 0];
        const v154 = memory[((((1152 + (255 & (v110 >>> 24))) | 0)) >>> 0) + 0];
        const v155 = memory[((((1152 + (255 & v111)) | 0)) >>> 0) + 0];
        const v156 = memory_i32[(((((304 + (((2 + v145) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v157 = memory[((((1152 + (255 & (v113 >>> 8))) | 0)) >>> 0) + 0];
        const v158 = memory[((((1152 + (255 & (v110 >>> 16))) | 0)) >>> 0) + 0];
        const v159 = memory[((((1152 + (255 & (v111 >>> 24))) | 0)) >>> 0) + 0];
        const v160 = memory[((((1152 + (255 & v112)) | 0)) >>> 0) + 0];
        const v161 = memory_i32[(((((304 + (((3 + v145) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v162 = memory[((((1152 + (255 & (v110 >>> 8))) | 0)) >>> 0) + 0];
        const v163 = memory[((((1152 + (255 & (v111 >>> 16))) | 0)) >>> 0) + 0];
        const v164 = memory[((((1152 + (255 & (v112 >>> 24))) | 0)) >>> 0) + 0];
        const v165 = memory[((((1152 + (255 & v113)) | 0)) >>> 0) + 0];
        memory_i32[260] = (((((255 & v149) << 24) | ((255 & v148) << 16)) | (((255 & v147) << 8) | (255 & v150))) ^ v146);
        memory_i32[261] = (((((255 & v154) << 24) | ((255 & v153) << 16)) | (((255 & v152) << 8) | (255 & v155))) ^ v151);
        memory_i32[262] = (((((255 & v159) << 24) | ((255 & v158) << 16)) | (((255 & v157) << 8) | (255 & v160))) ^ v156);
        memory_i32[263] = (((((255 & v164) << 24) | ((255 & v163) << 16)) | (((255 & v162) << 8) | (255 & v165))) ^ v161);
        let s50 = 0, s51 = 0;
        L39: {
            const v166 = s50;
            const v167 = s51;
            let s52 = v166, s53 = v167;
            L40: for (;;) {
                const v168 = s52;
                const v169 = s53;
                const v170 = ((1 + v168) | 0);
                const v171 = ((15 - v168) | 0);
                const v172 = memory[((((1040 + v171) | 0)) >>> 0) + 0];
                const v173 = (255 & (255 & v172));
                const v174 = (v173 >>> 7);
                memory[((((1040 + v171) | 0)) >>> 0) + 0] = (255 & (255 & (v169 | (v173 << 1))));
                if (((((v170) >>> 0) < ((16) >>> 0)) | 0)) {
                    s52 = v170;
                    s53 = v174;
                    continue L40;
                }
                s52 = v170;
                s53 = v174;
                break L40;
            }
            const v168 = s52;
            const v169 = s53;
            s50 = v168;
            s51 = v169;
        }
        const v167 = s51;
        const v175 = memory[1055];
        memory[1055] = (255 & ((135 & ((0 - v167) | 0)) ^ (255 & v175)));
        const v176 = memory_i32[260];
        const v177 = memory_i32[261];
        const v178 = memory_i32[262];
        const v179 = memory_i32[263];
        memory_i32[264] = v176;
        memory_i32[265] = v177;
        memory_i32[266] = v178;
        memory_i32[267] = v179;
        let s54 = 0, s55 = 0;
        L41: {
            const v180 = s54;
            const v181 = s55;
            let s56 = v180, s57 = v181;
            L42: for (;;) {
                const v182 = s56;
                const v183 = s57;
                const v184 = ((1 + v182) | 0);
                const v185 = ((15 - v182) | 0);
                const v186 = memory[((((1056 + v185) | 0)) >>> 0) + 0];
                const v187 = (255 & (255 & v186));
                const v188 = (v187 >>> 7);
                memory[((((1056 + v185) | 0)) >>> 0) + 0] = (255 & (255 & (v183 | (v187 << 1))));
                if (((((v184) >>> 0) < ((16) >>> 0)) | 0)) {
                    s56 = v184;
                    s57 = v188;
                    continue L42;
                }
                s56 = v184;
                s57 = v188;
                break L42;
            }
            const v182 = s56;
            const v183 = s57;
            s54 = v182;
            s55 = v183;
        }
        const v181 = s55;
        const v189 = memory[1071];
        memory[1071] = (255 & ((135 & ((0 - v181) | 0)) ^ (255 & v189)));
        memory_i32[268] = 0;
        memory_i32[269] = 0;
        memory_i32[270] = 0;
        memory_i32[271] = 0;
        const v190 = memory_i32[256];
        const v191 = memory_i32[260];
        const v192 = memory_i32[261];
        const v193 = memory_i32[262];
        const v194 = memory_i32[263];
        const v195 = memory_i32[76];
        const v196 = memory_i32[77];
        const v197 = memory_i32[78];
        const v198 = memory_i32[79];
        const v199 = ((v190 - 1) | 0);
        let s58 = 0, s59 = (v195 ^ v191), s60 = (v196 ^ v192), s61 = (v197 ^ v193), s62 = (v198 ^ v194);
        L43: {
            const v200 = s58;
            const v201 = s59;
            const v202 = s60;
            const v203 = s61;
            const v204 = s62;
            let s63 = v200, s64 = v201, s65 = v202, s66 = v203, s67 = v204;
            L44: for (;;) {
                const v205 = s63;
                const v206 = s64;
                const v207 = s65;
                const v208 = s66;
                const v209 = s67;
                const v210 = ((1 + v205) | 0);
                const v211 = (((1 + v205) | 0) << 2);
                const v212 = memory_i32[(((((304 + (v211 << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v213 = memory_i32[(((((1408 + ((255 & v206) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v214 = memory_i32[(((((2432 + ((255 & (v207 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v215 = memory_i32[(((((3456 + ((255 & (v208 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v216 = memory_i32[(((((4480 + ((255 & (v209 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v217 = (((v216 ^ v215) ^ (v214 ^ v213)) ^ v212);
                const v218 = memory_i32[(((((304 + (((1 + v211) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v219 = memory_i32[(((((1408 + ((255 & v207) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v220 = memory_i32[(((((2432 + ((255 & (v208 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v221 = memory_i32[(((((3456 + ((255 & (v209 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v222 = memory_i32[(((((4480 + ((255 & (v206 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v223 = (((v222 ^ v221) ^ (v220 ^ v219)) ^ v218);
                const v224 = memory_i32[(((((304 + (((2 + v211) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v225 = memory_i32[(((((1408 + ((255 & v208) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v226 = memory_i32[(((((2432 + ((255 & (v209 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v227 = memory_i32[(((((3456 + ((255 & (v206 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v228 = memory_i32[(((((4480 + ((255 & (v207 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v229 = (((v228 ^ v227) ^ (v226 ^ v225)) ^ v224);
                const v230 = memory_i32[(((((304 + (((3 + v211) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v231 = memory_i32[(((((1408 + ((255 & v209) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v232 = memory_i32[(((((2432 + ((255 & (v206 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v233 = memory_i32[(((((3456 + ((255 & (v207 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v234 = memory_i32[(((((4480 + ((255 & (v208 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                const v235 = (((v234 ^ v233) ^ (v232 ^ v231)) ^ v230);
                if (((((v210) >>> 0) < ((v199) >>> 0)) | 0)) {
                    s63 = v210;
                    s64 = v217;
                    s65 = v223;
                    s66 = v229;
                    s67 = v235;
                    continue L44;
                }
                s63 = v210;
                s64 = v217;
                s65 = v223;
                s66 = v229;
                s67 = v235;
                break L44;
            }
            const v205 = s63;
            const v206 = s64;
            const v207 = s65;
            const v208 = s66;
            const v209 = s67;
            s58 = v205;
            s59 = v206;
            s60 = v207;
            s61 = v208;
            s62 = v209;
        }
        const v201 = s59;
        const v202 = s60;
        const v203 = s61;
        const v204 = s62;
        const v236 = (v190 << 2);
        const v237 = memory_i32[(((((304 + (v236 << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v238 = memory[((((1152 + (255 & (v202 >>> 8))) | 0)) >>> 0) + 0];
        const v239 = memory[((((1152 + (255 & (v203 >>> 16))) | 0)) >>> 0) + 0];
        const v240 = memory[((((1152 + (255 & (v204 >>> 24))) | 0)) >>> 0) + 0];
        const v241 = memory[((((1152 + (255 & v201)) | 0)) >>> 0) + 0];
        const v242 = memory_i32[(((((304 + (((1 + v236) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v243 = memory[((((1152 + (255 & (v203 >>> 8))) | 0)) >>> 0) + 0];
        const v244 = memory[((((1152 + (255 & (v204 >>> 16))) | 0)) >>> 0) + 0];
        const v245 = memory[((((1152 + (255 & (v201 >>> 24))) | 0)) >>> 0) + 0];
        const v246 = memory[((((1152 + (255 & v202)) | 0)) >>> 0) + 0];
        const v247 = memory_i32[(((((304 + (((2 + v236) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v248 = memory[((((1152 + (255 & (v204 >>> 8))) | 0)) >>> 0) + 0];
        const v249 = memory[((((1152 + (255 & (v201 >>> 16))) | 0)) >>> 0) + 0];
        const v250 = memory[((((1152 + (255 & (v202 >>> 24))) | 0)) >>> 0) + 0];
        const v251 = memory[((((1152 + (255 & v203)) | 0)) >>> 0) + 0];
        const v252 = memory_i32[(((((304 + (((3 + v236) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
        const v253 = memory[((((1152 + (255 & (v201 >>> 8))) | 0)) >>> 0) + 0];
        const v254 = memory[((((1152 + (255 & (v202 >>> 16))) | 0)) >>> 0) + 0];
        const v255 = memory[((((1152 + (255 & (v203 >>> 24))) | 0)) >>> 0) + 0];
        const v256 = memory[((((1152 + (255 & v204)) | 0)) >>> 0) + 0];
        memory_i32[272] = (((((255 & v240) << 24) | ((255 & v239) << 16)) | (((255 & v238) << 8) | (255 & v241))) ^ v237);
        memory_i32[273] = (((((255 & v245) << 24) | ((255 & v244) << 16)) | (((255 & v243) << 8) | (255 & v246))) ^ v242);
        memory_i32[274] = (((((255 & v250) << 24) | ((255 & v249) << 16)) | (((255 & v248) << 8) | (255 & v251))) ^ v247);
        memory_i32[275] = (((((255 & v255) << 24) | ((255 & v254) << 16)) | (((255 & v253) << 8) | (255 & v256))) ^ v252);
        const v257 = ((((v0) | 0) === ((16) | 0)) | 0);
        const v258 = ((((v0) | 0) === ((24) | 0)) | 0);
        const v259 = ((v257) ? (4) : (((v258) ? (6) : (8))));
        const v260 = ((v257) ? (10) : (((v258) ? (12) : (14))));
        memory_i32[256] = v260;
        memory_i32[16] = 0;
        memory_i32[17] = 0;
        memory_i32[18] = 0;
        memory_i32[19] = 0;
        memory_i32[20] = 0;
        memory_i32[21] = 0;
        memory_i32[22] = 0;
        memory_i32[23] = 0;
        memory_i32[24] = 0;
        memory_i32[25] = 0;
        memory_i32[26] = 0;
        memory_i32[27] = 0;
        memory_i32[28] = 0;
        memory_i32[29] = 0;
        memory_i32[30] = 0;
        memory_i32[31] = 0;
        memory_i32[32] = 0;
        memory_i32[33] = 0;
        memory_i32[34] = 0;
        memory_i32[35] = 0;
        memory_i32[36] = 0;
        memory_i32[37] = 0;
        memory_i32[38] = 0;
        memory_i32[39] = 0;
        memory_i32[40] = 0;
        memory_i32[41] = 0;
        memory_i32[42] = 0;
        memory_i32[43] = 0;
        memory_i32[44] = 0;
        memory_i32[45] = 0;
        memory_i32[46] = 0;
        memory_i32[47] = 0;
        memory_i32[48] = 0;
        memory_i32[49] = 0;
        memory_i32[50] = 0;
        memory_i32[51] = 0;
        memory_i32[52] = 0;
        memory_i32[53] = 0;
        memory_i32[54] = 0;
        memory_i32[55] = 0;
        memory_i32[56] = 0;
        memory_i32[57] = 0;
        memory_i32[58] = 0;
        memory_i32[59] = 0;
        memory_i32[60] = 0;
        memory_i32[61] = 0;
        memory_i32[62] = 0;
        memory_i32[63] = 0;
        memory_i32[64] = 0;
        memory_i32[65] = 0;
        memory_i32[66] = 0;
        memory_i32[67] = 0;
        memory_i32[68] = 0;
        memory_i32[69] = 0;
        memory_i32[70] = 0;
        memory_i32[71] = 0;
        memory_i32[72] = 0;
        memory_i32[73] = 0;
        memory_i32[74] = 0;
        memory_i32[75] = 0;
        let s68 = 0;
        L45: {
            const v261 = s68;
            if (((((((((v261) >>> 0) < ((v259) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s68 = v261;
                break L45;
            }
            let s69 = v261;
            L46: {
                const v262 = s69;
                let s70 = v262;
                L47: for (;;) {
                    const v263 = s70;
                    let s71 = v263;
                    L48: {
                        const v264 = s71;
                        const v265 = (v264 << 2);
                        const v266 = memory[((((32 + ((1 + v265) | 0)) | 0)) >>> 0) + 0];
                        const v267 = memory[((((32 + ((2 + v265) | 0)) | 0)) >>> 0) + 0];
                        const v268 = memory[((((32 + ((3 + v265) | 0)) | 0)) >>> 0) + 0];
                        const v269 = memory[((((32 + v265) | 0)) >>> 0) + 0];
                        memory_i32[(((((544 + (v264 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v268) << 24) | ((255 & v267) << 16)) | ((255 & v266) << 8)) | (255 & v269));
                        s71 = v264;
                    }
                    const v264 = s71;
                    const v270 = ((1 + v264) | 0);
                    if (((((v270) >>> 0) < ((v259) >>> 0)) | 0)) {
                        s70 = v270;
                        continue L47;
                    }
                    s70 = v270;
                    break L47;
                }
                const v263 = s70;
                s69 = v263;
            }
            const v262 = s69;
            s68 = v262;
        }
        const v271 = (((1 + v260) | 0) << 2);
        const v272 = ((v271 - v259) | 0);
        let s72 = 0;
        L49: {
            const v273 = s72;
            if (((((((((v273) >>> 0) < ((v272) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s72 = v273;
                break L49;
            }
            let s73 = v273;
            L50: {
                const v274 = s73;
                let s74 = v274;
                L51: for (;;) {
                    const v275 = s74;
                    let s75 = v275;
                    L52: {
                        const v276 = s75;
                        const v277 = ((v259 + v276) | 0);
                        const v278 = memory_i32[(((((544 + (((v277 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v279 = ((((((v277) >>> 0) % (((v259) >>> 0)))) >>> 0));
                        const v280 = ((v278 >>> 8) | (v278 << 24));
                        const v281 = memory[((((1152 + (255 & (v280 >>> 8))) | 0)) >>> 0) + 0];
                        const v282 = memory[((((1152 + (255 & (v280 >>> 16))) | 0)) >>> 0) + 0];
                        const v283 = memory[((((1152 + (255 & (v280 >>> 24))) | 0)) >>> 0) + 0];
                        const v284 = memory[((((1152 + (255 & v280)) | 0)) >>> 0) + 0];
                        const v285 = memory[((((9856 + ((((((((v277) >>> 0) / (((v259) >>> 0)))) >>> 0)) - 1) | 0)) | 0)) >>> 0) + 0];
                        const v286 = memory[((((1152 + (255 & (v278 >>> 8))) | 0)) >>> 0) + 0];
                        const v287 = memory[((((1152 + (255 & (v278 >>> 16))) | 0)) >>> 0) + 0];
                        const v288 = memory[((((1152 + (255 & (v278 >>> 24))) | 0)) >>> 0) + 0];
                        const v289 = memory[((((1152 + (255 & v278)) | 0)) >>> 0) + 0];
                        const v290 = memory_i32[(((((544 + (((v277 - v259) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((544 + (v277 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v290 ^ (((((((v279) | 0) === ((4) | 0)) | 0) & ((((v259) | 0) === ((8) | 0)) | 0))) ? (((((255 & v288) << 24) | ((255 & v287) << 16)) | (((255 & v286) << 8) | (255 & v289)))) : (((((((v279) | 0) === ((0) | 0)) | 0)) ? (((255 & v285) ^ ((((255 & v283) << 24) | ((255 & v282) << 16)) | (((255 & v281) << 8) | (255 & v284))))) : (v278)))));
                        s75 = v276;
                    }
                    const v276 = s75;
                    const v291 = ((1 + v276) | 0);
                    if (((((v291) >>> 0) < ((v272) >>> 0)) | 0)) {
                        s74 = v291;
                        continue L51;
                    }
                    s74 = v291;
                    break L51;
                }
                const v275 = s74;
                s73 = v275;
            }
            const v274 = s73;
            s72 = v274;
        }
        let s76 = 0;
        L53: {
            const v292 = s76;
            if (((((((((v292) >>> 0) < ((v271) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s76 = v292;
                break L53;
            }
            let s77 = v292;
            L54: {
                const v293 = s77;
                let s78 = v293;
                L55: for (;;) {
                    const v294 = s78;
                    let s79 = v294;
                    L56: {
                        const v295 = s79;
                        const v296 = memory_i32[(((((544 + (v295 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        memory_i32[(((((64 + (v295 << 2)) | 0)) >>> 0) + 0) >>> 2] = v296;
                        s79 = v295;
                    }
                    const v295 = s79;
                    const v297 = ((1 + v295) | 0);
                    if (((((v297) >>> 0) < ((v271) >>> 0)) | 0)) {
                        s78 = v297;
                        continue L55;
                    }
                    s78 = v297;
                    break L55;
                }
                const v294 = s78;
                s77 = v294;
            }
            const v293 = s77;
            s76 = v293;
        }
        return;
    }
    function macBlocks(v0, v1, v2) {
        const v3 = memory_i32[256];
        const v4 = (((((v0) | 0) === ((0) | 0)) | 0) & v1);
        const v5 = ((v4) ? (1) : (v0));
        const v6 = ((v4) ? (16) : (v2));
        L0: {
            if (((((v4) | 0) === 0) | 0)) {
                break L0;
            }
            memory[9888] = (255 & 128);
            memory.fill(0, 9889, 9889 + 16);
        }
        const v7 = ((v5 - 1) | 0);
        const v8 = (((((v5) | 0) !== ((0) | 0)) | 0) & v1);
        L1: {
            if ((((((((((v6) | 0) !== ((0) | 0)) | 0) & v1)) | 0) === 0) | 0)) {
                break L1;
            }
            const v9 = (((v5 << 4) - v6) | 0);
            const v10 = ((v9 - 16) | 0);
            const v11 = ((((((1 + v7) | 0)) | 0) !== ((1) | 0)) | 0);
            L2: {
                if (((((v11) | 0) === 0) | 0)) {
                    break L2;
                }
                const v12 = memory[((((9888 + v10) | 0)) >>> 0) + 0];
                const v13 = memory[1088];
                memory[((((9888 + v10) | 0)) >>> 0) + 0] = (255 & ((255 & v13) ^ (255 & v12)));
                const v14 = memory[((((9888 + ((1 + v10) | 0)) | 0)) >>> 0) + 0];
                const v15 = memory[1089];
                memory[((((9888 + ((1 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v15) ^ (255 & v14)));
                const v16 = memory[((((9888 + ((2 + v10) | 0)) | 0)) >>> 0) + 0];
                const v17 = memory[1090];
                memory[((((9888 + ((2 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v17) ^ (255 & v16)));
                const v18 = memory[((((9888 + ((3 + v10) | 0)) | 0)) >>> 0) + 0];
                const v19 = memory[1091];
                memory[((((9888 + ((3 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v19) ^ (255 & v18)));
                const v20 = memory[((((9888 + ((4 + v10) | 0)) | 0)) >>> 0) + 0];
                const v21 = memory[1092];
                memory[((((9888 + ((4 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v21) ^ (255 & v20)));
                const v22 = memory[((((9888 + ((5 + v10) | 0)) | 0)) >>> 0) + 0];
                const v23 = memory[1093];
                memory[((((9888 + ((5 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v23) ^ (255 & v22)));
                const v24 = memory[((((9888 + ((6 + v10) | 0)) | 0)) >>> 0) + 0];
                const v25 = memory[1094];
                memory[((((9888 + ((6 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v25) ^ (255 & v24)));
                const v26 = memory[((((9888 + ((7 + v10) | 0)) | 0)) >>> 0) + 0];
                const v27 = memory[1095];
                memory[((((9888 + ((7 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v27) ^ (255 & v26)));
                const v28 = memory[((((9888 + ((8 + v10) | 0)) | 0)) >>> 0) + 0];
                const v29 = memory[1096];
                memory[((((9888 + ((8 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v29) ^ (255 & v28)));
                const v30 = memory[((((9888 + ((9 + v10) | 0)) | 0)) >>> 0) + 0];
                const v31 = memory[1097];
                memory[((((9888 + ((9 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v31) ^ (255 & v30)));
                const v32 = memory[((((9888 + ((10 + v10) | 0)) | 0)) >>> 0) + 0];
                const v33 = memory[1098];
                memory[((((9888 + ((10 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v33) ^ (255 & v32)));
                const v34 = memory[((((9888 + ((11 + v10) | 0)) | 0)) >>> 0) + 0];
                const v35 = memory[1099];
                memory[((((9888 + ((11 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v35) ^ (255 & v34)));
                const v36 = memory[((((9888 + ((12 + v10) | 0)) | 0)) >>> 0) + 0];
                const v37 = memory[1100];
                memory[((((9888 + ((12 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v37) ^ (255 & v36)));
                const v38 = memory[((((9888 + ((13 + v10) | 0)) | 0)) >>> 0) + 0];
                const v39 = memory[1101];
                memory[((((9888 + ((13 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v39) ^ (255 & v38)));
                const v40 = memory[((((9888 + ((14 + v10) | 0)) | 0)) >>> 0) + 0];
                const v41 = memory[1102];
                memory[((((9888 + ((14 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v41) ^ (255 & v40)));
                const v42 = memory[((((9888 + ((15 + v10) | 0)) | 0)) >>> 0) + 0];
                const v43 = memory[1103];
                memory[((((9888 + ((15 + v10) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v43) ^ (255 & v42)));
            }
            memory[((((9888 + v9) | 0)) >>> 0) + 0] = (255 & 128);
            memory.fill(0, ((((9888 + ((1 + v9) | 0)) | 0)) >>> 0), ((((9888 + ((1 + v9) | 0)) | 0)) >>> 0) + ((((v6 + v9) | 0)) >>> 0));
            const v44 = (v7 << 4);
            L3: {
                if (((((((((v11) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                    break L3;
                }
                const v45 = memory[1103];
                const v46 = memory[1102];
                const v47 = memory[1101];
                const v48 = memory[1100];
                const v49 = memory[1099];
                const v50 = memory[1098];
                const v51 = memory[1097];
                const v52 = memory[1096];
                const v53 = memory[1095];
                const v54 = memory[1094];
                const v55 = memory[1093];
                const v56 = memory[1092];
                const v57 = memory[1091];
                const v58 = memory[1090];
                const v59 = memory[1089];
                const v60 = memory[1088];
                memory[544] = v60;
                memory[545] = v59;
                memory[546] = v58;
                memory[547] = v57;
                memory[548] = v56;
                memory[549] = v55;
                memory[550] = v54;
                memory[551] = v53;
                memory[552] = v52;
                memory[553] = v51;
                memory[554] = v50;
                memory[555] = v49;
                memory[556] = v48;
                memory[557] = v47;
                memory[558] = v46;
                memory[559] = v45;
                let s0 = 0, s1 = 0;
                L4: {
                    const v61 = s0;
                    const v62 = s1;
                    let s2 = v61, s3 = v62;
                    L5: for (;;) {
                        const v63 = s2;
                        const v64 = s3;
                        const v65 = ((1 + v63) | 0);
                        const v66 = ((15 - v63) | 0);
                        const v67 = memory[((((544 + v66) | 0)) >>> 0) + 0];
                        const v68 = (255 & (255 & v67));
                        const v69 = (v68 >>> 7);
                        memory[((((544 + v66) | 0)) >>> 0) + 0] = (255 & (255 & (v64 | (v68 << 1))));
                        if (((((v65) >>> 0) < ((16) >>> 0)) | 0)) {
                            s2 = v65;
                            s3 = v69;
                            continue L5;
                        }
                        s2 = v65;
                        s3 = v69;
                        break L5;
                    }
                    const v63 = s2;
                    const v64 = s3;
                    s0 = v63;
                    s1 = v64;
                }
                const v62 = s1;
                const v70 = memory[559];
                const v71 = memory[((((9888 + v44) | 0)) >>> 0) + 0];
                memory[559] = (255 & ((135 & ((0 - v62) | 0)) ^ (255 & v70)));
                const v72 = memory[544];
                memory[((((9888 + v44) | 0)) >>> 0) + 0] = (255 & ((255 & v72) ^ (255 & v71)));
                const v73 = memory[((((9888 + ((1 + v44) | 0)) | 0)) >>> 0) + 0];
                const v74 = memory[545];
                memory[((((9888 + ((1 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v74) ^ (255 & v73)));
                const v75 = memory[((((9888 + ((2 + v44) | 0)) | 0)) >>> 0) + 0];
                const v76 = memory[546];
                memory[((((9888 + ((2 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v76) ^ (255 & v75)));
                const v77 = memory[((((9888 + ((3 + v44) | 0)) | 0)) >>> 0) + 0];
                const v78 = memory[547];
                memory[((((9888 + ((3 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v78) ^ (255 & v77)));
                const v79 = memory[((((9888 + ((4 + v44) | 0)) | 0)) >>> 0) + 0];
                const v80 = memory[548];
                memory[((((9888 + ((4 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v80) ^ (255 & v79)));
                const v81 = memory[((((9888 + ((5 + v44) | 0)) | 0)) >>> 0) + 0];
                const v82 = memory[549];
                memory[((((9888 + ((5 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v82) ^ (255 & v81)));
                const v83 = memory[((((9888 + ((6 + v44) | 0)) | 0)) >>> 0) + 0];
                const v84 = memory[550];
                memory[((((9888 + ((6 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v84) ^ (255 & v83)));
                const v85 = memory[((((9888 + ((7 + v44) | 0)) | 0)) >>> 0) + 0];
                const v86 = memory[551];
                memory[((((9888 + ((7 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v86) ^ (255 & v85)));
                const v87 = memory[((((9888 + ((8 + v44) | 0)) | 0)) >>> 0) + 0];
                const v88 = memory[552];
                memory[((((9888 + ((8 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v88) ^ (255 & v87)));
                const v89 = memory[((((9888 + ((9 + v44) | 0)) | 0)) >>> 0) + 0];
                const v90 = memory[553];
                memory[((((9888 + ((9 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v90) ^ (255 & v89)));
                const v91 = memory[((((9888 + ((10 + v44) | 0)) | 0)) >>> 0) + 0];
                const v92 = memory[554];
                memory[((((9888 + ((10 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v92) ^ (255 & v91)));
                const v93 = memory[((((9888 + ((11 + v44) | 0)) | 0)) >>> 0) + 0];
                const v94 = memory[555];
                memory[((((9888 + ((11 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v94) ^ (255 & v93)));
                const v95 = memory[((((9888 + ((12 + v44) | 0)) | 0)) >>> 0) + 0];
                const v96 = memory[556];
                memory[((((9888 + ((12 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v96) ^ (255 & v95)));
                const v97 = memory[((((9888 + ((13 + v44) | 0)) | 0)) >>> 0) + 0];
                const v98 = memory[557];
                memory[((((9888 + ((13 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v98) ^ (255 & v97)));
                const v99 = memory[((((9888 + ((14 + v44) | 0)) | 0)) >>> 0) + 0];
                const v100 = memory[558];
                memory[((((9888 + ((14 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v100) ^ (255 & v99)));
                const v101 = memory[((((9888 + ((15 + v44) | 0)) | 0)) >>> 0) + 0];
                const v102 = memory[559];
                memory[((((9888 + ((15 + v44) | 0)) | 0)) >>> 0) + 0] = (255 & ((255 & v102) ^ (255 & v101)));
            }
        }
        L6: {
            if ((((((((((v6) | 0) === ((0) | 0)) | 0) & v1)) | 0) === 0) | 0)) {
                break L6;
            }
            const v103 = memory_i32[272];
            const v104 = memory_i32[273];
            const v105 = memory_i32[274];
            const v106 = memory_i32[275];
            const v107 = ((9888 + (v7 << 4)) | 0);
            const v108 = memory_i32[(((v107) >>> 0) + 0) >>> 2];
            const v109 = ((4 + v107) | 0);
            const v110 = memory_i32[(((v109) >>> 0) + 0) >>> 2];
            const v111 = ((4 + v109) | 0);
            const v112 = memory_i32[(((v111) >>> 0) + 0) >>> 2];
            const v113 = memory_i32[(((((4 + v111) | 0)) >>> 0) + 0) >>> 2];
            memory_i32[(((v107) >>> 0) + 0) >>> 2] = (v103 ^ v108);
            const v114 = ((4 + v107) | 0);
            memory_i32[(((v114) >>> 0) + 0) >>> 2] = (v104 ^ v110);
            const v115 = ((4 + v114) | 0);
            memory_i32[(((v115) >>> 0) + 0) >>> 2] = (v105 ^ v112);
            memory_i32[(((((4 + v115) | 0)) >>> 0) + 0) >>> 2] = (v106 ^ v113);
        }
        let s4 = 0;
        L7: {
            const v116 = s4;
            if (((((((((v116) >>> 0) < ((v5) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s4 = v116;
                break L7;
            }
            let s5 = v116;
            L8: {
                const v117 = s5;
                let s6 = v117;
                L9: for (;;) {
                    const v118 = s6;
                    let s7 = v118;
                    L10: {
                        const v119 = s7;
                        const v120 = (((((v119) | 0) === ((v7) | 0)) | 0) & v8);
                        const v121 = ((((((v5) | 0) !== ((1) | 0)) | 0) & ((((v6) | 0) !== ((0) | 0)) | 0)) & v120);
                        const v122 = ((9888 + (v119 << 4)) | 0);
                        const v123 = memory_i32[(((v122) >>> 0) + 0) >>> 2];
                        const v124 = ((4 + v122) | 0);
                        const v125 = memory_i32[(((v124) >>> 0) + 0) >>> 2];
                        const v126 = ((4 + v124) | 0);
                        const v127 = memory_i32[(((v126) >>> 0) + 0) >>> 2];
                        const v128 = memory_i32[(((((4 + v126) | 0)) >>> 0) + 0) >>> 2];
                        const v129 = memory_i32[268];
                        const v130 = memory_i32[269];
                        const v131 = memory_i32[270];
                        const v132 = memory_i32[271];
                        const v133 = memory_i32[260];
                        const v134 = memory_i32[261];
                        const v135 = memory_i32[262];
                        const v136 = memory_i32[263];
                        const v137 = memory_i32[264];
                        const v138 = memory_i32[265];
                        const v139 = memory_i32[266];
                        const v140 = memory_i32[267];
                        const v141 = memory_i32[76];
                        const v142 = memory_i32[77];
                        const v143 = memory_i32[78];
                        const v144 = memory_i32[79];
                        const v145 = ((v3 - 1) | 0);
                        let s8 = 0, s9 = (v141 ^ (v129 ^ ((v120) ? ((((v121) ? (v137) : (v133)) ^ v123)) : (v123)))), s10 = (v142 ^ (v130 ^ ((v120) ? ((((v121) ? (v138) : (v134)) ^ v125)) : (v125)))), s11 = (v143 ^ (v131 ^ ((v120) ? ((((v121) ? (v139) : (v135)) ^ v127)) : (v127)))), s12 = (v144 ^ (v132 ^ ((v120) ? ((((v121) ? (v140) : (v136)) ^ v128)) : (v128))));
                        L11: {
                            const v146 = s8;
                            const v147 = s9;
                            const v148 = s10;
                            const v149 = s11;
                            const v150 = s12;
                            let s13 = v146, s14 = v147, s15 = v148, s16 = v149, s17 = v150;
                            L12: for (;;) {
                                const v151 = s13;
                                const v152 = s14;
                                const v153 = s15;
                                const v154 = s16;
                                const v155 = s17;
                                const v156 = ((1 + v151) | 0);
                                const v157 = (((1 + v151) | 0) << 2);
                                const v158 = memory_i32[(((((304 + (v157 << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v159 = memory_i32[(((((1408 + ((255 & v152) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v160 = memory_i32[(((((2432 + ((255 & (v153 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v161 = memory_i32[(((((3456 + ((255 & (v154 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v162 = memory_i32[(((((4480 + ((255 & (v155 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v163 = (((v162 ^ v161) ^ (v160 ^ v159)) ^ v158);
                                const v164 = memory_i32[(((((304 + (((1 + v157) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v165 = memory_i32[(((((1408 + ((255 & v153) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v166 = memory_i32[(((((2432 + ((255 & (v154 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v167 = memory_i32[(((((3456 + ((255 & (v155 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v168 = memory_i32[(((((4480 + ((255 & (v152 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v169 = (((v168 ^ v167) ^ (v166 ^ v165)) ^ v164);
                                const v170 = memory_i32[(((((304 + (((2 + v157) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v171 = memory_i32[(((((1408 + ((255 & v154) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v172 = memory_i32[(((((2432 + ((255 & (v155 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v173 = memory_i32[(((((3456 + ((255 & (v152 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v174 = memory_i32[(((((4480 + ((255 & (v153 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v175 = (((v174 ^ v173) ^ (v172 ^ v171)) ^ v170);
                                const v176 = memory_i32[(((((304 + (((3 + v157) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v177 = memory_i32[(((((1408 + ((255 & v155) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v178 = memory_i32[(((((2432 + ((255 & (v152 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v179 = memory_i32[(((((3456 + ((255 & (v153 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v180 = memory_i32[(((((4480 + ((255 & (v154 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v181 = (((v180 ^ v179) ^ (v178 ^ v177)) ^ v176);
                                if (((((v156) >>> 0) < ((v145) >>> 0)) | 0)) {
                                    s13 = v156;
                                    s14 = v163;
                                    s15 = v169;
                                    s16 = v175;
                                    s17 = v181;
                                    continue L12;
                                }
                                s13 = v156;
                                s14 = v163;
                                s15 = v169;
                                s16 = v175;
                                s17 = v181;
                                break L12;
                            }
                            const v151 = s13;
                            const v152 = s14;
                            const v153 = s15;
                            const v154 = s16;
                            const v155 = s17;
                            s8 = v151;
                            s9 = v152;
                            s10 = v153;
                            s11 = v154;
                            s12 = v155;
                        }
                        const v147 = s9;
                        const v148 = s10;
                        const v149 = s11;
                        const v150 = s12;
                        const v182 = (v3 << 2);
                        const v183 = memory_i32[(((((304 + (v182 << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v184 = memory[((((1152 + (255 & (v148 >>> 8))) | 0)) >>> 0) + 0];
                        const v185 = memory[((((1152 + (255 & (v149 >>> 16))) | 0)) >>> 0) + 0];
                        const v186 = memory[((((1152 + (255 & (v150 >>> 24))) | 0)) >>> 0) + 0];
                        const v187 = memory[((((1152 + (255 & v147)) | 0)) >>> 0) + 0];
                        const v188 = memory_i32[(((((304 + (((1 + v182) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v189 = memory[((((1152 + (255 & (v149 >>> 8))) | 0)) >>> 0) + 0];
                        const v190 = memory[((((1152 + (255 & (v150 >>> 16))) | 0)) >>> 0) + 0];
                        const v191 = memory[((((1152 + (255 & (v147 >>> 24))) | 0)) >>> 0) + 0];
                        const v192 = memory[((((1152 + (255 & v148)) | 0)) >>> 0) + 0];
                        const v193 = memory_i32[(((((304 + (((2 + v182) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v194 = memory[((((1152 + (255 & (v150 >>> 8))) | 0)) >>> 0) + 0];
                        const v195 = memory[((((1152 + (255 & (v147 >>> 16))) | 0)) >>> 0) + 0];
                        const v196 = memory[((((1152 + (255 & (v148 >>> 24))) | 0)) >>> 0) + 0];
                        const v197 = memory[((((1152 + (255 & v149)) | 0)) >>> 0) + 0];
                        const v198 = memory_i32[(((((304 + (((3 + v182) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                        const v199 = memory[((((1152 + (255 & (v147 >>> 8))) | 0)) >>> 0) + 0];
                        const v200 = memory[((((1152 + (255 & (v148 >>> 16))) | 0)) >>> 0) + 0];
                        const v201 = memory[((((1152 + (255 & (v149 >>> 24))) | 0)) >>> 0) + 0];
                        const v202 = memory[((((1152 + (255 & v150)) | 0)) >>> 0) + 0];
                        memory_i32[268] = (((((255 & v186) << 24) | ((255 & v185) << 16)) | (((255 & v184) << 8) | (255 & v187))) ^ v183);
                        memory_i32[269] = (((((255 & v191) << 24) | ((255 & v190) << 16)) | (((255 & v189) << 8) | (255 & v192))) ^ v188);
                        memory_i32[270] = (((((255 & v196) << 24) | ((255 & v195) << 16)) | (((255 & v194) << 8) | (255 & v197))) ^ v193);
                        memory_i32[271] = (((((255 & v201) << 24) | ((255 & v200) << 16)) | (((255 & v199) << 8) | (255 & v202))) ^ v198);
                        s7 = v119;
                    }
                    const v119 = s7;
                    const v203 = ((1 + v119) | 0);
                    if (((((v203) >>> 0) < ((v5) >>> 0)) | 0)) {
                        s6 = v203;
                        continue L9;
                    }
                    s6 = v203;
                    break L9;
                }
                const v118 = s6;
                s5 = v118;
            }
            const v117 = s5;
            s4 = v117;
        }
        const v204 = memory_i32[268];
        const v205 = memory_i32[269];
        const v206 = memory_i32[270];
        const v207 = memory_i32[271];
        memory_i32[276] = v204;
        memory_i32[277] = v205;
        memory_i32[278] = v206;
        memory_i32[279] = v207;
        return;
    }
    function processBlocks(v0, v1, v2, v3) {
        let s0 = 0;
        L0: {
            const v4 = s0;
            if (((((((((v4) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v4;
                break L0;
            }
            let s1 = v4;
            L1: {
                const v5 = s1;
                let s2 = v5;
                L2: for (;;) {
                    const v6 = s2;
                    let s3 = v6;
                    L3: {
                        const v7 = s3;
                        const v8 = ((v7 + v0) | 0);
                        const v9 = Math.imul(v2, v8);
                        const v10 = ((v3 - v9) | 0);
                        const v11 = ((((((v10) >>> 0) < ((v2) >>> 0)) | 0)) ? (v10) : (v2));
                        const v12 = memory_i32[256];
                        const v13 = memory_i32[280];
                        const v14 = memory_i32[281];
                        const v15 = memory_i32[282];
                        const v16 = memory_i32[283];
                        let s4 = Math.imul(v2, v8), s5 = v13, s6 = v14, s7 = v15, s8 = v16;
                        L4: {
                            const v17 = s4;
                            const v18 = s5;
                            const v19 = s6;
                            const v20 = s7;
                            const v21 = s8;
                            const v22 = (((v21 >>> 24) | ((16711680 & v21) >>> 8)) | (((65280 & v21) << 8) | ((255 & v21) << 24)));
                            const v23 = ((v17 + v22) | 0);
                            const v24 = (((v23 >>> 24) | ((16711680 & v23) >>> 8)) | (((65280 & v23) << 8) | ((255 & v23) << 24)));
                            const v25 = (1 & ((((v23) >>> 0) < ((v22) >>> 0)) | 0));
                            if (((((v25) | 0) === ((0) | 0)) | 0)) {
                                s4 = v25;
                                s5 = v18;
                                s6 = v19;
                                s7 = v20;
                                s8 = v24;
                                break L4;
                            }
                            const v26 = (((v20 >>> 24) | ((16711680 & v20) >>> 8)) | (((65280 & v20) << 8) | ((255 & v20) << 24)));
                            const v27 = ((v25 + v26) | 0);
                            const v28 = (((v27 >>> 24) | ((16711680 & v27) >>> 8)) | (((65280 & v27) << 8) | ((255 & v27) << 24)));
                            const v29 = (1 & ((((v27) >>> 0) < ((v26) >>> 0)) | 0));
                            if (((((v29) | 0) === ((0) | 0)) | 0)) {
                                s4 = v29;
                                s5 = v18;
                                s6 = v19;
                                s7 = v28;
                                s8 = v24;
                                break L4;
                            }
                            const v30 = (((v19 >>> 24) | ((16711680 & v19) >>> 8)) | (((65280 & v19) << 8) | ((255 & v19) << 24)));
                            const v31 = ((v29 + v30) | 0);
                            const v32 = (((v31 >>> 24) | ((16711680 & v31) >>> 8)) | (((65280 & v31) << 8) | ((255 & v31) << 24)));
                            const v33 = (1 & ((((v31) >>> 0) < ((v30) >>> 0)) | 0));
                            if (((((v33) | 0) === ((0) | 0)) | 0)) {
                                s4 = v33;
                                s5 = v18;
                                s6 = v32;
                                s7 = v28;
                                s8 = v24;
                                break L4;
                            }
                            const v34 = (((v18 >>> 24) | ((16711680 & v18) >>> 8)) | (((65280 & v18) << 8) | ((255 & v18) << 24)));
                            const v35 = ((v33 + v34) | 0);
                            const v36 = (((v35 >>> 24) | ((16711680 & v35) >>> 8)) | (((65280 & v35) << 8) | ((255 & v35) << 24)));
                            const v37 = (1 & ((((v35) >>> 0) < ((v34) >>> 0)) | 0));
                            if (((((v37) | 0) === ((0) | 0)) | 0)) {
                                s4 = v37;
                                s5 = v36;
                                s6 = v32;
                                s7 = v28;
                                s8 = v24;
                                break L4;
                            }
                            s4 = v37;
                            s5 = v36;
                            s6 = v32;
                            s7 = v28;
                            s8 = v24;
                        }
                        const v18 = s5;
                        const v19 = s6;
                        const v20 = s7;
                        const v21 = s8;
                        let s9 = 0, s10 = v18, s11 = v19, s12 = v20, s13 = v21;
                        L5: {
                            const v38 = s9;
                            const v39 = s10;
                            const v40 = s11;
                            const v41 = s12;
                            const v42 = s13;
                            let s14 = v38, s15 = v39, s16 = v40, s17 = v41, s18 = v42;
                            L6: for (;;) {
                                const v43 = s14;
                                const v44 = s15;
                                const v45 = s16;
                                const v46 = s17;
                                const v47 = s18;
                                const v48 = ((1 + v43) | 0);
                                const v49 = ((9888 + (((v43 + v9) | 0) << 4)) | 0);
                                const v50 = memory_i32[16];
                                const v51 = memory_i32[17];
                                const v52 = memory_i32[18];
                                const v53 = memory_i32[19];
                                const v54 = ((v12 - 1) | 0);
                                let s19 = 0, s20 = (v50 ^ v44), s21 = (v51 ^ v45), s22 = (v52 ^ v46), s23 = (v53 ^ v47);
                                L7: {
                                    const v55 = s19;
                                    const v56 = s20;
                                    const v57 = s21;
                                    const v58 = s22;
                                    const v59 = s23;
                                    let s24 = v55, s25 = v56, s26 = v57, s27 = v58, s28 = v59;
                                    L8: for (;;) {
                                        const v60 = s24;
                                        const v61 = s25;
                                        const v62 = s26;
                                        const v63 = s27;
                                        const v64 = s28;
                                        const v65 = ((1 + v60) | 0);
                                        const v66 = (((1 + v60) | 0) << 2);
                                        const v67 = memory_i32[(((((64 + (v66 << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v68 = memory_i32[(((((1408 + ((255 & v61) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v69 = memory_i32[(((((2432 + ((255 & (v62 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v70 = memory_i32[(((((3456 + ((255 & (v63 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v71 = memory_i32[(((((4480 + ((255 & (v64 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v72 = (((v71 ^ v70) ^ (v69 ^ v68)) ^ v67);
                                        const v73 = memory_i32[(((((64 + (((1 + v66) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v74 = memory_i32[(((((1408 + ((255 & v62) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v75 = memory_i32[(((((2432 + ((255 & (v63 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v76 = memory_i32[(((((3456 + ((255 & (v64 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v77 = memory_i32[(((((4480 + ((255 & (v61 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v78 = (((v77 ^ v76) ^ (v75 ^ v74)) ^ v73);
                                        const v79 = memory_i32[(((((64 + (((2 + v66) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v80 = memory_i32[(((((1408 + ((255 & v63) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v81 = memory_i32[(((((2432 + ((255 & (v64 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v82 = memory_i32[(((((3456 + ((255 & (v61 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v83 = memory_i32[(((((4480 + ((255 & (v62 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v84 = (((v83 ^ v82) ^ (v81 ^ v80)) ^ v79);
                                        const v85 = memory_i32[(((((64 + (((3 + v66) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v86 = memory_i32[(((((1408 + ((255 & v64) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v87 = memory_i32[(((((2432 + ((255 & (v61 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v88 = memory_i32[(((((3456 + ((255 & (v62 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v89 = memory_i32[(((((4480 + ((255 & (v63 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        const v90 = (((v89 ^ v88) ^ (v87 ^ v86)) ^ v85);
                                        if (((((v65) >>> 0) < ((v54) >>> 0)) | 0)) {
                                            s24 = v65;
                                            s25 = v72;
                                            s26 = v78;
                                            s27 = v84;
                                            s28 = v90;
                                            continue L8;
                                        }
                                        s24 = v65;
                                        s25 = v72;
                                        s26 = v78;
                                        s27 = v84;
                                        s28 = v90;
                                        break L8;
                                    }
                                    const v60 = s24;
                                    const v61 = s25;
                                    const v62 = s26;
                                    const v63 = s27;
                                    const v64 = s28;
                                    s19 = v60;
                                    s20 = v61;
                                    s21 = v62;
                                    s22 = v63;
                                    s23 = v64;
                                }
                                const v56 = s20;
                                const v57 = s21;
                                const v58 = s22;
                                const v59 = s23;
                                const v91 = (v12 << 2);
                                const v92 = memory_i32[(((((64 + (v91 << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v93 = memory[((((1152 + (255 & (v57 >>> 8))) | 0)) >>> 0) + 0];
                                const v94 = memory[((((1152 + (255 & (v58 >>> 16))) | 0)) >>> 0) + 0];
                                const v95 = memory[((((1152 + (255 & (v59 >>> 24))) | 0)) >>> 0) + 0];
                                const v96 = memory[((((1152 + (255 & v56)) | 0)) >>> 0) + 0];
                                const v97 = memory_i32[(((((64 + (((1 + v91) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v98 = memory[((((1152 + (255 & (v58 >>> 8))) | 0)) >>> 0) + 0];
                                const v99 = memory[((((1152 + (255 & (v59 >>> 16))) | 0)) >>> 0) + 0];
                                const v100 = memory[((((1152 + (255 & (v56 >>> 24))) | 0)) >>> 0) + 0];
                                const v101 = memory[((((1152 + (255 & v57)) | 0)) >>> 0) + 0];
                                const v102 = memory_i32[(((((64 + (((2 + v91) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v103 = memory[((((1152 + (255 & (v59 >>> 8))) | 0)) >>> 0) + 0];
                                const v104 = memory[((((1152 + (255 & (v56 >>> 16))) | 0)) >>> 0) + 0];
                                const v105 = memory[((((1152 + (255 & (v57 >>> 24))) | 0)) >>> 0) + 0];
                                const v106 = memory[((((1152 + (255 & v58)) | 0)) >>> 0) + 0];
                                const v107 = memory_i32[(((((64 + (((3 + v91) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                const v108 = memory[((((1152 + (255 & (v56 >>> 8))) | 0)) >>> 0) + 0];
                                const v109 = memory[((((1152 + (255 & (v57 >>> 16))) | 0)) >>> 0) + 0];
                                const v110 = memory[((((1152 + (255 & (v58 >>> 24))) | 0)) >>> 0) + 0];
                                const v111 = memory[((((1152 + (255 & v59)) | 0)) >>> 0) + 0];
                                const v112 = memory_i32[(((v49) >>> 0) + 0) >>> 2];
                                const v113 = ((4 + v49) | 0);
                                const v114 = memory_i32[(((v113) >>> 0) + 0) >>> 2];
                                const v115 = ((4 + v113) | 0);
                                const v116 = memory_i32[(((v115) >>> 0) + 0) >>> 2];
                                const v117 = memory_i32[(((((4 + v115) | 0)) >>> 0) + 0) >>> 2];
                                memory_i32[(((v49) >>> 0) + 0) >>> 2] = ((((((255 & v95) << 24) | ((255 & v94) << 16)) | (((255 & v93) << 8) | (255 & v96))) ^ v92) ^ v112);
                                const v118 = ((4 + v49) | 0);
                                memory_i32[(((v118) >>> 0) + 0) >>> 2] = ((((((255 & v100) << 24) | ((255 & v99) << 16)) | (((255 & v98) << 8) | (255 & v101))) ^ v97) ^ v114);
                                const v119 = ((4 + v118) | 0);
                                memory_i32[(((v119) >>> 0) + 0) >>> 2] = ((((((255 & v105) << 24) | ((255 & v104) << 16)) | (((255 & v103) << 8) | (255 & v106))) ^ v102) ^ v116);
                                memory_i32[(((((4 + v119) | 0)) >>> 0) + 0) >>> 2] = ((((((255 & v110) << 24) | ((255 & v109) << 16)) | (((255 & v108) << 8) | (255 & v111))) ^ v107) ^ v117);
                                let s29 = 1, s30 = v44, s31 = v45, s32 = v46, s33 = v47;
                                L9: {
                                    const v120 = s29;
                                    const v121 = s30;
                                    const v122 = s31;
                                    const v123 = s32;
                                    const v124 = s33;
                                    const v125 = (((v124 >>> 24) | ((16711680 & v124) >>> 8)) | (((65280 & v124) << 8) | ((255 & v124) << 24)));
                                    const v126 = ((v120 + v125) | 0);
                                    const v127 = (((v126 >>> 24) | ((16711680 & v126) >>> 8)) | (((65280 & v126) << 8) | ((255 & v126) << 24)));
                                    const v128 = (1 & ((((v126) >>> 0) < ((v125) >>> 0)) | 0));
                                    if (((((v128) | 0) === ((0) | 0)) | 0)) {
                                        s29 = v128;
                                        s30 = v121;
                                        s31 = v122;
                                        s32 = v123;
                                        s33 = v127;
                                        break L9;
                                    }
                                    const v129 = (((v123 >>> 24) | ((16711680 & v123) >>> 8)) | (((65280 & v123) << 8) | ((255 & v123) << 24)));
                                    const v130 = ((v128 + v129) | 0);
                                    const v131 = (((v130 >>> 24) | ((16711680 & v130) >>> 8)) | (((65280 & v130) << 8) | ((255 & v130) << 24)));
                                    const v132 = (1 & ((((v130) >>> 0) < ((v129) >>> 0)) | 0));
                                    if (((((v132) | 0) === ((0) | 0)) | 0)) {
                                        s29 = v132;
                                        s30 = v121;
                                        s31 = v122;
                                        s32 = v131;
                                        s33 = v127;
                                        break L9;
                                    }
                                    const v133 = (((v122 >>> 24) | ((16711680 & v122) >>> 8)) | (((65280 & v122) << 8) | ((255 & v122) << 24)));
                                    const v134 = ((v132 + v133) | 0);
                                    const v135 = (((v134 >>> 24) | ((16711680 & v134) >>> 8)) | (((65280 & v134) << 8) | ((255 & v134) << 24)));
                                    const v136 = (1 & ((((v134) >>> 0) < ((v133) >>> 0)) | 0));
                                    if (((((v136) | 0) === ((0) | 0)) | 0)) {
                                        s29 = v136;
                                        s30 = v121;
                                        s31 = v135;
                                        s32 = v131;
                                        s33 = v127;
                                        break L9;
                                    }
                                    const v137 = (((v121 >>> 24) | ((16711680 & v121) >>> 8)) | (((65280 & v121) << 8) | ((255 & v121) << 24)));
                                    const v138 = ((v136 + v137) | 0);
                                    const v139 = (((v138 >>> 24) | ((16711680 & v138) >>> 8)) | (((65280 & v138) << 8) | ((255 & v138) << 24)));
                                    const v140 = (1 & ((((v138) >>> 0) < ((v137) >>> 0)) | 0));
                                    if (((((v140) | 0) === ((0) | 0)) | 0)) {
                                        s29 = v140;
                                        s30 = v139;
                                        s31 = v135;
                                        s32 = v131;
                                        s33 = v127;
                                        break L9;
                                    }
                                    s29 = v140;
                                    s30 = v139;
                                    s31 = v135;
                                    s32 = v131;
                                    s33 = v127;
                                }
                                const v121 = s30;
                                const v122 = s31;
                                const v123 = s32;
                                const v124 = s33;
                                if (((((v48) >>> 0) < ((v11) >>> 0)) | 0)) {
                                    s14 = v48;
                                    s15 = v121;
                                    s16 = v122;
                                    s17 = v123;
                                    s18 = v124;
                                    continue L6;
                                }
                                s14 = v48;
                                s15 = v121;
                                s16 = v122;
                                s17 = v123;
                                s18 = v124;
                                break L6;
                            }
                            const v43 = s14;
                            const v44 = s15;
                            const v45 = s16;
                            const v46 = s17;
                            const v47 = s18;
                            s9 = v43;
                            s10 = v44;
                            s11 = v45;
                            s12 = v46;
                            s13 = v47;
                        }
                        s3 = v7;
                    }
                    const v7 = s3;
                    const v141 = ((1 + v7) | 0);
                    if (((((v141) >>> 0) < ((v1) >>> 0)) | 0)) {
                        s2 = v141;
                        continue L2;
                    }
                    s2 = v141;
                    break L2;
                }
                const v6 = s2;
                s1 = v6;
            }
            const v5 = s1;
            s0 = v5;
        }
        return;
    }
    function reset(v0) {
        memory.fill(0, 0, 0 + 1140);
        memory.fill(0, 9888, 9888 + ((v0) >>> 0));
        return;
    }
    function tagInit() {
        const v0 = memory_i32[284];
        L0: {
            if (((((((((v0) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
                break L0;
            }
            memory_i32[284] = 1;
            const v1 = memory_i32[276];
            const v2 = memory_i32[277];
            const v3 = memory_i32[278];
            const v4 = memory_i32[279];
            memory_i32[280] = v1;
            memory_i32[281] = v2;
            memory_i32[282] = v3;
            memory_i32[283] = v4;
            const v5 = memory[1128];
            memory[1128] = (255 & (127 & (255 & v5)));
            const v6 = memory[1132];
            memory[1132] = (255 & (127 & (255 & v6)));
        }
        return;
    }
    const instance = { exports: { aadBlocks: aadBlocks, decryptBlocks: decryptBlocks, decryptInit: decryptInit, encryptBlocks: encryptBlocks, encryptInit: encryptInit, macBlocks: macBlocks, processBlocks: processBlocks, reset: reset, tagInit: tagInit, memory: { buffer: __buf } } };
    ;
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 10495648);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 1140),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 1140, 1140))),
        "state.key1": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.key": new Uint8Array(memoryExport.buffer, 32, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 64, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 64 + i * 240, 240))),
        "state.expandedKeyCmac": new Uint8Array(memoryExport.buffer, 304, 240),
        "state.expandedKeyCmac_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 304 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 544, 480),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 480, 480))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 1024, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1024 + i * 4, 4))),
        "state.k1": new Uint8Array(memoryExport.buffer, 1040, 16),
        "state.k1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1040 + i * 16, 16))),
        "state.k2": new Uint8Array(memoryExport.buffer, 1056, 16),
        "state.k2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1056 + i * 16, 16))),
        "state.iv": new Uint8Array(memoryExport.buffer, 1072, 16),
        "state.iv_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1072 + i * 16, 16))),
        "state.d": new Uint8Array(memoryExport.buffer, 1088, 16),
        "state.d_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1088 + i * 16, 16))),
        "state.tag": new Uint8Array(memoryExport.buffer, 1104, 16),
        "state.tag_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1104 + i * 16, 16))),
        "state.ctr": new Uint8Array(memoryExport.buffer, 1120, 16),
        "state.ctr_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1120 + i * 16, 16))),
        "state.ctrReady": new Uint8Array(memoryExport.buffer, 1136, 4),
        "state.ctrReady_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1136 + i * 4, 4))),
        constants: new Uint8Array(memoryExport.buffer, 1152, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1152 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 1152, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1152 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 1152, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1152 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 1408, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1408 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 2432, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2432 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 3456, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3456 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 4480, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4480 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 5504, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5504 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 5504, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5504 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5760, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5760 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6784, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6784 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7808, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7808 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8832, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8832 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9856, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9856 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9872, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9872 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9888, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9888 + i * 10485760, 10485760)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments });
}
let _cache;
export default function aes_siv(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
