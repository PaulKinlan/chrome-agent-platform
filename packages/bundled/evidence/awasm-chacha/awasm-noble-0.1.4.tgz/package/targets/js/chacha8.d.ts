export default function chacha(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=chacha8.d.ts.map