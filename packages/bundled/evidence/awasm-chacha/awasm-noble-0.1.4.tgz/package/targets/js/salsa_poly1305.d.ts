export default function arx(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=salsa_poly1305.d.ts.map