export default function sha2(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=sha256.d.ts.map