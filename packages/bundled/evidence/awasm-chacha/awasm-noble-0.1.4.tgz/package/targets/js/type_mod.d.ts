export default function runtimeTypes(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=type_mod.d.ts.map