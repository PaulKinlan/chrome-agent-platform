export default function md5(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=md5.d.ts.map