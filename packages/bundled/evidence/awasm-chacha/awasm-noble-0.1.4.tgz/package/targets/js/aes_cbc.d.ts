export default function aes_cbc(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_cbc.d.ts.map