// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    const __buf = new ArrayBuffer(21053440);
    if (!(__buf instanceof ArrayBuffer))
        throw new Error('wrong buffer');
    const memory = new Uint8Array(__buf);
    const memory_i32 = new Int32Array(__buf);
    function compress(v0, v1, v2, v3, v4, v5) {
        let s0 = 0;
        L0: {
            const v6 = s0;
            if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v6;
                break L0;
            }
            let s1 = v6;
            L1: {
                const v7 = s1;
                let s2 = v7;
                L2: for (;;) {
                    const v8 = s2;
                    let s3 = v8;
                    L3: {
                        const v9 = s3;
                        const v10 = ((v9 + v0) | 0);
                        const v11 = ((((((10240) >>> 0) / (((v5) >>> 0)))) >>> 0));
                        let s4 = 0;
                        L4: {
                            const v12 = s4;
                            if (((((((((v12) >>> 0) < ((v2) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                s4 = v12;
                                break L4;
                            }
                            let s5 = v12;
                            L5: {
                                const v13 = s5;
                                let s6 = v13;
                                L6: for (;;) {
                                    const v14 = s6;
                                    let s7 = v14;
                                    L7: {
                                        const v15 = s7;
                                        const v16 = ((v3 + v15) | 0);
                                        const v17 = ((1 + v16) | 0);
                                        const v18 = memory_i32[(((((((21012480 + (v10 << 2)) | 0) + (Math.imul(v5, v17) << 2)) | 0)) >>> 0) + 0) >>> 2];
                                        let s8 = 0;
                                        L8: {
                                            const v19 = s8;
                                            if (((((((((v19) >>> 0) < ((32) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                                s8 = v19;
                                                break L8;
                                            }
                                            let s9 = v19;
                                            L9: {
                                                const v20 = s9;
                                                let s10 = v20;
                                                L10: for (;;) {
                                                    const v21 = s10;
                                                    let s11 = v21;
                                                    L11: {
                                                        const v22 = s11;
                                                        let s12 = 0, s13 = 0, s14 = 0, s15 = 0, s16 = 0, s17 = 0, s18 = 0, s19 = 0;
                                                        L12: {
                                                            const v23 = s12;
                                                            const v24 = s13;
                                                            const v25 = s14;
                                                            const v26 = s15;
                                                            const v27 = s16;
                                                            const v28 = s17;
                                                            const v29 = s18;
                                                            const v30 = s19;
                                                            let s20 = v23, s21 = v24, s22 = v25, s23 = v26, s24 = v27, s25 = v28, s26 = v29, s27 = v30;
                                                            L13: {
                                                                const v31 = s20;
                                                                const v32 = s21;
                                                                const v33 = s22;
                                                                const v34 = s23;
                                                                const v35 = s24;
                                                                const v36 = s25;
                                                                const v37 = s26;
                                                                const v38 = s27;
                                                                if (((((((((v17) | 0) !== ((v18) | 0)) | 0)) | 0) === 0) | 0)) {
                                                                    s20 = v31;
                                                                    s21 = v32;
                                                                    s22 = v33;
                                                                    s23 = v34;
                                                                    s24 = v35;
                                                                    s25 = v36;
                                                                    s26 = v37;
                                                                    s27 = v38;
                                                                    break L13;
                                                                }
                                                                const v39 = ((((((10485760 + (v22 << 5)) | 0) + (v18 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                const v40 = memory_i32[(((v39) >>> 0) + 0) >>> 2];
                                                                const v41 = memory_i32[(((v39) >>> 0) + 4) >>> 2];
                                                                const v42 = memory_i32[(((v39) >>> 0) + 8) >>> 2];
                                                                const v43 = memory_i32[(((v39) >>> 0) + 12) >>> 2];
                                                                const v44 = memory_i32[(((v39) >>> 0) + 16) >>> 2];
                                                                const v45 = memory_i32[(((v39) >>> 0) + 20) >>> 2];
                                                                const v46 = memory_i32[(((v39) >>> 0) + 24) >>> 2];
                                                                const v47 = memory_i32[(((v39) >>> 0) + 28) >>> 2];
                                                                s12 = v40;
                                                                s13 = v41;
                                                                s14 = v42;
                                                                s15 = v43;
                                                                s16 = v44;
                                                                s17 = v45;
                                                                s18 = v46;
                                                                s19 = v47;
                                                                break L12;
                                                                s20 = v40;
                                                                s21 = v41;
                                                                s22 = v42;
                                                                s23 = v43;
                                                                s24 = v44;
                                                                s25 = v45;
                                                                s26 = v46;
                                                                s27 = v47;
                                                            }
                                                            const v48 = (((((v22 << 5) + (v10 << 10)) | 0) + (Math.imul(v5, v17) << 10)) | 0);
                                                            const v49 = memory_i32[(((v48) >>> 0) + 0) >>> 2];
                                                            const v50 = memory_i32[(((v48) >>> 0) + 4) >>> 2];
                                                            const v51 = memory_i32[(((v48) >>> 0) + 8) >>> 2];
                                                            const v52 = memory_i32[(((v48) >>> 0) + 12) >>> 2];
                                                            const v53 = memory_i32[(((v48) >>> 0) + 16) >>> 2];
                                                            const v54 = memory_i32[(((v48) >>> 0) + 20) >>> 2];
                                                            const v55 = memory_i32[(((v48) >>> 0) + 24) >>> 2];
                                                            const v56 = memory_i32[(((v48) >>> 0) + 28) >>> 2];
                                                            s12 = v49;
                                                            s13 = v50;
                                                            s14 = v51;
                                                            s15 = v52;
                                                            s16 = v53;
                                                            s17 = v54;
                                                            s18 = v55;
                                                            s19 = v56;
                                                        }
                                                        const v23 = s12;
                                                        const v24 = s13;
                                                        const v25 = s14;
                                                        const v26 = s15;
                                                        const v27 = s16;
                                                        const v28 = s17;
                                                        const v29 = s18;
                                                        const v30 = s19;
                                                        const v57 = ((((((10485760 + (v22 << 5)) | 0) + (v16 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                        const v58 = (((((v22 << 5) + (v10 << 10)) | 0) + (Math.imul(v5, v17) << 10)) | 0);
                                                        const v59 = memory_i32[(((v57) >>> 0) + 0) >>> 2];
                                                        const v60 = memory_i32[(((v57) >>> 0) + 4) >>> 2];
                                                        const v61 = memory_i32[(((v57) >>> 0) + 8) >>> 2];
                                                        const v62 = memory_i32[(((v57) >>> 0) + 12) >>> 2];
                                                        const v63 = memory_i32[(((v57) >>> 0) + 16) >>> 2];
                                                        const v64 = memory_i32[(((v57) >>> 0) + 20) >>> 2];
                                                        const v65 = memory_i32[(((v57) >>> 0) + 24) >>> 2];
                                                        const v66 = memory_i32[(((v57) >>> 0) + 28) >>> 2];
                                                        const v67 = (v59 ^ v23);
                                                        const v68 = (v60 ^ v24);
                                                        const v69 = (v61 ^ v25);
                                                        const v70 = (v62 ^ v26);
                                                        const v71 = (v63 ^ v27);
                                                        const v72 = (v64 ^ v28);
                                                        const v73 = (v65 ^ v29);
                                                        const v74 = (v66 ^ v30);
                                                        memory_i32[(((v58) >>> 0) + 0) >>> 2] = v67;
                                                        memory_i32[(((v58) >>> 0) + 4) >>> 2] = v68;
                                                        memory_i32[(((v58) >>> 0) + 8) >>> 2] = v69;
                                                        memory_i32[(((v58) >>> 0) + 12) >>> 2] = v70;
                                                        memory_i32[(((v58) >>> 0) + 16) >>> 2] = v71;
                                                        memory_i32[(((v58) >>> 0) + 20) >>> 2] = v72;
                                                        memory_i32[(((v58) >>> 0) + 24) >>> 2] = v73;
                                                        memory_i32[(((v58) >>> 0) + 28) >>> 2] = v74;
                                                        L14: {
                                                            L15: {
                                                                if (((((v4) | 0) === 0) | 0)) {
                                                                    break L15;
                                                                }
                                                                const v75 = ((((((10485760 + (v22 << 5)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                const v76 = ((((((10485760 + (v22 << 5)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                const v77 = memory_i32[(((v75) >>> 0) + 0) >>> 2];
                                                                const v78 = memory_i32[(((v75) >>> 0) + 4) >>> 2];
                                                                const v79 = memory_i32[(((v75) >>> 0) + 8) >>> 2];
                                                                const v80 = memory_i32[(((v75) >>> 0) + 12) >>> 2];
                                                                const v81 = memory_i32[(((v75) >>> 0) + 16) >>> 2];
                                                                const v82 = memory_i32[(((v75) >>> 0) + 20) >>> 2];
                                                                const v83 = memory_i32[(((v75) >>> 0) + 24) >>> 2];
                                                                const v84 = memory_i32[(((v75) >>> 0) + 28) >>> 2];
                                                                memory_i32[(((v76) >>> 0) + 0) >>> 2] = (v67 ^ v77);
                                                                memory_i32[(((v76) >>> 0) + 4) >>> 2] = (v68 ^ v78);
                                                                memory_i32[(((v76) >>> 0) + 8) >>> 2] = (v69 ^ v79);
                                                                memory_i32[(((v76) >>> 0) + 12) >>> 2] = (v70 ^ v80);
                                                                memory_i32[(((v76) >>> 0) + 16) >>> 2] = (v71 ^ v81);
                                                                memory_i32[(((v76) >>> 0) + 20) >>> 2] = (v72 ^ v82);
                                                                memory_i32[(((v76) >>> 0) + 24) >>> 2] = (v73 ^ v83);
                                                                memory_i32[(((v76) >>> 0) + 28) >>> 2] = (v74 ^ v84);
                                                                break L14;
                                                            }
                                                            const v85 = ((((((10485760 + (v22 << 5)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                            memory_i32[(((v85) >>> 0) + 0) >>> 2] = v67;
                                                            memory_i32[(((v85) >>> 0) + 4) >>> 2] = v68;
                                                            memory_i32[(((v85) >>> 0) + 8) >>> 2] = v69;
                                                            memory_i32[(((v85) >>> 0) + 12) >>> 2] = v70;
                                                            memory_i32[(((v85) >>> 0) + 16) >>> 2] = v71;
                                                            memory_i32[(((v85) >>> 0) + 20) >>> 2] = v72;
                                                            memory_i32[(((v85) >>> 0) + 24) >>> 2] = v73;
                                                            memory_i32[(((v85) >>> 0) + 28) >>> 2] = v74;
                                                        }
                                                        s11 = v22;
                                                    }
                                                    const v22 = s11;
                                                    const v86 = ((1 + v22) | 0);
                                                    if (((((v86) >>> 0) < ((32) >>> 0)) | 0)) {
                                                        s10 = v86;
                                                        continue L10;
                                                    }
                                                    s10 = v86;
                                                    break L10;
                                                }
                                                const v21 = s10;
                                                s9 = v21;
                                            }
                                            const v20 = s9;
                                            s8 = v20;
                                        }
                                        let s28 = 0;
                                        L16: {
                                            const v87 = s28;
                                            if (((((((((v87) >>> 0) < ((2) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                                s28 = v87;
                                                break L16;
                                            }
                                            let s29 = v87;
                                            L17: {
                                                const v88 = s29;
                                                let s30 = v88;
                                                L18: for (;;) {
                                                    const v89 = s30;
                                                    let s31 = v89;
                                                    L19: {
                                                        const v90 = s31;
                                                        const v91 = ((((((v90) | 0) === 0) | 0)) ? (v17) : (3));
                                                        const v92 = ((((((v90) | 0) === 0) | 0)) ? (3) : (v17));
                                                        let s32 = 0;
                                                        L20: {
                                                            const v93 = s32;
                                                            if (((((((((v93) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                                                s32 = v93;
                                                                break L20;
                                                            }
                                                            let s33 = v93;
                                                            L21: {
                                                                const v94 = s33;
                                                                let s34 = v94;
                                                                L22: for (;;) {
                                                                    const v95 = s34;
                                                                    let s35 = v95;
                                                                    L23: {
                                                                        const v96 = s35;
                                                                        const v97 = ((((((v96 << 4) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v98 = (((((((1 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v99 = (((((((2 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v100 = (((((((3 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v101 = (((((((4 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v102 = (((((((5 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v103 = (((((((6 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v104 = (((((((7 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v105 = (((((((8 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v106 = (((((((9 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v107 = (((((((10 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v108 = (((((((11 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v109 = (((((((12 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v110 = (((((((13 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v111 = (((((((14 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v112 = (((((((15 + (v96 << 4)) | 0) << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v91) << 10)) | 0);
                                                                        const v113 = ((1 + (v96 << 1)) | 0);
                                                                        const v114 = ((16 + (v96 << 1)) | 0);
                                                                        const v115 = ((17 + (v96 << 1)) | 0);
                                                                        const v116 = ((32 + (v96 << 1)) | 0);
                                                                        const v117 = ((33 + (v96 << 1)) | 0);
                                                                        const v118 = ((48 + (v96 << 1)) | 0);
                                                                        const v119 = ((49 + (v96 << 1)) | 0);
                                                                        const v120 = ((64 + (v96 << 1)) | 0);
                                                                        const v121 = ((65 + (v96 << 1)) | 0);
                                                                        const v122 = ((80 + (v96 << 1)) | 0);
                                                                        const v123 = ((81 + (v96 << 1)) | 0);
                                                                        const v124 = ((96 + (v96 << 1)) | 0);
                                                                        const v125 = ((97 + (v96 << 1)) | 0);
                                                                        const v126 = ((112 + (v96 << 1)) | 0);
                                                                        const v127 = ((113 + (v96 << 1)) | 0);
                                                                        const v128 = (v96 << 1);
                                                                        const v129 = memory_i32[(((v97) >>> 0) + 0) >>> 2];
                                                                        const v130 = memory_i32[(((v97) >>> 0) + 4) >>> 2];
                                                                        const v131 = memory_i32[(((v98) >>> 0) + 0) >>> 2];
                                                                        const v132 = memory_i32[(((v98) >>> 0) + 4) >>> 2];
                                                                        const v133 = memory_i32[(((v99) >>> 0) + 0) >>> 2];
                                                                        const v134 = memory_i32[(((v99) >>> 0) + 4) >>> 2];
                                                                        const v135 = memory_i32[(((v100) >>> 0) + 0) >>> 2];
                                                                        const v136 = memory_i32[(((v100) >>> 0) + 4) >>> 2];
                                                                        const v137 = memory_i32[(((v101) >>> 0) + 0) >>> 2];
                                                                        const v138 = memory_i32[(((v101) >>> 0) + 4) >>> 2];
                                                                        const v139 = memory_i32[(((v102) >>> 0) + 0) >>> 2];
                                                                        const v140 = memory_i32[(((v102) >>> 0) + 4) >>> 2];
                                                                        const v141 = memory_i32[(((v103) >>> 0) + 0) >>> 2];
                                                                        const v142 = memory_i32[(((v103) >>> 0) + 4) >>> 2];
                                                                        const v143 = memory_i32[(((v104) >>> 0) + 0) >>> 2];
                                                                        const v144 = memory_i32[(((v104) >>> 0) + 4) >>> 2];
                                                                        const v145 = memory_i32[(((v105) >>> 0) + 0) >>> 2];
                                                                        const v146 = memory_i32[(((v105) >>> 0) + 4) >>> 2];
                                                                        const v147 = memory_i32[(((v106) >>> 0) + 0) >>> 2];
                                                                        const v148 = memory_i32[(((v106) >>> 0) + 4) >>> 2];
                                                                        const v149 = memory_i32[(((v107) >>> 0) + 0) >>> 2];
                                                                        const v150 = memory_i32[(((v107) >>> 0) + 4) >>> 2];
                                                                        const v151 = memory_i32[(((v108) >>> 0) + 0) >>> 2];
                                                                        const v152 = memory_i32[(((v108) >>> 0) + 4) >>> 2];
                                                                        const v153 = memory_i32[(((v109) >>> 0) + 0) >>> 2];
                                                                        const v154 = memory_i32[(((v109) >>> 0) + 4) >>> 2];
                                                                        const v155 = memory_i32[(((v110) >>> 0) + 0) >>> 2];
                                                                        const v156 = memory_i32[(((v110) >>> 0) + 4) >>> 2];
                                                                        const v157 = memory_i32[(((v111) >>> 0) + 0) >>> 2];
                                                                        const v158 = memory_i32[(((v111) >>> 0) + 4) >>> 2];
                                                                        const v159 = memory_i32[(((v112) >>> 0) + 0) >>> 2];
                                                                        const v160 = memory_i32[(((v112) >>> 0) + 4) >>> 2];
                                                                        const v161 = (65535 & v139);
                                                                        const v162 = (65535 & v131);
                                                                        const v163 = Math.imul(v162, v161);
                                                                        const v164 = (v131 >>> 16);
                                                                        const v165 = (v139 >>> 16);
                                                                        const v166 = Math.imul(v162, v165);
                                                                        const v167 = ((((Math.imul(v164, v161) + (65535 & v166)) | 0) + (v163 >>> 16)) | 0);
                                                                        const v168 = ((65535 & v163) | (v167 << 16));
                                                                        const v169 = (v168 << 1);
                                                                        const v170 = ((v139 + v131) | 0);
                                                                        const v171 = ((v169 + v170) | 0);
                                                                        const v172 = ((((((-1 ^ v171) & (v169 | v170)) | (v169 & v170)) >>> 31) + ((((v168 >>> 31) | ((((((v167 >>> 16) + (v166 >>> 16)) | 0) + Math.imul(v164, v165)) | 0) << 1)) + ((((((-1 ^ v170) & (v139 | v131)) | (v139 & v131)) >>> 31) + ((v140 + v132) | 0)) | 0)) | 0)) | 0);
                                                                        const v173 = (v172 ^ v156);
                                                                        const v174 = (65535 & v173);
                                                                        const v175 = (65535 & v147);
                                                                        const v176 = Math.imul(v175, v174);
                                                                        const v177 = (v147 >>> 16);
                                                                        const v178 = (v173 >>> 16);
                                                                        const v179 = Math.imul(v175, v178);
                                                                        const v180 = ((((Math.imul(v177, v174) + (65535 & v179)) | 0) + (v176 >>> 16)) | 0);
                                                                        const v181 = ((65535 & v176) | (v180 << 16));
                                                                        const v182 = (v181 << 1);
                                                                        const v183 = ((v173 + v147) | 0);
                                                                        const v184 = ((v182 + v183) | 0);
                                                                        const v185 = (v184 ^ v139);
                                                                        const v186 = (v171 ^ v155);
                                                                        const v187 = ((((((-1 ^ v184) & (v182 | v183)) | (v182 & v183)) >>> 31) + ((((v181 >>> 31) | ((((((v180 >>> 16) + (v179 >>> 16)) | 0) + Math.imul(v177, v178)) | 0) << 1)) + ((((((-1 ^ v183) & (v173 | v147)) | (v173 & v147)) >>> 31) + ((v186 + v148) | 0)) | 0)) | 0)) | 0);
                                                                        const v188 = (v187 ^ v140);
                                                                        const v189 = ((v188 << 8) | (v185 >>> 24));
                                                                        const v190 = (65535 & v189);
                                                                        const v191 = (65535 & v171);
                                                                        const v192 = Math.imul(v191, v190);
                                                                        const v193 = (v171 >>> 16);
                                                                        const v194 = (v189 >>> 16);
                                                                        const v195 = Math.imul(v191, v194);
                                                                        const v196 = ((((Math.imul(v193, v190) + (65535 & v195)) | 0) + (v192 >>> 16)) | 0);
                                                                        const v197 = ((65535 & v192) | (v196 << 16));
                                                                        const v198 = (v197 << 1);
                                                                        const v199 = ((v189 + v171) | 0);
                                                                        const v200 = ((v198 + v199) | 0);
                                                                        const v201 = (v200 ^ v173);
                                                                        const v202 = ((v185 << 8) | (v188 >>> 24));
                                                                        const v203 = ((((((-1 ^ v200) & (v198 | v199)) | (v198 & v199)) >>> 31) + ((((v197 >>> 31) | ((((((v196 >>> 16) + (v195 >>> 16)) | 0) + Math.imul(v193, v194)) | 0) << 1)) + ((((((-1 ^ v199) & (v189 | v171)) | (v189 & v171)) >>> 31) + ((v202 + v172) | 0)) | 0)) | 0)) | 0);
                                                                        const v204 = (v203 ^ v186);
                                                                        const v205 = ((v204 << 16) | (v201 >>> 16));
                                                                        const v206 = (65535 & v205);
                                                                        const v207 = (65535 & v184);
                                                                        const v208 = Math.imul(v207, v206);
                                                                        const v209 = (v184 >>> 16);
                                                                        const v210 = (v205 >>> 16);
                                                                        const v211 = Math.imul(v207, v210);
                                                                        const v212 = ((((Math.imul(v209, v206) + (65535 & v211)) | 0) + (v208 >>> 16)) | 0);
                                                                        const v213 = ((65535 & v208) | (v212 << 16));
                                                                        const v214 = (v213 << 1);
                                                                        const v215 = ((v205 + v184) | 0);
                                                                        const v216 = ((v214 + v215) | 0);
                                                                        const v217 = (v216 ^ v189);
                                                                        const v218 = ((v201 << 16) | (v204 >>> 16));
                                                                        const v219 = ((((((-1 ^ v216) & (v214 | v215)) | (v214 & v215)) >>> 31) + ((((v213 >>> 31) | ((((((v212 >>> 16) + (v211 >>> 16)) | 0) + Math.imul(v209, v210)) | 0) << 1)) + ((((((-1 ^ v215) & (v205 | v184)) | (v205 & v184)) >>> 31) + ((v218 + v187) | 0)) | 0)) | 0)) | 0);
                                                                        const v220 = (v219 ^ v202);
                                                                        const v221 = ((v220 >>> 31) | (v217 << 1));
                                                                        const v222 = (65535 & v143);
                                                                        const v223 = (65535 & v135);
                                                                        const v224 = Math.imul(v223, v222);
                                                                        const v225 = (v135 >>> 16);
                                                                        const v226 = (v143 >>> 16);
                                                                        const v227 = Math.imul(v223, v226);
                                                                        const v228 = ((((Math.imul(v225, v222) + (65535 & v227)) | 0) + (v224 >>> 16)) | 0);
                                                                        const v229 = ((65535 & v224) | (v228 << 16));
                                                                        const v230 = (v229 << 1);
                                                                        const v231 = ((v143 + v135) | 0);
                                                                        const v232 = ((v230 + v231) | 0);
                                                                        const v233 = (v232 ^ v159);
                                                                        const v234 = ((((((-1 ^ v232) & (v230 | v231)) | (v230 & v231)) >>> 31) + ((((v229 >>> 31) | ((((((v228 >>> 16) + (v227 >>> 16)) | 0) + Math.imul(v225, v226)) | 0) << 1)) + ((((((-1 ^ v231) & (v143 | v135)) | (v143 & v135)) >>> 31) + ((v144 + v136) | 0)) | 0)) | 0)) | 0);
                                                                        const v235 = (v234 ^ v160);
                                                                        const v236 = (65535 & v235);
                                                                        const v237 = (65535 & v151);
                                                                        const v238 = Math.imul(v237, v236);
                                                                        const v239 = (v151 >>> 16);
                                                                        const v240 = (v235 >>> 16);
                                                                        const v241 = Math.imul(v237, v240);
                                                                        const v242 = ((((Math.imul(v239, v236) + (65535 & v241)) | 0) + (v238 >>> 16)) | 0);
                                                                        const v243 = ((65535 & v238) | (v242 << 16));
                                                                        const v244 = (v243 << 1);
                                                                        const v245 = ((v235 + v151) | 0);
                                                                        const v246 = ((v244 + v245) | 0);
                                                                        const v247 = (v246 ^ v143);
                                                                        const v248 = ((((((-1 ^ v246) & (v244 | v245)) | (v244 & v245)) >>> 31) + ((((v243 >>> 31) | ((((((v242 >>> 16) + (v241 >>> 16)) | 0) + Math.imul(v239, v240)) | 0) << 1)) + ((((((-1 ^ v245) & (v235 | v151)) | (v235 & v151)) >>> 31) + ((v233 + v152) | 0)) | 0)) | 0)) | 0);
                                                                        const v249 = (v248 ^ v144);
                                                                        const v250 = ((v249 << 8) | (v247 >>> 24));
                                                                        const v251 = (65535 & v250);
                                                                        const v252 = (65535 & v232);
                                                                        const v253 = Math.imul(v252, v251);
                                                                        const v254 = (v232 >>> 16);
                                                                        const v255 = (v250 >>> 16);
                                                                        const v256 = Math.imul(v252, v255);
                                                                        const v257 = ((((Math.imul(v254, v251) + (65535 & v256)) | 0) + (v253 >>> 16)) | 0);
                                                                        const v258 = ((65535 & v253) | (v257 << 16));
                                                                        const v259 = (v258 << 1);
                                                                        const v260 = ((v250 + v232) | 0);
                                                                        const v261 = ((v259 + v260) | 0);
                                                                        const v262 = ((v247 << 8) | (v249 >>> 24));
                                                                        const v263 = ((((((-1 ^ v261) & (v259 | v260)) | (v259 & v260)) >>> 31) + ((((v258 >>> 31) | ((((((v257 >>> 16) + (v256 >>> 16)) | 0) + Math.imul(v254, v255)) | 0) << 1)) + ((((((-1 ^ v260) & (v250 | v232)) | (v250 & v232)) >>> 31) + ((v262 + v234) | 0)) | 0)) | 0)) | 0);
                                                                        const v264 = (v263 ^ v233);
                                                                        const v265 = (v261 ^ v235);
                                                                        const v266 = ((v265 << 16) | (v264 >>> 16));
                                                                        const v267 = (65535 & v221);
                                                                        const v268 = (65535 & v137);
                                                                        const v269 = (65535 & v129);
                                                                        const v270 = Math.imul(v269, v268);
                                                                        const v271 = (v129 >>> 16);
                                                                        const v272 = (v137 >>> 16);
                                                                        const v273 = Math.imul(v269, v272);
                                                                        const v274 = ((((Math.imul(v271, v268) + (65535 & v273)) | 0) + (v270 >>> 16)) | 0);
                                                                        const v275 = ((65535 & v270) | (v274 << 16));
                                                                        const v276 = (v275 << 1);
                                                                        const v277 = ((v137 + v129) | 0);
                                                                        const v278 = ((v276 + v277) | 0);
                                                                        const v279 = ((((((-1 ^ v278) & (v276 | v277)) | (v276 & v277)) >>> 31) + ((((v275 >>> 31) | ((((((v274 >>> 16) + (v273 >>> 16)) | 0) + Math.imul(v271, v272)) | 0) << 1)) + ((((((-1 ^ v277) & (v137 | v129)) | (v137 & v129)) >>> 31) + ((v138 + v130) | 0)) | 0)) | 0)) | 0);
                                                                        const v280 = (v279 ^ v154);
                                                                        const v281 = (65535 & v280);
                                                                        const v282 = (65535 & v145);
                                                                        const v283 = Math.imul(v282, v281);
                                                                        const v284 = (v145 >>> 16);
                                                                        const v285 = (v280 >>> 16);
                                                                        const v286 = Math.imul(v282, v285);
                                                                        const v287 = ((((Math.imul(v284, v281) + (65535 & v286)) | 0) + (v283 >>> 16)) | 0);
                                                                        const v288 = ((65535 & v283) | (v287 << 16));
                                                                        const v289 = (v288 << 1);
                                                                        const v290 = ((v280 + v145) | 0);
                                                                        const v291 = ((v289 + v290) | 0);
                                                                        const v292 = (v291 ^ v137);
                                                                        const v293 = (v278 ^ v153);
                                                                        const v294 = ((((((-1 ^ v291) & (v289 | v290)) | (v289 & v290)) >>> 31) + ((((v288 >>> 31) | ((((((v287 >>> 16) + (v286 >>> 16)) | 0) + Math.imul(v284, v285)) | 0) << 1)) + ((((((-1 ^ v290) & (v280 | v145)) | (v280 & v145)) >>> 31) + ((v293 + v146) | 0)) | 0)) | 0)) | 0);
                                                                        const v295 = (v294 ^ v138);
                                                                        const v296 = ((v295 << 8) | (v292 >>> 24));
                                                                        const v297 = (65535 & v296);
                                                                        const v298 = (65535 & v278);
                                                                        const v299 = Math.imul(v298, v297);
                                                                        const v300 = (v278 >>> 16);
                                                                        const v301 = (v296 >>> 16);
                                                                        const v302 = Math.imul(v298, v301);
                                                                        const v303 = ((((Math.imul(v300, v297) + (65535 & v302)) | 0) + (v299 >>> 16)) | 0);
                                                                        const v304 = ((65535 & v299) | (v303 << 16));
                                                                        const v305 = (v304 << 1);
                                                                        const v306 = ((v296 + v278) | 0);
                                                                        const v307 = ((v305 + v306) | 0);
                                                                        const v308 = (65535 & v307);
                                                                        const v309 = Math.imul(v308, v267);
                                                                        const v310 = (v307 >>> 16);
                                                                        const v311 = (v221 >>> 16);
                                                                        const v312 = Math.imul(v308, v311);
                                                                        const v313 = ((((Math.imul(v310, v267) + (65535 & v312)) | 0) + (v309 >>> 16)) | 0);
                                                                        const v314 = ((65535 & v309) | (v313 << 16));
                                                                        const v315 = (v314 << 1);
                                                                        const v316 = ((v221 + v307) | 0);
                                                                        const v317 = ((v315 + v316) | 0);
                                                                        const v318 = ((v292 << 8) | (v295 >>> 24));
                                                                        const v319 = ((((((-1 ^ v307) & (v305 | v306)) | (v305 & v306)) >>> 31) + ((((v304 >>> 31) | ((((((v303 >>> 16) + (v302 >>> 16)) | 0) + Math.imul(v300, v301)) | 0) << 1)) + ((((((-1 ^ v306) & (v296 | v278)) | (v296 & v278)) >>> 31) + ((v318 + v279) | 0)) | 0)) | 0)) | 0);
                                                                        const v320 = ((v217 >>> 31) | (v220 << 1));
                                                                        const v321 = ((((((-1 ^ v317) & (v315 | v316)) | (v315 & v316)) >>> 31) + ((((v314 >>> 31) | ((((((v313 >>> 16) + (v312 >>> 16)) | 0) + Math.imul(v310, v311)) | 0) << 1)) + ((((((-1 ^ v316) & (v221 | v307)) | (v221 & v307)) >>> 31) + ((v320 + v319) | 0)) | 0)) | 0)) | 0);
                                                                        const v322 = (v321 ^ v266);
                                                                        const v323 = (65535 & v322);
                                                                        const v324 = (65535 & v141);
                                                                        const v325 = (65535 & v133);
                                                                        const v326 = Math.imul(v325, v324);
                                                                        const v327 = (v133 >>> 16);
                                                                        const v328 = (v141 >>> 16);
                                                                        const v329 = Math.imul(v325, v328);
                                                                        const v330 = ((((Math.imul(v327, v324) + (65535 & v329)) | 0) + (v326 >>> 16)) | 0);
                                                                        const v331 = ((65535 & v326) | (v330 << 16));
                                                                        const v332 = (v331 << 1);
                                                                        const v333 = ((v141 + v133) | 0);
                                                                        const v334 = ((v332 + v333) | 0);
                                                                        const v335 = ((((((-1 ^ v334) & (v332 | v333)) | (v332 & v333)) >>> 31) + ((((v331 >>> 31) | ((((((v330 >>> 16) + (v329 >>> 16)) | 0) + Math.imul(v327, v328)) | 0) << 1)) + ((((((-1 ^ v333) & (v141 | v133)) | (v141 & v133)) >>> 31) + ((v142 + v134) | 0)) | 0)) | 0)) | 0);
                                                                        const v336 = (v335 ^ v158);
                                                                        const v337 = (65535 & v336);
                                                                        const v338 = (65535 & v149);
                                                                        const v339 = Math.imul(v338, v337);
                                                                        const v340 = (v149 >>> 16);
                                                                        const v341 = (v336 >>> 16);
                                                                        const v342 = Math.imul(v338, v341);
                                                                        const v343 = ((((Math.imul(v340, v337) + (65535 & v342)) | 0) + (v339 >>> 16)) | 0);
                                                                        const v344 = ((65535 & v339) | (v343 << 16));
                                                                        const v345 = (v344 << 1);
                                                                        const v346 = ((v336 + v149) | 0);
                                                                        const v347 = ((v345 + v346) | 0);
                                                                        const v348 = (v347 ^ v141);
                                                                        const v349 = (v334 ^ v157);
                                                                        const v350 = ((((((-1 ^ v347) & (v345 | v346)) | (v345 & v346)) >>> 31) + ((((v344 >>> 31) | ((((((v343 >>> 16) + (v342 >>> 16)) | 0) + Math.imul(v340, v341)) | 0) << 1)) + ((((((-1 ^ v346) & (v336 | v149)) | (v336 & v149)) >>> 31) + ((v349 + v150) | 0)) | 0)) | 0)) | 0);
                                                                        const v351 = (v350 ^ v142);
                                                                        const v352 = ((v351 << 8) | (v348 >>> 24));
                                                                        const v353 = (65535 & v352);
                                                                        const v354 = (65535 & v334);
                                                                        const v355 = Math.imul(v354, v353);
                                                                        const v356 = (v334 >>> 16);
                                                                        const v357 = (v352 >>> 16);
                                                                        const v358 = Math.imul(v354, v357);
                                                                        const v359 = ((((Math.imul(v356, v353) + (65535 & v358)) | 0) + (v355 >>> 16)) | 0);
                                                                        const v360 = ((65535 & v355) | (v359 << 16));
                                                                        const v361 = (v360 << 1);
                                                                        const v362 = ((v352 + v334) | 0);
                                                                        const v363 = ((v361 + v362) | 0);
                                                                        const v364 = (v363 ^ v336);
                                                                        const v365 = ((v348 << 8) | (v351 >>> 24));
                                                                        const v366 = ((((((-1 ^ v363) & (v361 | v362)) | (v361 & v362)) >>> 31) + ((((v360 >>> 31) | ((((((v359 >>> 16) + (v358 >>> 16)) | 0) + Math.imul(v356, v357)) | 0) << 1)) + ((((((-1 ^ v362) & (v352 | v334)) | (v352 & v334)) >>> 31) + ((v365 + v335) | 0)) | 0)) | 0)) | 0);
                                                                        const v367 = (v366 ^ v349);
                                                                        const v368 = ((v367 << 16) | (v364 >>> 16));
                                                                        const v369 = (65535 & v368);
                                                                        const v370 = (65535 & v347);
                                                                        const v371 = Math.imul(v370, v369);
                                                                        const v372 = (v347 >>> 16);
                                                                        const v373 = (v368 >>> 16);
                                                                        const v374 = Math.imul(v370, v373);
                                                                        const v375 = ((((Math.imul(v372, v369) + (65535 & v374)) | 0) + (v371 >>> 16)) | 0);
                                                                        const v376 = ((65535 & v371) | (v375 << 16));
                                                                        const v377 = (v376 << 1);
                                                                        const v378 = ((v368 + v347) | 0);
                                                                        const v379 = ((v377 + v378) | 0);
                                                                        const v380 = (65535 & v379);
                                                                        const v381 = Math.imul(v380, v323);
                                                                        const v382 = (v379 >>> 16);
                                                                        const v383 = (v322 >>> 16);
                                                                        const v384 = Math.imul(v380, v383);
                                                                        const v385 = ((((Math.imul(v382, v323) + (65535 & v384)) | 0) + (v381 >>> 16)) | 0);
                                                                        const v386 = ((65535 & v381) | (v385 << 16));
                                                                        const v387 = (v386 << 1);
                                                                        const v388 = ((v322 + v379) | 0);
                                                                        const v389 = ((v387 + v388) | 0);
                                                                        const v390 = (v389 ^ v221);
                                                                        const v391 = ((v364 << 16) | (v367 >>> 16));
                                                                        const v392 = ((((((-1 ^ v379) & (v377 | v378)) | (v377 & v378)) >>> 31) + ((((v376 >>> 31) | ((((((v375 >>> 16) + (v374 >>> 16)) | 0) + Math.imul(v372, v373)) | 0) << 1)) + ((((((-1 ^ v378) & (v368 | v347)) | (v368 & v347)) >>> 31) + ((v391 + v350) | 0)) | 0)) | 0)) | 0);
                                                                        const v393 = ((v264 << 16) | (v265 >>> 16));
                                                                        const v394 = (v317 ^ v393);
                                                                        const v395 = ((((((-1 ^ v389) & (v387 | v388)) | (v387 & v388)) >>> 31) + ((((v386 >>> 31) | ((((((v385 >>> 16) + (v384 >>> 16)) | 0) + Math.imul(v382, v383)) | 0) << 1)) + ((((((-1 ^ v388) & (v322 | v379)) | (v322 & v379)) >>> 31) + ((v394 + v392) | 0)) | 0)) | 0)) | 0);
                                                                        const v396 = (v395 ^ v320);
                                                                        const v397 = ((v396 << 8) | (v390 >>> 24));
                                                                        const v398 = (65535 & v397);
                                                                        const v399 = (65535 & v317);
                                                                        const v400 = Math.imul(v399, v398);
                                                                        const v401 = (v317 >>> 16);
                                                                        const v402 = (v397 >>> 16);
                                                                        const v403 = Math.imul(v399, v402);
                                                                        const v404 = ((((Math.imul(v401, v398) + (65535 & v403)) | 0) + (v400 >>> 16)) | 0);
                                                                        const v405 = ((65535 & v400) | (v404 << 16));
                                                                        const v406 = (v405 << 1);
                                                                        const v407 = ((v397 + v317) | 0);
                                                                        const v408 = ((v406 + v407) | 0);
                                                                        const v409 = ((v390 << 8) | (v396 >>> 24));
                                                                        const v410 = ((((((-1 ^ v408) & (v406 | v407)) | (v406 & v407)) >>> 31) + ((((v405 >>> 31) | ((((((v404 >>> 16) + (v403 >>> 16)) | 0) + Math.imul(v401, v402)) | 0) << 1)) + ((((((-1 ^ v407) & (v397 | v317)) | (v397 & v317)) >>> 31) + ((v409 + v321) | 0)) | 0)) | 0)) | 0);
                                                                        const v411 = (v410 ^ v394);
                                                                        const v412 = (v408 ^ v322);
                                                                        const v413 = ((v412 << 16) | (v411 >>> 16));
                                                                        const v414 = ((v411 << 16) | (v412 >>> 16));
                                                                        const v415 = (65535 & v414);
                                                                        const v416 = (65535 & v389);
                                                                        const v417 = Math.imul(v416, v415);
                                                                        const v418 = (v389 >>> 16);
                                                                        const v419 = (v414 >>> 16);
                                                                        const v420 = Math.imul(v416, v419);
                                                                        const v421 = ((((Math.imul(v418, v415) + (65535 & v420)) | 0) + (v417 >>> 16)) | 0);
                                                                        const v422 = ((65535 & v417) | (v421 << 16));
                                                                        const v423 = (v422 << 1);
                                                                        const v424 = ((v414 + v389) | 0);
                                                                        const v425 = ((v423 + v424) | 0);
                                                                        const v426 = ((((((-1 ^ v425) & (v423 | v424)) | (v423 & v424)) >>> 31) + ((((v422 >>> 31) | ((((((v421 >>> 16) + (v420 >>> 16)) | 0) + Math.imul(v418, v419)) | 0) << 1)) + ((((((-1 ^ v424) & (v414 | v389)) | (v414 & v389)) >>> 31) + ((v413 + v395) | 0)) | 0)) | 0)) | 0);
                                                                        const v427 = (v426 ^ v409);
                                                                        const v428 = (v425 ^ v397);
                                                                        const v429 = ((v428 >>> 31) | (v427 << 1));
                                                                        const v430 = ((v427 >>> 31) | (v428 << 1));
                                                                        const v431 = (v379 ^ v352);
                                                                        const v432 = (v392 ^ v365);
                                                                        const v433 = ((v432 >>> 31) | (v431 << 1));
                                                                        const v434 = (v319 ^ v293);
                                                                        const v435 = (v307 ^ v280);
                                                                        const v436 = ((v435 << 16) | (v434 >>> 16));
                                                                        const v437 = (65535 & v433);
                                                                        const v438 = (65535 & v200);
                                                                        const v439 = Math.imul(v438, v437);
                                                                        const v440 = (v200 >>> 16);
                                                                        const v441 = (v433 >>> 16);
                                                                        const v442 = Math.imul(v438, v441);
                                                                        const v443 = ((((Math.imul(v440, v437) + (65535 & v442)) | 0) + (v439 >>> 16)) | 0);
                                                                        const v444 = ((65535 & v439) | (v443 << 16));
                                                                        const v445 = (v444 << 1);
                                                                        const v446 = ((v433 + v200) | 0);
                                                                        const v447 = ((v445 + v446) | 0);
                                                                        const v448 = ((v431 >>> 31) | (v432 << 1));
                                                                        const v449 = ((((((-1 ^ v447) & (v445 | v446)) | (v445 & v446)) >>> 31) + ((((v444 >>> 31) | ((((((v443 >>> 16) + (v442 >>> 16)) | 0) + Math.imul(v440, v441)) | 0) << 1)) + ((((((-1 ^ v446) & (v433 | v200)) | (v433 & v200)) >>> 31) + ((v448 + v203) | 0)) | 0)) | 0)) | 0);
                                                                        const v450 = (v449 ^ v436);
                                                                        const v451 = (65535 & v450);
                                                                        const v452 = (65535 & v393);
                                                                        const v453 = (65535 & v246);
                                                                        const v454 = Math.imul(v453, v452);
                                                                        const v455 = (v246 >>> 16);
                                                                        const v456 = (v393 >>> 16);
                                                                        const v457 = Math.imul(v453, v456);
                                                                        const v458 = ((((Math.imul(v455, v452) + (65535 & v457)) | 0) + (v454 >>> 16)) | 0);
                                                                        const v459 = ((65535 & v454) | (v458 << 16));
                                                                        const v460 = (v459 << 1);
                                                                        const v461 = ((v393 + v246) | 0);
                                                                        const v462 = ((v460 + v461) | 0);
                                                                        const v463 = (65535 & v462);
                                                                        const v464 = Math.imul(v463, v451);
                                                                        const v465 = (v462 >>> 16);
                                                                        const v466 = (v450 >>> 16);
                                                                        const v467 = Math.imul(v463, v466);
                                                                        const v468 = ((((Math.imul(v465, v451) + (65535 & v467)) | 0) + (v464 >>> 16)) | 0);
                                                                        const v469 = ((65535 & v464) | (v468 << 16));
                                                                        const v470 = (v469 << 1);
                                                                        const v471 = ((v450 + v462) | 0);
                                                                        const v472 = ((v470 + v471) | 0);
                                                                        const v473 = (v472 ^ v433);
                                                                        const v474 = ((((((-1 ^ v462) & (v460 | v461)) | (v460 & v461)) >>> 31) + ((((v459 >>> 31) | ((((((v458 >>> 16) + (v457 >>> 16)) | 0) + Math.imul(v455, v456)) | 0) << 1)) + ((((((-1 ^ v461) & (v393 | v246)) | (v393 & v246)) >>> 31) + ((v266 + v248) | 0)) | 0)) | 0)) | 0);
                                                                        const v475 = ((v434 << 16) | (v435 >>> 16));
                                                                        const v476 = (v447 ^ v475);
                                                                        const v477 = ((((((-1 ^ v472) & (v470 | v471)) | (v470 & v471)) >>> 31) + ((((v469 >>> 31) | ((((((v468 >>> 16) + (v467 >>> 16)) | 0) + Math.imul(v465, v466)) | 0) << 1)) + ((((((-1 ^ v471) & (v450 | v462)) | (v450 & v462)) >>> 31) + ((v476 + v474) | 0)) | 0)) | 0)) | 0);
                                                                        const v478 = (v477 ^ v448);
                                                                        const v479 = ((v478 << 8) | (v473 >>> 24));
                                                                        const v480 = (65535 & v479);
                                                                        const v481 = (65535 & v447);
                                                                        const v482 = Math.imul(v481, v480);
                                                                        const v483 = (v447 >>> 16);
                                                                        const v484 = (v479 >>> 16);
                                                                        const v485 = Math.imul(v481, v484);
                                                                        const v486 = ((((Math.imul(v483, v480) + (65535 & v485)) | 0) + (v482 >>> 16)) | 0);
                                                                        const v487 = ((65535 & v482) | (v486 << 16));
                                                                        const v488 = (v487 << 1);
                                                                        const v489 = ((v479 + v447) | 0);
                                                                        const v490 = ((v488 + v489) | 0);
                                                                        const v491 = ((v473 << 8) | (v478 >>> 24));
                                                                        const v492 = ((((((-1 ^ v490) & (v488 | v489)) | (v488 & v489)) >>> 31) + ((((v487 >>> 31) | ((((((v486 >>> 16) + (v485 >>> 16)) | 0) + Math.imul(v483, v484)) | 0) << 1)) + ((((((-1 ^ v489) & (v479 | v447)) | (v479 & v447)) >>> 31) + ((v491 + v449) | 0)) | 0)) | 0)) | 0);
                                                                        const v493 = (v492 ^ v476);
                                                                        const v494 = (v490 ^ v450);
                                                                        const v495 = ((v494 << 16) | (v493 >>> 16));
                                                                        const v496 = ((v493 << 16) | (v494 >>> 16));
                                                                        const v497 = (65535 & v496);
                                                                        const v498 = (65535 & v472);
                                                                        const v499 = Math.imul(v498, v497);
                                                                        const v500 = (v472 >>> 16);
                                                                        const v501 = (v496 >>> 16);
                                                                        const v502 = Math.imul(v498, v501);
                                                                        const v503 = ((((Math.imul(v500, v497) + (65535 & v502)) | 0) + (v499 >>> 16)) | 0);
                                                                        const v504 = ((65535 & v499) | (v503 << 16));
                                                                        const v505 = (v504 << 1);
                                                                        const v506 = ((v496 + v472) | 0);
                                                                        const v507 = ((v505 + v506) | 0);
                                                                        const v508 = ((((((-1 ^ v507) & (v505 | v506)) | (v505 & v506)) >>> 31) + ((((v504 >>> 31) | ((((((v503 >>> 16) + (v502 >>> 16)) | 0) + Math.imul(v500, v501)) | 0) << 1)) + ((((((-1 ^ v506) & (v496 | v472)) | (v496 & v472)) >>> 31) + ((v495 + v477) | 0)) | 0)) | 0)) | 0);
                                                                        const v509 = (v508 ^ v491);
                                                                        const v510 = (v507 ^ v479);
                                                                        const v511 = ((v510 >>> 31) | (v509 << 1));
                                                                        const v512 = ((v509 >>> 31) | (v510 << 1));
                                                                        const v513 = (v462 ^ v250);
                                                                        const v514 = (v474 ^ v262);
                                                                        const v515 = ((v514 >>> 31) | (v513 << 1));
                                                                        const v516 = (65535 & v515);
                                                                        const v517 = (65535 & v363);
                                                                        const v518 = Math.imul(v517, v516);
                                                                        const v519 = (v363 >>> 16);
                                                                        const v520 = (v515 >>> 16);
                                                                        const v521 = Math.imul(v517, v520);
                                                                        const v522 = ((((Math.imul(v519, v516) + (65535 & v521)) | 0) + (v518 >>> 16)) | 0);
                                                                        const v523 = ((65535 & v518) | (v522 << 16));
                                                                        const v524 = (v523 << 1);
                                                                        const v525 = ((v515 + v363) | 0);
                                                                        const v526 = ((v524 + v525) | 0);
                                                                        const v527 = ((v513 >>> 31) | (v514 << 1));
                                                                        const v528 = ((((((-1 ^ v526) & (v524 | v525)) | (v524 & v525)) >>> 31) + ((((v523 >>> 31) | ((((((v522 >>> 16) + (v521 >>> 16)) | 0) + Math.imul(v519, v520)) | 0) << 1)) + ((((((-1 ^ v525) & (v515 | v363)) | (v515 & v363)) >>> 31) + ((v527 + v366) | 0)) | 0)) | 0)) | 0);
                                                                        const v529 = (v528 ^ v218);
                                                                        const v530 = (65535 & v529);
                                                                        const v531 = (65535 & v475);
                                                                        const v532 = (65535 & v291);
                                                                        const v533 = Math.imul(v532, v531);
                                                                        const v534 = (v291 >>> 16);
                                                                        const v535 = (v475 >>> 16);
                                                                        const v536 = Math.imul(v532, v535);
                                                                        const v537 = ((((Math.imul(v534, v531) + (65535 & v536)) | 0) + (v533 >>> 16)) | 0);
                                                                        const v538 = ((65535 & v533) | (v537 << 16));
                                                                        const v539 = (v538 << 1);
                                                                        const v540 = ((v475 + v291) | 0);
                                                                        const v541 = ((v539 + v540) | 0);
                                                                        const v542 = (65535 & v541);
                                                                        const v543 = Math.imul(v542, v530);
                                                                        const v544 = (v541 >>> 16);
                                                                        const v545 = (v529 >>> 16);
                                                                        const v546 = Math.imul(v542, v545);
                                                                        const v547 = ((((Math.imul(v544, v530) + (65535 & v546)) | 0) + (v543 >>> 16)) | 0);
                                                                        const v548 = ((65535 & v543) | (v547 << 16));
                                                                        const v549 = (v548 << 1);
                                                                        const v550 = ((v529 + v541) | 0);
                                                                        const v551 = ((v549 + v550) | 0);
                                                                        const v552 = (v551 ^ v515);
                                                                        const v553 = ((((((-1 ^ v541) & (v539 | v540)) | (v539 & v540)) >>> 31) + ((((v538 >>> 31) | ((((((v537 >>> 16) + (v536 >>> 16)) | 0) + Math.imul(v534, v535)) | 0) << 1)) + ((((((-1 ^ v540) & (v475 | v291)) | (v475 & v291)) >>> 31) + ((v436 + v294) | 0)) | 0)) | 0)) | 0);
                                                                        const v554 = (v526 ^ v205);
                                                                        const v555 = ((((((-1 ^ v551) & (v549 | v550)) | (v549 & v550)) >>> 31) + ((((v548 >>> 31) | ((((((v547 >>> 16) + (v546 >>> 16)) | 0) + Math.imul(v544, v545)) | 0) << 1)) + ((((((-1 ^ v550) & (v529 | v541)) | (v529 & v541)) >>> 31) + ((v554 + v553) | 0)) | 0)) | 0)) | 0);
                                                                        const v556 = (v555 ^ v527);
                                                                        const v557 = ((v556 << 8) | (v552 >>> 24));
                                                                        const v558 = (65535 & v557);
                                                                        const v559 = (65535 & v526);
                                                                        const v560 = Math.imul(v559, v558);
                                                                        const v561 = (v526 >>> 16);
                                                                        const v562 = (v557 >>> 16);
                                                                        const v563 = Math.imul(v559, v562);
                                                                        const v564 = ((((Math.imul(v561, v558) + (65535 & v563)) | 0) + (v560 >>> 16)) | 0);
                                                                        const v565 = ((65535 & v560) | (v564 << 16));
                                                                        const v566 = (v565 << 1);
                                                                        const v567 = ((v557 + v526) | 0);
                                                                        const v568 = ((v566 + v567) | 0);
                                                                        const v569 = ((v552 << 8) | (v556 >>> 24));
                                                                        const v570 = ((((((-1 ^ v568) & (v566 | v567)) | (v566 & v567)) >>> 31) + ((((v565 >>> 31) | ((((((v564 >>> 16) + (v563 >>> 16)) | 0) + Math.imul(v561, v562)) | 0) << 1)) + ((((((-1 ^ v567) & (v557 | v526)) | (v557 & v526)) >>> 31) + ((v569 + v528) | 0)) | 0)) | 0)) | 0);
                                                                        const v571 = (v570 ^ v554);
                                                                        const v572 = (v568 ^ v529);
                                                                        const v573 = ((v572 << 16) | (v571 >>> 16));
                                                                        const v574 = ((v571 << 16) | (v572 >>> 16));
                                                                        const v575 = (65535 & v574);
                                                                        const v576 = (65535 & v551);
                                                                        const v577 = Math.imul(v576, v575);
                                                                        const v578 = (v551 >>> 16);
                                                                        const v579 = (v574 >>> 16);
                                                                        const v580 = Math.imul(v576, v579);
                                                                        const v581 = ((((Math.imul(v578, v575) + (65535 & v580)) | 0) + (v577 >>> 16)) | 0);
                                                                        const v582 = ((65535 & v577) | (v581 << 16));
                                                                        const v583 = (v582 << 1);
                                                                        const v584 = ((v574 + v551) | 0);
                                                                        const v585 = ((v583 + v584) | 0);
                                                                        const v586 = ((((((-1 ^ v585) & (v583 | v584)) | (v583 & v584)) >>> 31) + ((((v582 >>> 31) | ((((((v581 >>> 16) + (v580 >>> 16)) | 0) + Math.imul(v578, v579)) | 0) << 1)) + ((((((-1 ^ v584) & (v574 | v551)) | (v574 & v551)) >>> 31) + ((v573 + v555) | 0)) | 0)) | 0)) | 0);
                                                                        const v587 = (v586 ^ v569);
                                                                        const v588 = (v585 ^ v557);
                                                                        const v589 = ((v588 >>> 31) | (v587 << 1));
                                                                        const v590 = ((v587 >>> 31) | (v588 << 1));
                                                                        const v591 = (v541 ^ v296);
                                                                        const v592 = (v553 ^ v318);
                                                                        const v593 = ((v592 >>> 31) | (v591 << 1));
                                                                        const v594 = (65535 & v593);
                                                                        const v595 = (65535 & v261);
                                                                        const v596 = Math.imul(v595, v594);
                                                                        const v597 = (v261 >>> 16);
                                                                        const v598 = (v593 >>> 16);
                                                                        const v599 = Math.imul(v595, v598);
                                                                        const v600 = ((((Math.imul(v597, v594) + (65535 & v599)) | 0) + (v596 >>> 16)) | 0);
                                                                        const v601 = ((65535 & v596) | (v600 << 16));
                                                                        const v602 = (v601 << 1);
                                                                        const v603 = ((v593 + v261) | 0);
                                                                        const v604 = ((v602 + v603) | 0);
                                                                        const v605 = ((v591 >>> 31) | (v592 << 1));
                                                                        const v606 = ((((((-1 ^ v604) & (v602 | v603)) | (v602 & v603)) >>> 31) + ((((v601 >>> 31) | ((((((v600 >>> 16) + (v599 >>> 16)) | 0) + Math.imul(v597, v598)) | 0) << 1)) + ((((((-1 ^ v603) & (v593 | v261)) | (v593 & v261)) >>> 31) + ((v605 + v263) | 0)) | 0)) | 0)) | 0);
                                                                        const v607 = (v606 ^ v391);
                                                                        const v608 = (65535 & v607);
                                                                        const v609 = (65535 & v216);
                                                                        const v610 = Math.imul(v609, v608);
                                                                        const v611 = (v216 >>> 16);
                                                                        const v612 = (v607 >>> 16);
                                                                        const v613 = Math.imul(v609, v612);
                                                                        const v614 = ((((Math.imul(v611, v608) + (65535 & v613)) | 0) + (v610 >>> 16)) | 0);
                                                                        const v615 = ((65535 & v610) | (v614 << 16));
                                                                        const v616 = (v615 << 1);
                                                                        const v617 = ((v607 + v216) | 0);
                                                                        const v618 = ((v616 + v617) | 0);
                                                                        const v619 = (v618 ^ v593);
                                                                        const v620 = (v604 ^ v368);
                                                                        const v621 = ((((((-1 ^ v618) & (v616 | v617)) | (v616 & v617)) >>> 31) + ((((v615 >>> 31) | ((((((v614 >>> 16) + (v613 >>> 16)) | 0) + Math.imul(v611, v612)) | 0) << 1)) + ((((((-1 ^ v617) & (v607 | v216)) | (v607 & v216)) >>> 31) + ((v620 + v219) | 0)) | 0)) | 0)) | 0);
                                                                        const v622 = (v621 ^ v605);
                                                                        const v623 = ((v622 << 8) | (v619 >>> 24));
                                                                        const v624 = (65535 & v623);
                                                                        const v625 = (65535 & v604);
                                                                        const v626 = Math.imul(v625, v624);
                                                                        const v627 = (v604 >>> 16);
                                                                        const v628 = (v623 >>> 16);
                                                                        const v629 = Math.imul(v625, v628);
                                                                        const v630 = ((((Math.imul(v627, v624) + (65535 & v629)) | 0) + (v626 >>> 16)) | 0);
                                                                        const v631 = ((65535 & v626) | (v630 << 16));
                                                                        const v632 = (v631 << 1);
                                                                        const v633 = ((v623 + v604) | 0);
                                                                        const v634 = ((v632 + v633) | 0);
                                                                        const v635 = ((v619 << 8) | (v622 >>> 24));
                                                                        const v636 = ((((((-1 ^ v634) & (v632 | v633)) | (v632 & v633)) >>> 31) + ((((v631 >>> 31) | ((((((v630 >>> 16) + (v629 >>> 16)) | 0) + Math.imul(v627, v628)) | 0) << 1)) + ((((((-1 ^ v633) & (v623 | v604)) | (v623 & v604)) >>> 31) + ((v635 + v606) | 0)) | 0)) | 0)) | 0);
                                                                        const v637 = (v636 ^ v620);
                                                                        const v638 = (v634 ^ v607);
                                                                        const v639 = ((v638 << 16) | (v637 >>> 16));
                                                                        const v640 = ((v637 << 16) | (v638 >>> 16));
                                                                        const v641 = (65535 & v640);
                                                                        const v642 = (65535 & v618);
                                                                        const v643 = Math.imul(v642, v641);
                                                                        const v644 = (v618 >>> 16);
                                                                        const v645 = (v640 >>> 16);
                                                                        const v646 = Math.imul(v642, v645);
                                                                        const v647 = ((((Math.imul(v644, v641) + (65535 & v646)) | 0) + (v643 >>> 16)) | 0);
                                                                        const v648 = ((65535 & v643) | (v647 << 16));
                                                                        const v649 = (v648 << 1);
                                                                        const v650 = ((v640 + v618) | 0);
                                                                        const v651 = ((v649 + v650) | 0);
                                                                        const v652 = ((((((-1 ^ v651) & (v649 | v650)) | (v649 & v650)) >>> 31) + ((((v648 >>> 31) | ((((((v647 >>> 16) + (v646 >>> 16)) | 0) + Math.imul(v644, v645)) | 0) << 1)) + ((((((-1 ^ v650) & (v640 | v618)) | (v640 & v618)) >>> 31) + ((v639 + v621) | 0)) | 0)) | 0)) | 0);
                                                                        const v653 = (v652 ^ v635);
                                                                        const v654 = (v651 ^ v623);
                                                                        const v655 = ((v654 >>> 31) | (v653 << 1));
                                                                        const v656 = ((v653 >>> 31) | (v654 << 1));
                                                                        L24: {
                                                                            L25: {
                                                                                if (((((((((v90) | 0) === 0) | 0)) | 0) === 0) | 0)) {
                                                                                    break L25;
                                                                                }
                                                                                const v657 = (((((v128 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v658 = (((((v113 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v659 = (((((v114 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v660 = (((((v115 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v661 = (((((v116 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v662 = (((((v117 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v663 = (((((v118 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v664 = (((((v119 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v665 = (((((v120 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v666 = (((((v121 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v667 = (((((v122 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v668 = (((((v123 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v669 = (((((v124 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v670 = (((((v125 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v671 = (((((v126 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                const v672 = (((((v127 << 3) + (v10 << 10)) | 0) + (Math.imul(v5, v92) << 10)) | 0);
                                                                                memory_i32[(((v657) >>> 0) + 0) >>> 2] = v408;
                                                                                memory_i32[(((v657) >>> 0) + 4) >>> 2] = v410;
                                                                                memory_i32[(((v658) >>> 0) + 0) >>> 2] = v490;
                                                                                memory_i32[(((v658) >>> 0) + 4) >>> 2] = v492;
                                                                                memory_i32[(((v659) >>> 0) + 0) >>> 2] = v568;
                                                                                memory_i32[(((v659) >>> 0) + 4) >>> 2] = v570;
                                                                                memory_i32[(((v660) >>> 0) + 0) >>> 2] = v634;
                                                                                memory_i32[(((v660) >>> 0) + 4) >>> 2] = v636;
                                                                                memory_i32[(((v661) >>> 0) + 0) >>> 2] = v656;
                                                                                memory_i32[(((v661) >>> 0) + 4) >>> 2] = v655;
                                                                                memory_i32[(((v662) >>> 0) + 0) >>> 2] = v430;
                                                                                memory_i32[(((v662) >>> 0) + 4) >>> 2] = v429;
                                                                                memory_i32[(((v663) >>> 0) + 0) >>> 2] = v512;
                                                                                memory_i32[(((v663) >>> 0) + 4) >>> 2] = v511;
                                                                                memory_i32[(((v664) >>> 0) + 0) >>> 2] = v590;
                                                                                memory_i32[(((v664) >>> 0) + 4) >>> 2] = v589;
                                                                                memory_i32[(((v665) >>> 0) + 0) >>> 2] = v585;
                                                                                memory_i32[(((v665) >>> 0) + 4) >>> 2] = v586;
                                                                                memory_i32[(((v666) >>> 0) + 0) >>> 2] = v651;
                                                                                memory_i32[(((v666) >>> 0) + 4) >>> 2] = v652;
                                                                                memory_i32[(((v667) >>> 0) + 0) >>> 2] = v425;
                                                                                memory_i32[(((v667) >>> 0) + 4) >>> 2] = v426;
                                                                                memory_i32[(((v668) >>> 0) + 0) >>> 2] = v507;
                                                                                memory_i32[(((v668) >>> 0) + 4) >>> 2] = v508;
                                                                                memory_i32[(((v669) >>> 0) + 0) >>> 2] = v496;
                                                                                memory_i32[(((v669) >>> 0) + 4) >>> 2] = v495;
                                                                                memory_i32[(((v670) >>> 0) + 0) >>> 2] = v574;
                                                                                memory_i32[(((v670) >>> 0) + 4) >>> 2] = v573;
                                                                                memory_i32[(((v671) >>> 0) + 0) >>> 2] = v640;
                                                                                memory_i32[(((v671) >>> 0) + 4) >>> 2] = v639;
                                                                                memory_i32[(((v672) >>> 0) + 0) >>> 2] = v414;
                                                                                memory_i32[(((v672) >>> 0) + 4) >>> 2] = v413;
                                                                                break L24;
                                                                            }
                                                                            const v673 = ((((((10485760 + (v128 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v674 = ((((((10485760 + (v128 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v675 = memory_i32[(((v673) >>> 0) + 0) >>> 2];
                                                                            const v676 = memory_i32[(((v673) >>> 0) + 4) >>> 2];
                                                                            const v677 = ((((((10485760 + (v113 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v678 = ((((((10485760 + (v113 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v674) >>> 0) + 0) >>> 2] = (v408 ^ v675);
                                                                            memory_i32[(((v674) >>> 0) + 4) >>> 2] = (v410 ^ v676);
                                                                            const v679 = memory_i32[(((v677) >>> 0) + 0) >>> 2];
                                                                            const v680 = memory_i32[(((v677) >>> 0) + 4) >>> 2];
                                                                            const v681 = ((((((10485760 + (v114 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v682 = ((((((10485760 + (v114 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v678) >>> 0) + 0) >>> 2] = (v490 ^ v679);
                                                                            memory_i32[(((v678) >>> 0) + 4) >>> 2] = (v492 ^ v680);
                                                                            const v683 = memory_i32[(((v681) >>> 0) + 0) >>> 2];
                                                                            const v684 = memory_i32[(((v681) >>> 0) + 4) >>> 2];
                                                                            const v685 = ((((((10485760 + (v115 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v686 = ((((((10485760 + (v115 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v682) >>> 0) + 0) >>> 2] = (v568 ^ v683);
                                                                            memory_i32[(((v682) >>> 0) + 4) >>> 2] = (v570 ^ v684);
                                                                            const v687 = memory_i32[(((v685) >>> 0) + 0) >>> 2];
                                                                            const v688 = memory_i32[(((v685) >>> 0) + 4) >>> 2];
                                                                            const v689 = ((((((10485760 + (v116 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v690 = ((((((10485760 + (v116 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v686) >>> 0) + 0) >>> 2] = (v634 ^ v687);
                                                                            memory_i32[(((v686) >>> 0) + 4) >>> 2] = (v636 ^ v688);
                                                                            const v691 = memory_i32[(((v689) >>> 0) + 0) >>> 2];
                                                                            const v692 = memory_i32[(((v689) >>> 0) + 4) >>> 2];
                                                                            const v693 = ((((((10485760 + (v117 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v694 = ((((((10485760 + (v117 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v690) >>> 0) + 0) >>> 2] = (v656 ^ v691);
                                                                            memory_i32[(((v690) >>> 0) + 4) >>> 2] = (v655 ^ v692);
                                                                            const v695 = memory_i32[(((v693) >>> 0) + 0) >>> 2];
                                                                            const v696 = memory_i32[(((v693) >>> 0) + 4) >>> 2];
                                                                            const v697 = ((((((10485760 + (v118 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v698 = ((((((10485760 + (v118 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v694) >>> 0) + 0) >>> 2] = (v430 ^ v695);
                                                                            memory_i32[(((v694) >>> 0) + 4) >>> 2] = (v429 ^ v696);
                                                                            const v699 = memory_i32[(((v697) >>> 0) + 0) >>> 2];
                                                                            const v700 = memory_i32[(((v697) >>> 0) + 4) >>> 2];
                                                                            const v701 = ((((((10485760 + (v119 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v702 = ((((((10485760 + (v119 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v698) >>> 0) + 0) >>> 2] = (v512 ^ v699);
                                                                            memory_i32[(((v698) >>> 0) + 4) >>> 2] = (v511 ^ v700);
                                                                            const v703 = memory_i32[(((v701) >>> 0) + 0) >>> 2];
                                                                            const v704 = memory_i32[(((v701) >>> 0) + 4) >>> 2];
                                                                            const v705 = ((((((10485760 + (v120 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v706 = ((((((10485760 + (v120 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v702) >>> 0) + 0) >>> 2] = (v590 ^ v703);
                                                                            memory_i32[(((v702) >>> 0) + 4) >>> 2] = (v589 ^ v704);
                                                                            const v707 = memory_i32[(((v705) >>> 0) + 0) >>> 2];
                                                                            const v708 = memory_i32[(((v705) >>> 0) + 4) >>> 2];
                                                                            const v709 = ((((((10485760 + (v121 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v710 = ((((((10485760 + (v121 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v706) >>> 0) + 0) >>> 2] = (v585 ^ v707);
                                                                            memory_i32[(((v706) >>> 0) + 4) >>> 2] = (v586 ^ v708);
                                                                            const v711 = memory_i32[(((v709) >>> 0) + 0) >>> 2];
                                                                            const v712 = memory_i32[(((v709) >>> 0) + 4) >>> 2];
                                                                            const v713 = ((((((10485760 + (v122 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v714 = ((((((10485760 + (v122 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v710) >>> 0) + 0) >>> 2] = (v651 ^ v711);
                                                                            memory_i32[(((v710) >>> 0) + 4) >>> 2] = (v652 ^ v712);
                                                                            const v715 = memory_i32[(((v713) >>> 0) + 0) >>> 2];
                                                                            const v716 = memory_i32[(((v713) >>> 0) + 4) >>> 2];
                                                                            const v717 = ((((((10485760 + (v123 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v718 = ((((((10485760 + (v123 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v714) >>> 0) + 0) >>> 2] = (v425 ^ v715);
                                                                            memory_i32[(((v714) >>> 0) + 4) >>> 2] = (v426 ^ v716);
                                                                            const v719 = memory_i32[(((v717) >>> 0) + 0) >>> 2];
                                                                            const v720 = memory_i32[(((v717) >>> 0) + 4) >>> 2];
                                                                            const v721 = ((((((10485760 + (v124 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v722 = ((((((10485760 + (v124 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v718) >>> 0) + 0) >>> 2] = (v507 ^ v719);
                                                                            memory_i32[(((v718) >>> 0) + 4) >>> 2] = (v508 ^ v720);
                                                                            const v723 = memory_i32[(((v721) >>> 0) + 0) >>> 2];
                                                                            const v724 = memory_i32[(((v721) >>> 0) + 4) >>> 2];
                                                                            const v725 = ((((((10485760 + (v125 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v726 = ((((((10485760 + (v125 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v722) >>> 0) + 0) >>> 2] = (v496 ^ v723);
                                                                            memory_i32[(((v722) >>> 0) + 4) >>> 2] = (v495 ^ v724);
                                                                            const v727 = memory_i32[(((v725) >>> 0) + 0) >>> 2];
                                                                            const v728 = memory_i32[(((v725) >>> 0) + 4) >>> 2];
                                                                            const v729 = ((((((10485760 + (v126 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v730 = ((((((10485760 + (v126 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v726) >>> 0) + 0) >>> 2] = (v574 ^ v727);
                                                                            memory_i32[(((v726) >>> 0) + 4) >>> 2] = (v573 ^ v728);
                                                                            const v731 = memory_i32[(((v729) >>> 0) + 0) >>> 2];
                                                                            const v732 = memory_i32[(((v729) >>> 0) + 4) >>> 2];
                                                                            const v733 = ((((((10485760 + (v127 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            const v734 = ((((((10485760 + (v127 << 3)) | 0) + (v17 << 10)) | 0) + (Math.imul(v11, v10) << 10)) | 0);
                                                                            memory_i32[(((v730) >>> 0) + 0) >>> 2] = (v640 ^ v731);
                                                                            memory_i32[(((v730) >>> 0) + 4) >>> 2] = (v639 ^ v732);
                                                                            const v735 = memory_i32[(((v733) >>> 0) + 0) >>> 2];
                                                                            const v736 = memory_i32[(((v733) >>> 0) + 4) >>> 2];
                                                                            memory_i32[(((v734) >>> 0) + 0) >>> 2] = (v414 ^ v735);
                                                                            memory_i32[(((v734) >>> 0) + 4) >>> 2] = (v413 ^ v736);
                                                                        }
                                                                        s35 = v96;
                                                                    }
                                                                    const v96 = s35;
                                                                    const v737 = ((1 + v96) | 0);
                                                                    if (((((v737) >>> 0) < ((8) >>> 0)) | 0)) {
                                                                        s34 = v737;
                                                                        continue L22;
                                                                    }
                                                                    s34 = v737;
                                                                    break L22;
                                                                }
                                                                const v95 = s34;
                                                                s33 = v95;
                                                            }
                                                            const v94 = s33;
                                                            s32 = v94;
                                                        }
                                                        s31 = v90;
                                                    }
                                                    const v90 = s31;
                                                    const v738 = ((1 + v90) | 0);
                                                    if (((((v738) >>> 0) < ((2) >>> 0)) | 0)) {
                                                        s30 = v738;
                                                        continue L18;
                                                    }
                                                    s30 = v738;
                                                    break L18;
                                                }
                                                const v89 = s30;
                                                s29 = v89;
                                            }
                                            const v88 = s29;
                                            s28 = v88;
                                        }
                                        s7 = v15;
                                    }
                                    const v15 = s7;
                                    const v739 = ((1 + v15) | 0);
                                    if (((((v739) >>> 0) < ((v2) >>> 0)) | 0)) {
                                        s6 = v739;
                                        continue L6;
                                    }
                                    s6 = v739;
                                    break L6;
                                }
                                const v14 = s6;
                                s5 = v14;
                            }
                            const v13 = s5;
                            s4 = v13;
                        }
                        s3 = v9;
                    }
                    const v9 = s3;
                    const v740 = ((1 + v9) | 0);
                    if (((((v740) >>> 0) < ((v1) >>> 0)) | 0)) {
                        s2 = v740;
                        continue L2;
                    }
                    s2 = v740;
                    break L2;
                }
                const v8 = s2;
                s1 = v8;
            }
            const v7 = s1;
            s0 = v7;
        }
        return;
    }
    function getAddresses(v0, v1, v2, v3, v4, v5, v6, v7, v8, v9) {
        const v10 = ((((((10240) >>> 0) / (((v9) >>> 0)))) >>> 0));
        const v11 = memory_i32[2621450];
        const v12 = memory_i32[2621440];
        const v13 = memory_i32[2621444];
        const v14 = (((((((v13) >>> 0) < ((2) >>> 0)) | 0) & ((((v12) | 0) === 0) | 0)) & ((((v11) | 0) === ((2) | 0)) | 0)) | ((((v11) | 0) === ((1) | 0)) | 0));
        const v15 = ((((((v12) | 0) === 0) | 0)) ? (Math.imul(v4, v13)) : (((v3 - v4) | 0)));
        const v16 = (((((v13) | 0) === 0) | 0) & ((((v12) | 0) === 0) | 0));
        const v17 = (((((((v13) | 0) !== ((3) | 0)) | 0) & ((((v12) | 0) !== ((0) | 0)) | 0))) ? (Math.imul(((1 + v13) | 0), v4)) : (0));
        const v18 = memory_i32[2621442];
        let s0 = 0;
        L0: {
            const v19 = s0;
            if (((((((((v19) >>> 0) < ((v2) >>> 0)) | 0)) | 0) === 0) | 0)) {
                s0 = v19;
                break L0;
            }
            let s1 = v19;
            L1: {
                const v20 = s1;
                let s2 = v20;
                L2: for (;;) {
                    const v21 = s2;
                    let s3 = v21;
                    L3: {
                        const v22 = s3;
                        const v23 = ((v22 + v5) | 0);
                        const v24 = ((v23 - 1) | 0);
                        const v25 = ((((((v14) | 0) === 0) | 0)) ? (((v22 + v7) | 0)) : (2));
                        const v26 = ((((((v14) | 0) === 0) | 0)) ? (0) : (((((((v23) >>> 0) % (((128) >>> 0)))) >>> 0))));
                        L4: {
                            if ((((((((((((v23) | 0) === ((2) | 0)) | 0) & v16) | ((((v26) | 0) === 0) | 0)) & ((((v14) | 0) === ((1) | 0)) | 0))) | 0) === 0) | 0)) {
                                break L4;
                            }
                            let s4 = 0;
                            L5: {
                                const v27 = s4;
                                if (((((((((v27) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                    s4 = v27;
                                    break L5;
                                }
                                let s5 = v27;
                                L6: {
                                    const v28 = s5;
                                    let s6 = v28;
                                    L7: for (;;) {
                                        const v29 = s6;
                                        let s7 = v29;
                                        L8: {
                                            const v30 = s7;
                                            const v31 = ((v30 + v0) | 0);
                                            const v32 = ((10485808 + (Math.imul(v10, v31) << 10)) | 0);
                                            const v33 = ((10485808 + (Math.imul(v10, v31) << 10)) | 0);
                                            const v34 = memory_i32[(((v32) >>> 0) + 0) >>> 2];
                                            const v35 = memory_i32[(((v32) >>> 0) + 4) >>> 2];
                                            const v36 = ((1 + v34) | 0);
                                            memory_i32[(((((((21012480 + (v31 << 2)) | 0) + (v9 << 2)) | 0)) >>> 0) + 0) >>> 2] = 1;
                                            memory_i32[(((((((21012480 + (v31 << 2)) | 0) + (v9 << 3)) | 0)) >>> 0) + 0) >>> 2] = 2;
                                            memory.fill(0, (((((((v30 + v0) | 0) << 10) + (v9 << 10)) | 0)) >>> 0), (((((((v30 + v0) | 0) << 10) + (v9 << 10)) | 0)) >>> 0) + 1024);
                                            memory.fill(0, (((((((v30 + v0) | 0) << 10) + (v9 << 11)) | 0)) >>> 0), (((((((v30 + v0) | 0) << 10) + (v9 << 11)) | 0)) >>> 0) + 1024);
                                            memory_i32[(((v33) >>> 0) + 0) >>> 2] = v36;
                                            memory_i32[(((v33) >>> 0) + 4) >>> 2] = ((((((-1 ^ v36) & (1 | v34)) | (1 & v34)) >>> 31) + v35) | 0);
                                            s7 = v30;
                                        }
                                        const v30 = s7;
                                        const v37 = ((1 + v30) | 0);
                                        if (((((v37) >>> 0) < ((v1) >>> 0)) | 0)) {
                                            s6 = v37;
                                            continue L7;
                                        }
                                        s6 = v37;
                                        break L7;
                                    }
                                    const v29 = s6;
                                    s5 = v29;
                                }
                                const v28 = s5;
                                s4 = v28;
                            }
                            compress(v0, v1, 2, 0, 0, v9);
                        }
                        const v38 = Math.imul(v4, v13);
                        const v39 = ((v8 + v38) | 0);
                        const v40 = ((v5 + v38) | 0);
                        let s8 = 0;
                        L9: {
                            const v41 = s8;
                            if (((((((((v41) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
                                s8 = v41;
                                break L9;
                            }
                            let s9 = v41;
                            L10: {
                                const v42 = s9;
                                let s10 = v42;
                                L11: for (;;) {
                                    const v43 = s10;
                                    let s11 = v43;
                                    L12: {
                                        const v44 = s11;
                                        const v45 = ((v44 + v0) | 0);
                                        const v46 = ((v44 + v18) | 0);
                                        const v47 = ((((((10485760 + (v26 << 3)) | 0) + (v25 << 10)) | 0) + (Math.imul(v10, v45) << 10)) | 0);
                                        const v48 = memory_i32[(((v47) >>> 0) + 4) >>> 2];
                                        const v49 = (((((((v13) | 0) === 0) | 0) & ((((v12) | 0) === 0) | 0))) ? (v46) : (((((((v48) >>> 0) % (((v6) >>> 0)))) >>> 0))));
                                        const v50 = (((((((v13) | 0) === 0) | 0) & ((((v12) | 0) === 0) | 0))) ? (v24) : (((((((((((v49) | 0) === ((v46) | 0)) | 0)) | 0) === 0) | 0)) ? (((((((v23) | 0) === 0) | 0)) ? (((v15 - 1) | 0)) : (v15))) : (((v24 + v15) | 0)))));
                                        const v51 = memory_i32[(((v47) >>> 0) + 0) >>> 2];
                                        const v52 = (v51 >>> 16);
                                        const v53 = (v51 >>> 16);
                                        const v54 = (65535 & v51);
                                        const v55 = Math.imul(v54, v52);
                                        const v56 = (65535 & v51);
                                        const v57 = (((((((((Math.imul(v53, v56) + (65535 & v55)) | 0) + (Math.imul(v54, v56) >>> 16)) | 0) >>> 16) + (v55 >>> 16)) | 0) + Math.imul(v53, v52)) | 0);
                                        const v58 = (v57 >>> 16);
                                        const v59 = (v50 >>> 16);
                                        const v60 = (65535 & v50);
                                        const v61 = Math.imul(v60, v58);
                                        const v62 = (65535 & v57);
                                        const v63 = ((((((((((((v50 - 1) | 0) - (((((((((Math.imul(v59, v62) + (65535 & v61)) | 0) + (Math.imul(v60, v62) >>> 16)) | 0) >>> 16) + (v61 >>> 16)) | 0) + Math.imul(v59, v58)) | 0)) | 0) + v17) | 0)) >>> 0) % (((v3) >>> 0)))) >>> 0));
                                        memory_i32[(((((((20971520 + (v45 << 2)) | 0) + (Math.imul(v9, v22) << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v63 + Math.imul(v49, v3)) | 0);
                                        const v64 = ((v22 + ((1 + v7) | 0)) | 0);
                                        const v65 = ((1 + ((((v63 - v38) | 0) - v5) | 0)) | 0);
                                        memory_i32[(((((((21012480 + (v45 << 2)) | 0) + (Math.imul(v9, v64) << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((((v65) >>> 0) < ((((1 + v22) | 0)) >>> 0)) | 0) & ((((v49) | 0) === ((v46) | 0)) | 0))) ? (((v65 + v7) | 0)) : (((((((((v63) >>> 0) < ((v40) >>> 0)) | 0) & ((((v63) >>> 0) >= ((v39) >>> 0)) | 0)) & ((((v49) | 0) === ((v46) | 0)) | 0))) ? (((((v63 - v39) | 0) + 4) | 0)) : (v64))));
                                        s11 = v44;
                                    }
                                    const v44 = s11;
                                    const v66 = ((1 + v44) | 0);
                                    if (((((v66) >>> 0) < ((v1) >>> 0)) | 0)) {
                                        s10 = v66;
                                        continue L11;
                                    }
                                    s10 = v66;
                                    break L11;
                                }
                                const v43 = s10;
                                s9 = v43;
                            }
                            const v42 = s9;
                            s8 = v42;
                        }
                        s3 = v22;
                    }
                    const v22 = s3;
                    const v67 = ((1 + v22) | 0);
                    if (((((v67) >>> 0) < ((v2) >>> 0)) | 0)) {
                        s2 = v67;
                        continue L2;
                    }
                    s2 = v67;
                    break L2;
                }
                const v21 = s2;
                s1 = v21;
            }
            const v20 = s1;
            s0 = v20;
        }
        return;
    }
    const instance = { exports: { compress: compress, getAddresses: getAddresses, memory: { buffer: __buf } } };
    ;
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 21053440);
    const segments = Object.freeze({ refBlocks: new Uint8Array(memoryExport.buffer, 0, 10485760),
        refBlocks_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 10485760, 10485760))),
        inputBlocks: new Uint8Array(memoryExport.buffer, 10485760, 10485760),
        inputBlocks_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10485760 + i * 10485760, 10485760))),
        indices: new Uint8Array(memoryExport.buffer, 20971520, 40960),
        indices_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 20971520 + i * 40960, 40960))),
        refIndices: new Uint8Array(memoryExport.buffer, 21012480, 40960),
        refIndices_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 21012480 + i * 40960, 40960)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments });
}
let _cache;
export default function argon(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
