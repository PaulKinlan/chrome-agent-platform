export default function sha1(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=sha1.d.ts.map