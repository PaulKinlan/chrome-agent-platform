export default function chacha(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=chacha12.d.ts.map