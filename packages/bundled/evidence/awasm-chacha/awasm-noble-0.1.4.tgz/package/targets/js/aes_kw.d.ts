export default function aes_kw(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=aes_kw.d.ts.map