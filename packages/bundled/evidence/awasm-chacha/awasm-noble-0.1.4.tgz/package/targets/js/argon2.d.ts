export default function argon(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=argon2.d.ts.map