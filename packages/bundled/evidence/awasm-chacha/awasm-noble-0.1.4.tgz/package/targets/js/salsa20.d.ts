export default function salsa(_imports: {} | undefined, pool: any): any;
//# sourceMappingURL=salsa20.d.ts.map