// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 81, maximum: 81, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABUwxgAn9/AX9gAAF/YAF/AGADf39/AX9gBH9/f38Ef39/f2AEf39/fwBgAABgA39/fwBgA39/fwN/f39gAn9/An9/YAV/f39/fwV/f39/f2ABfwF/AlkEA2VudgdfbWVtb3J5AgNRUQNlbnYUX3dvcmtlcl9ub3RpZnlCcmlkZ2UAAANlbnYUX3dvcmtlcl9vbmxpbmVCcmlkZ2UAAQNlbnYLaW5pdFdvcmtlcnMAAgMPDgABAwQEBQIFAgYHAgIAB9ABDwZtZW1vcnkCAA5fd29ya2VyX25vdGlmeQADDl93b3JrZXJfb25saW5lAAQKYWRkUGFkZGluZwAFC2Flc0Jsb2NrRGVjAAYLYWVzQmxvY2tFbmMABw1kZWNyeXB0QmxvY2tzAAgLZGVjcnlwdEluaXQACQ1lbmNyeXB0QmxvY2tzAAoLZW5jcnlwdEluaXQACwppbml0VGFibGVzAAwKaW5pdFdvcmtlcgANBXJlc2V0AA4Kc3RvcFdvcmtlcgAPDXZlcmlmeVBhZGRpbmcAEAqaPg7iAQEQf0EAIAFBAAIIIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCCCEHIQYhBSAFIAYgBwMIIQohCSEIIAggCSAKAgghDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAz8ACaiAA/hcCACALQYAGbEGAz8ACakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACCSEBIQAgACABIABBH0lFDQAaGiAAIAECCSEDIQIgAiADAwkhBSEEIAQgBQIJIQchBiAGQQFqIghBgAZsQYDNwAJq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQscAEEAQabNmrV6NgKwSEEAQabNmrV6NgK0SEEAC60JAUN/QQAoAoAEIQRBACgCICEFQQAoAiQhBkEAKAIoIQdBACgCLCEIIARBAWshCUEAIAAgBXMgASAGcyACIAdzIAMgCHMCCiEOIQ0hDCELIQogCiALIAwgDSAOAwohEyESIREhECEPIA9BAWohFCAPQQFqQQJ0IhVBAnRBIGooAgAhFiAQQf8BcUECdEGQKGooAgAhFyATQQh2Qf8BcUECdEGQMGooAgAhGCASQRB2Qf8BcUECdEGQOGooAgAhGSARQRh2Qf8BcUECdEGQwABqKAIAIRogFiAXIBhzIBkgGnNzcyEbIBVBAWpBAnRBIGooAgAhHCARQf8BcUECdEGQKGooAgAhHSAQQQh2Qf8BcUECdEGQMGooAgAhHiATQRB2Qf8BcUECdEGQOGooAgAhHyASQRh2Qf8BcUECdEGQwABqKAIAISAgHCAdIB5zIB8gIHNzcyEhIBVBAmpBAnRBIGooAgAhIiASQf8BcUECdEGQKGooAgAhIyARQQh2Qf8BcUECdEGQMGooAgAhJCAQQRB2Qf8BcUECdEGQOGooAgAhJSATQRh2Qf8BcUECdEGQwABqKAIAISYgIiAjICRzICUgJnNzcyEnIBVBA2pBAnRBIGooAgAhKCATQf8BcUECdEGQKGooAgAhKSASQQh2Qf8BcUECdEGQMGooAgAhKiARQRB2Qf8BcUECdEGQOGooAgAhKyAQQRh2Qf8BcUECdEGQwABqKAIAISwgKCApICpzICsgLHNzcyEtIBQgGyAhICcgLSAUIAlJDQAaGhoaGiAUIBsgISAnIC0LIRMhEiERIRAhDyAPIBAgESASIBMLIQ4hDSEMIQshCiAEQQJ0Ii5BAnRBIGooAgAhLyAOQQh2Qf8BcUGQJmotAAAhMCANQRB2Qf8BcUGQJmotAAAhMSAMQRh2Qf8BcUGQJmotAAAhMiALQf8BcUGQJmotAAAhMyAuQQFqQQJ0QSBqKAIAITQgC0EIdkH/AXFBkCZqLQAAITUgDkEQdkH/AXFBkCZqLQAAITYgDUEYdkH/AXFBkCZqLQAAITcgDEH/AXFBkCZqLQAAITggLkECakECdEEgaigCACE5IAxBCHZB/wFxQZAmai0AACE6IAtBEHZB/wFxQZAmai0AACE7IA5BGHZB/wFxQZAmai0AACE8IA1B/wFxQZAmai0AACE9IC5BA2pBAnRBIGooAgAhPiANQQh2Qf8BcUGQJmotAAAhPyAMQRB2Qf8BcUGQJmotAAAhQCALQRh2Qf8BcUGQJmotAAAhQSAOQf8BcUGQJmotAAAhQkEAIC8gM0H/AXEgMEH/AXFBCHRyIDFB/wFxQRB0IDJB/wFxQRh0cnJzNgKQAkEAIDQgOEH/AXEgNUH/AXFBCHRyIDZB/wFxQRB0IDdB/wFxQRh0cnJzNgKUAkEAIDkgPUH/AXEgOkH/AXFBCHRyIDtB/wFxQRB0IDxB/wFxQRh0cnJzNgKYAkEAID4gQkH/AXEgP0H/AXFBCHRyIEBB/wFxQRB0IEFB/wFxQRh0cnJzNgKcAkEAKAKQAiFDQQAoApQCIURBACgCmAIhRUEAKAKcAiFGIEMgRCBFIEYLqQkBQ39BACgCgAQhBEEAKAIgIQVBACgCJCEGQQAoAighB0EAKAIsIQggBEEBayEJQQAgACAFcyABIAZzIAIgB3MgAyAIcwIKIQ4hDSEMIQshCiAKIAsgDCANIA4DCiETIRIhESEQIQ8gD0EBaiEUIA9BAWpBAnQiFUECdEEgaigCACEWIBBB/wFxQQJ0QZAGaigCACEXIBFBCHZB/wFxQQJ0QZAOaigCACEYIBJBEHZB/wFxQQJ0QZAWaigCACEZIBNBGHZB/wFxQQJ0QZAeaigCACEaIBYgFyAYcyAZIBpzc3MhGyAVQQFqQQJ0QSBqKAIAIRwgEUH/AXFBAnRBkAZqKAIAIR0gEkEIdkH/AXFBAnRBkA5qKAIAIR4gE0EQdkH/AXFBAnRBkBZqKAIAIR8gEEEYdkH/AXFBAnRBkB5qKAIAISAgHCAdIB5zIB8gIHNzcyEhIBVBAmpBAnRBIGooAgAhIiASQf8BcUECdEGQBmooAgAhIyATQQh2Qf8BcUECdEGQDmooAgAhJCAQQRB2Qf8BcUECdEGQFmooAgAhJSARQRh2Qf8BcUECdEGQHmooAgAhJiAiICMgJHMgJSAmc3NzIScgFUEDakECdEEgaigCACEoIBNB/wFxQQJ0QZAGaigCACEpIBBBCHZB/wFxQQJ0QZAOaigCACEqIBFBEHZB/wFxQQJ0QZAWaigCACErIBJBGHZB/wFxQQJ0QZAeaigCACEsICggKSAqcyArICxzc3MhLSAUIBsgISAnIC0gFCAJSQ0AGhoaGhogFCAbICEgJyAtCyETIRIhESEQIQ8gDyAQIBEgEiATCyEOIQ0hDCELIQogBEECdCIuQQJ0QSBqKAIAIS8gDEEIdkH/AXFBkARqLQAAITAgDUEQdkH/AXFBkARqLQAAITEgDkEYdkH/AXFBkARqLQAAITIgC0H/AXFBkARqLQAAITMgLkEBakECdEEgaigCACE0IA1BCHZB/wFxQZAEai0AACE1IA5BEHZB/wFxQZAEai0AACE2IAtBGHZB/wFxQZAEai0AACE3IAxB/wFxQZAEai0AACE4IC5BAmpBAnRBIGooAgAhOSAOQQh2Qf8BcUGQBGotAAAhOiALQRB2Qf8BcUGQBGotAAAhOyAMQRh2Qf8BcUGQBGotAAAhPCANQf8BcUGQBGotAAAhPSAuQQNqQQJ0QSBqKAIAIT4gC0EIdkH/AXFBkARqLQAAIT8gDEEQdkH/AXFBkARqLQAAIUAgDUEYdkH/AXFBkARqLQAAIUEgDkH/AXFBkARqLQAAIUJBACAvIDNB/wFxIDBB/wFxQQh0ciAxQf8BcUEQdCAyQf8BcUEYdHJyczYCkAJBACA0IDhB/wFxIDVB/wFxQQh0ciA2Qf8BcUEQdCA3Qf8BcUEYdHJyczYClAJBACA5ID1B/wFxIDpB/wFxQQh0ciA7Qf8BcUEQdCA8Qf8BcUEYdHJyczYCmAJBACA+IEJB/wFxID9B/wFxQQh0ciBAQf8BcUEQdCBBQf8BcUEYdHJyczYCnAJBACgCkAIhQ0EAKAKUAiFEQQAoApgCIUVBACgCnAIhRiBDIEQgRSBGC7wCARt/QQYgAEEBayIFbCAFIANBf0YiBBshBiAAQQFrIQdBACgCsEghCEEAKAK0SCEJQQAgCCAJIAVBBmwgAyAEG0EAAgohDiENIQwhCyEKIAogCyAMIA0gDgMKIRMhEiERIRAhDyAPQQFqIRQgByATa0EDdEGwyABqIhUoAgAhFiAVQQRqKAIAIRcgECARIBJB/wFxQRh0IBJBgP4DcUEIdHIgEkGAgPwHcUEIdiASQRh2cnJzIBYgFxAGIRghGSEaIRsgFSAZNgIAIBVBBGogGDYCACASQQFrIRxBACATQQFqIh0gHSAHRhshHiAUIBsgGiAcIB4gFCAGSQ0AGhoaGhogFCAbIBogHCAeCyETIRIhESEQIQ8gDyAQIBEgEiATCyEOIQ0hDCELIQpBACALNgKwSEEAIAw2ArRIC5oOAU1/EAxBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgshBSAFIAUgA0lFDQAaIAUCCyEGIAYDCyEHIAcCCyEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACCyERIBEgESAQSUUNABogEQILIRIgEgMLIRMgEwILIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBkARqLQAAIRkgGEEQdkH/AXFBkARqLQAAIRogGEEYdkH/AXFBkARqLQAAIRsgGEH/AXFBkARqLQAAIRwgFSADbkEBa0GQyABqLQAAIR0gFkEIdkH/AXFBkARqLQAAIR4gFkEQdkH/AXFBkARqLQAAIR8gFkEYdkH/AXFBkARqLQAAISAgFkH/AXFBkARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgshJCAkICQgD0lFDQAaICQCCyElICUDCyEmICYCCyEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJEEAAgshKiAqICogD0lFDQAaICoCCyErICsDCyEsICwCCyEtIC1BAnRBIGooAgAhLiAtQQJ0QZACaiAuNgIAIC0LIS0gLUEBaiEvIC8gLyAPSQ0AGiAvCyEsICwLISsgKwshKkEAKAKABCEwIDBBAWohMUEAAgshMiAyIDIgMUlFDQAaIDICCyEzIDMDCyE0IDQCCyE1IDFBAWsgNWtBAnQiNkECdEGQAmooAgAhNyA1QQJ0IjhBAnRBIGogNzYCACA2QQFqQQJ0QZACaigCACE5IDhBAWpBAnRBIGogOTYCACA2QQJqQQJ0QZACaigCACE6IDhBAmpBAnRBIGogOjYCACA2QQNqQQJ0QZACaigCACE7IDhBA2pBAnRBIGogOzYCACA1CyE1IDVBAWohPCA8IDwgMUkNABogPAshNCA0CyEzIDMLITIgD0EIayE9QQACCyE+ID4gPiA9SUUNABogPgILIT8gPwMLIUAgQAILIUEgQUEEaiJCQQJ0QSBqKAIAIUMgQ0EIdkH/AXFBkARqLQAAIUQgQ0EQdkH/AXFBkARqLQAAIUUgQ0EYdkH/AXFBkARqLQAAIUYgQ0H/AXFBkARqLQAAIUcgR0H/AXEgREH/AXFBCHRyIEVB/wFxQRB0IEZB/wFxQRh0cnIiSEEAdkH/AXFBAnRBkChqKAIAIUkgSEEIdkH/AXFBAnRBkDBqKAIAIUogSEEQdkH/AXFBAnRBkDhqKAIAIUsgSEEYdkH/AXFBAnRBkMAAaigCACFMIEJBAnRBIGogSSBKcyBLIExzczYCACBBCyFBIEFBAWohTSBNIE0gPUkNABogTQshQCBACyE/ID8LIT4LvQIBHH9BBiAAQQFrIgVsIAUgA0F/RiIEGyEGIABBAWshB0EAKAKwSCEIQQAoArRIIQlBACAIIAlBASADIAQbQQACCiEOIQ0hDCELIQogCiALIAwgDSAOAwohEyESIREhECEPIA9BAWohFCATQQFqQQN0QbDIAGoiFSgCACEWIBVBBGooAgAhFyAQIBEgFiAXEAchGCEZIRohGyAVIBk2AgAgFUEEaiAYNgIAIBogEkH/AXFBGHQgEkGA/gNxQQh0ciASQYCA/AdxQQh2IBJBGHZycnMhHCASQQFqIR1BACATQQFqIh4gHiAHRhshHyAUIBsgHCAdIB8gFCAGSQ0AGhoaGhogFCAbIBwgHSAfCyETIRIhESEQIQ8gDyAQIBEgEiATCyEOIQ0hDCELIQpBACALNgKwSEEAIAw2ArRIC50JASl/EAxBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgshBSAFIAUgA0lFDQAaIAUCCyEGIAYDCyEHIAcCCyEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACCyERIBEgESAQSUUNABogEQILIRIgEgMLIRMgEwILIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBkARqLQAAIRkgGEEQdkH/AXFBkARqLQAAIRogGEEYdkH/AXFBkARqLQAAIRsgGEH/AXFBkARqLQAAIRwgFSADbkEBa0GQyABqLQAAIR0gFkEIdkH/AXFBkARqLQAAIR4gFkEQdkH/AXFBkARqLQAAIR8gFkEYdkH/AXFBkARqLQAAISAgFkH/AXFBkARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgshJCAkICQgD0lFDQAaICQCCyElICUDCyEmICYCCyEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJAuKCgE9f0EAKAKgSCEAAgYgAEEARkUNAEEAQQECCSECIQEgASACAwkhBCEDIANBAWohBSAEIARBAXQgBEEHdkEBcUEbbHNB/wFxcyEGIANBkAZqIARB/wFxOgAAIAUgBiAFQYACSQ0AGhogBSAGCyEEIQMgAyAECyECIQFBAEHjAEH/AXE6AJAEQQACCyEHIAcgB0H/AUlFDQAaIAcCCyEIIAgDCyEJIAkCCyEKQf8BIAprQZAGai0AACELIApBkAZqLQAAIQ4gDkH/AXFBkARqIAtB/wFxIgwgDEEIdHIiDSANQQR2cyANQQV2cyANQQZ2cyANQQd2c0HjAHNB/wFxQf8BcToAACAKCyEKIApBAWohDyAPIA9B/wFJDQAaIA8LIQkgCQshCCAICyEHQQACCyEQIBAgEEGAAklFDQAaIBACCyERIBEDCyESIBICCyETIBNBkCZqQQBB/wFxOgAAIBMLIRMgE0EBaiEUIBQgFEGAAkkNABogFAshEiASCyERIBELIRBBAAILIRUgFSAVQYACSUUNABogFQILIRYgFgMLIRcgFwILIRggGEGQBGotAAAhGSAZQf8BcUGQJmogGEH/AXE6AAAgGAshGCAYQQFqIRogGiAaQYACSQ0AGiAaCyEXIBcLIRYgFgshFUEAQQECCSEcIRsgGyAcAwkhHiEdIB1BAWohHyAeQQF0IB5BB3ZBAXFBG2xzQf8BcSEgIB1BkMgAaiAeQf8BcToAACAfICAgH0EQSQ0AGhogHyAgCyEeIR0gHSAeCyEcIRtBAAILISEgISAhQYACSUUNABogIQILISIgIgMLISMgIwILISQgJEGQBGotAAAhJSAkQZAmai0AACEnICRBAnRBkAZqICVB/wFxIiYgJkEBdCAmQQd2QQFxQRtsc0H/AXFzQRh0ICZBEHQgJkEIdCAmQQF0ICZBB3ZBAXFBG2xzQf8BcXJycjYCACAkQQJ0QZAoaiAnQf8BcSIoIChBAXQgKEEHdkEBcUEbbHNB/wFxIitzICtBAXQgK0EHdkEBcUEbbHNB/wFxIixBAXQgLEEHdkEBcUEbbHNB/wFxc0EYdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIi1BAXQgLUEHdkEBcUEbbHNB/wFxIi5zIC5BAXQgLkEHdkEBcUEbbHNB/wFxc0EQdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIilBAXQgKUEHdkEBcUEbbHNB/wFxIipBAXQgKkEHdkEBcUEbbHNB/wFxc0EIdCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIvIC9BAXQgL0EHdkEBcUEbbHNB/wFxIjBzIDBBAXQgMEEHdkEBcUEbbHNB/wFxc3JycjYCACAkCyEkICRBAWohMSAxIDFBgAJJDQAaIDELISMgIwshIiAiCyEhQQACCyEyIDIgMkGAAklFDQAaIDICCyEzIDMDCyE0IDQCCyE1IDVBAnRBkAZqKAIAITYgNUECdEGQDmogNkEIdyI3NgIAIDVBAnRBkBZqIDdBCHciODYCACA1QQJ0QZAeaiA4QQh3NgIAIDVBAnRBkChqKAIAITkgNUECdEGQMGogOUEIdyI6NgIAIDVBAnRBkDhqIDpBCHciOzYCACA1QQJ0QZDAAGogO0EIdzYCACA1CyE1IDVBAWohPCA8IDxBgAJJDQAaIDwLITQgNAshMyAzCyEyQQBBATYCoEgLC3wBBH8gAEGABmxBgM7AAmohAyAAQYAGbEGAz8ACaiEEIABBgAZsQYDNwAJqQQH+FwIAAgYCBiABRQ0ADAELAgYDBiAEQQD+QQIAIQUCBiAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCyADQQH+FwIAIAINAUEBDQALCwsLFwBBAEEAQYQE/AsAQbDIAEEAIAD8CwALFAAgAEGABmxBgM3AAmpBAP4XAgALMwEDf0EAKAKwSCECQQAoArRIIQMgAUEBakEAIAJBps2atXpHIANBps2atXpHchshBCAECw=='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 5277328);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 516),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 516, 516))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 272 + i * 240, 240))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 512 + i * 4, 4))),
        constants: new Uint8Array(memoryExport.buffer, 528, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 528, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 528, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 784, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 784 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1808, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1808 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2832, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2832 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3856, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3856 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 4880, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4880, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5136, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5136 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6160, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6160 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7184, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7184 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8208, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8208 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9232, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9232 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9248, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9248 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9264, 5242880),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9264 + i * 5242880, 5242880))),
        _worker: new Uint8Array(memoryExport.buffer, 5252224, 25104),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252224 + i * 25104, 25104))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 5252224, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252224 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 5252352, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252352 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 5252480, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252480 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 5252608, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252608 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 5252736, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5252736 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 5277312, 4),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5277312 + i * 4, 4)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function aes_kw(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
