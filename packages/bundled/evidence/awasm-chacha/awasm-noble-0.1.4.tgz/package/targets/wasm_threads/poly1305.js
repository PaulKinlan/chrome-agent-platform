// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 591, maximum: 591, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABYg1gAn9/AX9gAAF/YAF/AGAIf39/f39/f38AYAZ/f39/f38AYAN/f38AYAV/f39/fwBgBn9/f39/fwF/YAF/AX9gA39/fwN/f39gAn9/An9/YAAAYAZ/f39/f38Gf39/f39/AlsEA2VudgdfbWVtb3J5AgPPBM8EA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAw8OAwQAAQUGAgIFBwMEBgIH5QEPBm1lbW9yeQIAGV9wcm9jZXNzQmxvY2tzX3RocmVhZF9pbnQAAxxfcHJvY2Vzc091dEJsb2Nrc190aHJlYWRfaW50AAQOX3dvcmtlcl9ub3RpZnkABQ5fd29ya2VyX29ubGluZQAGCmluaXRXb3JrZXIABwttYWNCbG9ja3NBdAAICW1hY0ZpbmlzaAAJB21hY0luaXQACghtYWNQYWRBdAALB3BhZGRpbmcADA1wcm9jZXNzQmxvY2tzAA0QcHJvY2Vzc091dEJsb2NrcwAOBXJlc2V0AA8Kc3RvcFdvcmtlcgAQCttlDvECARp/IAAgAWohCCAIIAFBBHBrIQkgAAIIIQogCiAKIAlJRQ0AGiAKAgghCyALAwghDCAMAgghDSACIAdrIQ5BAAIIIQ8gDyAPQQRJRQ0AGiAPAgghECAQAwghESARAgghEiANIBJqIhMgEyADIARsbCAOIAUgBhAIIBILIRIgEkEBaiEUIBQgFEEESQ0AGiAUCyERIBELIRAgEAshDyANCyENIA1BBGohFSAVIBUgCUkNABogFQshDCAMCyELIAsLIQogCQIIIRYgFiAWIAhJRQ0AGiAWAgghFyAXAwghGCAYAgghGSACIAdrIRpBAAIIIRsgGyAbQQFJRQ0AGiAbAgghHCAcAwghHSAdAgghHiAZIB5qIh8gHyADIARsbCAaIAUgBhAIIB4LIR4gHkEBaiEgICAgIEEBSQ0AGiAgCyEdIB0LIRwgHAshGyAZCyEZIBlBAWohISAhICEgCEkNABogIQshGCAYCyEXIBcLIRYLzQUBMH8gACABaiEGIAYgAUEEcGshByAAAgghCCAIIAggB0lFDQAaIAgCCCEJIAkDCCEKIAoCCCELQQACCCEMIAwgDEEESUUNABogDAIIIQ0gDQMIIQ4gDgIIIQ8gCyAPaiEQIBAQCSAQQfAGbEHgBmooAgAhESAQQfAGbEHkBmooAgAhEiAQQfAGbEHoBmooAgAhEyAQQfAGbEHsBmooAgAhFEEAAgghFSAVIBUgAklFDQAaIBUCCCEWIBYDCCEXIBcCCCEYIBAgA2xBBHQgGEEEdEGAgJgRamoiGSARNgIAIBlBBGoiGiASNgIAIBpBBGoiGyATNgIAIBtBBGogFDYCACAYCyEYIBhBAWohHCAcIBwgAkkNABogHAshFyAXCyEWIBYLIRUgDwshDyAPQQFqIR0gHSAdQQRJDQAaIB0LIQ4gDgshDSANCyEMIAsLIQsgC0EEaiEeIB4gHiAHSQ0AGiAeCyEKIAoLIQkgCQshCCAHAgghHyAfIB8gBklFDQAaIB8CCCEgICADCCEhICECCCEiQQACCCEjICMgI0EBSUUNABogIwIIISQgJAMIISUgJQIIISYgIiAmaiEnICcQCSAnQfAGbEHgBmooAgAhKCAnQfAGbEHkBmooAgAhKSAnQfAGbEHoBmooAgAhKiAnQfAGbEHsBmooAgAhK0EAAgghLCAsICwgAklFDQAaICwCCCEtIC0DCCEuIC4CCCEvICcgA2xBBHQgL0EEdEGAgJgRamoiMCAoNgIAIDBBBGoiMSApNgIAIDFBBGoiMiAqNgIAIDJBBGogKzYCACAvCyEvIC9BAWohMyAzIDMgAkkNABogMwshLiAuCyEtIC0LISwgJgshJiAmQQFqITQgNCA0QQFJDQAaIDQLISUgJQshJCAkCyEjICILISIgIkEBaiE1IDUgNSAGSQ0AGiA1CyEhICELISAgIAshHwviAQEQf0EAIAFBAAIJIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCCSEHIQYhBSAFIAYgBwMJIQohCSEIIAggCSAKAgkhDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAhrgSaiAA/hcCACALQYAGbEGAhrgSakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACCiEBIQAgACABIABBH0lFDQAaGiAAIAECCiEDIQIgAiADAwohBSEEIAQgBQIKIQchBiAGQQFqIghBgAZsQYCEuBJq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQvuAgESfyAAQYAGbEGAhbgSaiEDIABBgAZsQYCGuBJqIQQgAEGABmxBgIS4EmpBAf4XAgACCwILIAFFDQAMAQsCCwMLIARBAP5BAgAhBQILIAVFIAJBAUdxRQ0AIARBAEJ//gECACEGDAELAgsgBUEBRkUNAEEAKAKAxLkSIQdBACgChMS5EiEIQQAoAojEuRIhCUEAKAKMxLkSIQpBACgCkMS5EiELIABBgAZsQYCHuBJq/hACACEMIABBgAZsQYCIuBJq/hACACENIABBgAZsQYCJuBJq/hACACEOIAwgDSAOIAcgCCAJIAogCxADCwILIAVBAkZFDQBBACgCgMS5EiEPQQAoAoTEuRIhEEEAKAKIxLkSIREgAEGABmxBgIe4Emr+EAIAIRIgAEGABmxBgIi4Emr+EAIAIRMgAEGABmxBgIm4Emr+EAIAIRQgEiATIBQgDyAQIBEQBAsgA0EB/hcCACACDQFBAQ0ACwsLC68kB0l/C344fzZ+J38LfgV/IABB8AZsQdAAaigCACEFIABB8AZsQdgAaigCACEGIABB8AZsQeAAaigCACEHIABB8AZsQegAaigCACEIIABB8AZsQfAAaigCACEJIABB8AZsQaABaigCACEKIABB8AZsQagBaigCACELIABB8AZsQbABaigCACEMIABB8AZsQbgBaigCACENIABB8AZsQcABaigCACEOIABB8AZsQfABaigCACEPIABB8AZsQfgBaigCACEQIABB8AZsQYACaigCACERIABB8AZsQYgCaigCACESIABB8AZsQZACaigCACETIABB8AZsQcACaigCACEUIABB8AZsQcgCaigCACEVIABB8AZsQdACaigCACEWIABB8AZsQdgCaigCACEXIABB8AZsQeACaigCACEYIABB8AZsQZgDaigCACEZIABB8AZsQaADaigCACEaIABB8AZsQagDaigCACEbIABB8AZsQbADaigCACEcIABB8AZsQegDaigCACEdIABB8AZsQfADaigCACEeIABB8AZsQfgDaigCACEfIABB8AZsQYAEaigCACEgIABB8AZsQbgEaigCACEhIABB8AZsQcAEaigCACEiIABB8AZsQcgEaigCACEjIABB8AZsQdAEaigCACEkIABB8AZsQYgFaigCACElIABB8AZsQZAFaigCACEmIABB8AZsQZgFaigCACEnIABB8AZsQaAFaigCACEoIABB8AZsQdAFaigCACEpIABB8AZsQdgFaigCACEqIABB8AZsQeAFaigCACErIABB8AZsQegFaigCACEsIABB8AZsQfAFaigCACEtAgsgAkEESSADIARBAEdxckUNAAILIAJBAEdFDQAgAEHwBmxB0AVqKAIAIS4gAEHwBmxB2AVqKAIAIS8gAEHwBmxB4AVqKAIAITAgAEHwBmxB6AVqKAIAITEgAEHwBmxB8AVqKAIAITJBACAuIC8gMCAxIDICDCE4ITchNiE1ITQhMyAzIDQgNSA2IDcgOAMMIT4hPSE8ITshOiE5IDlBAWohPyABQQR2IDlqQQR0QYCAmBFqIkAoAgAhQSBAQQRqIkIoAgAhQyBCQQRqIkQoAgAhRSBEQQRqKAIAIUYgQEEANgIAIEBBBGoiR0EANgIAIEdBBGoiSEEANgIAIEhBBGpBADYCACA6IEFBAHZB////H3FqIkmtIBStfiA7IEFBGnYgQ0EGdHJB////H3FqIkqtICitfnwgPCBDQRR2IEVBDHRyQf///x9xaiJLrSAnrX58ID0gRUEOdiBGQRJ0ckH///8fcWoiTK0gJq1+fCA+IEZBCHZBAEGAgIAIIAMgOUEBaiACRiAEQQBHcXEbckH///8fcWoiTa0gJa1+fCJOQv///x+DIk9C////H4MgTkIaiCBPQhqIfCBJrSAVrX4gSq0gFK1+fCBLrSAorX58IEytICetfnwgTa0gJq1+fHwiUEIaiCBQQv///x+DIlFCGoh8IEmtIBatfiBKrSAVrX58IEutIBStfnwgTK0gKK1+fCBNrSAnrX58fCJSQhqIIFJC////H4MiU0IaiHwgSa0gF61+IEqtIBatfnwgS60gFa1+fCBMrSAUrX58IE2tICitfnx8IlRCGoggVEL///8fgyJVQhqIfCBJrSAYrX4gSq0gF61+fCBLrSAWrX58IEytIBWtfnwgTa0gFK1+fHwiVkIaiCBWQv///x+DIldCGoh8QgV+fCJYQv///x+DpyFZIFFC////H4MgWEIaiHynIVogU0L///8fg6chWyBVQv///x+DpyFcIFdC////H4OnIV0gPyBZIFogWyBcIF0gPyACSQ0AGhoaGhoaID8gWSBaIFsgXCBdCyE+IT0hPCE7ITohOSA5IDogOyA8ID0gPgshOCE3ITYhNSE0ITMgAEHwBmxB0AVqIDStNwMAIABB8AZsQdgFaiA1rTcDACAAQfAGbEHgBWogNq03AwAgAEHwBmxB6AVqIDetNwMAIABB8AZsQfAFaiA4rTcDAAsLAgsgAkECdkEARyADQQBGIARBAEZycUUNACACQQJ2IV5BACApICogKyAsIC0CDCFkIWMhYiFhIWAhXyBfIGAgYSBiIGMgZAMMIWohaSFoIWchZiFlIGVBAWohayABQQR2IGVBAnQibGpBBHRBgICYEWoibSgCACFuIG1BBGoibygCACFwIG9BBGoicSgCACFyIHFBBGooAgAhcyBtQQA2AgAgbUEEaiJ0QQA2AgAgdEEEaiJ1QQA2AgAgdUEEakEANgIAIAFBBHYgbEEBampBBHRBgICYEWoidigCACF3IHZBBGoieCgCACF5IHhBBGoieigCACF7IHpBBGooAgAhfCB2QQA2AgAgdkEEaiJ9QQA2AgAgfUEEaiJ+QQA2AgAgfkEEakEANgIAIAFBBHYgbEECampBBHRBgICYEWoifygCACGAASB/QQRqIoEBKAIAIYIBIIEBQQRqIoMBKAIAIYQBIIMBQQRqKAIAIYUBIH9BADYCACB/QQRqIoYBQQA2AgAghgFBBGoihwFBADYCACCHAUEEakEANgIAIAFBBHYgbEEDampBBHRBgICYEWoiiAEoAgAhiQEgiAFBBGoiigEoAgAhiwEgigFBBGoijAEoAgAhjQEgjAFBBGooAgAhjgEgiAFBADYCACCIAUEEaiKPAUEANgIAII8BQQRqIpABQQA2AgAgkAFBBGpBADYCACBmIG5BAHZB////H3FqrSKRASAFrSKSAX4gZyBuQRp2IHBBBnRyQf///x9xaq0ikwEgHK0inAF+fCBoIHBBFHYgckEMdHJB////H3FqrSKVASAbrSKaAX58IGkgckEOdiBzQRJ0ckH///8fcWqtIpgBIBqtIpcBfnwgaiBzQQh2QYCAgAhyQf///x9xaq0imwEgGa1+fCB3QQB2Qf///x9xrSKdASAKrSKeAX4gd0EadiB5QQZ0ckH///8fca0inwEgIK0iqAF+fCB5QRR2IHtBDHRyQf///x9xrSKhASAfrSKmAX58IHtBDnYgfEESdHJB////H3GtIqQBIB6tIqMBfnwgfEEIdkGAgIAIckH///8fca0ipwEgHa1+fHwggAFBAHZB////H3GtIqkBIA+tIqoBfiCAAUEadiCCAUEGdHJB////H3GtIqsBICStIrQBfnwgggFBFHYghAFBDHRyQf///x9xrSKtASAjrSKyAX58IIQBQQ52IIUBQRJ0ckH///8fca0isAEgIq0irwF+fCCFAUEIdkGAgIAIckH///8fca0iswEgIa1+fCCJAUEAdkH///8fca0itQEgFK0itgF+IIkBQRp2IIsBQQZ0ckH///8fca0itwEgKK0iwAF+fCCLAUEUdiCNAUEMdHJB////H3GtIrkBICetIr4BfnwgjQFBDnYgjgFBEnRyQf///x9xrSK8ASAmrSK7AX58II4BQQh2QYCAgAhyQf///x9xrSK/ASAlrX58fHwiwQFC////H4MgkQEgCa1+IJMBIAitIpkBfnwglQEgB60ilgF+fCCYASAGrSKUAX58IJsBIJIBfnwgnQEgDq1+IJ8BIA2tIqUBfnwgoQEgDK0iogF+fCCkASALrSKgAX58IKcBIJ4Bfnx8IKkBIBOtfiCrASASrSKxAX58IK0BIBGtIq4BfnwgsAEgEK0irAF+fCCzASCqAX58ILUBIBitfiC3ASAXrSK9AX58ILkBIBatIroBfnwgvAEgFa0iuAF+fCC/ASC2AX58fHwgkQEgmQF+IJMBIJYBfnwglQEglAF+fCCYASCSAX58IJsBIJwBfnwgnQEgpQF+IJ8BIKIBfnwgoQEgoAF+fCCkASCeAX58IKcBIKgBfnx8IKkBILEBfiCrASCuAX58IK0BIKwBfnwgsAEgqgF+fCCzASC0AX58ILUBIL0BfiC3ASC6AX58ILkBILgBfnwgvAEgtgF+fCC/ASDAAX58fHwgkQEglgF+IJMBIJQBfnwglQEgkgF+fCCYASCcAX58IJsBIJoBfnwgnQEgogF+IJ8BIKABfnwgoQEgngF+fCCkASCoAX58IKcBIKYBfnx8IKkBIK4BfiCrASCsAX58IK0BIKoBfnwgsAEgtAF+fCCzASCyAX58ILUBILoBfiC3ASC4AX58ILkBILYBfnwgvAEgwAF+fCC/ASC+AX58fHwgkQEglAF+IJMBIJIBfnwglQEgnAF+fCCYASCaAX58IJsBIJcBfnwgnQEgoAF+IJ8BIJ4BfnwgoQEgqAF+fCCkASCmAX58IKcBIKMBfnx8IKkBIKwBfiCrASCqAX58IK0BILQBfnwgsAEgsgF+fCCzASCvAX58ILUBILgBfiC3ASC2AX58ILkBIMABfnwgvAEgvgF+fCC/ASC7AX58fHwgwQFCGoh8IsIBQhqIfCLDAUIaiHwixAFCGoh8IsUBQhqIQgV+fCLGAUL///8fg6chxwEgwgFC////H4MgxgFCGoh8pyHIASDDAUL///8fg6chyQEgxAFC////H4OnIcoBIMUBQv///x+DpyHLASBrIMcBIMgBIMkBIMoBIMsBIGsgXkkNABoaGhoaGiBrIMcBIMgBIMkBIMoBIMsBCyFqIWkhaCFnIWYhZSBlIGYgZyBoIGkgagshZCFjIWIhYSFgIV8gAEHwBmxB0AVqIGCtNwMAIABB8AZsQdgFaiBhrTcDACAAQfAGbEHgBWogYq03AwAgAEHwBmxB6AVqIGOtNwMAIABB8AZsQfAFaiBkrTcDACACQQNxIcwBAgsgzAFBAEdFDQAgXkECdCHNAQILIMwBQQBHRQ0AIABB8AZsQdAFaigCACHOASAAQfAGbEHYBWooAgAhzwEgAEHwBmxB4AVqKAIAIdABIABB8AZsQegFaigCACHRASAAQfAGbEHwBWooAgAh0gFBACDOASDPASDQASDRASDSAQIMIdgBIdcBIdYBIdUBIdQBIdMBINMBINQBINUBINYBINcBINgBAwwh3gEh3QEh3AEh2wEh2gEh2QEg2QFBAWoh3wEgAUEEdiDNASDZAWpqQQR0QYCAmBFqIuABKAIAIeEBIOABQQRqIuIBKAIAIeMBIOIBQQRqIuQBKAIAIeUBIOQBQQRqKAIAIeYBIOABQQA2AgAg4AFBBGoi5wFBADYCACDnAUEEaiLoAUEANgIAIOgBQQRqQQA2AgAg2gEg4QFBAHZB////H3FqIukBrSAUrX4g2wEg4QFBGnYg4wFBBnRyQf///x9xaiLqAa0gKK1+fCDcASDjAUEUdiDlAUEMdHJB////H3FqIusBrSAnrX58IN0BIOUBQQ52IOYBQRJ0ckH///8fcWoi7AGtICatfnwg3gEg5gFBCHZBAEGAgIAIIAMg2QFBAWogzAFGIARBAEdxcRtyQf///x9xaiLtAa0gJa1+fCLuAUL///8fgyLvAUL///8fgyDuAUIaiCDvAUIaiHwg6QGtIBWtfiDqAa0gFK1+fCDrAa0gKK1+fCDsAa0gJ61+fCDtAa0gJq1+fHwi8AFCGogg8AFC////H4Mi8QFCGoh8IOkBrSAWrX4g6gGtIBWtfnwg6wGtIBStfnwg7AGtICitfnwg7QGtICetfnx8IvIBQhqIIPIBQv///x+DIvMBQhqIfCDpAa0gF61+IOoBrSAWrX58IOsBrSAVrX58IOwBrSAUrX58IO0BrSAorX58fCL0AUIaiCD0AUL///8fgyL1AUIaiHwg6QGtIBitfiDqAa0gF61+fCDrAa0gFq1+fCDsAa0gFa1+fCDtAa0gFK1+fHwi9gFCGogg9gFC////H4Mi9wFCGoh8QgV+fCL4AUL///8fg6ch+QEg8QFC////H4Mg+AFCGoh8pyH6ASDzAUL///8fg6ch+wEg9QFC////H4OnIfwBIPcBQv///x+DpyH9ASDfASD5ASD6ASD7ASD8ASD9ASDfASDMAUkNABoaGhoaGiDfASD5ASD6ASD7ASD8ASD9AQsh3gEh3QEh3AEh2wEh2gEh2QEg2QEg2gEg2wEg3AEg3QEg3gELIdgBIdcBIdYBIdUBIdQBIdMBIABB8AZsQdAFaiDUAa03AwAgAEHwBmxB2AVqINUBrTcDACAAQfAGbEHgBWog1gGtNwMAIABB8AZsQegFaiDXAa03AwAgAEHwBmxB8AVqINgBrTcDAAsLCwvuAwIcfwN+IABB8AZsQdAFaigCACEBIABB8AZsQdgFaigCACECIABB8AZsQeAFaigCACEDIABB8AZsQegFaigCACEEIABB8AZsQfAFaigCACEFIABB8AZsQaAGaigCACEZIABB8AZsQagGaigCACEaIABB8AZsQbAGaigCACEbIABB8AZsQbgGaigCACEcIABB8AZsQeAGaiABIAUgBCADIAJBGnZqIgZBGnZqIghBGnZqIgpBGnZBBWxqIgxB////H3EiDSAKQf///x9xIgsgCEH///8fcSIJIAZB////H3EiByACQf///x9xIAxBGnZqIg4gDUEFaiIPQRp2aiIQQRp2aiIRQRp2aiISQRp2akGAgIAgayITQR92QQFrIhRBf3MiFXEgD0H///8fcSAUcXIgDiAVcSAQQf///x9xIBRxciIWQRp0cq0gGa18Ih2nNgIAIABB8AZsQeQGaiAWQQZ2IAcgFXEgEUH///8fcSAUcXIiF0EUdHKtIBqtfCAdQiCIfCIepzYCACAAQfAGbEHoBmogF0EMdiAJIBVxIBJB////H3EgFHFyIhhBDnRyrSAbrXwgHkIgiHwiH6c2AgAgAEHwBmxB7AZqIBhBEnYgCyAVcSATIBRxckEIdHKtIBytfCAfQiCIfKc2AgALqRoHLX8LfgV/C34Ffwt+DH8gAEHwBmxBwQBqLQAAIQEgAEHwBmxBwgBqLQAAIQIgAEHwBmxBwwBqLQAAIQMgAEHwBmxBwABqLQAAIQQgAEHwBmxBxQBqLQAAIQUgAEHwBmxBxgBqLQAAIQYgAEHwBmxBxwBqLQAAIQcgAEHwBmxBxABqLQAAIQggAEHwBmxByQBqLQAAIQkgAEHwBmxBygBqLQAAIQogAEHwBmxBywBqLQAAIQsgAEHwBmxByABqLQAAIQwgAEHwBmxBzQBqLQAAIQ0gAEHwBmxBzgBqLQAAIQ4gAEHwBmxBzwBqLQAAIQ8gAEHwBmxBzABqLQAAIRAgAEHwBmxBM2otAAAhESAAQfAGbEE3ai0AACESIABB8AZsQTtqLQAAIRMgAEHwBmxBP2otAAAhFCAAQfAGbEE0ai0AACEVIABB8AZsQThqLQAAIRYgAEHwBmxBPGotAAAhFyAAQfAGbEExai0AACEYIABB8AZsQTJqLQAAIRkgAEHwBmxBMGotAAAhGiAAQfAGbEE1ai0AACEcIABB8AZsQTZqLQAAIR0gAEHwBmxBOWotAAAhHyAAQfAGbEE6ai0AACEgIABB8AZsQT1qLQAAISIgAEHwBmxBPmotAAAhIyAAQfAGbEHAAmogGkH/AXEgGEH/AXFBCHQgGUH/AXFBEHRyciARQf8BcUEPcUEYdHIiG0EAdkH///8fcSIlrTcDACAAQfAGbEHwAWogJa0gJa1+IBtBGnYgFUH/AXFB/AFxIBxB/wFxQQh0IB1B/wFxQRB0cnIgEkH/AXFBD3FBGHRyIh5BBnRyQf///x9xIiatIBdB/wFxQfwBcSAiQf8BcUEIdCAjQf8BcUEQdHJyIBRB/wFxQQ9xQRh0ciIkQQh2Qf///x9xIilBBWwiLa1+fCAeQRR2IBZB/wFxQfwBcSAfQf8BcUEIdCAgQf8BcUEQdHJyIBNB/wFxQQ9xQRh0ciIhQQx0ckH///8fcSInrSAhQQ52ICRBEnRyQf///x9xIihBBWwiLK1+fCAorSAnQQVsIiutfnwgKa0gJkEFbCIqrX58Ii5C////H4MiL0L///8fgyAuQhqIIC9CGoh8ICWtICatfiAmrSAlrX58ICetIC2tfnwgKK0gLK1+fCAprSArrX58fCIwQhqIIDBC////H4MiMUIaiHwgJa0gJ61+ICatICatfnwgJ60gJa1+fCAorSAtrX58ICmtICytfnx8IjJCGoggMkL///8fgyIzQhqIfCAlrSAorX4gJq0gJ61+fCAnrSAmrX58ICitICWtfnwgKa0gLa1+fHwiNEIaiCA0Qv///x+DIjVCGoh8ICWtICmtfiAmrSAorX58ICetICetfnwgKK0gJq1+fCAprSAlrX58fCI2QhqIIDZC////H4MiN0IaiHxCBX58IjhC////H4OnIjmtNwMAIABB8AZsQaABaiA5rSAlrX4gMUL///8fgyA4QhqIfKciOq0gLa1+fCAzQv///x+DpyI7rSAsrX58IDVC////H4OnIjytICutfnwgN0L///8fg6ciPa0gKq1+fCI+Qv///x+DIj9C////H4MgPkIaiCA/QhqIfCA5rSAmrX4gOq0gJa1+fCA7rSAtrX58IDytICytfnwgPa0gK61+fHwiQEIaiCBAQv///x+DIkFCGoh8IDmtICetfiA6rSAmrX58IDutICWtfnwgPK0gLa1+fCA9rSAsrX58fCJCQhqIIEJC////H4MiQ0IaiHwgOa0gKK1+IDqtICetfnwgO60gJq1+fCA8rSAlrX58ID2tIC2tfnx8IkRCGoggREL///8fgyJFQhqIfCA5rSAprX4gOq0gKK1+fCA7rSAnrX58IDytICatfnwgPa0gJa1+fHwiRkIaiCBGQv///x+DIkdCGoh8QgV+fCJIQv///x+DpyJJrTcDACAAQfAGbEHQAGogSa0gJa1+IEFC////H4MgSEIaiHynIkqtIC2tfnwgQ0L///8fg6ciS60gLK1+fCBFQv///x+DpyJMrSArrX58IEdC////H4OnIk2tICqtfnwiTkL///8fgyJPQv///x+DIE5CGoggT0IaiHwgSa0gJq1+IEqtICWtfnwgS60gLa1+fCBMrSAsrX58IE2tICutfnx8IlBCGoggUEL///8fgyJRQhqIfCBJrSAnrX4gSq0gJq1+fCBLrSAlrX58IEytIC2tfnwgTa0gLK1+fHwiUkIaiCBSQv///x+DIlNCGoh8IEmtICitfiBKrSAnrX58IEutICatfnwgTK0gJa1+fCBNrSAtrX58fCJUQhqIIFRC////H4MiVUIaiHwgSa0gKa1+IEqtICitfnwgS60gJ61+fCBMrSAmrX58IE2tICWtfnx8IlZCGoggVkL///8fgyJXQhqIfEIFfnwiWEL///8fg6ciWa03AwAgAEHwBmxBgAVqICVBBWytNwMAIABB8AZsQbAEaiA5QQVsrTcDACAAQfAGbEHgA2ogSUEFbK03AwAgAEHwBmxBkANqIFlBBWytNwMAIABB8AZsQcgCaiAmrTcDACAAQfAGbEH4AWogOq03AwAgAEHwBmxBqAFqIEqtNwMAIABB8AZsQdgAaiBRQv///x+DIFhCGoh8pyJarTcDACAAQfAGbEGIBWogJkEFbK03AwAgAEHwBmxBuARqIDpBBWytNwMAIABB8AZsQegDaiBKQQVsrTcDACAAQfAGbEGYA2ogWkEFbK03AwAgAEHwBmxB0AJqICetNwMAIABB8AZsQYACaiA7rTcDACAAQfAGbEGwAWogS603AwAgAEHwBmxB4ABqIFNC////H4OnIlutNwMAIABB8AZsQZAFaiAnQQVsrTcDACAAQfAGbEHABGogO0EFbK03AwAgAEHwBmxB8ANqIEtBBWytNwMAIABB8AZsQaADaiBbQQVsrTcDACAAQfAGbEHYAmogKK03AwAgAEHwBmxBiAJqIDytNwMAIABB8AZsQbgBaiBMrTcDACAAQfAGbEHoAGogVUL///8fg6ciXK03AwAgAEHwBmxBmAVqIChBBWytNwMAIABB8AZsQcgEaiA8QQVsrTcDACAAQfAGbEH4A2ogTEEFbK03AwAgAEHwBmxBqANqIFxBBWytNwMAIABB8AZsQeACaiAprTcDACAAQfAGbEGQAmogPa03AwAgAEHwBmxBwAFqIE2tNwMAIABB8AZsQfAAaiBXQv///x+DpyJdrTcDACAAQfAGbEGgBWogKUEFbK03AwAgAEHwBmxB0ARqID1BBWytNwMAIABB8AZsQYAEaiBNQQVsrTcDACAAQfAGbEGwA2ogXUEFbK03AwAgAEHwBmxB+ABqQgA3AwAgAEHwBmxByAFqQgA3AwAgAEHwBmxBmAJqQgA3AwAgAEHwBmxB6AJqQgA3AwAgAEHwBmxBuANqQgA3AwAgAEHwBmxBiARqQgA3AwAgAEHwBmxB2ARqQgA3AwAgAEHwBmxBqAVqQgA3AwAgAEHwBmxBgAFqQgA3AwAgAEHwBmxB0AFqQgA3AwAgAEHwBmxBoAJqQgA3AwAgAEHwBmxB8AJqQgA3AwAgAEHwBmxBwANqQgA3AwAgAEHwBmxBkARqQgA3AwAgAEHwBmxB4ARqQgA3AwAgAEHwBmxBsAVqQgA3AwAgAEHwBmxBiAFqQgA3AwAgAEHwBmxB2AFqQgA3AwAgAEHwBmxBqAJqQgA3AwAgAEHwBmxB+AJqQgA3AwAgAEHwBmxByANqQgA3AwAgAEHwBmxBmARqQgA3AwAgAEHwBmxB6ARqQgA3AwAgAEHwBmxBuAVqQgA3AwAgAEHwBmxBkAFqQgA3AwAgAEHwBmxB4AFqQgA3AwAgAEHwBmxBsAJqQgA3AwAgAEHwBmxBgANqQgA3AwAgAEHwBmxB0ANqQgA3AwAgAEHwBmxBoARqQgA3AwAgAEHwBmxB8ARqQgA3AwAgAEHwBmxBwAVqQgA3AwAgAEHwBmxBmAFqQgA3AwAgAEHwBmxB6AFqQgA3AwAgAEHwBmxBuAJqQgA3AwAgAEHwBmxBiANqQgA3AwAgAEHwBmxB2ANqQgA3AwAgAEHwBmxBqARqQgA3AwAgAEHwBmxB+ARqQgA3AwAgAEHwBmxByAVqQgA3AwAgAEHwBmxBoAZqIl4gBEH/AXEgAUH/AXFBCHQgAkH/AXFBEHQgA0H/AXFBGHRycnKtNwMAIF5BCGoiXyAIQf8BcSAFQf8BcUEIdCAGQf8BcUEQdCAHQf8BcUEYdHJycq03AwAgX0EIaiJgIAxB/wFxIAlB/wFxQQh0IApB/wFxQRB0IAtB/wFxQRh0cnJyrTcDACBgQQhqImEgEEH/AXEgDUH/AXFBCHQgDkH/AXFBEHQgD0H/AXFBGHRycnKtNwMAIGFBCGoiYkIANwMAIGJBCGoiY0IANwMAIGNBCGoiZEIANwMAIGRBCGpCADcDACAAQfAGbEHQBWpBAEHQAPwLAAvqBAEffwILIAJBAEdFDQAgACABaiIDQYCAmBFqQQE6AAAgA0EBaiIEQYCAmBFqLQAAIQUgBEGAgJgRakEAIAVBASACSRs6AAAgA0ECaiIGQYCAmBFqLQAAIQcgBkGAgJgRakEAIAdBAiACSRs6AAAgA0EDaiIIQYCAmBFqLQAAIQkgCEGAgJgRakEAIAlBAyACSRs6AAAgA0EEaiIKQYCAmBFqLQAAIQsgCkGAgJgRakEAIAtBBCACSRs6AAAgA0EFaiIMQYCAmBFqLQAAIQ0gDEGAgJgRakEAIA1BBSACSRs6AAAgA0EGaiIOQYCAmBFqLQAAIQ8gDkGAgJgRakEAIA9BBiACSRs6AAAgA0EHaiIQQYCAmBFqLQAAIREgEEGAgJgRakEAIBFBByACSRs6AAAgA0EIaiISQYCAmBFqLQAAIRMgEkGAgJgRakEAIBNBCCACSRs6AAAgA0EJaiIUQYCAmBFqLQAAIRUgFEGAgJgRakEAIBVBCSACSRs6AAAgA0EKaiIWQYCAmBFqLQAAIRcgFkGAgJgRakEAIBdBCiACSRs6AAAgA0ELaiIYQYCAmBFqLQAAIRkgGEGAgJgRakEAIBlBCyACSRs6AAAgA0EMaiIaQYCAmBFqLQAAIRsgGkGAgJgRakEAIBtBDCACSRs6AAAgA0ENaiIcQYCAmBFqLQAAIR0gHEGAgJgRakEAIB1BDSACSRs6AAAgA0EOaiIeQYCAmBFqLQAAIR8gHkGAgJgRakEAIB9BDiACSRs6AAAgA0EPaiIgQYCAmBFqLQAAISEgIEGAgJgRakEAICFBDyACSRs6AAALCyABAX8gACACIARsbCABIAMQC0EBQQAgAUEARhshBiAGC6sHATt/AgsCCyABQQFGRQ0AIAAgASACIAMgBCAFIAYgBxADDAELQQBBASABQQFBgAggAkEBa2ogAm4iCEEBIAhPGyIJQQFraiAJbiIKIAEgAmxB/wdqQYAIbiILIAogC00bIgxBASAMTxsgAUUbIQ0CCwILIA1BAU1FDQAgACABIAIgAyAEIAUgBiAHEAMMAQtBACADNgKAxLkSQQAgBDYChMS5EkEAIAU2AojEuRJBACAGNgKMxLkSQQAgBzYCkMS5EhABIQ4gAUEAIAEgDmkiDyABIA9NGyIQIA0gECANTRsiEUEgIBFBIE0bIhJBAWsgEkEARhsiE0EBaiIUQQFraiAUbiEVIAAgAWohFiATIAEgFUEBa2ogFW5BAWsiFyATIBdNGyEYQQBBAEEAAgkhGyEaIRkgGSAaIBsgGUEfSUUNABoaGiAZIBogGwIJIR4hHSEcIBwgHSAeAwkhISEgIR8gHyAgICECCSEkISMhIiAiICMgJCAkIBhPDQIaGhogIkEBaiElIAAgJEEBaiAVbGohJiAjICQCCiEpISggKCApIA5BASAldHFBAEcgJiAWSXFFDQAaGiAlQYAGbEGAh7gSaiAm/hcCACAlQYAGbEGAiLgSaiAVIBYgJmsiJyAVICdNG/4XAgAgJUGABmxBgIm4EmogAv4XAgAgKEEBICV0ciEqIClBAWohKyAqICsLISkhKCAiICggKQshJCEjISIgIkEBaiEsICwgIyAkICxBH0kNABoaGiAsICMgJAshISEgIR8gHyAgICELIR4hHSEcIBwgHSAeCyEbIRohGUEBIBoQACEtIAAgASAVIAEgFU0bIAIgAyAEIAUgBiAHEAMgGgIIIS4gLiAuQQBHRQ0AGiAuAgghLyAvAwghMCAwAgghMUEAIDFBAAIJITQhMyEyIDIgMyA0IDNBAEdFDQAaGhogMiAzIDQCCSE3ITYhNSA1IDYgNwMJITohOSE4IDggOSA6AgkhPSE8ITsgOyA8ID0gPEEBcUUNABoaGiA7QYAGbEGAhbgSakEA/kECACE/IDFBASA7dCI+cyA/QQBHDQQaID0gPnIhQCA7IDwgQAshPSE8ITsgO0EBaiFBIDxBAXYhQiBBIEIgPSBCQQBHDQAaGhogQSBCID0LITohOSE4IDggOSA6CyE3ITYhNSA1IDYgNwshNCEzITIgMQshMSAxIDFBAEcNABogMQshMCAwCyEvIC8LIS5BgMS5EkEAQYAB/AsACwsLiwcBO38CCwILIAFBAUZFDQAgACABIAIgAyAEIAUQBAwBC0EAQQEgAUEBQYAIIAJBAWtqIAJuIgZBASAGTxsiB0EBa2ogB24iCCABIAJsQf8HakGACG4iCSAIIAlNGyIKQQEgCk8bIAFFGyELAgsCCyALQQFNRQ0AIAAgASACIAMgBCAFEAQMAQtBACADNgKAxLkSQQAgBDYChMS5EkEAIAU2AojEuRIQASEMIAFBACABIAxpIg0gASANTRsiDiALIA4gC00bIg9BICAPQSBNGyIQQQFrIBBBAEYbIhFBAWoiEkEBa2ogEm4hEyAAIAFqIRQgESABIBNBAWtqIBNuQQFrIhUgESAVTRshFkEAQQBBAAIJIRkhGCEXIBcgGCAZIBdBH0lFDQAaGhogFyAYIBkCCSEcIRshGiAaIBsgHAMJIR8hHiEdIB0gHiAfAgkhIiEhISAgICAhICIgIiAWTw0CGhoaICBBAWohIyAAICJBAWogE2xqISQgISAiAgohJyEmICYgJyAMQQEgI3RxQQBHICQgFElxRQ0AGhogI0GABmxBgIe4EmogJP4XAgAgI0GABmxBgIi4EmogEyAUICRrIiUgEyAlTRv+FwIAICNBgAZsQYCJuBJqIAL+FwIAICZBASAjdHIhKCAnQQFqISkgKCApCyEnISYgICAmICcLISIhISEgICBBAWohKiAqICEgIiAqQR9JDQAaGhogKiAhICILIR8hHiEdIB0gHiAfCyEcIRshGiAaIBsgHAshGSEYIRdBAiAYEAAhKyAAIAEgEyABIBNNGyACIAMgBCAFEAQgGAIIISwgLCAsQQBHRQ0AGiAsAgghLSAtAwghLiAuAgghL0EAIC9BAAIJITIhMSEwIDAgMSAyIDFBAEdFDQAaGhogMCAxIDICCSE1ITQhMyAzIDQgNQMJITghNyE2IDYgNyA4AgkhOyE6ITkgOSA6IDsgOkEBcUUNABoaGiA5QYAGbEGAhbgSakEA/kECACE9IC9BASA5dCI8cyA9QQBHDQQaIDsgPHIhPiA5IDogPgshOyE6ITkgOUEBaiE/IDpBAXYhQCA/IEAgOyBAQQBHDQAaGhogPyBAIDsLITghNyE2IDYgNyA4CyE1ITQhMyAzIDQgNQshMiExITAgLwshLyAvIC9BAEcNABogLwshLiAuCyEtIC0LISxBgMS5EkEAQYAB/AsACwsLfwEGfyADQQRuIQUgAEHwBmxBAEHwBiABbPwLAEEAAgghBiAGIAYgAUlFDQAaIAYCCCEHIAcDCCEIIAgCCCEJIAAgCWogBCAFbGxBAnRBgICYEWpBACAC/AsAIAkLIQkgCUEBaiEKIAogCiABSQ0AGiAKCyEIIAgLIQcgBwshBgsUACAAQYAGbEGAhLgSakEA/hcCAAs='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 38691456);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 36044800),
        state_chunks: Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 880, 880))),
        "state.state_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 880, 40))),
        "state.poly_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 880, 832))),
        "state.poly.key_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 880, 32))),
        "state.poly.r_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 80 + i * 880, 320))),
        "state.poly.r5_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 400 + i * 880, 320))),
        "state.poly.h_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 720 + i * 880, 80))),
        "state.poly.pad_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 800 + i * 880, 64))),
        "state.poly.tag_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 864 + i * 880, 16))),
        buffer: new Uint8Array(memoryExport.buffer, 36044800, 2621440),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 36044800 + i * 2621440, 2621440))),
        _worker: new Uint8Array(memoryExport.buffer, 38666240, 25216),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666240 + i * 25216, 25216))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 38666240, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666240 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 38666368, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666368 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 38666496, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666496 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 38666624, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666624 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 38666752, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38666752 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 38691328, 128),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 38691328 + i * 128, 128)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function poly1305(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
