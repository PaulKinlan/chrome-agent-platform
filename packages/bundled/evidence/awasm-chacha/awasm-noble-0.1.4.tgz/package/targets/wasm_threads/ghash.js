// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 41121, maximum: 41121, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABYw5gAn9/AX9gAAF/YAF/AGAIf39/f39/f38AYAZ/f39/f38AYAN/f38AYAZ/f39/f38Bf2AFf39/f38AYAF/AX9gAn97An97YAN/f38Df39/YAJ/fwJ/f2AAAGADf35+A39+fgJdBANlbnYHX21lbW9yeQIDocECocECA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAwwLAwQAAQUCBgMEBwIHwAEMBm1lbW9yeQIAGV9wcm9jZXNzQmxvY2tzX3RocmVhZF9pbnQAAxxfcHJvY2Vzc091dEJsb2Nrc190aHJlYWRfaW50AAQOX3dvcmtlcl9ub3RpZnkABQ5fd29ya2VyX29ubGluZQAGCmluaXRXb3JrZXIABwdtYWNJbml0AAgHcGFkZGluZwAJDXByb2Nlc3NCbG9ja3MAChBwcm9jZXNzT3V0QmxvY2tzAAsFcmVzZXQADApzdG9wV29ya2VyAA0K7zYLhRIZDH8BewF/AXsBfwF7AX8BewF/A3sCfhF7DX8BewF/AXsBfwF7AX8BewF/A3sCfhF7A38gACABaiEIIAggAUEEcGshCSAAAgghCiAKIAogCUlFDQAaIAoCCCELIAsDCCEMIAwCCCENIAIgB2shDkEAAgghDyAPIA9BBElFDQAaIA8CCCEQIBADCCERIBECCCESIA0gEmohEyATQcCBBGxBIGr9AAQAIRRBACAUAgkhFiEVIBUgFiAVIA5JRQ0AGhogFSAWAgkhGCEXIBcgGAMJIRohGSAZIBoCCSEcIRsgEyADbEEEdCAbQQR0QYCA4IN6amr9AAQAIR0gEyADbEEEdCAbQQR0QYCA4IN6amr9DAAAAAAAAAAAAAAAAAAAAAD9CwQAIBwgHf1RIR4gE0HAgQRsIB79HQAiH0IAiEL/AYOnQQB2Qf8BcUEEdEHAAGpq/QAEACEhIBNBwIEEbEGAAiAfQgiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEiIBNBwIEEbEGABCAfQhCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEjIBNBwIEEbEGABiAfQhiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEkIBNBwIEEbEGACCAfQiCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACElIBNBwIEEbEGACiAfQiiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEmIBNBwIEEbEGADCAfQjCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEnIBNBwIEEbEGADiAfQjiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEoIBNBwIEEbEGAECAe/R0BIiBCAIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISkgE0HAgQRsQYASICBCCIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISogE0HAgQRsQYAUICBCEIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISsgE0HAgQRsQYAWICBCGIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISwgE0HAgQRsQYAYICBCIIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS0gE0HAgQRsQYAaICBCKIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS4gE0HAgQRsQYAcICBCMIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS8gE0HAgQRsQYAeICBCOIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAITAgISAi/VEgI/1RICT9USAl/VEgJv1RICf9USAo/VEgKf1RICr9USAr/VEgLP1RIC39USAu/VEgL/1RIDD9USExIBsgMQshHCEbIBtBAWohMiAyIBwgMiAOSQ0AGhogMiAcCyEaIRkgGSAaCyEYIRcgFyAYCyEWIRUgE0HAgQRsQSBqIBb9CwQAIBILIRIgEkEBaiEzIDMgM0EESQ0AGiAzCyERIBELIRAgEAshDyANCyENIA1BBGohNCA0IDQgCUkNABogNAshDCAMCyELIAsLIQogCQIIITUgNSA1IAhJRQ0AGiA1AgghNiA2AwghNyA3AgghOCACIAdrITlBAAIIITogOiA6QQFJRQ0AGiA6AgghOyA7AwghPCA8AgghPSA4ID1qIT4gPkHAgQRsQSBq/QAEACE/QQAgPwIJIUEhQCBAIEEgQCA5SUUNABoaIEAgQQIJIUMhQiBCIEMDCSFFIUQgRCBFAgkhRyFGID4gA2xBBHQgRkEEdEGAgOCDempq/QAEACFIID4gA2xBBHQgRkEEdEGAgOCDempq/QwAAAAAAAAAAAAAAAAAAAAA/QsEACBHIEj9USFJID5BwIEEbCBJ/R0AIkpCAIhC/wGDp0EAdkH/AXFBBHRBwABqav0ABAAhTCA+QcCBBGxBgAIgSkIIiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTSA+QcCBBGxBgAQgSkIQiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTiA+QcCBBGxBgAYgSkIYiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTyA+QcCBBGxBgAggSkIgiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUCA+QcCBBGxBgAogSkIoiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUSA+QcCBBGxBgAwgSkIwiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUiA+QcCBBGxBgA4gSkI4iEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUyA+QcCBBGxBgBAgSf0dASJLQgCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFUID5BwIEEbEGAEiBLQgiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFVID5BwIEEbEGAFCBLQhCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFWID5BwIEEbEGAFiBLQhiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFXID5BwIEEbEGAGCBLQiCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFYID5BwIEEbEGAGiBLQiiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFZID5BwIEEbEGAHCBLQjCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFaID5BwIEEbEGAHiBLQjiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFbIEwgTf1RIE79USBP/VEgUP1RIFH9USBS/VEgU/1RIFT9USBV/VEgVv1RIFf9USBY/VEgWf1RIFr9USBb/VEhXCBGIFwLIUchRiBGQQFqIV0gXSBHIF0gOUkNABoaIF0gRwshRSFEIEQgRQshQyFCIEIgQwshQSFAID5BwIEEbEEgaiBB/QsEACA9CyE9ID1BAWohXiBeIF5BAUkNABogXgshPCA8CyE7IDsLITogOAshOCA4QQFqIV8gXyBfIAhJDQAaIF8LITcgNwshNiA2CyE1C7EEBQt/AXsQfwF7B38gACABaiEGIAYgAUEEcGshByAAAgghCCAIIAggB0lFDQAaIAgCCCEJIAkDCCEKIAoCCCELQQACCCEMIAwgDEEESUUNABogDAIIIQ0gDQMIIQ4gDgIIIQ8gCyAPaiEQIBBBwIEEbEEgav0ABAAhEUEAAgghEiASIBIgAklFDQAaIBICCCETIBMDCCEUIBQCCCEVIBAgA2xBBHQgFUEEdEGAgOCDempqIBH9CwQAIBULIRUgFUEBaiEWIBYgFiACSQ0AGiAWCyEUIBQLIRMgEwshEiAPCyEPIA9BAWohFyAXIBdBBEkNABogFwshDiAOCyENIA0LIQwgCwshCyALQQRqIRggGCAYIAdJDQAaIBgLIQogCgshCSAJCyEIIAcCCCEZIBkgGSAGSUUNABogGQIIIRogGgMIIRsgGwIIIRxBAAIIIR0gHSAdQQFJRQ0AGiAdAgghHiAeAwghHyAfAgghICAcICBqISEgIUHAgQRsQSBq/QAEACEiQQACCCEjICMgIyACSUUNABogIwIIISQgJAMIISUgJQIIISYgISADbEEEdCAmQQR0QYCA4IN6amogIv0LBAAgJgshJiAmQQFqIScgJyAnIAJJDQAaICcLISUgJQshJCAkCyEjICALISAgIEEBaiEoICggKEEBSQ0AGiAoCyEfIB8LIR4gHgshHSAcCyEcIBxBAWohKSApICkgBkkNABogKQshGyAbCyEaIBoLIRkL5AEBEH9BACABQQACCiEEIQMhAiACIAMgBCADQQBHRQ0AGhoaIAIgAyAEAgohByEGIQUgBSAGIAcDCiEKIQkhCCAIIAkgCgIKIQ0hDCELIAsgDCANIAxBAXFFDQAaGhogC0GABmxBgIaAhXpqIAD+FwIAIAtBgAZsQYCGgIV6akEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAubAQEMf0EAQQACCyEBIQAgACABIABBH0lFDQAaGiAAIAECCyEDIQIgAiADAwshBSEEIAQgBQILIQchBiAGQQFqIghBgAZsQYCEgIV6av4QAgAhCSAHQQEgCHRBACAJG3IhCiAGIAoLIQchBiAGQQFqIQsgCyAHIAtBH0kNABoaIAsgBwshBSEEIAQgBQshAyECIAIgAwshASEAIAEL/wIBEn8gAEGABmxBgIWAhXpqIQMgAEGABmxBgIaAhXpqIQQgAEGABmxBgISAhXpqQQH+FwIAAgwCDCABRQ0ADAELAgwDDCAEQQD+QQIAIQUCDCAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCwIMIAVBAUZFDQBBACgCgMSBhQohB0EAKAKExIGFCiEIQQAoAojEgYUKIQlBACgCjMSBhQohCkEAKAKQxIGFCiELIABBgAZsQYCHgIV6av4QAgAhDCAAQYAGbEGAiICFemr+EAIAIQ0gAEGABmxBgImAhXpq/hACACEOIAwgDSAOIAcgCCAJIAogCxADCwIMIAVBAkZFDQBBACgCgMSBhQohD0EAKAKExIGFCiEQQQAoAojEgYUKIREgAEGABmxBgIeAhXpq/hACACESIABBgAZsQYCIgIV6av4QAgAhEyAAQYAGbEGAiYCFemr+EAIAIRQgEiATIBQgDyAQIBEQBAsgA0EB/hcCACACDQFBAQ0ACwsLC70JGw1/Bn4BfwJ+AX8CfgF/An4BfwJ+AX8CfgF/An4BfwJ+AX8IfgZ/AXsBfwF7AX8BewF/A3sDfyAAQcCBBGxBEGoiAUEANgIAIAFBBGoiAkEANgIAIAJBBGoiA0EANgIAIANBBGpBADYCACAAQcCBBGxBIGr9DAAAAAAAAAAAAAAAAAAAAAD9CwQAIABBwIEEbCIEQQA2AgAgBEEEaiIFQQA2AgAgBUEEaiIGQQA2AgAgBkEEakEANgIAIABBwIEEbEEwaiIHKAIAIQggB0EEaiIJKAIAIQogCUEEaiILKAIAIQwgC0EEaigCACENQQAgCq1CIIYgCK2EIg5C/4H8h/CfwP8Ag0EIrIYgDkEIrIhC/4H8h/CfwP8Ag4QiEEL//4OA8P8/g0EQrIYgEEEQrIhC//+DgPD/P4OEIhFBIKyGIBFBIKyIhCANrUIghiAMrYQiD0L/gfyH8J/A/wCDQQishiAPQQisiEL/gfyH8J/A/wCDhCISQv//g4Dw/z+DQRCshiASQRCsiEL//4OA8P8/g4QiE0EgrIYgE0EgrIiEAg0hFiEVIRQgFCAVIBYgFEEQSUUNABoaGiAUIBUgFgINIRkhGCEXIBcgGCAZAw0hHCEbIRogGiAbIBwCDSEfIR4hHUEAIB4gHwINISIhISEgICAgISAiICBBCElFDQAaGhogICAhICICDSElISQhIyAjICQgJQMNISghJyEmICYgJyAoAg0hKyEqISkgAEHAgQRsIClBBHRBwIAEamogKkL/gfyH8J/A/wCDQQishiAqQQisiEL/gfyH8J/A/wCDhCIsQv//g4Dw/z+DQRCshiAsQRCsiEL//4OA8P8/g4QiLUEgrIYgLUEgrIiE/RIgK0L/gfyH8J/A/wCDQQishiArQQisiEL/gfyH8J/A/wCDhCIuQv//g4Dw/z+DQRCshiAuQRCsiEL//4OA8P8/g4QiL0EgrIYgL0EgrIiE/R4B/QsEACAqQj+GICtCAYiEITAgKkIBiEKAgICAgICAgGFCACArQgGDfYOFITEgKSAxIDALISshKiEpIClBAWohMiAyICogKyAyQQhJDQAaGhogMiAqICsLISghJyEmICYgJyAoCyElISQhIyAjICQgJQshIiEhISBBAAIIITMgMyAzQYACSUUNABogMwIIITQgNAMIITUgNQIIITZBAP0MAAAAAAAAAAAAAAAAAAAAAAIJITghNyA3IDggN0EISUUNABoaIDcgOAIJITohOSA5IDoDCSE8ITsgOyA8AgkhPiE9IABBwIEEbCA9QQR0QcCABGpq/QAEACE/ID4gP0IAIDZBByA9a3ZBAXGtff0S/U79USFAID0gQAshPiE9ID1BAWohQSBBID4gQUEISQ0AGhogQSA+CyE8ITsgOyA8CyE6ITkgOSA6CyE4ITcgAEHAgQRsIB1BCHQgNmpBBHRBwABqaiA4/QsEACA2CyE2IDZBAWohQiBCIEJBgAJJDQAaIEILITUgNQshNCA0CyEzIB0gISAiCyEfIR4hHSAdQQFqIUMgQyAeIB8gQ0EQSQ0AGhoaIEMgHiAfCyEcIRshGiAaIBsgHAshGSEYIRcgFyAYIBkLIRYhFSEUC4kBAQd/IARBBG4hBgIMIANBAEdFDQBBAAIIIQcgByAHIANJRQ0AGiAHAgghCCAIAwghCSAJAgghCiAAIAIgBmxsQQJ0IAEgCmpBgIDgg3pqakEAOgAAIAoLIQogCkEBaiELIAsgCyADSQ0AGiALCyEJIAkLIQggCAshBwtBAUEAIAFBAEYbIQwgDAu1BwE7fwIMAgwgAUEBRkUNACAAIAEgAiADIAQgBSAGIAcQAwwBC0EAQQEgAUEBQYAIIAJBAWtqIAJuIghBASAITxsiCUEBa2ogCW4iCiABIAJsQf8HakGACG4iCyAKIAtNGyIMQQEgDE8bIAFFGyENAgwCDCANQQFNRQ0AIAAgASACIAMgBCAFIAYgBxADDAELQQAgAzYCgMSBhQpBACAENgKExIGFCkEAIAU2AojEgYUKQQAgBjYCjMSBhQpBACAHNgKQxIGFChABIQ4gAUEAIAEgDmkiDyABIA9NGyIQIA0gECANTRsiEUEgIBFBIE0bIhJBAWsgEkEARhsiE0EBaiIUQQFraiAUbiEVIAAgAWohFiATIAEgFUEBa2ogFW5BAWsiFyATIBdNGyEYQQBBAEEAAgohGyEaIRkgGSAaIBsgGUEfSUUNABoaGiAZIBogGwIKIR4hHSEcIBwgHSAeAwohISEgIR8gHyAgICECCiEkISMhIiAiICMgJCAkIBhPDQIaGhogIkEBaiElIAAgJEEBaiAVbGohJiAjICQCCyEpISggKCApIA5BASAldHFBAEcgJiAWSXFFDQAaGiAlQYAGbEGAh4CFemogJv4XAgAgJUGABmxBgIiAhXpqIBUgFiAmayInIBUgJ00b/hcCACAlQYAGbEGAiYCFemogAv4XAgAgKEEBICV0ciEqIClBAWohKyAqICsLISkhKCAiICggKQshJCEjISIgIkEBaiEsICwgIyAkICxBH0kNABoaGiAsICMgJAshISEgIR8gHyAgICELIR4hHSEcIBwgHSAeCyEbIRohGUEBIBoQACEtIAAgASAVIAEgFU0bIAIgAyAEIAUgBiAHEAMgGgIIIS4gLiAuQQBHRQ0AGiAuAgghLyAvAwghMCAwAgghMUEAIDFBAAIKITQhMyEyIDIgMyA0IDNBAEdFDQAaGhogMiAzIDQCCiE3ITYhNSA1IDYgNwMKITohOSE4IDggOSA6AgohPSE8ITsgOyA8ID0gPEEBcUUNABoaGiA7QYAGbEGAhYCFempBAP5BAgAhPyAxQQEgO3QiPnMgP0EARw0EGiA9ID5yIUAgOyA8IEALIT0hPCE7IDtBAWohQSA8QQF2IUIgQSBCID0gQkEARw0AGhoaIEEgQiA9CyE6ITkhOCA4IDkgOgshNyE2ITUgNSA2IDcLITQhMyEyIDELITEgMSAxQQBHDQAaIDELITAgMAshLyAvCyEuQYDEgYV6QQBBgAH8CwALCwuTBwE7fwIMAgwgAUEBRkUNACAAIAEgAiADIAQgBRAEDAELQQBBASABQQFBgAggAkEBa2ogAm4iBkEBIAZPGyIHQQFraiAHbiIIIAEgAmxB/wdqQYAIbiIJIAggCU0bIgpBASAKTxsgAUUbIQsCDAIMIAtBAU1FDQAgACABIAIgAyAEIAUQBAwBC0EAIAM2AoDEgYUKQQAgBDYChMSBhQpBACAFNgKIxIGFChABIQwgAUEAIAEgDGkiDSABIA1NGyIOIAsgDiALTRsiD0EgIA9BIE0bIhBBAWsgEEEARhsiEUEBaiISQQFraiASbiETIAAgAWohFCARIAEgE0EBa2ogE25BAWsiFSARIBVNGyEWQQBBAEEAAgohGSEYIRcgFyAYIBkgF0EfSUUNABoaGiAXIBggGQIKIRwhGyEaIBogGyAcAwohHyEeIR0gHSAeIB8CCiEiISEhICAgICEgIiAiIBZPDQIaGhogIEEBaiEjIAAgIkEBaiATbGohJCAhICICCyEnISYgJiAnIAxBASAjdHFBAEcgJCAUSXFFDQAaGiAjQYAGbEGAh4CFemogJP4XAgAgI0GABmxBgIiAhXpqIBMgFCAkayIlIBMgJU0b/hcCACAjQYAGbEGAiYCFemogAv4XAgAgJkEBICN0ciEoICdBAWohKSAoICkLISchJiAgICYgJwshIiEhISAgIEEBaiEqICogISAiICpBH0kNABoaGiAqICEgIgshHyEeIR0gHSAeIB8LIRwhGyEaIBogGyAcCyEZIRghF0ECIBgQACErIAAgASATIAEgE00bIAIgAyAEIAUQBCAYAgghLCAsICxBAEdFDQAaICwCCCEtIC0DCCEuIC4CCCEvQQAgL0EAAgohMiExITAgMCAxIDIgMUEAR0UNABoaGiAwIDEgMgIKITUhNCEzIDMgNCA1AwohOCE3ITYgNiA3IDgCCiE7ITohOSA5IDogOyA6QQFxRQ0AGhoaIDlBgAZsQYCFgIV6akEA/kECACE9IC9BASA5dCI8cyA9QQBHDQQaIDsgPHIhPiA5IDogPgshOyE6ITkgOUEBaiE/IDpBAXYhQCA/IEAgOyBAQQBHDQAaGhogPyBAIDsLITghNyE2IDYgNyA4CyE1ITQhMyAzIDQgNQshMiExITAgLwshLyAvIC9BAEcNABogLwshLiAuCyEtIC0LISxBgMSBhXpBAEGAAfwLAAsLC4IBAQZ/IANBBG4hBSAAQcCBBGxBAEHAgQQgAWz8CwBBAAIIIQYgBiAGIAFJRQ0AGiAGAgghByAHAwghCCAIAgghCSAAIAlqIAQgBWxsQQJ0QYCA4IN6akEAIAL8CwAgCQshCSAJQQFqIQogCiAKIAFJDQAaIAoLIQggCAshByAHCyEGCxUAIABBgAZsQYCEgIV6akEA/hcCAAs='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 2694865536);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 2692218880),
        state_chunks: Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 65728, 65728))),
        "state.state_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 65728, 16))),
        "state.ghash_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 16 + i * 65728, 48))),
        "state.ghash.y_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 16 + i * 65728, 16))),
        "state.ghash.y64_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 65728, 16))),
        "state.ghash.h_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 65728, 16))),
        "state.table64v_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 64 + i * 65728, 65536))),
        "state.tmp64v_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 65600 + i * 65728, 128))),
        buffer: new Uint8Array(memoryExport.buffer, 2692218880, 2621440),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2692218880 + i * 2621440, 2621440))),
        _worker: new Uint8Array(memoryExport.buffer, 2694840320, 25216),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840320 + i * 25216, 25216))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 2694840320, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840320 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 2694840448, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840448 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 2694840576, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840576 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 2694840704, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840704 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 2694840832, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694840832 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 2694865408, 128),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2694865408 + i * 128, 128)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function ghash(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
