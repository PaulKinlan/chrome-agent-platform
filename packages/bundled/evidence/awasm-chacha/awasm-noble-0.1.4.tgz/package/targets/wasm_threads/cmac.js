// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 541, maximum: 541, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABZQ5gAn9/AX9gAAF/YAF/AGADf39/AGACf38AYAZ/f39/f38Bf2AIf39/f39/f38AYAZ/f39/f38AYAV/f39/fwBgA39/fwN/f39gAn9/An9/YAAAYAF/AX9gBX9/f39/BX9/f39/AlsEA2VudgdfbWVtb3J5AgOdBJ0EA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAwoJAAEDBAUGBwgCB4UBCgZtZW1vcnkCAA5fd29ya2VyX25vdGlmeQADDl93b3JrZXJfb25saW5lAAQKaW5pdFdvcmtlcgAFB21hY0luaXQABgdwYWRkaW5nAAcNcHJvY2Vzc0Jsb2NrcwAIEHByb2Nlc3NPdXRCbG9ja3MACQVyZXNldAAKCnN0b3BXb3JrZXIACwrnRgniAQEQf0EAIAFBAAIJIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCCSEHIQYhBSAFIAYgBwMJIQohCSEIIAggCSAKAgkhDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAy/AQaiAA/hcCACALQYAGbEGAy/AQakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACCiEBIQAgACABIABBH0lFDQAaGiAAIAECCiEDIQIgAiADAwohBSEEIAQgBQIKIQchBiAGQQFqIghBgAZsQYDJ8BBq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQt8AQR/IABBgAZsQYDK8BBqIQMgAEGABmxBgMvwEGohBCAAQYAGbEGAyfAQakEB/hcCAAILAgsgAUUNAAwBCwILAwsgBEEA/kECACEFAgsgBUUgAkEBR3FFDQAgBEEAQn/+AQIAIQYMAQsgA0EB/hcCACACDQFBAQ0ACwsLC/MnAcwBf0EAKAKQxPALIQICCyACQQBGRQ0AQQBBAQIKIQQhAyADIAQDCiEGIQUgBUEBaiEHIAYgBkEBdCAGQQd2QQFxQRtsc0H/AXFzIQggBUGAgvALaiAGQf8BcToAACAHIAggB0GAAkkNABoaIAcgCAshBiEFIAUgBgshBCEDQQBB4wBB/wFxOgCAgPALQQACDCEJIAkgCUH/AUlFDQAaIAkCDCEKIAoDDCELIAsCDCEMQf8BIAxrQYCC8AtqLQAAIQ0gDEGAgvALai0AACEQIBBB/wFxQYCA8AtqIA1B/wFxIg4gDkEIdHIiDyAPQQR2cyAPQQV2cyAPQQZ2cyAPQQd2c0HjAHNB/wFxQf8BcToAACAMCyEMIAxBAWohESARIBFB/wFJDQAaIBELIQsgCwshCiAKCyEJQQACDCESIBIgEkGAAklFDQAaIBICDCETIBMDDCEUIBQCDCEVIBVBgKLwC2pBAEH/AXE6AAAgFQshFSAVQQFqIRYgFiAWQYACSQ0AGiAWCyEUIBQLIRMgEwshEkEAAgwhFyAXIBdBgAJJRQ0AGiAXAgwhGCAYAwwhGSAZAgwhGiAaQYCA8AtqLQAAIRsgG0H/AXFBgKLwC2ogGkH/AXE6AAAgGgshGiAaQQFqIRwgHCAcQYACSQ0AGiAcCyEZIBkLIRggGAshF0EAQQECCiEeIR0gHSAeAwohICEfIB9BAWohISAgQQF0ICBBB3ZBAXFBG2xzQf8BcSEiIB9BgMTwC2ogIEH/AXE6AAAgISAiICFBEEkNABoaICEgIgshICEfIB8gIAshHiEdQQACDCEjICMgI0GAAklFDQAaICMCDCEkICQDDCElICUCDCEmICZBgIDwC2otAAAhJyAmQYCi8AtqLQAAISkgJkECdEGAgvALaiAnQf8BcSIoIChBAXQgKEEHdkEBcUEbbHNB/wFxc0EYdCAoQRB0IChBCHQgKEEBdCAoQQd2QQFxQRtsc0H/AXFycnI2AgAgJkECdEGApPALaiApQf8BcSIqICpBAXQgKkEHdkEBcUEbbHNB/wFxIi1zIC1BAXQgLUEHdkEBcUEbbHNB/wFxIi5BAXQgLkEHdkEBcUEbbHNB/wFxc0EYdCAqICpBAXQgKkEHdkEBcUEbbHNB/wFxIi9BAXQgL0EHdkEBcUEbbHNB/wFxIjBzIDBBAXQgMEEHdkEBcUEbbHNB/wFxc0EQdCAqICpBAXQgKkEHdkEBcUEbbHNB/wFxIitBAXQgK0EHdkEBcUEbbHNB/wFxIixBAXQgLEEHdkEBcUEbbHNB/wFxc0EIdCAqQQF0ICpBB3ZBAXFBG2xzQf8BcSIxIDFBAXQgMUEHdkEBcUEbbHNB/wFxIjJzIDJBAXQgMkEHdkEBcUEbbHNB/wFxc3JycjYCACAmCyEmICZBAWohMyAzIDNBgAJJDQAaIDMLISUgJQshJCAkCyEjQQACDCE0IDQgNEGAAklFDQAaIDQCDCE1IDUDDCE2IDYCDCE3IDdBAnRBgILwC2ooAgAhOCA3QQJ0QYCK8AtqIDhBCHciOTYCACA3QQJ0QYCS8AtqIDlBCHciOjYCACA3QQJ0QYCa8AtqIDpBCHc2AgAgN0ECdEGApPALaigCACE7IDdBAnRBgKzwC2ogO0EIdyI8NgIAIDdBAnRBgLTwC2ogPEEIdyI9NgIAIDdBAnRBgLzwC2ogPUEIdzYCACA3CyE3IDdBAWohPiA+ID5BgAJJDQAaID4LITYgNgshNSA1CyE0QQBBATYCkMTwCwtBBEEGQQggAUEYRiJAGyABQRBGIj8bIUEgAEHgBGxBwARqQQpBDEEOIEAbID8bIkI2AgAgAEHgBGxBMGpBADYCACAAQeAEbEE0akEANgIAIABB4ARsQThqQQA2AgAgAEHgBGxBPGpBADYCACAAQeAEbEHAAGpBADYCACAAQeAEbEHEAGpBADYCACAAQeAEbEHIAGpBADYCACAAQeAEbEHMAGpBADYCACAAQeAEbEHQAGpBADYCACAAQeAEbEHUAGpBADYCACAAQeAEbEHYAGpBADYCACAAQeAEbEHcAGpBADYCACAAQeAEbEHgAGpBADYCACAAQeAEbEHkAGpBADYCACAAQeAEbEHoAGpBADYCACAAQeAEbEHsAGpBADYCACAAQeAEbEHwAGpBADYCACAAQeAEbEH0AGpBADYCACAAQeAEbEH4AGpBADYCACAAQeAEbEH8AGpBADYCACAAQeAEbEGAAWpBADYCACAAQeAEbEGEAWpBADYCACAAQeAEbEGIAWpBADYCACAAQeAEbEGMAWpBADYCACAAQeAEbEGQAWpBADYCACAAQeAEbEGUAWpBADYCACAAQeAEbEGYAWpBADYCACAAQeAEbEGcAWpBADYCACAAQeAEbEGgAWpBADYCACAAQeAEbEGkAWpBADYCACAAQeAEbEGoAWpBADYCACAAQeAEbEGsAWpBADYCACAAQeAEbEGwAWpBADYCACAAQeAEbEG0AWpBADYCACAAQeAEbEG4AWpBADYCACAAQeAEbEG8AWpBADYCACAAQeAEbEHAAWpBADYCACAAQeAEbEHEAWpBADYCACAAQeAEbEHIAWpBADYCACAAQeAEbEHMAWpBADYCACAAQeAEbEHQAWpBADYCACAAQeAEbEHUAWpBADYCACAAQeAEbEHYAWpBADYCACAAQeAEbEHcAWpBADYCACAAQeAEbEHgAWpBADYCACAAQeAEbEHkAWpBADYCACAAQeAEbEHoAWpBADYCACAAQeAEbEHsAWpBADYCACAAQeAEbEHwAWpBADYCACAAQeAEbEH0AWpBADYCACAAQeAEbEH4AWpBADYCACAAQeAEbEH8AWpBADYCACAAQeAEbEGAAmpBADYCACAAQeAEbEGEAmpBADYCACAAQeAEbEGIAmpBADYCACAAQeAEbEGMAmpBADYCACAAQeAEbEGQAmpBADYCACAAQeAEbEGUAmpBADYCACAAQeAEbEGYAmpBADYCACAAQeAEbEGcAmpBADYCAEEAAgwhQyBDIEMgQUlFDQAaIEMCDCFEIEQDDCFFIEUCDCFGIABB4ARsIEZBAnQiR0EBakEQamotAAAhSCAAQeAEbCBHQQJqQRBqai0AACFJIABB4ARsIEdBA2pBEGpqLQAAIUogAEHgBGwgR0EQamotAAAhSyAAQeAEbCBGQQJ0QaACamogS0H/AXEgSEH/AXFBCHQgSUH/AXFBEHQgSkH/AXFBGHRycnI2AgAgRgshRiBGQQFqIUwgTCBMIEFJDQAaIEwLIUUgRQshRCBECyFDIEJBAWpBAnQhTSBNIEFrIU5BAAIMIU8gTyBPIE5JRQ0AGiBPAgwhUCBQAwwhUSBRAgwhUiAAQeAEbCBSIEFqIlNBAWtBAnRBoAJqaigCACFUIFRBGHQgVEEIdnIiVkEIdkH/AXFBgIDwC2otAAAhVyBWQRB2Qf8BcUGAgPALai0AACFYIFZBGHZB/wFxQYCA8AtqLQAAIVkgVkH/AXFBgIDwC2otAAAhWiBTIEFuQQFrQYDE8AtqLQAAIVsgVEEIdkH/AXFBgIDwC2otAAAhXCBUQRB2Qf8BcUGAgPALai0AACFdIFRBGHZB/wFxQYCA8AtqLQAAIV4gVEH/AXFBgIDwC2otAAAhXyAAQeAEbCBTIEFrQQJ0QaACamooAgAhYCAAQeAEbCBTQQJ0QaACamogX0H/AXEgXEH/AXFBCHRyIF1B/wFxQRB0IF5B/wFxQRh0cnIgWkH/AXEgV0H/AXFBCHRyIFhB/wFxQRB0IFlB/wFxQRh0cnIgW0H/AXFzIFQgUyBBcCJVQQBGGyBBQQhGIFVBBEZxGyBgczYCACBSCyFSIFJBAWohYSBhIGEgTkkNABogYQshUSBRCyFQIFALIU9BAAIMIWIgYiBiIE1JRQ0AGiBiAgwhYyBjAwwhZCBkAgwhZSAAQeAEbCBlQQJ0QaACamooAgAhZiAAQeAEbCBlQQJ0QTBqaiBmNgIAIGULIWUgZUEBaiFnIGcgZyBNSQ0AGiBnCyFkIGQLIWMgYwshYiAAQeAEbEHABGooAgAhaCAAQeAEbEEwaigCACFqIABB4ARsQTRqKAIAIWsgAEHgBGxBOGooAgAhbCAAQeAEbEE8aigCACFtIGhBAWshbkEAIGogayBsIG0CDSFzIXIhcSFwIW8gbyBwIHEgciBzAw0heCF3IXYhdSF0IHRBAWoheSAAQeAEbCB0QQFqQQJ0InpBAnRBMGpqKAIAIXsgdUH/AXFBAnRBgILwC2ooAgAhfCB2QQh2Qf8BcUECdEGAivALaigCACF9IHdBEHZB/wFxQQJ0QYCS8AtqKAIAIX4geEEYdkH/AXFBAnRBgJrwC2ooAgAhfyB7IHwgfXMgfiB/c3NzIYABIABB4ARsIHpBAWpBAnRBMGpqKAIAIYEBIHZB/wFxQQJ0QYCC8AtqKAIAIYIBIHdBCHZB/wFxQQJ0QYCK8AtqKAIAIYMBIHhBEHZB/wFxQQJ0QYCS8AtqKAIAIYQBIHVBGHZB/wFxQQJ0QYCa8AtqKAIAIYUBIIEBIIIBIIMBcyCEASCFAXNzcyGGASAAQeAEbCB6QQJqQQJ0QTBqaigCACGHASB3Qf8BcUECdEGAgvALaigCACGIASB4QQh2Qf8BcUECdEGAivALaigCACGJASB1QRB2Qf8BcUECdEGAkvALaigCACGKASB2QRh2Qf8BcUECdEGAmvALaigCACGLASCHASCIASCJAXMgigEgiwFzc3MhjAEgAEHgBGwgekEDakECdEEwamooAgAhjQEgeEH/AXFBAnRBgILwC2ooAgAhjgEgdUEIdkH/AXFBAnRBgIrwC2ooAgAhjwEgdkEQdkH/AXFBAnRBgJLwC2ooAgAhkAEgd0EYdkH/AXFBAnRBgJrwC2ooAgAhkQEgjQEgjgEgjwFzIJABIJEBc3NzIZIBIHkggAEghgEgjAEgkgEgeSBuSQ0AGhoaGhogeSCAASCGASCMASCSAQsheCF3IXYhdSF0IHQgdSB2IHcgeAshcyFyIXEhcCFvIABB4ARsIGhBAnQikwFBAnRBMGpqKAIAIZQBIHFBCHZB/wFxQYCA8AtqLQAAIZUBIHJBEHZB/wFxQYCA8AtqLQAAIZYBIHNBGHZB/wFxQYCA8AtqLQAAIZcBIHBB/wFxQYCA8AtqLQAAIZgBIABB4ARsIJMBQQFqQQJ0QTBqaigCACGZASByQQh2Qf8BcUGAgPALai0AACGaASBzQRB2Qf8BcUGAgPALai0AACGbASBwQRh2Qf8BcUGAgPALai0AACGcASBxQf8BcUGAgPALai0AACGdASAAQeAEbCCTAUECakECdEEwamooAgAhngEgc0EIdkH/AXFBgIDwC2otAAAhnwEgcEEQdkH/AXFBgIDwC2otAAAhoAEgcUEYdkH/AXFBgIDwC2otAAAhoQEgckH/AXFBgIDwC2otAAAhogEgAEHgBGwgkwFBA2pBAnRBMGpqKAIAIaMBIHBBCHZB/wFxQYCA8AtqLQAAIaQBIHFBEHZB/wFxQYCA8AtqLQAAIaUBIHJBGHZB/wFxQYCA8AtqLQAAIaYBIHNB/wFxQYCA8AtqLQAAIacBIABB4ARsQZAEaiJpIJQBIJgBQf8BcSCVAUH/AXFBCHRyIJYBQf8BcUEQdCCXAUH/AXFBGHRycnM2AgAgaUEEaiKoASCZASCdAUH/AXEgmgFB/wFxQQh0ciCbAUH/AXFBEHQgnAFB/wFxQRh0cnJzNgIAIKgBQQRqIqkBIJ4BIKIBQf8BcSCfAUH/AXFBCHRyIKABQf8BcUEQdCChAUH/AXFBGHRycnM2AgAgqQFBBGogowEgpwFB/wFxIKQBQf8BcUEIdHIgpQFB/wFxQRB0IKYBQf8BcUEYdHJyczYCAEEAQQACCiGrASGqASCqASCrAQMKIa0BIawBIKwBQQFqIa4BIABB4ARsQQ8grAFrIq8BQZAEamotAAAhsAEgsAFB/wFxQf8BcSKxAUEHdiGyASAAQeAEbCCvAUGQBGpqILEBQQF0IK0BckH/AXFB/wFxOgAAIK4BILIBIK4BQRBJDQAaGiCuASCyAQshrQEhrAEgrAEgrQELIasBIaoBIABB4ARsQZ8Eai0AACGzASAAQeAEbEGfBGogswFB/wFxQQAgqwFrQYcBcXNB/wFxOgAAIABB4ARsQZAEaiK1ASgCACG2ASC1AUEEaiK3ASgCACG4ASC3AUEEaiK5ASgCACG6ASC5AUEEaigCACG7ASAAQeAEbEGgBGoitAEgtgE2AgAgtAFBBGoivAEguAE2AgAgvAFBBGoivQEgugE2AgAgvQFBBGoguwE2AgBBAEEAAgohvwEhvgEgvgEgvwEDCiHBASHAASDAAUEBaiHCASAAQeAEbEEPIMABayLDAUGgBGpqLQAAIcQBIMQBQf8BcUH/AXEixQFBB3YhxgEgAEHgBGwgwwFBoARqaiDFAUEBdCDBAXJB/wFxQf8BcToAACDCASDGASDCAUEQSQ0AGhogwgEgxgELIcEBIcABIMABIMEBCyG/ASG+ASAAQeAEbEGvBGotAAAhxwEgAEHgBGxBrwRqIMcBQf8BcUEAIL8Ba0GHAXFzQf8BcToAACAAQeAEbEGwBGoiyAFBADYCACDIAUEEaiLJAUEANgIAIMkBQQRqIsoBQQA2AgAgygFBBGpBADYCACAAQeAEbCLLAUEANgIAIMsBQQRqIswBQQA2AgAgzAFBBGoizQFBADYCACDNAUEEakEANgIAC8AIASB/IAFBAEYhBgILIAZFDQAgACACbEEEdEGgxPALakGAAUH/AXE6AAAgACACbEEEdEGhxPALakEAQRD8CwALAgsgA0EAR0UNACAAIAJsQQR0IAFBoMTwC2pqQYABQf8BcToAACAAIAJsQQR0IAFBAWoiB0GgxPALamotAAAhCCAAIAJsQQR0IAdBoMTwC2pqQQAgCEH/AXFBASADSRtB/wFxOgAAIAAgAmxBBHQgAUECaiIJQaDE8Atqai0AACEKIAAgAmxBBHQgCUGgxPALampBACAKQf8BcUECIANJG0H/AXE6AAAgACACbEEEdCABQQNqIgtBoMTwC2pqLQAAIQwgACACbEEEdCALQaDE8AtqakEAIAxB/wFxQQMgA0kbQf8BcToAACAAIAJsQQR0IAFBBGoiDUGgxPALamotAAAhDiAAIAJsQQR0IA1BoMTwC2pqQQAgDkH/AXFBBCADSRtB/wFxOgAAIAAgAmxBBHQgAUEFaiIPQaDE8Atqai0AACEQIAAgAmxBBHQgD0GgxPALampBACAQQf8BcUEFIANJG0H/AXE6AAAgACACbEEEdCABQQZqIhFBoMTwC2pqLQAAIRIgACACbEEEdCARQaDE8AtqakEAIBJB/wFxQQYgA0kbQf8BcToAACAAIAJsQQR0IAFBB2oiE0GgxPALamotAAAhFCAAIAJsQQR0IBNBoMTwC2pqQQAgFEH/AXFBByADSRtB/wFxOgAAIAAgAmxBBHQgAUEIaiIVQaDE8Atqai0AACEWIAAgAmxBBHQgFUGgxPALampBACAWQf8BcUEIIANJG0H/AXE6AAAgACACbEEEdCABQQlqIhdBoMTwC2pqLQAAIRggACACbEEEdCAXQaDE8AtqakEAIBhB/wFxQQkgA0kbQf8BcToAACAAIAJsQQR0IAFBCmoiGUGgxPALamotAAAhGiAAIAJsQQR0IBlBoMTwC2pqQQAgGkH/AXFBCiADSRtB/wFxOgAAIAAgAmxBBHQgAUELaiIbQaDE8Atqai0AACEcIAAgAmxBBHQgG0GgxPALampBACAcQf8BcUELIANJG0H/AXE6AAAgACACbEEEdCABQQxqIh1BoMTwC2pqLQAAIR4gACACbEEEdCAdQaDE8AtqakEAIB5B/wFxQQwgA0kbQf8BcToAACAAIAJsQQR0IAFBDWoiH0GgxPALamotAAAhICAAIAJsQQR0IB9BoMTwC2pqQQAgIEH/AXFBDSADSRtB/wFxOgAAIAAgAmxBBHQgAUEOaiIhQaDE8Atqai0AACEiIAAgAmxBBHQgIUGgxPALampBACAiQf8BcUEOIANJG0H/AXE6AAAgACACbEEEdCABQQ9qIiNBoMTwC2pqLQAAISQgACACbEEEdCAjQaDE8AtqakEAICRB/wFxQQ8gA0kbQf8BcToAAAtBAUEAIAYbISUgJQuMDwF6f0EAAgwhCCAIIAggAUlFDQAaIAgCDCEJIAkDDCEKIAoCDCELIAAgC2ohDCAMQeAEbEGQBGohDSAMQeAEbEGgBGohDiACQQFrIRAgDEHgBGxBwARqKAIAIREgDEHgBGxBsARqIg8oAgAhEiAPQQRqIhMoAgAhFCATQQRqIhUoAgAhFiAVQQRqKAIAIRdBACASIBQgFiAXAg0hHCEbIRohGSEYIBggGSAaIBsgHAMNISEhICEfIR4hHSAdQQFqISIgDCADbEEEdCAdQQR0QaDE8AtqaiIlKAIAISYgJUEEaiInKAIAISggJ0EEaiIpKAIAISogKUEEaigCACErICVBADYCACAlQQRqIixBADYCACAsQQRqIi1BADYCACAtQQRqQQA2AgAgDSgCACEuIA1BBGoiLygCACEwIC9BBGoiMSgCACEyIDFBBGooAgAhMyAOKAIAITQgDkEEaiI1KAIAITYgNUEEaiI3KAIAITggN0EEaigCACE5IAxB4ARsQTBqKAIAITogDEHgBGxBNGooAgAhOyAMQeAEbEE4aigCACE8IAxB4ARsQTxqKAIAIT0gEUEBayE+QQAgJiA0IC4gBSAdIBBGcSIjIAZBAEcgB0EAR3JxIiQbcyAmICMbIB5zIDpzICggNiAwICQbcyAoICMbIB9zIDtzICogOCAyICQbcyAqICMbICBzIDxzICsgOSAzICQbcyArICMbICFzID1zAg0hQyFCIUEhQCE/ID8gQCBBIEIgQwMNIUghRyFGIUUhRCBEQQFqIUkgDEHgBGwgREEBakECdCJKQQJ0QTBqaigCACFLIEVB/wFxQQJ0QYCC8AtqKAIAIUwgRkEIdkH/AXFBAnRBgIrwC2ooAgAhTSBHQRB2Qf8BcUECdEGAkvALaigCACFOIEhBGHZB/wFxQQJ0QYCa8AtqKAIAIU8gSyBMIE1zIE4gT3NzcyFQIAxB4ARsIEpBAWpBAnRBMGpqKAIAIVEgRkH/AXFBAnRBgILwC2ooAgAhUiBHQQh2Qf8BcUECdEGAivALaigCACFTIEhBEHZB/wFxQQJ0QYCS8AtqKAIAIVQgRUEYdkH/AXFBAnRBgJrwC2ooAgAhVSBRIFIgU3MgVCBVc3NzIVYgDEHgBGwgSkECakECdEEwamooAgAhVyBHQf8BcUECdEGAgvALaigCACFYIEhBCHZB/wFxQQJ0QYCK8AtqKAIAIVkgRUEQdkH/AXFBAnRBgJLwC2ooAgAhWiBGQRh2Qf8BcUECdEGAmvALaigCACFbIFcgWCBZcyBaIFtzc3MhXCAMQeAEbCBKQQNqQQJ0QTBqaigCACFdIEhB/wFxQQJ0QYCC8AtqKAIAIV4gRUEIdkH/AXFBAnRBgIrwC2ooAgAhXyBGQRB2Qf8BcUECdEGAkvALaigCACFgIEdBGHZB/wFxQQJ0QYCa8AtqKAIAIWEgXSBeIF9zIGAgYXNzcyFiIEkgUCBWIFwgYiBJID5JDQAaGhoaGiBJIFAgViBcIGILIUghRyFGIUUhRCBEIEUgRiBHIEgLIUMhQiFBIUAhPyAMQeAEbCARQQJ0ImNBAnRBMGpqKAIAIWQgQUEIdkH/AXFBgIDwC2otAAAhZSBCQRB2Qf8BcUGAgPALai0AACFmIENBGHZB/wFxQYCA8AtqLQAAIWcgQEH/AXFBgIDwC2otAAAhaCBkIGhB/wFxIGVB/wFxQQh0ciBmQf8BcUEQdCBnQf8BcUEYdHJycyFpIAxB4ARsIGNBAWpBAnRBMGpqKAIAIWogQkEIdkH/AXFBgIDwC2otAAAhayBDQRB2Qf8BcUGAgPALai0AACFsIEBBGHZB/wFxQYCA8AtqLQAAIW0gQUH/AXFBgIDwC2otAAAhbiBqIG5B/wFxIGtB/wFxQQh0ciBsQf8BcUEQdCBtQf8BcUEYdHJycyFvIAxB4ARsIGNBAmpBAnRBMGpqKAIAIXAgQ0EIdkH/AXFBgIDwC2otAAAhcSBAQRB2Qf8BcUGAgPALai0AACFyIEFBGHZB/wFxQYCA8AtqLQAAIXMgQkH/AXFBgIDwC2otAAAhdCBwIHRB/wFxIHFB/wFxQQh0ciByQf8BcUEQdCBzQf8BcUEYdHJycyF1IAxB4ARsIGNBA2pBAnRBMGpqKAIAIXYgQEEIdkH/AXFBgIDwC2otAAAhdyBBQRB2Qf8BcUGAgPALai0AACF4IEJBGHZB/wFxQYCA8AtqLQAAIXkgQ0H/AXFBgIDwC2otAAAheiB2IHpB/wFxIHdB/wFxQQh0ciB4Qf8BcUEQdCB5Qf8BcUEYdHJycyF7ICIgaSBvIHUgeyAiIAJJDQAaGhoaGiAiIGkgbyB1IHsLISEhICEfIR4hHSAdIB4gHyAgICELIRwhGyEaIRkhGCAPIBk2AgAgD0EEaiJ8IBo2AgAgfEEEaiJ9IBs2AgAgfUEEaiAcNgIAIAxB4ARsIn4gGTYCACB+QQRqIn8gGjYCACB/QQRqIoABIBs2AgAggAFBBGogHDYCACALCyELIAtBAWohgQEggQEggQEgAUkNABoggQELIQogCgshCSAJCyEIC40CARV/QQACDCEGIAYgBiABSUUNABogBgIMIQcgBwMMIQggCAIMIQkgACAJaiEKIApB4ARsQbAEaiELQQACDCEMIAwgDCACSUUNABogDAIMIQ0gDQMMIQ4gDgIMIQ8gCygCACERIAtBBGoiEigCACETIBJBBGoiFCgCACEVIBRBBGooAgAhFiAKIANsQQR0IA9BBHRBoMTwC2pqIhAgETYCACAQQQRqIhcgEzYCACAXQQRqIhggFTYCACAYQQRqIBY2AgAgDwshDyAPQQFqIRkgGSAZIAJJDQAaIBkLIQ4gDgshDSANCyEMIAkLIQkgCUEBaiEaIBogGiABSQ0AGiAaCyEIIAgLIQcgBwshBgt/AQZ/IANBBG4hBSAAQeAEbEEAQeAEIAFs/AsAQQACDCEGIAYgBiABSUUNABogBgIMIQcgBwMMIQggCAIMIQkgACAJaiAEIAVsbEECdEGgxPALakEAIAL8CwAgCQshCSAJQQFqIQogCiAKIAFJDQAaIAoLIQggCAshByAHCyEGCxQAIABBgAZsQYDJ8BBqQQD+FwIACw=='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 35423376);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 24903680),
        state_chunks: Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 608, 608))),
        "state.state_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 608, 16))),
        "state.key_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 16 + i * 608, 32))),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 48 + i * 608, 240))),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 288 + i * 608, 240))),
        "state.k1_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 608, 16))),
        "state.k2_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 608, 16))),
        "state.iv_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 560 + i * 608, 16))),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 576 + i * 608, 4))),
        "state.tag_chunks": Object.freeze(Array.from({ length: 40960 }, (_, i) => new Uint8Array(memoryExport.buffer, 592 + i * 608, 16))),
        constants: new Uint8Array(memoryExport.buffer, 24903680, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24903680 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 24903680, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24903680 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 24903680, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24903680 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 24903936, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24903936 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 24904960, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24904960 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 24905984, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24905984 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 24907008, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24907008 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 24908032, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24908032 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 24908032, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24908032 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 24908288, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24908288 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 24909312, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24909312 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 24910336, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24910336 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 24911360, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24911360 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 24912384, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24912384 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 24912400, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24912400 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 24912416, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 24912416 + i * 10485760, 10485760))),
        _worker: new Uint8Array(memoryExport.buffer, 35398272, 25104),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398272 + i * 25104, 25104))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 35398272, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398272 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 35398400, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398400 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 35398528, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398528 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 35398656, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398656 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 35398784, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35398784 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 35423360, 4),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 35423360 + i * 4, 4)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function cmac(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
