// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 162, maximum: 162, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABUQxgAn9/AX9gAAF/YAF/AGAEf39/fwBgA39/fwBgAABgAX8Bf2AFf39/f38Ff39/f39gA39/fwN/f39gAn9/An9/YAN/fn4Df35+YAJ/ewJ/ewJbBANlbnYHX21lbW9yeQIDogGiAQNlbnYUX3dvcmtlcl9ub3RpZnlCcmlkZ2UAAANlbnYUX3dvcmtlcl9vbmxpbmVCcmlkZ2UAAQNlbnYLaW5pdFdvcmtlcnMAAgMREAMAAQQDBAMEBAQEAwICBQUH8QERBm1lbW9yeQIAGV9wcm9jZXNzQmxvY2tzX3RocmVhZF9pbnQAAw5fd29ya2VyX25vdGlmeQAEDl93b3JrZXJfb25saW5lAAUJYWFkQmxvY2tzAAYNZGVjcnlwdEJsb2NrcwAHC2RlY3J5cHRJbml0AAgNZW5jcnlwdEJsb2NrcwAJC2VuY3J5cHRJbml0AAoKaW5pdFdvcmtlcgALCW1hY0Jsb2NrcwAMCnBvbHlCbG9ja3MADQ1wcm9jZXNzQmxvY2tzAA4FcmVzZXQADwpzdG9wV29ya2VyABAJdGFnRmluaXNoABEHdGFnSW5pdAASCouFARC7GQHCAX8gACABaiEEIAQgAUEBcGshBSAAAgYhBiAGIAYgBUlFDQAaIAYCBiEHIAcDBiEIIAgCBiEJIAkgAmwhCiADIAprIgsgAiALIAJJGyEMQQAoApAGIQ1BACgCsAYhDkEAKAK0BiEPQQAoArgGIRBBACgCvAYhEUEAIA4gCSACbGogDyAQIBECByEWIRUhFCETIRIgEiATIBQgFSAWAwchGyEaIRkhGCEXIBdBAWohHEEAKAJAIR5BACgCRCEfQQAoAkghIEEAKAJMISEgDUEBayEiQQAgGCAecyAZIB9zIBogIHMgGyAhcwIHISchJiElISQhIyAjICQgJSAmICcDByEsISshKiEpISggKEEBaiEtIChBAWpBAnQiLkECdEHAAGooAgAhLyApQf8BcUECdEGgigRqKAIAITAgKkEIdkH/AXFBAnRBoJIEaigCACExICtBEHZB/wFxQQJ0QaCaBGooAgAhMiAsQRh2Qf8BcUECdEGgogRqKAIAITMgLyAwIDFzIDIgM3NzcyE0IC5BAWpBAnRBwABqKAIAITUgKkH/AXFBAnRBoIoEaigCACE2ICtBCHZB/wFxQQJ0QaCSBGooAgAhNyAsQRB2Qf8BcUECdEGgmgRqKAIAITggKUEYdkH/AXFBAnRBoKIEaigCACE5IDUgNiA3cyA4IDlzc3MhOiAuQQJqQQJ0QcAAaigCACE7ICtB/wFxQQJ0QaCKBGooAgAhPCAsQQh2Qf8BcUECdEGgkgRqKAIAIT0gKUEQdkH/AXFBAnRBoJoEaigCACE+ICpBGHZB/wFxQQJ0QaCiBGooAgAhPyA7IDwgPXMgPiA/c3NzIUAgLkEDakECdEHAAGooAgAhQSAsQf8BcUECdEGgigRqKAIAIUIgKUEIdkH/AXFBAnRBoJIEaigCACFDICpBEHZB/wFxQQJ0QaCaBGooAgAhRCArQRh2Qf8BcUECdEGgogRqKAIAIUUgQSBCIENzIEQgRXNzcyFGIC0gNCA6IEAgRiAtICJJDQAaGhoaGiAtIDQgOiBAIEYLISwhKyEqISkhKCAoICkgKiArICwLISchJiElISQhIyANQQJ0IkdBAnRBwABqKAIAIUggJUEIdkH/AXFBoIgEai0AACFJICZBEHZB/wFxQaCIBGotAAAhSiAnQRh2Qf8BcUGgiARqLQAAIUsgJEH/AXFBoIgEai0AACFMIEdBAWpBAnRBwABqKAIAIU0gJkEIdkH/AXFBoIgEai0AACFOICdBEHZB/wFxQaCIBGotAAAhTyAkQRh2Qf8BcUGgiARqLQAAIVAgJUH/AXFBoIgEai0AACFRIEdBAmpBAnRBwABqKAIAIVIgJ0EIdkH/AXFBoIgEai0AACFTICRBEHZB/wFxQaCIBGotAAAhVCAlQRh2Qf8BcUGgiARqLQAAIVUgJkH/AXFBoIgEai0AACFWIEdBA2pBAnRBwABqKAIAIVcgJEEIdkH/AXFBoIgEai0AACFYICVBEHZB/wFxQaCIBGotAAAhWSAmQRh2Qf8BcUGgiARqLQAAIVogJ0H/AXFBoIgEai0AACFbIAogF2pBBHRBwMwEaiIdKAIAIVwgHUEEaiJdKAIAIV4gXUEEaiJfKAIAIWAgX0EEaigCACFhIB0gXCBIIExB/wFxIElB/wFxQQh0ciBKQf8BcUEQdCBLQf8BcUEYdHJyc3M2AgAgHUEEaiJiIF4gTSBRQf8BcSBOQf8BcUEIdHIgT0H/AXFBEHQgUEH/AXFBGHRycnNzNgIAIGJBBGoiYyBgIFIgVkH/AXEgU0H/AXFBCHRyIFRB/wFxQRB0IFVB/wFxQRh0cnJzczYCACBjQQRqIGEgVyBbQf8BcSBYQf8BcUEIdHIgWUH/AXFBEHQgWkH/AXFBGHRycnNzNgIAIBhBAWohZCAcIGQgGSAaIBsgHCAMSQ0AGhoaGhogHCBkIBkgGiAbCyEbIRohGSEYIRcgFyAYIBkgGiAbCyEWIRUhFCETIRIgCQshCSAJQQFqIWUgZSBlIAVJDQAaIGULIQggCAshByAHCyEGIAUCBiFmIGYgZiAESUUNABogZgIGIWcgZwMGIWggaAIGIWkgaSACbCFqIAMgamsiayACIGsgAkkbIWxBACgCkAYhbUEAKAKwBiFuQQAoArQGIW9BACgCuAYhcEEAKAK8BiFxQQAgbiBpIAJsaiBvIHAgcQIHIXYhdSF0IXMhciByIHMgdCB1IHYDByF7IXoheSF4IXcgd0EBaiF8QQAoAkAhfkEAKAJEIX9BACgCSCGAAUEAKAJMIYEBIG1BAWshggFBACB4IH5zIHkgf3MgeiCAAXMgeyCBAXMCByGHASGGASGFASGEASGDASCDASCEASCFASCGASCHAQMHIYwBIYsBIYoBIYkBIYgBIIgBQQFqIY0BIIgBQQFqQQJ0Io4BQQJ0QcAAaigCACGPASCJAUH/AXFBAnRBoIoEaigCACGQASCKAUEIdkH/AXFBAnRBoJIEaigCACGRASCLAUEQdkH/AXFBAnRBoJoEaigCACGSASCMAUEYdkH/AXFBAnRBoKIEaigCACGTASCPASCQASCRAXMgkgEgkwFzc3MhlAEgjgFBAWpBAnRBwABqKAIAIZUBIIoBQf8BcUECdEGgigRqKAIAIZYBIIsBQQh2Qf8BcUECdEGgkgRqKAIAIZcBIIwBQRB2Qf8BcUECdEGgmgRqKAIAIZgBIIkBQRh2Qf8BcUECdEGgogRqKAIAIZkBIJUBIJYBIJcBcyCYASCZAXNzcyGaASCOAUECakECdEHAAGooAgAhmwEgiwFB/wFxQQJ0QaCKBGooAgAhnAEgjAFBCHZB/wFxQQJ0QaCSBGooAgAhnQEgiQFBEHZB/wFxQQJ0QaCaBGooAgAhngEgigFBGHZB/wFxQQJ0QaCiBGooAgAhnwEgmwEgnAEgnQFzIJ4BIJ8Bc3NzIaABII4BQQNqQQJ0QcAAaigCACGhASCMAUH/AXFBAnRBoIoEaigCACGiASCJAUEIdkH/AXFBAnRBoJIEaigCACGjASCKAUEQdkH/AXFBAnRBoJoEaigCACGkASCLAUEYdkH/AXFBAnRBoKIEaigCACGlASChASCiASCjAXMgpAEgpQFzc3MhpgEgjQEglAEgmgEgoAEgpgEgjQEgggFJDQAaGhoaGiCNASCUASCaASCgASCmAQshjAEhiwEhigEhiQEhiAEgiAEgiQEgigEgiwEgjAELIYcBIYYBIYUBIYQBIYMBIG1BAnQipwFBAnRBwABqKAIAIagBIIUBQQh2Qf8BcUGgiARqLQAAIakBIIYBQRB2Qf8BcUGgiARqLQAAIaoBIIcBQRh2Qf8BcUGgiARqLQAAIasBIIQBQf8BcUGgiARqLQAAIawBIKcBQQFqQQJ0QcAAaigCACGtASCGAUEIdkH/AXFBoIgEai0AACGuASCHAUEQdkH/AXFBoIgEai0AACGvASCEAUEYdkH/AXFBoIgEai0AACGwASCFAUH/AXFBoIgEai0AACGxASCnAUECakECdEHAAGooAgAhsgEghwFBCHZB/wFxQaCIBGotAAAhswEghAFBEHZB/wFxQaCIBGotAAAhtAEghQFBGHZB/wFxQaCIBGotAAAhtQEghgFB/wFxQaCIBGotAAAhtgEgpwFBA2pBAnRBwABqKAIAIbcBIIQBQQh2Qf8BcUGgiARqLQAAIbgBIIUBQRB2Qf8BcUGgiARqLQAAIbkBIIYBQRh2Qf8BcUGgiARqLQAAIboBIIcBQf8BcUGgiARqLQAAIbsBIGogd2pBBHRBwMwEaiJ9KAIAIbwBIH1BBGoivQEoAgAhvgEgvQFBBGoivwEoAgAhwAEgvwFBBGooAgAhwQEgfSC8ASCoASCsAUH/AXEgqQFB/wFxQQh0ciCqAUH/AXFBEHQgqwFB/wFxQRh0cnJzczYCACB9QQRqIsIBIL4BIK0BILEBQf8BcSCuAUH/AXFBCHRyIK8BQf8BcUEQdCCwAUH/AXFBGHRycnNzNgIAIMIBQQRqIsMBIMABILIBILYBQf8BcSCzAUH/AXFBCHRyILQBQf8BcUEQdCC1AUH/AXFBGHRycnNzNgIAIMMBQQRqIMEBILcBILsBQf8BcSC4AUH/AXFBCHRyILkBQf8BcUEQdCC6AUH/AXFBGHRycnNzNgIAIHhBAWohxAEgfCDEASB5IHogeyB8IGxJDQAaGhoaGiB8IMQBIHkgeiB7CyF7IXoheSF4IXcgdyB4IHkgeiB7CyF2IXUhdCFzIXIgaQshaSBpQQFqIcUBIMUBIMUBIARJDQAaIMUBCyFoIGgLIWcgZwshZgviAQEQf0EAIAFBAAIIIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCCCEHIQYhBSAFIAYgBwMIIQohCSEIIAggCSAKAgghDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGA04QFaiAA/hcCACALQYAGbEGA04QFakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACCSEBIQAgACABIABBH0lFDQAaGiAAIAECCSEDIQIgAiADAwkhBSEEIAQgBQIJIQchBiAGQQFqIghBgAZsQYDRhAVq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQsKACAAIAEgAhANC7ECAQ1/AgUgA0EARkUNABASAgUgAEEAR0UNAEEAIABB/wdqQYAIbkGACCAAEA4LIAACBiEEQbAGLQAAIQVBsAYgBUH/AXEgBEH/AXFqIgZB/wFxOgAAIARBCHYgBkEIdmoiByAHQQBGDQAaQbEGLQAAIQhBsQYgCEH/AXEgB0H/AXFqIglB/wFxOgAAIAdBCHYgCUEIdmoiCiAKQQBGDQAaQbIGLQAAIQtBsgYgC0H/AXEgCkH/AXFqIgxB/wFxOgAAIApBCHYgDEEIdmoiDSANQQBGDQAaQbMGLQAAIQ4gDUEIdiAOQf8BcSANQf8BcWoiD0EIdmohEEGzBiAPQf8BcToAACAQIBBBAEYNABogEAshBAsCBSADQQBHRQ0AIAAgASACEAwCBSABRQ0AEBELCwsKACAAIAEgAhAKC7ECAQ1/AgUgA0EARkUNACAAIAEgAhAMAgUgAUUNABARCwsCBSADQQBHRQ0AEBICBSAAQQBHRQ0AQQAgAEH/B2pBgAhuQYAIIAAQDgsgAAIGIQRBsAYtAAAhBUGwBiAFQf8BcSAEQf8BcWoiBkH/AXE6AAAgBEEIdiAGQQh2aiIHIAdBAEYNABpBsQYtAAAhCEGxBiAIQf8BcSAHQf8BcWoiCUH/AXE6AAAgB0EIdiAJQQh2aiIKIApBAEYNABpBsgYtAAAhC0GyBiALQf8BcSAKQf8BcWoiDEH/AXE6AAAgCkEIdiAMQQh2aiINIA1BAEYNABpBswYtAAAhDiANQQh2IA5B/wFxIA1B/wFxaiIPQQh2aiEQQbMGIA9B/wFxOgAAIBAgEEEARg0AGiAQCyEECwvwRh2jAn8GfgF/An4BfwJ+AX8CfgF/An4BfwJ+AX8CfgF/An4Bfwh+Bn8BewF/AXsBfwF7AX8DewF/Bn4rf0EAKAKgBiEDQQAoAqQGIQRBACgCqAYhBUEAKAKwzAQhBgIFIAZBAEZFDQBBAEEBAgkhCCEHIAcgCAMJIQohCSAJQQFqIQsgCiAKQQF0IApBB3ZBAXFBG2xzQf8BcXMhDCAJQaCKBGogCkH/AXE6AAAgCyAMIAtBgAJJDQAaGiALIAwLIQohCSAJIAoLIQghB0EAQeMAQf8BcToAoIgEQQACBiENIA0gDUH/AUlFDQAaIA0CBiEOIA4DBiEPIA8CBiEQQf8BIBBrQaCKBGotAAAhESAQQaCKBGotAAAhFCAUQf8BcUGgiARqIBFB/wFxIhIgEkEIdHIiEyATQQR2cyATQQV2cyATQQZ2cyATQQd2c0HjAHNB/wFxQf8BcToAACAQCyEQIBBBAWohFSAVIBVB/wFJDQAaIBULIQ8gDwshDiAOCyENQQACBiEWIBYgFkGAAklFDQAaIBYCBiEXIBcDBiEYIBgCBiEZIBlBoKoEakEAQf8BcToAACAZCyEZIBlBAWohGiAaIBpBgAJJDQAaIBoLIRggGAshFyAXCyEWQQACBiEbIBsgG0GAAklFDQAaIBsCBiEcIBwDBiEdIB0CBiEeIB5BoIgEai0AACEfIB9B/wFxQaCqBGogHkH/AXE6AAAgHgshHiAeQQFqISAgICAgQYACSQ0AGiAgCyEdIB0LIRwgHAshG0EAQQECCSEiISEgISAiAwkhJCEjICNBAWohJSAkQQF0ICRBB3ZBAXFBG2xzQf8BcSEmICNBoMwEaiAkQf8BcToAACAlICYgJUEQSQ0AGhogJSAmCyEkISMgIyAkCyEiISFBAAIGIScgJyAnQYACSUUNABogJwIGISggKAMGISkgKQIGISogKkGgiARqLQAAISsgKkGgqgRqLQAAIS0gKkECdEGgigRqICtB/wFxIiwgLEEBdCAsQQd2QQFxQRtsc0H/AXFzQRh0ICxBEHQgLEEIdCAsQQF0ICxBB3ZBAXFBG2xzQf8BcXJycjYCACAqQQJ0QaCsBGogLUH/AXEiLiAuQQF0IC5BB3ZBAXFBG2xzQf8BcSIxcyAxQQF0IDFBB3ZBAXFBG2xzQf8BcSIyQQF0IDJBB3ZBAXFBG2xzQf8BcXNBGHQgLiAuQQF0IC5BB3ZBAXFBG2xzQf8BcSIzQQF0IDNBB3ZBAXFBG2xzQf8BcSI0cyA0QQF0IDRBB3ZBAXFBG2xzQf8BcXNBEHQgLiAuQQF0IC5BB3ZBAXFBG2xzQf8BcSIvQQF0IC9BB3ZBAXFBG2xzQf8BcSIwQQF0IDBBB3ZBAXFBG2xzQf8BcXNBCHQgLkEBdCAuQQd2QQFxQRtsc0H/AXEiNSA1QQF0IDVBB3ZBAXFBG2xzQf8BcSI2cyA2QQF0IDZBB3ZBAXFBG2xzQf8BcXNycnI2AgAgKgshKiAqQQFqITcgNyA3QYACSQ0AGiA3CyEpICkLISggKAshJ0EAAgYhOCA4IDhBgAJJRQ0AGiA4AgYhOSA5AwYhOiA6AgYhOyA7QQJ0QaCKBGooAgAhPCA7QQJ0QaCSBGogPEEIdyI9NgIAIDtBAnRBoJoEaiA9QQh3Ij42AgAgO0ECdEGgogRqID5BCHc2AgAgO0ECdEGgrARqKAIAIT8gO0ECdEGgtARqID9BCHciQDYCACA7QQJ0QaC8BGogQEEIdyJBNgIAIDtBAnRBoMQEaiBBQQh3NgIAIDsLITsgO0EBaiFCIEIgQkGAAkkNABogQgshOiA6CyE5IDkLIThBAEEBNgKwzAQLQQRBBkEIIABBGEYiRBsgAEEQRiJDGyFFQQBBCkEMQQ4gRBsgQxsiRjYCkAZBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQBBADYCkAJBAEEANgKUAkEAQQA2ApgCQQBBADYCnAJBAEEANgKgAkEAQQA2AqQCQQBBADYCqAJBAEEANgKsAkEAAgYhRyBHIEcgRUlFDQAaIEcCBiFIIEgDBiFJIEkCBiFKIEpBAnQiS0EBai0AACFMIEtBAmotAAAhTSBLQQNqLQAAIU4gSy0AACFPIEpBAnRBsAJqIE9B/wFxIExB/wFxQQh0IE1B/wFxQRB0IE5B/wFxQRh0cnJyNgIAIEoLIUogSkEBaiFQIFAgUCBFSQ0AGiBQCyFJIEkLIUggSAshRyBGQQFqQQJ0IVEgUSBFayFSQQACBiFTIFMgUyBSSUUNABogUwIGIVQgVAMGIVUgVQIGIVYgViBFaiJXQQFrQQJ0QbACaigCACFYIFhBGHQgWEEIdnIiWkEIdkH/AXFBoIgEai0AACFbIFpBEHZB/wFxQaCIBGotAAAhXCBaQRh2Qf8BcUGgiARqLQAAIV0gWkH/AXFBoIgEai0AACFeIFcgRW5BAWtBoMwEai0AACFfIFhBCHZB/wFxQaCIBGotAAAhYCBYQRB2Qf8BcUGgiARqLQAAIWEgWEEYdkH/AXFBoIgEai0AACFiIFhB/wFxQaCIBGotAAAhYyBXIEVrQQJ0QbACaigCACFkIFdBAnRBsAJqIGNB/wFxIGBB/wFxQQh0ciBhQf8BcUEQdCBiQf8BcUEYdHJyIF5B/wFxIFtB/wFxQQh0ciBcQf8BcUEQdCBdQf8BcUEYdHJyIF9B/wFxcyBYIFcgRXAiWUEARhsgRUEIRiBZQQRGcRsgZHM2AgAgVgshViBWQQFqIWUgZSBlIFJJDQAaIGULIVUgVQshVCBUCyFTQQACBiFmIGYgZiBRSUUNABogZgIGIWcgZwMGIWggaAIGIWkgaUECdEGwAmooAgAhaiBpQQJ0QcAAaiBqNgIAIGkLIWkgaUEBaiFrIGsgayBRSQ0AGiBrCyFoIGgLIWcgZwshZkEAKAKQBiFsQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBACgCQCFtQQAoAkQhbkEAKAJIIW9BACgCTCFwIGxBAWshcUEAIG0gAyBucyAEIG9zIAUgcHMCByF2IXUhdCFzIXIgciBzIHQgdSB2AwcheyF6IXkheCF3IHdBAWohfCB3QQFqQQJ0In1BAnRBwABqKAIAIX4geEH/AXFBAnRBoIoEaigCACF/IHlBCHZB/wFxQQJ0QaCSBGooAgAhgAEgekEQdkH/AXFBAnRBoJoEaigCACGBASB7QRh2Qf8BcUECdEGgogRqKAIAIYIBIH4gfyCAAXMggQEgggFzc3MhgwEgfUEBakECdEHAAGooAgAhhAEgeUH/AXFBAnRBoIoEaigCACGFASB6QQh2Qf8BcUECdEGgkgRqKAIAIYYBIHtBEHZB/wFxQQJ0QaCaBGooAgAhhwEgeEEYdkH/AXFBAnRBoKIEaigCACGIASCEASCFASCGAXMghwEgiAFzc3MhiQEgfUECakECdEHAAGooAgAhigEgekH/AXFBAnRBoIoEaigCACGLASB7QQh2Qf8BcUECdEGgkgRqKAIAIYwBIHhBEHZB/wFxQQJ0QaCaBGooAgAhjQEgeUEYdkH/AXFBAnRBoKIEaigCACGOASCKASCLASCMAXMgjQEgjgFzc3MhjwEgfUEDakECdEHAAGooAgAhkAEge0H/AXFBAnRBoIoEaigCACGRASB4QQh2Qf8BcUECdEGgkgRqKAIAIZIBIHlBEHZB/wFxQQJ0QaCaBGooAgAhkwEgekEYdkH/AXFBAnRBoKIEaigCACGUASCQASCRASCSAXMgkwEglAFzc3MhlQEgfCCDASCJASCPASCVASB8IHFJDQAaGhoaGiB8IIMBIIkBII8BIJUBCyF7IXoheSF4IXcgdyB4IHkgeiB7CyF2IXUhdCFzIXIgbEECdCKWAUECdEHAAGooAgAhlwEgdEEIdkH/AXFBoIgEai0AACGYASB1QRB2Qf8BcUGgiARqLQAAIZkBIHZBGHZB/wFxQaCIBGotAAAhmgEgc0H/AXFBoIgEai0AACGbASCWAUEBakECdEHAAGooAgAhnAEgdUEIdkH/AXFBoIgEai0AACGdASB2QRB2Qf8BcUGgiARqLQAAIZ4BIHNBGHZB/wFxQaCIBGotAAAhnwEgdEH/AXFBoIgEai0AACGgAUEAIJcBIJsBQf8BcSCYAUH/AXFBCHRyIJkBQf8BcUEQdCCaAUH/AXFBGHRycnM2ApAHQQAgnAEgoAFB/wFxIJ0BQf8BcUEIdHIgngFB/wFxQRB0IJ8BQf8BcUEYdHJyczYClAdBACgCQCGhAUEAKAJEIaIBQQAoAkghowFBACgCTCGkASBsQQFrIaUBQQBBASChAXMgAyCiAXMgBCCjAXMgBSCkAXMCByGqASGpASGoASGnASGmASCmASCnASCoASCpASCqAQMHIa8BIa4BIa0BIawBIasBIKsBQQFqIbABIKsBQQFqQQJ0IrEBQQJ0QcAAaigCACGyASCsAUH/AXFBAnRBoIoEaigCACGzASCtAUEIdkH/AXFBAnRBoJIEaigCACG0ASCuAUEQdkH/AXFBAnRBoJoEaigCACG1ASCvAUEYdkH/AXFBAnRBoKIEaigCACG2ASCyASCzASC0AXMgtQEgtgFzc3MhtwEgsQFBAWpBAnRBwABqKAIAIbgBIK0BQf8BcUECdEGgigRqKAIAIbkBIK4BQQh2Qf8BcUECdEGgkgRqKAIAIboBIK8BQRB2Qf8BcUECdEGgmgRqKAIAIbsBIKwBQRh2Qf8BcUECdEGgogRqKAIAIbwBILgBILkBILoBcyC7ASC8AXNzcyG9ASCxAUECakECdEHAAGooAgAhvgEgrgFB/wFxQQJ0QaCKBGooAgAhvwEgrwFBCHZB/wFxQQJ0QaCSBGooAgAhwAEgrAFBEHZB/wFxQQJ0QaCaBGooAgAhwQEgrQFBGHZB/wFxQQJ0QaCiBGooAgAhwgEgvgEgvwEgwAFzIMEBIMIBc3NzIcMBILEBQQNqQQJ0QcAAaigCACHEASCvAUH/AXFBAnRBoIoEaigCACHFASCsAUEIdkH/AXFBAnRBoJIEaigCACHGASCtAUEQdkH/AXFBAnRBoJoEaigCACHHASCuAUEYdkH/AXFBAnRBoKIEaigCACHIASDEASDFASDGAXMgxwEgyAFzc3MhyQEgsAEgtwEgvQEgwwEgyQEgsAEgpQFJDQAaGhoaGiCwASC3ASC9ASDDASDJAQshrwEhrgEhrQEhrAEhqwEgqwEgrAEgrQEgrgEgrwELIaoBIakBIagBIacBIaYBIGxBAnQiygFBAnRBwABqKAIAIcsBIKgBQQh2Qf8BcUGgiARqLQAAIcwBIKkBQRB2Qf8BcUGgiARqLQAAIc0BIKoBQRh2Qf8BcUGgiARqLQAAIc4BIKcBQf8BcUGgiARqLQAAIc8BIMoBQQFqQQJ0QcAAaigCACHQASCpAUEIdkH/AXFBoIgEai0AACHRASCqAUEQdkH/AXFBoIgEai0AACHSASCnAUEYdkH/AXFBoIgEai0AACHTASCoAUH/AXFBoIgEai0AACHUAUEAIMsBIM8BQf8BcSDMAUH/AXFBCHRyIM0BQf8BcUEQdCDOAUH/AXFBGHRycnM2ApgHQQAg0AEg1AFB/wFxINEBQf8BcUEIdHIg0gFB/wFxQRB0INMBQf8BcUEYdHJyczYCnAdBBEEGQQggAEEYRhsgAEEQRhtBAXYh1QFBAAIGIdYBINYBINYBINUBSUUNABog1gECBiHXASDXAQMGIdgBINgBAgYh2QFBACgCQCHaAUEAKAJEIdsBQQAoAkgh3AFBACgCTCHdASBsQQFrId4BQQBBAiDZAWog2gFzIAMg2wFzIAQg3AFzIAUg3QFzAgch4wEh4gEh4QEh4AEh3wEg3wEg4AEg4QEg4gEg4wEDByHoASHnASHmASHlASHkASDkAUEBaiHpASDkAUEBakECdCLqAUECdEHAAGooAgAh6wEg5QFB/wFxQQJ0QaCKBGooAgAh7AEg5gFBCHZB/wFxQQJ0QaCSBGooAgAh7QEg5wFBEHZB/wFxQQJ0QaCaBGooAgAh7gEg6AFBGHZB/wFxQQJ0QaCiBGooAgAh7wEg6wEg7AEg7QFzIO4BIO8Bc3NzIfABIOoBQQFqQQJ0QcAAaigCACHxASDmAUH/AXFBAnRBoIoEaigCACHyASDnAUEIdkH/AXFBAnRBoJIEaigCACHzASDoAUEQdkH/AXFBAnRBoJoEaigCACH0ASDlAUEYdkH/AXFBAnRBoKIEaigCACH1ASDxASDyASDzAXMg9AEg9QFzc3Mh9gEg6gFBAmpBAnRBwABqKAIAIfcBIOcBQf8BcUECdEGgigRqKAIAIfgBIOgBQQh2Qf8BcUECdEGgkgRqKAIAIfkBIOUBQRB2Qf8BcUECdEGgmgRqKAIAIfoBIOYBQRh2Qf8BcUECdEGgogRqKAIAIfsBIPcBIPgBIPkBcyD6ASD7AXNzcyH8ASDqAUEDakECdEHAAGooAgAh/QEg6AFB/wFxQQJ0QaCKBGooAgAh/gEg5QFBCHZB/wFxQQJ0QaCSBGooAgAh/wEg5gFBEHZB/wFxQQJ0QaCaBGooAgAhgAIg5wFBGHZB/wFxQQJ0QaCiBGooAgAhgQIg/QEg/gEg/wFzIIACIIECc3NzIYICIOkBIPABIPYBIPwBIIICIOkBIN4BSQ0AGhoaGhog6QEg8AEg9gEg/AEgggILIegBIecBIeYBIeUBIeQBIOQBIOUBIOYBIOcBIOgBCyHjASHiASHhASHgASHfASBsQQJ0IoMCQQJ0QcAAaigCACGEAiDhAUEIdkH/AXFBoIgEai0AACGFAiDiAUEQdkH/AXFBoIgEai0AACGGAiDjAUEYdkH/AXFBoIgEai0AACGHAiDgAUH/AXFBoIgEai0AACGIAiCDAkEBakECdEHAAGooAgAhiQIg4gFBCHZB/wFxQaCIBGotAAAhigIg4wFBEHZB/wFxQaCIBGotAAAhiwIg4AFBGHZB/wFxQaCIBGotAAAhjAIg4QFB/wFxQaCIBGotAAAhjQIg2QFBAXQijgJBAnRBIGoghAIgiAJB/wFxIIUCQf8BcUEIdHIghgJB/wFxQRB0IIcCQf8BcUEYdHJyczYCACCOAkEBakECdEEgaiCJAiCNAkH/AXEgigJB/wFxQQh0ciCLAkH/AXFBEHQgjAJB/wFxQRh0cnJzNgIAINkBCyHZASDZAUEBaiGPAiCPAiCPAiDVAUkNABogjwILIdgBINgBCyHXASDXAQsh1gFBACACrUIghiABrYQ3A8AGQQBCADcDyAZB0AZBAEEQ/AsAQbAGQQBBEPwLAEEAQQA2AuAGQQBBADYC8AZBAEEANgL0BkEAQQA2AvgGQQBBADYC/AZBAP0MAAAAAAAAAAAAAAAAAAAAAP0LBIAHQQACBiGQAiCQAiCQAkEISUUNABogkAICBiGRAiCRAgMGIZICIJICAgYhkwIgkwJBkAdqLQAAIZUCQQ8gkwJrIpQCQZAHai0AACGWAiCTAkGQB2oglgI6AAAglAJBkAdqIJUCOgAAIJMCCyGTAiCTAkEBaiGXAiCXAiCXAkEISQ0AGiCXAgshkgIgkgILIZECIJECCyGQAkEALQCfByGYAkEAQQACCSGaAiGZAiCZAiCaAgMJIZwCIZsCIJsCQQFqIZ0CIJsCQZAHai0AACGeAiCeAkH/AXEinwJBAXFBB3QhoAIgmwJBkAdqIJ8CQQF2IJwCckH/AXFB/wFxOgAAIJ0CIKACIJ0CQRBJDQAaGiCdAiCgAgshnAIhmwIgmwIgnAILIZoCIZkCQQAtAJAHIaECQQAgoQJB/wFxQQAgmAJB/wFxQQFxa0HhAXFzQf8BcToAkAdBACgCkAchogJBACgClAchowJBACgCmAchpAJBACgCnAchpQJBACCjAq1CIIYgogKthCKmAkL/gfyH8J/A/wCDQQishiCmAkEIrIhC/4H8h/CfwP8Ag4QiqAJC//+DgPD/P4NBEKyGIKgCQRCsiEL//4OA8P8/g4QiqQJBIKyGIKkCQSCsiIQgpQKtQiCGIKQCrYQipwJC/4H8h/CfwP8Ag0EIrIYgpwJBCKyIQv+B/Ifwn8D/AIOEIqoCQv//g4Dw/z+DQRCshiCqAkEQrIhC//+DgPD/P4OEIqsCQSCshiCrAkEgrIiEAgohrgIhrQIhrAIgrAIgrQIgrgIgrAJBEElFDQAaGhogrAIgrQIgrgICCiGxAiGwAiGvAiCvAiCwAiCxAgMKIbQCIbMCIbICILICILMCILQCAgohtwIhtgIhtQJBACC2AiC3AgIKIboCIbkCIbgCILgCILkCILoCILgCQQhJRQ0AGhoaILgCILkCILoCAgohvQIhvAIhuwIguwIgvAIgvQIDCiHAAiG/AiG+AiC+AiC/AiDAAgIKIcMCIcICIcECIMECQQR0QaCHBGogwgJC/4H8h/CfwP8Ag0EIrIYgwgJBCKyIQv+B/Ifwn8D/AIOEIsQCQv//g4Dw/z+DQRCshiDEAkEQrIhC//+DgPD/P4OEIsUCQSCshiDFAkEgrIiE/RIgwwJC/4H8h/CfwP8Ag0EIrIYgwwJBCKyIQv+B/Ifwn8D/AIOEIsYCQv//g4Dw/z+DQRCshiDGAkEQrIhC//+DgPD/P4OEIscCQSCshiDHAkEgrIiE/R4B/QsEACDCAkI/hiDDAkIBiIQhyAIgwgJCAYhCgICAgICAgIBhQgAgwwJCAYN9g4UhyQIgwQIgyQIgyAILIcMCIcICIcECIMECQQFqIcoCIMoCIMICIMMCIMoCQQhJDQAaGhogygIgwgIgwwILIcACIb8CIb4CIL4CIL8CIMACCyG9AiG8AiG7AiC7AiC8AiC9AgshugIhuQIhuAJBAAIGIcsCIMsCIMsCQYACSUUNABogywICBiHMAiDMAgMGIc0CIM0CAgYhzgJBAP0MAAAAAAAAAAAAAAAAAAAAAAILIdACIc8CIM8CINACIM8CQQhJRQ0AGhogzwIg0AICCyHSAiHRAiDRAiDSAgMLIdQCIdMCINMCINQCAgsh1gIh1QIg1QJBBHRBoIcEav0ABAAh1wIg1gIg1wJCACDOAkEHINUCa3ZBAXGtff0S/U79USHYAiDVAiDYAgsh1gIh1QIg1QJBAWoh2QIg2QIg1gIg2QJBCEkNABoaINkCINYCCyHUAiHTAiDTAiDUAgsh0gIh0QIg0QIg0gILIdACIc8CILUCQQh0IM4CakEEdEGgB2og0AL9HQEi2wJC/4H8h/CfwP8Ag0EIrIYg2wJBCKyIQv+B/Ifwn8D/AIOEItwCQv//g4Dw/z+DQRCshiDcAkEQrIhC//+DgPD/P4OEIt0CQSCshiDdAkEgrIiE/RIg0AL9HQAi2gJC/4H8h/CfwP8Ag0EIrIYg2gJBCKyIQv+B/Ifwn8D/AIOEIt4CQv//g4Dw/z+DQRCshiDeAkEQrIhC//+DgPD/P4OEIt8CQSCshiDfAkEgrIiE/R4B/QsEACDOAgshzgIgzgJBAWoh4AIg4AIg4AJBgAJJDQAaIOACCyHNAiDNAgshzAIgzAILIcsCILUCILkCILoCCyG3AiG2AiG1AiC1AkEBaiHhAiDhAiC2AiC3AiDhAkEQSQ0AGhoaIOECILYCILcCCyG0AiGzAiGyAiCyAiCzAiC0AgshsQIhsAIhrwIgrwIgsAIgsQILIa4CIa0CIawCQQRBBkEIIABBGEYi4wIbIABBEEYi4gIbIeQCQQBBCkEMQQ4g4wIbIOICGyLlAjYCkAZBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQBBADYCkAJBAEEANgKUAkEAQQA2ApgCQQBBADYCnAJBAEEANgKgAkEAQQA2AqQCQQBBADYCqAJBAEEANgKsAkEAAgYh5gIg5gIg5gIg5AJJRQ0AGiDmAgIGIecCIOcCAwYh6AIg6AICBiHpAiDpAkECdCLqAkEBakEgai0AACHrAiDqAkECakEgai0AACHsAiDqAkEDakEgai0AACHtAiDqAkEgai0AACHuAiDpAkECdEGwAmog7gJB/wFxIOsCQf8BcUEIdCDsAkH/AXFBEHQg7QJB/wFxQRh0cnJyNgIAIOkCCyHpAiDpAkEBaiHvAiDvAiDvAiDkAkkNABog7wILIegCIOgCCyHnAiDnAgsh5gIg5QJBAWpBAnQh8AIg8AIg5AJrIfECQQACBiHyAiDyAiDyAiDxAklFDQAaIPICAgYh8wIg8wIDBiH0AiD0AgIGIfUCIPUCIOQCaiL2AkEBa0ECdEGwAmooAgAh9wIg9wJBGHQg9wJBCHZyIvkCQQh2Qf8BcUGgiARqLQAAIfoCIPkCQRB2Qf8BcUGgiARqLQAAIfsCIPkCQRh2Qf8BcUGgiARqLQAAIfwCIPkCQf8BcUGgiARqLQAAIf0CIPYCIOQCbkEBa0GgzARqLQAAIf4CIPcCQQh2Qf8BcUGgiARqLQAAIf8CIPcCQRB2Qf8BcUGgiARqLQAAIYADIPcCQRh2Qf8BcUGgiARqLQAAIYEDIPcCQf8BcUGgiARqLQAAIYIDIPYCIOQCa0ECdEGwAmooAgAhgwMg9gJBAnRBsAJqIIIDQf8BcSD/AkH/AXFBCHRyIIADQf8BcUEQdCCBA0H/AXFBGHRyciD9AkH/AXEg+gJB/wFxQQh0ciD7AkH/AXFBEHQg/AJB/wFxQRh0cnIg/gJB/wFxcyD3AiD2AiDkAnAi+AJBAEYbIOQCQQhGIPgCQQRGcRsggwNzNgIAIPUCCyH1AiD1AkEBaiGEAyCEAyCEAyDxAkkNABoghAMLIfQCIPQCCyHzAiDzAgsh8gJBAAIGIYUDIIUDIIUDIPACSUUNABoghQMCBiGGAyCGAwMGIYcDIIcDAgYhiAMgiANBAnRBsAJqKAIAIYkDIIgDQQJ0QcAAaiCJAzYCACCIAwshiAMgiANBAWohigMgigMgigMg8AJJDQAaIIoDCyGHAyCHAwshhgMghgMLIYUDC9EBAQh/IABBgAZsQYDShAVqIQMgAEGABmxBgNOEBWohBCAAQYAGbEGA0YQFakEB/hcCAAIFAgUgAUUNAAwBCwIFAwUgBEEA/kECACEFAgUgBUUgAkEBR3FFDQAgBEEAQn/+AQIAIQYMAQsCBSAFQQFGRQ0AQQAoAoCRhgUhByAAQYAGbEGA1IQFav4QAgAhCCAAQYAGbEGA1YQFav4QAgAhCSAAQYAGbEGA1oQFav4QAgAhCiAIIAkgCiAHEAMLIANBAf4XAgAgAg0BQQENAAsLCwsmAQF+QQApA8gGIQNBACADIABBBHQgAmutfDcDyAYgACABIAIQDQvBBg0BfwF7AX8BewF/AXsBfwF7AX8DewJ+EXsBfwIFIAEgAkEAR3FFDQAgAEEEdCACayIDQcDMBGpBACADIAJq/AsAC0EA/QAEgAchBEEAIAQCCyEGIQUgBSAGIAUgAElFDQAaGiAFIAYCCyEIIQcgByAIAwshCiEJIAkgCgILIQwhCyALQQR0QcDMBGr9AAQAIQ0gDCAN/VEhDiAO/R0BIhBCOIhC/wGDp0EAdkH/AXFBBHRBoAdq/QAEACERQYACIBBCMIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhEkGABCAQQiiIQv8Bg6dBAHZB/wFxakEEdEGgB2r9AAQAIRNBgAYgEEIgiEL/AYOnQQB2Qf8BcWpBBHRBoAdq/QAEACEUQYAIIBBCGIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhFUGACiAQQhCIQv8Bg6dBAHZB/wFxakEEdEGgB2r9AAQAIRZBgAwgEEIIiEL/AYOnQQB2Qf8BcWpBBHRBoAdq/QAEACEXQYAOIBBCAIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhGEGAECAO/R0AIg9COIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhGUGAEiAPQjCIQv8Bg6dBAHZB/wFxakEEdEGgB2r9AAQAIRpBgBQgD0IoiEL/AYOnQQB2Qf8BcWpBBHRBoAdq/QAEACEbQYAWIA9CIIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhHEGAGCAPQhiIQv8Bg6dBAHZB/wFxakEEdEGgB2r9AAQAIR1BgBogD0IQiEL/AYOnQQB2Qf8BcWpBBHRBoAdq/QAEACEeQYAcIA9CCIhC/wGDp0EAdkH/AXFqQQR0QaAHav0ABAAhH0GAHiAPQgCIQv8Bg6dBAHZB/wFxakEEdEGgB2r9AAQAISAgESAS/VEgE/1RIBT9USAV/VEgFv1RIBf9USAY/VEgGf1RIBr9USAb/VEgHP1RIB39USAe/VEgH/1RICD9USEhIAsgIQshDCELIAtBAWohIiAiIAwgIiAASQ0AGhogIiAMCyEKIQkgCSAKCyEIIQcgByAICyEGIQVBACAG/QsEgAcL6wYBO38CBQIFIAFBAUZFDQAgACABIAIgAxADDAELQQBBASABQQFBgAggAkEBa2ogAm4iBEEBIARPGyIFQQFraiAFbiIGIAEgAmxB/wdqQYAIbiIHIAYgB00bIghBASAITxsgAUUbIQkCBQIFIAlBAU1FDQAgACABIAIgAxADDAELQQAgAzYCgJGGBRABIQogAUEAIAEgCmkiCyABIAtNGyIMIAkgDCAJTRsiDUEgIA1BIE0bIg5BAWsgDkEARhsiD0EBaiIQQQFraiAQbiERIAAgAWohEiAPIAEgEUEBa2ogEW5BAWsiEyAPIBNNGyEUQQBBAEEAAgghFyEWIRUgFSAWIBcgFUEfSUUNABoaGiAVIBYgFwIIIRohGSEYIBggGSAaAwghHSEcIRsgGyAcIB0CCCEgIR8hHiAeIB8gICAgIBRPDQIaGhogHkEBaiEhIAAgIEEBaiARbGohIiAfICACCSElISQgJCAlIApBASAhdHFBAEcgIiASSXFFDQAaGiAhQYAGbEGA1IQFaiAi/hcCACAhQYAGbEGA1YQFaiARIBIgImsiIyARICNNG/4XAgAgIUGABmxBgNaEBWogAv4XAgAgJEEBICF0ciEmICVBAWohJyAmICcLISUhJCAeICQgJQshICEfIR4gHkEBaiEoICggHyAgIChBH0kNABoaGiAoIB8gIAshHSEcIRsgGyAcIB0LIRohGSEYIBggGSAaCyEXIRYhFUEBIBYQACEpIAAgASARIAEgEU0bIAIgAxADIBYCBiEqICogKkEAR0UNABogKgIGISsgKwMGISwgLAIGIS1BACAtQQACCCEwIS8hLiAuIC8gMCAvQQBHRQ0AGhoaIC4gLyAwAgghMyEyITEgMSAyIDMDCCE2ITUhNCA0IDUgNgIIITkhOCE3IDcgOCA5IDhBAXFFDQAaGhogN0GABmxBgNKEBWpBAP5BAgAhOyAtQQEgN3QiOnMgO0EARw0EGiA5IDpyITwgNyA4IDwLITkhOCE3IDdBAWohPSA4QQF2IT4gPSA+IDkgPkEARw0AGhoaID0gPiA5CyE2ITUhNCA0IDUgNgshMyEyITEgMSAyIDMLITAhLyEuIC0LIS0gLSAtQQBHDQAaIC0LISwgLAshKyArCyEqQYCRhgVBAEHAAPwLAAsLCxgAQQBBAEGgiAT8CwBBwMwEQQAgAPwLAAsUACAAQYAGbEGA0YQFakEA/hcCAAuJDAQCfgF7An5Lf0EAKQPABiEAQQApA8gGIQFBACAAQgOGNwPAzARBACABQgOGNwPIzARBAUEBQQAQDUEA/QAEgAchAkEAIAL9HQAiA6c2AtAGQQAgA0IgiKc2AtQGQQAgAv0dASIEpzYC2AZBACAEQiCIpzYC3AZBAAIGIQUgBSAFQQxJRQ0AGiAFAgYhBiAGAwYhByAHAgYhCCAIQaAGai0AACEJIAhB0AZqLQAAIQogCEHQBmogCkH/AXEgCUH/AXFzQf8BcToAACAICyEIIAhBAWohCyALIAtBDEkNABogCwshByAHCyEGIAYLIQVBAC0A3wYhDEEAIAxB/wFxQf8AcUH/AXE6AN8GQQAoApAGIQ1BACgC0AYhDkEAKALUBiEPQQAoAtgGIRBBACgC3AYhEUEAKAJAIRJBACgCRCETQQAoAkghFEEAKAJMIRUgDUEBayEWQQAgDiAScyAPIBNzIBAgFHMgESAVcwIHIRshGiEZIRghFyAXIBggGSAaIBsDByEgIR8hHiEdIRwgHEEBaiEhIBxBAWpBAnQiIkECdEHAAGooAgAhIyAdQf8BcUECdEGgigRqKAIAISQgHkEIdkH/AXFBAnRBoJIEaigCACElIB9BEHZB/wFxQQJ0QaCaBGooAgAhJiAgQRh2Qf8BcUECdEGgogRqKAIAIScgIyAkICVzICYgJ3NzcyEoICJBAWpBAnRBwABqKAIAISkgHkH/AXFBAnRBoIoEaigCACEqIB9BCHZB/wFxQQJ0QaCSBGooAgAhKyAgQRB2Qf8BcUECdEGgmgRqKAIAISwgHUEYdkH/AXFBAnRBoKIEaigCACEtICkgKiArcyAsIC1zc3MhLiAiQQJqQQJ0QcAAaigCACEvIB9B/wFxQQJ0QaCKBGooAgAhMCAgQQh2Qf8BcUECdEGgkgRqKAIAITEgHUEQdkH/AXFBAnRBoJoEaigCACEyIB5BGHZB/wFxQQJ0QaCiBGooAgAhMyAvIDAgMXMgMiAzc3NzITQgIkEDakECdEHAAGooAgAhNSAgQf8BcUECdEGgigRqKAIAITYgHUEIdkH/AXFBAnRBoJIEaigCACE3IB5BEHZB/wFxQQJ0QaCaBGooAgAhOCAfQRh2Qf8BcUECdEGgogRqKAIAITkgNSA2IDdzIDggOXNzcyE6ICEgKCAuIDQgOiAhIBZJDQAaGhoaGiAhICggLiA0IDoLISAhHyEeIR0hHCAcIB0gHiAfICALIRshGiEZIRghFyANQQJ0IjtBAnRBwABqKAIAITwgGUEIdkH/AXFBoIgEai0AACE9IBpBEHZB/wFxQaCIBGotAAAhPiAbQRh2Qf8BcUGgiARqLQAAIT8gGEH/AXFBoIgEai0AACFAIDtBAWpBAnRBwABqKAIAIUEgGkEIdkH/AXFBoIgEai0AACFCIBtBEHZB/wFxQaCIBGotAAAhQyAYQRh2Qf8BcUGgiARqLQAAIUQgGUH/AXFBoIgEai0AACFFIDtBAmpBAnRBwABqKAIAIUYgG0EIdkH/AXFBoIgEai0AACFHIBhBEHZB/wFxQaCIBGotAAAhSCAZQRh2Qf8BcUGgiARqLQAAIUkgGkH/AXFBoIgEai0AACFKIDtBA2pBAnRBwABqKAIAIUsgGEEIdkH/AXFBoIgEai0AACFMIBlBEHZB/wFxQaCIBGotAAAhTSAaQRh2Qf8BcUGgiARqLQAAIU4gG0H/AXFBoIgEai0AACFPQQAgPCBAQf8BcSA9Qf8BcUEIdHIgPkH/AXFBEHQgP0H/AXFBGHRycnM2AtAGQQAgQSBFQf8BcSBCQf8BcUEIdHIgQ0H/AXFBEHQgREH/AXFBGHRycnM2AtQGQQAgRiBKQf8BcSBHQf8BcUEIdHIgSEH/AXFBEHQgSUH/AXFBGHRycnM2AtgGQQAgSyBPQf8BcSBMQf8BcUEIdHIgTUH/AXFBEHQgTkH/AXFBGHRycnM2AtwGQQBBADYC8AZBAEEANgL0BkEAQQA2AvgGQQBBADYC/AZBAP0MAAAAAAAAAAAAAAAAAAAAAP0LBIAHC3sBBn9BACgC4AYhAAIFIABBAEZFDQBBAEEBNgLgBkEAKALQBiEBQQAoAtQGIQJBACgC2AYhA0EAKALcBiEEQQAgATYCsAZBACACNgK0BkEAIAM2ArgGQQAgBDYCvAZBAC0AvwYhBUEAIAVB/wFxQYABckH/AXE6AL8GCws='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 10586304);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 66592),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 66592, 66592))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.encKey": new Uint8Array(memoryExport.buffer, 32, 32),
        "state.encKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 64, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 64 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 304, 480),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 304 + i * 480, 480))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 784, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 784 + i * 4, 4))),
        "state.nonce": new Uint8Array(memoryExport.buffer, 800, 16),
        "state.nonce_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 800 + i * 16, 16))),
        "state.ctr": new Uint8Array(memoryExport.buffer, 816, 16),
        "state.ctr_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 816 + i * 16, 16))),
        "state.aadLen": new Uint8Array(memoryExport.buffer, 832, 8),
        "state.aadLen_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 832 + i * 8, 8))),
        "state.dataLen": new Uint8Array(memoryExport.buffer, 840, 8),
        "state.dataLen_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 840 + i * 8, 8))),
        "state.tag": new Uint8Array(memoryExport.buffer, 848, 16),
        "state.tag_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 848 + i * 16, 16))),
        "state.ctrReady": new Uint8Array(memoryExport.buffer, 864, 4),
        "state.ctrReady_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 864 + i * 4, 4))),
        "state.ghash": new Uint8Array(memoryExport.buffer, 880, 48),
        "state.ghash_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 880 + i * 48, 48))),
        "state.ghash.y": new Uint8Array(memoryExport.buffer, 880, 16),
        "state.ghash.y_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 880 + i * 16, 16))),
        "state.ghash.y64": new Uint8Array(memoryExport.buffer, 896, 16),
        "state.ghash.y64_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 896 + i * 16, 16))),
        "state.ghash.h": new Uint8Array(memoryExport.buffer, 912, 16),
        "state.ghash.h_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 912 + i * 16, 16))),
        "state.table64v": new Uint8Array(memoryExport.buffer, 928, 65536),
        "state.table64v_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 928 + i * 65536, 65536))),
        "state.tmp64v": new Uint8Array(memoryExport.buffer, 66464, 128),
        "state.tmp64v_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 66464 + i * 128, 128))),
        constants: new Uint8Array(memoryExport.buffer, 66592, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 66592 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 66592, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 66592 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 66592, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 66592 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 66848, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 66848 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 67872, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 67872 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 68896, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 68896 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 69920, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 69920 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 70944, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 70944 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 70944, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 70944 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 71200, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 71200 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 72224, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 72224 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 73248, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 73248 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 74272, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 74272 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 75296, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 75296 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 75312, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 75312 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 75328, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 75328 + i * 10485760, 10485760))),
        _worker: new Uint8Array(memoryExport.buffer, 10561152, 25152),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561152 + i * 25152, 25152))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 10561152, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561152 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 10561280, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561280 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 10561408, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561408 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10561536, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561536 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 10561664, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10561664 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 10586240, 64),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10586240 + i * 64, 64)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function aes_gcmsiv(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
