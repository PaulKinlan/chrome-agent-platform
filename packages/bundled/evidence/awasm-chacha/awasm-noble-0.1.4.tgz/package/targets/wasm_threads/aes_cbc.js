// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 161, maximum: 161, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABQQpgAn9/AX9gAAF/YAF/AGADf39/AX9gA39/fwBgAABgA39/fwN/f39gAn9/An9/YAF/AX9gBX9/f39/BX9/f39/AlsEA2VudgdfbWVtb3J5AgOhAaEBA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAw0MAAEDBAIEAgUEAgIAB7QBDQZtZW1vcnkCAA5fd29ya2VyX25vdGlmeQADDl93b3JrZXJfb25saW5lAAQKYWRkUGFkZGluZwAFDWRlY3J5cHRCbG9ja3MABgtkZWNyeXB0SW5pdAAHDWVuY3J5cHRCbG9ja3MACAtlbmNyeXB0SW5pdAAJCmluaXRUYWJsZXMACgppbml0V29ya2VyAAsFcmVzZXQADApzdG9wV29ya2VyAA0NdmVyaWZ5UGFkZGluZwAOCrtFDOIBARB/QQAgAUEAAgYhBCEDIQIgAiADIAQgA0EAR0UNABoaGiACIAMgBAIGIQchBiEFIAUgBiAHAwYhCiEJIQggCCAJIAoCBiENIQwhCyALIAwgDSAMQQFxRQ0AGhoaIAtBgAZsQYDPgAVqIAD+FwIAIAtBgAZsQYDPgAVqQQH+AAIAIQ4gDUEBIAt0ciEPIAsgDCAPCyENIQwhCyALQQFqIRAgDEEBdiERIBAgESANIBFBAEcNABoaGiAQIBEgDQshCiEJIQggCCAJIAoLIQchBiEFIAUgBiAHCyEEIQMhAiAEC5oBAQx/QQBBAAIHIQEhACAAIAEgAEEfSUUNABoaIAAgAQIHIQMhAiACIAMDByEFIQQgBCAFAgchByEGIAZBAWoiCEGABmxBgM2ABWr+EAIAIQkgB0EBIAh0QQAgCRtyIQogBiAKCyEHIQYgBkEBaiELIAsgByALQR9JDQAaGiALIAcLIQUhBCAEIAULIQMhAiACIAMLIQEhACABC+cFASF/QQFBACABQQBGGyEEIABBwMgAai0AACEFIABBwMgAaiACIAEgAUEARhsiAyAFQf8BcUEAIANJG0H/AXE6AAAgAEEBaiIGQcDIAGotAAAhByAGQcDIAGogAyAHQf8BcUEBIANJG0H/AXE6AAAgAEECaiIIQcDIAGotAAAhCSAIQcDIAGogAyAJQf8BcUECIANJG0H/AXE6AAAgAEEDaiIKQcDIAGotAAAhCyAKQcDIAGogAyALQf8BcUEDIANJG0H/AXE6AAAgAEEEaiIMQcDIAGotAAAhDSAMQcDIAGogAyANQf8BcUEEIANJG0H/AXE6AAAgAEEFaiIOQcDIAGotAAAhDyAOQcDIAGogAyAPQf8BcUEFIANJG0H/AXE6AAAgAEEGaiIQQcDIAGotAAAhESAQQcDIAGogAyARQf8BcUEGIANJG0H/AXE6AAAgAEEHaiISQcDIAGotAAAhEyASQcDIAGogAyATQf8BcUEHIANJG0H/AXE6AAAgAEEIaiIUQcDIAGotAAAhFSAUQcDIAGogAyAVQf8BcUEIIANJG0H/AXE6AAAgAEEJaiIWQcDIAGotAAAhFyAWQcDIAGogAyAXQf8BcUEJIANJG0H/AXE6AAAgAEEKaiIYQcDIAGotAAAhGSAYQcDIAGogAyAZQf8BcUEKIANJG0H/AXE6AAAgAEELaiIaQcDIAGotAAAhGyAaQcDIAGogAyAbQf8BcUELIANJG0H/AXE6AAAgAEEMaiIcQcDIAGotAAAhHSAcQcDIAGogAyAdQf8BcUEMIANJG0H/AXE6AAAgAEENaiIeQcDIAGotAAAhHyAeQcDIAGogAyAfQf8BcUENIANJG0H/AXE6AAAgAEEOaiIgQcDIAGotAAAhISAgQcDIAGogAyAhQf8BcUEOIANJG0H/AXE6AAAgAEEPaiIiQcDIAGotAAAhIyAiQcDIAGogAyAjQf8BcUEPIANJG0H/AXE6AAAgBAvVCgFRf0EAKAKABCEDQQACCCEEIAQgBCAASUUNABogBAIIIQUgBQMIIQYgBgIIIQcgB0EEdEHAyABqIggoAgAhCSAIQQRqIgooAgAhCyAKQQRqIgwoAgAhDSAMQQRqKAIAIQ5BACgCICEPQQAoAiQhEEEAKAIoIRFBACgCLCESIANBAWshE0EAIAkgD3MgCyAQcyANIBFzIA4gEnMCCSEYIRchFiEVIRQgFCAVIBYgFyAYAwkhHSEcIRshGiEZIBlBAWohHiAZQQFqQQJ0Ih9BAnRBIGooAgAhICAaQf8BcUECdEGgKGooAgAhISAdQQh2Qf8BcUECdEGgMGooAgAhIiAcQRB2Qf8BcUECdEGgOGooAgAhIyAbQRh2Qf8BcUECdEGgwABqKAIAISQgICAhICJzICMgJHNzcyElIB9BAWpBAnRBIGooAgAhJiAbQf8BcUECdEGgKGooAgAhJyAaQQh2Qf8BcUECdEGgMGooAgAhKCAdQRB2Qf8BcUECdEGgOGooAgAhKSAcQRh2Qf8BcUECdEGgwABqKAIAISogJiAnIChzICkgKnNzcyErIB9BAmpBAnRBIGooAgAhLCAcQf8BcUECdEGgKGooAgAhLSAbQQh2Qf8BcUECdEGgMGooAgAhLiAaQRB2Qf8BcUECdEGgOGooAgAhLyAdQRh2Qf8BcUECdEGgwABqKAIAITAgLCAtIC5zIC8gMHNzcyExIB9BA2pBAnRBIGooAgAhMiAdQf8BcUECdEGgKGooAgAhMyAcQQh2Qf8BcUECdEGgMGooAgAhNCAbQRB2Qf8BcUECdEGgOGooAgAhNSAaQRh2Qf8BcUECdEGgwABqKAIAITYgMiAzIDRzIDUgNnNzcyE3IB4gJSArIDEgNyAeIBNJDQAaGhoaGiAeICUgKyAxIDcLIR0hHCEbIRohGSAZIBogGyAcIB0LIRghFyEWIRUhFCADQQJ0IjhBAnRBIGooAgAhOSAYQQh2Qf8BcUGgJmotAAAhOiAXQRB2Qf8BcUGgJmotAAAhOyAWQRh2Qf8BcUGgJmotAAAhPCAVQf8BcUGgJmotAAAhPSA4QQFqQQJ0QSBqKAIAIT4gFUEIdkH/AXFBoCZqLQAAIT8gGEEQdkH/AXFBoCZqLQAAIUAgF0EYdkH/AXFBoCZqLQAAIUEgFkH/AXFBoCZqLQAAIUIgOEECakECdEEgaigCACFDIBZBCHZB/wFxQaAmai0AACFEIBVBEHZB/wFxQaAmai0AACFFIBhBGHZB/wFxQaAmai0AACFGIBdB/wFxQaAmai0AACFHIDhBA2pBAnRBIGooAgAhSCAXQQh2Qf8BcUGgJmotAAAhSSAWQRB2Qf8BcUGgJmotAAAhSiAVQRh2Qf8BcUGgJmotAAAhSyAYQf8BcUGgJmotAAAhTEEAKAKQBCFNQQAoApQEIU5BACgCmAQhT0EAKAKcBCFQIAggOSA9Qf8BcSA6Qf8BcUEIdHIgO0H/AXFBEHQgPEH/AXFBGHRycnMgTXM2AgAgCEEEaiJRID4gQkH/AXEgP0H/AXFBCHRyIEBB/wFxQRB0IEFB/wFxQRh0cnJzIE5zNgIAIFFBBGoiUiBDIEdB/wFxIERB/wFxQQh0ciBFQf8BcUEQdCBGQf8BcUEYdHJycyBPczYCACBSQQRqIEggTEH/AXEgSUH/AXFBCHRyIEpB/wFxQRB0IEtB/wFxQRh0cnJzIFBzNgIAQQAgCTYCkARBACALNgKUBEEAIA02ApgEQQAgDjYCnAQgBwshByAHQQFqIVMgUyBTIABJDQAaIFMLIQYgBgshBSAFCyEEC5oOAU1/EApBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgghBSAFIAUgA0lFDQAaIAUCCCEGIAYDCCEHIAcCCCEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACCCERIBEgESAQSUUNABogEQIIIRIgEgMIIRMgEwIIIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBoARqLQAAIRkgGEEQdkH/AXFBoARqLQAAIRogGEEYdkH/AXFBoARqLQAAIRsgGEH/AXFBoARqLQAAIRwgFSADbkEBa0GgyABqLQAAIR0gFkEIdkH/AXFBoARqLQAAIR4gFkEQdkH/AXFBoARqLQAAIR8gFkEYdkH/AXFBoARqLQAAISAgFkH/AXFBoARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgghJCAkICQgD0lFDQAaICQCCCElICUDCCEmICYCCCEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJEEAAgghKiAqICogD0lFDQAaICoCCCErICsDCCEsICwCCCEtIC1BAnRBIGooAgAhLiAtQQJ0QZACaiAuNgIAIC0LIS0gLUEBaiEvIC8gLyAPSQ0AGiAvCyEsICwLISsgKwshKkEAKAKABCEwIDBBAWohMUEAAgghMiAyIDIgMUlFDQAaIDICCCEzIDMDCCE0IDQCCCE1IDFBAWsgNWtBAnQiNkECdEGQAmooAgAhNyA1QQJ0IjhBAnRBIGogNzYCACA2QQFqQQJ0QZACaigCACE5IDhBAWpBAnRBIGogOTYCACA2QQJqQQJ0QZACaigCACE6IDhBAmpBAnRBIGogOjYCACA2QQNqQQJ0QZACaigCACE7IDhBA2pBAnRBIGogOzYCACA1CyE1IDVBAWohPCA8IDwgMUkNABogPAshNCA0CyEzIDMLITIgD0EIayE9QQACCCE+ID4gPiA9SUUNABogPgIIIT8gPwMIIUAgQAIIIUEgQUEEaiJCQQJ0QSBqKAIAIUMgQ0EIdkH/AXFBoARqLQAAIUQgQ0EQdkH/AXFBoARqLQAAIUUgQ0EYdkH/AXFBoARqLQAAIUYgQ0H/AXFBoARqLQAAIUcgR0H/AXEgREH/AXFBCHRyIEVB/wFxQRB0IEZB/wFxQRh0cnIiSEEAdkH/AXFBAnRBoChqKAIAIUkgSEEIdkH/AXFBAnRBoDBqKAIAIUogSEEQdkH/AXFBAnRBoDhqKAIAIUsgSEEYdkH/AXFBAnRBoMAAaigCACFMIEJBAnRBIGogSSBKcyBLIExzczYCACBBCyFBIEFBAWohTSBNIE0gPUkNABogTQshQCBACyE/ID8LIT4L2QoBVX9BACgCgAQhA0EAAgghBCAEIAQgAElFDQAaIAQCCCEFIAUDCCEGIAYCCCEHIAdBBHRBwMgAaiIIKAIAIQkgCEEEaiIKKAIAIQsgCkEEaiIMKAIAIQ0gDEEEaigCACEOQQAoApAEIQ9BACgClAQhEEEAKAKYBCERQQAoApwEIRJBACgCICETQQAoAiQhFEEAKAIoIRVBACgCLCEWIANBAWshF0EAIAkgD3MgE3MgCyAQcyAUcyANIBFzIBVzIA4gEnMgFnMCCSEcIRshGiEZIRggGCAZIBogGyAcAwkhISEgIR8hHiEdIB1BAWohIiAdQQFqQQJ0IiNBAnRBIGooAgAhJCAeQf8BcUECdEGgBmooAgAhJSAfQQh2Qf8BcUECdEGgDmooAgAhJiAgQRB2Qf8BcUECdEGgFmooAgAhJyAhQRh2Qf8BcUECdEGgHmooAgAhKCAkICUgJnMgJyAoc3NzISkgI0EBakECdEEgaigCACEqIB9B/wFxQQJ0QaAGaigCACErICBBCHZB/wFxQQJ0QaAOaigCACEsICFBEHZB/wFxQQJ0QaAWaigCACEtIB5BGHZB/wFxQQJ0QaAeaigCACEuICogKyAscyAtIC5zc3MhLyAjQQJqQQJ0QSBqKAIAITAgIEH/AXFBAnRBoAZqKAIAITEgIUEIdkH/AXFBAnRBoA5qKAIAITIgHkEQdkH/AXFBAnRBoBZqKAIAITMgH0EYdkH/AXFBAnRBoB5qKAIAITQgMCAxIDJzIDMgNHNzcyE1ICNBA2pBAnRBIGooAgAhNiAhQf8BcUECdEGgBmooAgAhNyAeQQh2Qf8BcUECdEGgDmooAgAhOCAfQRB2Qf8BcUECdEGgFmooAgAhOSAgQRh2Qf8BcUECdEGgHmooAgAhOiA2IDcgOHMgOSA6c3NzITsgIiApIC8gNSA7ICIgF0kNABoaGhoaICIgKSAvIDUgOwshISEgIR8hHiEdIB0gHiAfICAgIQshHCEbIRohGSEYIANBAnQiPEECdEEgaigCACE9IBpBCHZB/wFxQaAEai0AACE+IBtBEHZB/wFxQaAEai0AACE/IBxBGHZB/wFxQaAEai0AACFAIBlB/wFxQaAEai0AACFBIDxBAWpBAnRBIGooAgAhQyAbQQh2Qf8BcUGgBGotAAAhRCAcQRB2Qf8BcUGgBGotAAAhRSAZQRh2Qf8BcUGgBGotAAAhRiAaQf8BcUGgBGotAAAhRyA8QQJqQQJ0QSBqKAIAIUkgHEEIdkH/AXFBoARqLQAAIUogGUEQdkH/AXFBoARqLQAAIUsgGkEYdkH/AXFBoARqLQAAIUwgG0H/AXFBoARqLQAAIU0gPEEDakECdEEgaigCACFPIBlBCHZB/wFxQaAEai0AACFQIBpBEHZB/wFxQaAEai0AACFRIBtBGHZB/wFxQaAEai0AACFSIBxB/wFxQaAEai0AACFTIAggPSBBQf8BcSA+Qf8BcUEIdHIgP0H/AXFBEHQgQEH/AXFBGHRycnMiQjYCACAIQQRqIlUgQyBHQf8BcSBEQf8BcUEIdHIgRUH/AXFBEHQgRkH/AXFBGHRycnMiSDYCACBVQQRqIlYgSSBNQf8BcSBKQf8BcUEIdHIgS0H/AXFBEHQgTEH/AXFBGHRycnMiTjYCACBWQQRqIE8gU0H/AXEgUEH/AXFBCHRyIFFB/wFxQRB0IFJB/wFxQRh0cnJzIlQ2AgBBACBCNgKQBEEAIEg2ApQEQQAgTjYCmARBACBUNgKcBCAHCyEHIAdBAWohVyBXIFcgAEkNABogVwshBiAGCyEFIAULIQQLnQkBKX8QCkEEQQZBCCAAQRhGIgIbIABBEEYiARshA0EAQQpBDEEOIAIbIAEbIgQ2AoAEQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQACCCEFIAUgBSADSUUNABogBQIIIQYgBgMIIQcgBwIIIQggCEECdCIJQQFqLQAAIQogCUECai0AACELIAlBA2otAAAhDCAJLQAAIQ0gCEECdEGQAmogDUH/AXEgCkH/AXFBCHQgC0H/AXFBEHQgDEH/AXFBGHRycnI2AgAgCAshCCAIQQFqIQ4gDiAOIANJDQAaIA4LIQcgBwshBiAGCyEFIARBAWpBAnQhDyAPIANrIRBBAAIIIREgESARIBBJRQ0AGiARAgghEiASAwghEyATAgghFCAUIANqIhVBAWtBAnRBkAJqKAIAIRYgFkEYdCAWQQh2ciIYQQh2Qf8BcUGgBGotAAAhGSAYQRB2Qf8BcUGgBGotAAAhGiAYQRh2Qf8BcUGgBGotAAAhGyAYQf8BcUGgBGotAAAhHCAVIANuQQFrQaDIAGotAAAhHSAWQQh2Qf8BcUGgBGotAAAhHiAWQRB2Qf8BcUGgBGotAAAhHyAWQRh2Qf8BcUGgBGotAAAhICAWQf8BcUGgBGotAAAhISAVIANrQQJ0QZACaigCACEiIBVBAnRBkAJqICFB/wFxIB5B/wFxQQh0ciAfQf8BcUEQdCAgQf8BcUEYdHJyIBxB/wFxIBlB/wFxQQh0ciAaQf8BcUEQdCAbQf8BcUEYdHJyIB1B/wFxcyAWIBUgA3AiF0EARhsgA0EIRiAXQQRGcRsgInM2AgAgFAshFCAUQQFqISMgIyAjIBBJDQAaICMLIRMgEwshEiASCyERQQACCCEkICQgJCAPSUUNABogJAIIISUgJQMIISYgJgIIIScgJ0ECdEGQAmooAgAhKCAnQQJ0QSBqICg2AgAgJwshJyAnQQFqISkgKSApIA9JDQAaICkLISYgJgshJSAlCyEkC4oKAT1/QQAoArBIIQACBSAAQQBGRQ0AQQBBAQIHIQIhASABIAIDByEEIQMgA0EBaiEFIAQgBEEBdCAEQQd2QQFxQRtsc0H/AXFzIQYgA0GgBmogBEH/AXE6AAAgBSAGIAVBgAJJDQAaGiAFIAYLIQQhAyADIAQLIQIhAUEAQeMAQf8BcToAoARBAAIIIQcgByAHQf8BSUUNABogBwIIIQggCAMIIQkgCQIIIQpB/wEgCmtBoAZqLQAAIQsgCkGgBmotAAAhDiAOQf8BcUGgBGogC0H/AXEiDCAMQQh0ciINIA1BBHZzIA1BBXZzIA1BBnZzIA1BB3ZzQeMAc0H/AXFB/wFxOgAAIAoLIQogCkEBaiEPIA8gD0H/AUkNABogDwshCSAJCyEIIAgLIQdBAAIIIRAgECAQQYACSUUNABogEAIIIREgEQMIIRIgEgIIIRMgE0GgJmpBAEH/AXE6AAAgEwshEyATQQFqIRQgFCAUQYACSQ0AGiAUCyESIBILIREgEQshEEEAAgghFSAVIBVBgAJJRQ0AGiAVAgghFiAWAwghFyAXAgghGCAYQaAEai0AACEZIBlB/wFxQaAmaiAYQf8BcToAACAYCyEYIBhBAWohGiAaIBpBgAJJDQAaIBoLIRcgFwshFiAWCyEVQQBBAQIHIRwhGyAbIBwDByEeIR0gHUEBaiEfIB5BAXQgHkEHdkEBcUEbbHNB/wFxISAgHUGgyABqIB5B/wFxOgAAIB8gICAfQRBJDQAaGiAfICALIR4hHSAdIB4LIRwhG0EAAgghISAhICFBgAJJRQ0AGiAhAgghIiAiAwghIyAjAgghJCAkQaAEai0AACElICRBoCZqLQAAIScgJEECdEGgBmogJUH/AXEiJiAmQQF0ICZBB3ZBAXFBG2xzQf8BcXNBGHQgJkEQdCAmQQh0ICZBAXQgJkEHdkEBcUEbbHNB/wFxcnJyNgIAICRBAnRBoChqICdB/wFxIiggKEEBdCAoQQd2QQFxQRtsc0H/AXEiK3MgK0EBdCArQQd2QQFxQRtsc0H/AXEiLEEBdCAsQQd2QQFxQRtsc0H/AXFzQRh0ICggKEEBdCAoQQd2QQFxQRtsc0H/AXEiLUEBdCAtQQd2QQFxQRtsc0H/AXEiLnMgLkEBdCAuQQd2QQFxQRtsc0H/AXFzQRB0ICggKEEBdCAoQQd2QQFxQRtsc0H/AXEiKUEBdCApQQd2QQFxQRtsc0H/AXEiKkEBdCAqQQd2QQFxQRtsc0H/AXFzQQh0IChBAXQgKEEHdkEBcUEbbHNB/wFxIi8gL0EBdCAvQQd2QQFxQRtsc0H/AXEiMHMgMEEBdCAwQQd2QQFxQRtsc0H/AXFzcnJyNgIAICQLISQgJEEBaiExIDEgMUGAAkkNABogMQshIyAjCyEiICILISFBAAIIITIgMiAyQYACSUUNABogMgIIITMgMwMIITQgNAIIITUgNUECdEGgBmooAgAhNiA1QQJ0QaAOaiA2QQh3Ijc2AgAgNUECdEGgFmogN0EIdyI4NgIAIDVBAnRBoB5qIDhBCHc2AgAgNUECdEGgKGooAgAhOSA1QQJ0QaAwaiA5QQh3Ijo2AgAgNUECdEGgOGogOkEIdyI7NgIAIDVBAnRBoMAAaiA7QQh3NgIAIDULITUgNUEBaiE8IDwgPEGAAkkNABogPAshNCA0CyEzIDMLITJBAEEBNgKwSAsLfAEEfyAAQYAGbEGAzoAFaiEDIABBgAZsQYDPgAVqIQQgAEGABmxBgM2ABWpBAf4XAgACBQIFIAFFDQAMAQsCBQMFIARBAP5BAgAhBQIFIAVFIAJBAUdxRQ0AIARBAEJ//gECACEGDAELIANBAf4XAgAgAg0BQQENAAsLCwsXAEEAQQBBoAT8CwBBwMgAQQAgAPwLAAsUACAAQYAGbEGAzYAFakEA/hcCAAusBAETfyAAQQFrQcDIAGotAAAhAiAAQQFrQcDIAGotAAAhBCAAQQJrQcDIAGotAAAhBSAAQQNrQcDIAGotAAAhBiAAQQRrQcDIAGotAAAhByAAQQVrQcDIAGotAAAhCCAAQQZrQcDIAGotAAAhCSAAQQdrQcDIAGotAAAhCiAAQQhrQcDIAGotAAAhCyAAQQlrQcDIAGotAAAhDCAAQQprQcDIAGotAAAhDSAAQQtrQcDIAGotAAAhDiAAQQxrQcDIAGotAAAhDyAAQQ1rQcDIAGotAAAhECAAQQ5rQcDIAGotAAAhESAAQQ9rQcDIAGotAAAhEiAAQRBrQcDIAGotAAAhE0EAIAJB/wFxIgMgAEEARiAAIAFwQQBHciADQQBGIAMgAUtyckEAIANJIARB/wFxIANHcUEBIANJIAVB/wFxIANHcXJBAiADSSAGQf8BcSADR3FyQQMgA0kgB0H/AXEgA0dxckEEIANJIAhB/wFxIANHcXJBBSADSSAJQf8BcSADR3FyQQYgA0kgCkH/AXEgA0dxckEHIANJIAtB/wFxIANHcXJBCCADSSAMQf8BcSADR3FyQQkgA0kgDUH/AXEgA0dxckEKIANJIA5B/wFxIANHcXJBCyADSSAPQf8BcSADR3FyQQwgA0kgEEH/AXEgA0dxckENIANJIBFB/wFxIANHcXJBDiADSSASQf8BcSADR3FyQQ8gA0kgE0H/AXEgA0dxcnIbIRQgFAs='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 10520208);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 544),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 544, 544))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 272 + i * 240, 240))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 512 + i * 4, 4))),
        "state.iv": new Uint8Array(memoryExport.buffer, 528, 16),
        "state.iv_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 16, 16))),
        constants: new Uint8Array(memoryExport.buffer, 544, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 800 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1824 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2848 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3872 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4896 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4896 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5152 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6176 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7200 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8224 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9248 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9264 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9280 + i * 10485760, 10485760))),
        _worker: new Uint8Array(memoryExport.buffer, 10495104, 25104),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495104 + i * 25104, 25104))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 10495104, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495104 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 10495232, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495232 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 10495360, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495360 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10495488, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495488 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 10495616, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495616 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 10520192, 4),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10520192 + i * 4, 4)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function aes_cbc(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
