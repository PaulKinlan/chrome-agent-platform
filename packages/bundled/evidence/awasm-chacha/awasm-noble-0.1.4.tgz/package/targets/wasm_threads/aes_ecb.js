// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const workers = [];
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    let _poolId;
    _imports.env._worker_notifyBridge = (cmd, mask) => {
        instance.exports._worker_notify(cmd, mask);
        if (pool) {
            if (typeof _poolId !== 'number')
                throw new Error('not installed');
            return pool.notify(_poolId, mask);
        }
    };
    _imports.env._worker_onlineBridge = () => {
        let res = instance.exports._worker_online();
        if (pool)
            res &= pool.online();
        return res;
    };
    function initWorkers(limit = 32) {
        if (pool) {
            _poolId = pool.install(code, instance.exports.memory);
            return _poolId;
        }
        (async () => {
            try {
                let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
                    ? navigator.hardwareConcurrency
                    : 4;
                W = Math.min(W, 32, limit);
                let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
                let initWorker;
                if (typeof Worker !== 'undefined') {
                    const urlSrc = "(" + workerSrc + ")(self);";
                    let url;
                    try {
                        url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' }));
                    }
                    catch {
                        url = 'data:text/javascript;base64,' + btoa(urlSrc);
                    }
                    initWorker = () => {
                        if (!url)
                            return;
                        try {
                            return new Worker(url);
                        }
                        catch { }
                        try {
                            return new Worker(url, { type: 'module' });
                        }
                        catch { }
                    };
                }
                else {
                    let NodeWorker;
                    try {
                        // Avoid bundlers stuff
                        NodeWorker = new Function('return req' + 'uire("node:worker_threads").Worker')();
                    }
                    catch { }
                    if (!NodeWorker) {
                        try {
                            NodeWorker = (await import('node:worker_threads')).Worker;
                        }
                        catch { }
                    }
                    if (NodeWorker) {
                        // Node ESM eval workers lack require(); parentPort comes from import fallback.
                        initWorker = () => new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => (" + workerSrc + ")(parentPort));", { eval: true });
                    }
                }
                while (workers.length < W - 1) {
                    const w = initWorker && initWorker();
                    if (!w)
                        break;
                    const id = workers.push(w);
                    w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
                    if (_imports.env && _imports.env.onWorkerInstall)
                        _imports.env.onWorkerInstall(w, id);
                    if (typeof w.unref === 'function')
                        w.unref();
                }
            }
            catch (e) {
                console.log('initWorkers', e);
            }
        })();
    }
    _imports.env.initWorkers = initWorkers;
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 161, maximum: 161, shared: true });
    const code = Uint8Array.from(atob('AGFzbQEAAAABSAtgAn9/AX9gAAF/YAF/AGAEf39/fwBgA39/fwF/YAN/f38AYAAAYAF/AX9gBX9/f39/BX9/f39/YAN/f38Df39/YAJ/fwJ/fwJbBANlbnYHX21lbW9yeQIDoQGhAQNlbnYUX3dvcmtlcl9ub3RpZnlCcmlkZ2UAAANlbnYUX3dvcmtlcl9vbmxpbmVCcmlkZ2UAAQNlbnYLaW5pdFdvcmtlcnMAAgMREAMDAAEEBQIFAgYFAwMCAgAHmAIRBm1lbW9yeQIAHF9wcm9jZXNzQmxvY2tzRGVjX3RocmVhZF9pbnQAAxxfcHJvY2Vzc0Jsb2Nrc0VuY190aHJlYWRfaW50AAQOX3dvcmtlcl9ub3RpZnkABQ5fd29ya2VyX29ubGluZQAGCmFkZFBhZGRpbmcABw1kZWNyeXB0QmxvY2tzAAgLZGVjcnlwdEluaXQACQ1lbmNyeXB0QmxvY2tzAAoLZW5jcnlwdEluaXQACwppbml0VGFibGVzAAwKaW5pdFdvcmtlcgANEHByb2Nlc3NCbG9ja3NEZWMADhBwcm9jZXNzQmxvY2tzRW5jAA8FcmVzZXQAEApzdG9wV29ya2VyABENdmVyaWZ5UGFkZGluZwASCtRrEIQWAagBfyAAIAFqIQQgBCABQQFwayEFIAACByEGIAYgBiAFSUUNABogBgIHIQcgBwMHIQggCAIHIQkgCSACbCEKIAMgCmsiCyACIAsgAkkbIQxBACgCgAQhDUEAAgchDiAOAwchDyAPQQFqIRAgCiAPakEEdEGwyABqIhEoAgAhEiARQQRqIhMoAgAhFCATQQRqIhUoAgAhFiAVQQRqKAIAIRdBACgCICEYQQAoAiQhGUEAKAIoIRpBACgCLCEbIA1BAWshHEEAIBIgGHMgFCAZcyAWIBpzIBcgG3MCCCEhISAhHyEeIR0gHSAeIB8gICAhAwghJiElISQhIyEiICJBAWohJyAiQQFqQQJ0IihBAnRBIGooAgAhKSAjQf8BcUECdEGQKGooAgAhKiAmQQh2Qf8BcUECdEGQMGooAgAhKyAlQRB2Qf8BcUECdEGQOGooAgAhLCAkQRh2Qf8BcUECdEGQwABqKAIAIS0gKSAqICtzICwgLXNzcyEuIChBAWpBAnRBIGooAgAhLyAkQf8BcUECdEGQKGooAgAhMCAjQQh2Qf8BcUECdEGQMGooAgAhMSAmQRB2Qf8BcUECdEGQOGooAgAhMiAlQRh2Qf8BcUECdEGQwABqKAIAITMgLyAwIDFzIDIgM3NzcyE0IChBAmpBAnRBIGooAgAhNSAlQf8BcUECdEGQKGooAgAhNiAkQQh2Qf8BcUECdEGQMGooAgAhNyAjQRB2Qf8BcUECdEGQOGooAgAhOCAmQRh2Qf8BcUECdEGQwABqKAIAITkgNSA2IDdzIDggOXNzcyE6IChBA2pBAnRBIGooAgAhOyAmQf8BcUECdEGQKGooAgAhPCAlQQh2Qf8BcUECdEGQMGooAgAhPSAkQRB2Qf8BcUECdEGQOGooAgAhPiAjQRh2Qf8BcUECdEGQwABqKAIAIT8gOyA8ID1zID4gP3NzcyFAICcgLiA0IDogQCAnIBxJDQAaGhoaGiAnIC4gNCA6IEALISYhJSEkISMhIiAiICMgJCAlICYLISEhICEfIR4hHSANQQJ0IkFBAnRBIGooAgAhQiAhQQh2Qf8BcUGQJmotAAAhQyAgQRB2Qf8BcUGQJmotAAAhRCAfQRh2Qf8BcUGQJmotAAAhRSAeQf8BcUGQJmotAAAhRiBBQQFqQQJ0QSBqKAIAIUcgHkEIdkH/AXFBkCZqLQAAIUggIUEQdkH/AXFBkCZqLQAAIUkgIEEYdkH/AXFBkCZqLQAAIUogH0H/AXFBkCZqLQAAIUsgQUECakECdEEgaigCACFMIB9BCHZB/wFxQZAmai0AACFNIB5BEHZB/wFxQZAmai0AACFOICFBGHZB/wFxQZAmai0AACFPICBB/wFxQZAmai0AACFQIEFBA2pBAnRBIGooAgAhUSAgQQh2Qf8BcUGQJmotAAAhUiAfQRB2Qf8BcUGQJmotAAAhUyAeQRh2Qf8BcUGQJmotAAAhVCAhQf8BcUGQJmotAAAhVSARIEIgRkH/AXEgQ0H/AXFBCHRyIERB/wFxQRB0IEVB/wFxQRh0cnJzNgIAIBFBBGoiViBHIEtB/wFxIEhB/wFxQQh0ciBJQf8BcUEQdCBKQf8BcUEYdHJyczYCACBWQQRqIlcgTCBQQf8BcSBNQf8BcUEIdHIgTkH/AXFBEHQgT0H/AXFBGHRycnM2AgAgV0EEaiBRIFVB/wFxIFJB/wFxQQh0ciBTQf8BcUEQdCBUQf8BcUEYdHJyczYCACAQIBAgDEkNABogEAshDyAPCyEOIAkLIQkgCUEBaiFYIFggWCAFSQ0AGiBYCyEIIAgLIQcgBwshBiAFAgchWSBZIFkgBElFDQAaIFkCByFaIFoDByFbIFsCByFcIFwgAmwhXSADIF1rIl4gAiBeIAJJGyFfQQAoAoAEIWBBAAIHIWEgYQMHIWIgYkEBaiFjIF0gYmpBBHRBsMgAaiJkKAIAIWUgZEEEaiJmKAIAIWcgZkEEaiJoKAIAIWkgaEEEaigCACFqQQAoAiAha0EAKAIkIWxBACgCKCFtQQAoAiwhbiBgQQFrIW9BACBlIGtzIGcgbHMgaSBtcyBqIG5zAgghdCFzIXIhcSFwIHAgcSByIHMgdAMIIXkheCF3IXYhdSB1QQFqIXogdUEBakECdCJ7QQJ0QSBqKAIAIXwgdkH/AXFBAnRBkChqKAIAIX0geUEIdkH/AXFBAnRBkDBqKAIAIX4geEEQdkH/AXFBAnRBkDhqKAIAIX8gd0EYdkH/AXFBAnRBkMAAaigCACGAASB8IH0gfnMgfyCAAXNzcyGBASB7QQFqQQJ0QSBqKAIAIYIBIHdB/wFxQQJ0QZAoaigCACGDASB2QQh2Qf8BcUECdEGQMGooAgAhhAEgeUEQdkH/AXFBAnRBkDhqKAIAIYUBIHhBGHZB/wFxQQJ0QZDAAGooAgAhhgEgggEggwEghAFzIIUBIIYBc3NzIYcBIHtBAmpBAnRBIGooAgAhiAEgeEH/AXFBAnRBkChqKAIAIYkBIHdBCHZB/wFxQQJ0QZAwaigCACGKASB2QRB2Qf8BcUECdEGQOGooAgAhiwEgeUEYdkH/AXFBAnRBkMAAaigCACGMASCIASCJASCKAXMgiwEgjAFzc3MhjQEge0EDakECdEEgaigCACGOASB5Qf8BcUECdEGQKGooAgAhjwEgeEEIdkH/AXFBAnRBkDBqKAIAIZABIHdBEHZB/wFxQQJ0QZA4aigCACGRASB2QRh2Qf8BcUECdEGQwABqKAIAIZIBII4BII8BIJABcyCRASCSAXNzcyGTASB6IIEBIIcBII0BIJMBIHogb0kNABoaGhoaIHoggQEghwEgjQEgkwELIXkheCF3IXYhdSB1IHYgdyB4IHkLIXQhcyFyIXEhcCBgQQJ0IpQBQQJ0QSBqKAIAIZUBIHRBCHZB/wFxQZAmai0AACGWASBzQRB2Qf8BcUGQJmotAAAhlwEgckEYdkH/AXFBkCZqLQAAIZgBIHFB/wFxQZAmai0AACGZASCUAUEBakECdEEgaigCACGaASBxQQh2Qf8BcUGQJmotAAAhmwEgdEEQdkH/AXFBkCZqLQAAIZwBIHNBGHZB/wFxQZAmai0AACGdASByQf8BcUGQJmotAAAhngEglAFBAmpBAnRBIGooAgAhnwEgckEIdkH/AXFBkCZqLQAAIaABIHFBEHZB/wFxQZAmai0AACGhASB0QRh2Qf8BcUGQJmotAAAhogEgc0H/AXFBkCZqLQAAIaMBIJQBQQNqQQJ0QSBqKAIAIaQBIHNBCHZB/wFxQZAmai0AACGlASByQRB2Qf8BcUGQJmotAAAhpgEgcUEYdkH/AXFBkCZqLQAAIacBIHRB/wFxQZAmai0AACGoASBkIJUBIJkBQf8BcSCWAUH/AXFBCHRyIJcBQf8BcUEQdCCYAUH/AXFBGHRycnM2AgAgZEEEaiKpASCaASCeAUH/AXEgmwFB/wFxQQh0ciCcAUH/AXFBEHQgnQFB/wFxQRh0cnJzNgIAIKkBQQRqIqoBIJ8BIKMBQf8BcSCgAUH/AXFBCHRyIKEBQf8BcUEQdCCiAUH/AXFBGHRycnM2AgAgqgFBBGogpAEgqAFB/wFxIKUBQf8BcUEIdHIgpgFB/wFxQRB0IKcBQf8BcUEYdHJyczYCACBjIGMgX0kNABogYwshYiBiCyFhIFwLIVwgXEEBaiGrASCrASCrASAESQ0AGiCrAQshWyBbCyFaIFoLIVkL/BUBqAF/IAAgAWohBCAEIAFBAXBrIQUgAAIHIQYgBiAGIAVJRQ0AGiAGAgchByAHAwchCCAIAgchCSAJIAJsIQogAyAKayILIAIgCyACSRshDEEAKAKABCENQQACByEOIA4DByEPIA9BAWohECAKIA9qQQR0QbDIAGoiESgCACESIBFBBGoiEygCACEUIBNBBGoiFSgCACEWIBVBBGooAgAhF0EAKAIgIRhBACgCJCEZQQAoAighGkEAKAIsIRsgDUEBayEcQQAgEiAYcyAUIBlzIBYgGnMgFyAbcwIIISEhICEfIR4hHSAdIB4gHyAgICEDCCEmISUhJCEjISIgIkEBaiEnICJBAWpBAnQiKEECdEEgaigCACEpICNB/wFxQQJ0QZAGaigCACEqICRBCHZB/wFxQQJ0QZAOaigCACErICVBEHZB/wFxQQJ0QZAWaigCACEsICZBGHZB/wFxQQJ0QZAeaigCACEtICkgKiArcyAsIC1zc3MhLiAoQQFqQQJ0QSBqKAIAIS8gJEH/AXFBAnRBkAZqKAIAITAgJUEIdkH/AXFBAnRBkA5qKAIAITEgJkEQdkH/AXFBAnRBkBZqKAIAITIgI0EYdkH/AXFBAnRBkB5qKAIAITMgLyAwIDFzIDIgM3NzcyE0IChBAmpBAnRBIGooAgAhNSAlQf8BcUECdEGQBmooAgAhNiAmQQh2Qf8BcUECdEGQDmooAgAhNyAjQRB2Qf8BcUECdEGQFmooAgAhOCAkQRh2Qf8BcUECdEGQHmooAgAhOSA1IDYgN3MgOCA5c3NzITogKEEDakECdEEgaigCACE7ICZB/wFxQQJ0QZAGaigCACE8ICNBCHZB/wFxQQJ0QZAOaigCACE9ICRBEHZB/wFxQQJ0QZAWaigCACE+ICVBGHZB/wFxQQJ0QZAeaigCACE/IDsgPCA9cyA+ID9zc3MhQCAnIC4gNCA6IEAgJyAcSQ0AGhoaGhogJyAuIDQgOiBACyEmISUhJCEjISIgIiAjICQgJSAmCyEhISAhHyEeIR0gDUECdCJBQQJ0QSBqKAIAIUIgH0EIdkH/AXFBkARqLQAAIUMgIEEQdkH/AXFBkARqLQAAIUQgIUEYdkH/AXFBkARqLQAAIUUgHkH/AXFBkARqLQAAIUYgQUEBakECdEEgaigCACFHICBBCHZB/wFxQZAEai0AACFIICFBEHZB/wFxQZAEai0AACFJIB5BGHZB/wFxQZAEai0AACFKIB9B/wFxQZAEai0AACFLIEFBAmpBAnRBIGooAgAhTCAhQQh2Qf8BcUGQBGotAAAhTSAeQRB2Qf8BcUGQBGotAAAhTiAfQRh2Qf8BcUGQBGotAAAhTyAgQf8BcUGQBGotAAAhUCBBQQNqQQJ0QSBqKAIAIVEgHkEIdkH/AXFBkARqLQAAIVIgH0EQdkH/AXFBkARqLQAAIVMgIEEYdkH/AXFBkARqLQAAIVQgIUH/AXFBkARqLQAAIVUgESBCIEZB/wFxIENB/wFxQQh0ciBEQf8BcUEQdCBFQf8BcUEYdHJyczYCACARQQRqIlYgRyBLQf8BcSBIQf8BcUEIdHIgSUH/AXFBEHQgSkH/AXFBGHRycnM2AgAgVkEEaiJXIEwgUEH/AXEgTUH/AXFBCHRyIE5B/wFxQRB0IE9B/wFxQRh0cnJzNgIAIFdBBGogUSBVQf8BcSBSQf8BcUEIdHIgU0H/AXFBEHQgVEH/AXFBGHRycnM2AgAgECAQIAxJDQAaIBALIQ8gDwshDiAJCyEJIAlBAWohWCBYIFggBUkNABogWAshCCAICyEHIAcLIQYgBQIHIVkgWSBZIARJRQ0AGiBZAgchWiBaAwchWyBbAgchXCBcIAJsIV0gAyBdayJeIAIgXiACSRshX0EAKAKABCFgQQACByFhIGEDByFiIGJBAWohYyBdIGJqQQR0QbDIAGoiZCgCACFlIGRBBGoiZigCACFnIGZBBGoiaCgCACFpIGhBBGooAgAhakEAKAIgIWtBACgCJCFsQQAoAighbUEAKAIsIW4gYEEBayFvQQAgZSBrcyBnIGxzIGkgbXMgaiBucwIIIXQhcyFyIXEhcCBwIHEgciBzIHQDCCF5IXghdyF2IXUgdUEBaiF6IHVBAWpBAnQie0ECdEEgaigCACF8IHZB/wFxQQJ0QZAGaigCACF9IHdBCHZB/wFxQQJ0QZAOaigCACF+IHhBEHZB/wFxQQJ0QZAWaigCACF/IHlBGHZB/wFxQQJ0QZAeaigCACGAASB8IH0gfnMgfyCAAXNzcyGBASB7QQFqQQJ0QSBqKAIAIYIBIHdB/wFxQQJ0QZAGaigCACGDASB4QQh2Qf8BcUECdEGQDmooAgAhhAEgeUEQdkH/AXFBAnRBkBZqKAIAIYUBIHZBGHZB/wFxQQJ0QZAeaigCACGGASCCASCDASCEAXMghQEghgFzc3MhhwEge0ECakECdEEgaigCACGIASB4Qf8BcUECdEGQBmooAgAhiQEgeUEIdkH/AXFBAnRBkA5qKAIAIYoBIHZBEHZB/wFxQQJ0QZAWaigCACGLASB3QRh2Qf8BcUECdEGQHmooAgAhjAEgiAEgiQEgigFzIIsBIIwBc3NzIY0BIHtBA2pBAnRBIGooAgAhjgEgeUH/AXFBAnRBkAZqKAIAIY8BIHZBCHZB/wFxQQJ0QZAOaigCACGQASB3QRB2Qf8BcUECdEGQFmooAgAhkQEgeEEYdkH/AXFBAnRBkB5qKAIAIZIBII4BII8BIJABcyCRASCSAXNzcyGTASB6IIEBIIcBII0BIJMBIHogb0kNABoaGhoaIHoggQEghwEgjQEgkwELIXkheCF3IXYhdSB1IHYgdyB4IHkLIXQhcyFyIXEhcCBgQQJ0IpQBQQJ0QSBqKAIAIZUBIHJBCHZB/wFxQZAEai0AACGWASBzQRB2Qf8BcUGQBGotAAAhlwEgdEEYdkH/AXFBkARqLQAAIZgBIHFB/wFxQZAEai0AACGZASCUAUEBakECdEEgaigCACGaASBzQQh2Qf8BcUGQBGotAAAhmwEgdEEQdkH/AXFBkARqLQAAIZwBIHFBGHZB/wFxQZAEai0AACGdASByQf8BcUGQBGotAAAhngEglAFBAmpBAnRBIGooAgAhnwEgdEEIdkH/AXFBkARqLQAAIaABIHFBEHZB/wFxQZAEai0AACGhASByQRh2Qf8BcUGQBGotAAAhogEgc0H/AXFBkARqLQAAIaMBIJQBQQNqQQJ0QSBqKAIAIaQBIHFBCHZB/wFxQZAEai0AACGlASByQRB2Qf8BcUGQBGotAAAhpgEgc0EYdkH/AXFBkARqLQAAIacBIHRB/wFxQZAEai0AACGoASBkIJUBIJkBQf8BcSCWAUH/AXFBCHRyIJcBQf8BcUEQdCCYAUH/AXFBGHRycnM2AgAgZEEEaiKpASCaASCeAUH/AXEgmwFB/wFxQQh0ciCcAUH/AXFBEHQgnQFB/wFxQRh0cnJzNgIAIKkBQQRqIqoBIJ8BIKMBQf8BcSCgAUH/AXFBCHRyIKEBQf8BcUEQdCCiAUH/AXFBGHRycnM2AgAgqgFBBGogpAEgqAFB/wFxIKUBQf8BcUEIdHIgpgFB/wFxQRB0IKcBQf8BcUEYdHJyczYCACBjIGMgX0kNABogYwshYiBiCyFhIFwLIVwgXEEBaiGrASCrASCrASAESQ0AGiCrAQshWyBbCyFaIFoLIVkL4gEBEH9BACABQQACCSEEIQMhAiACIAMgBCADQQBHRQ0AGhoaIAIgAyAEAgkhByEGIQUgBSAGIAcDCSEKIQkhCCAIIAkgCgIJIQ0hDCELIAsgDCANIAxBAXFFDQAaGhogC0GABmxBgM+ABWogAP4XAgAgC0GABmxBgM+ABWpBAf4AAgAhDiANQQEgC3RyIQ8gCyAMIA8LIQ0hDCELIAtBAWohECAMQQF2IREgECARIA0gEUEARw0AGhoaIBAgESANCyEKIQkhCCAIIAkgCgshByEGIQUgBSAGIAcLIQQhAyECIAQLmgEBDH9BAEEAAgohASEAIAAgASAAQR9JRQ0AGhogACABAgohAyECIAIgAwMKIQUhBCAEIAUCCiEHIQYgBkEBaiIIQYAGbEGAzYAFav4QAgAhCSAHQQEgCHRBACAJG3IhCiAGIAoLIQchBiAGQQFqIQsgCyAHIAtBH0kNABoaIAsgBwshBSEEIAQgBQshAyECIAIgAwshASEAIAEL5wUBIX9BAUEAIAFBAEYbIQQgAEGwyABqLQAAIQUgAEGwyABqIAIgASABQQBGGyIDIAVB/wFxQQAgA0kbQf8BcToAACAAQQFqIgZBsMgAai0AACEHIAZBsMgAaiADIAdB/wFxQQEgA0kbQf8BcToAACAAQQJqIghBsMgAai0AACEJIAhBsMgAaiADIAlB/wFxQQIgA0kbQf8BcToAACAAQQNqIgpBsMgAai0AACELIApBsMgAaiADIAtB/wFxQQMgA0kbQf8BcToAACAAQQRqIgxBsMgAai0AACENIAxBsMgAaiADIA1B/wFxQQQgA0kbQf8BcToAACAAQQVqIg5BsMgAai0AACEPIA5BsMgAaiADIA9B/wFxQQUgA0kbQf8BcToAACAAQQZqIhBBsMgAai0AACERIBBBsMgAaiADIBFB/wFxQQYgA0kbQf8BcToAACAAQQdqIhJBsMgAai0AACETIBJBsMgAaiADIBNB/wFxQQcgA0kbQf8BcToAACAAQQhqIhRBsMgAai0AACEVIBRBsMgAaiADIBVB/wFxQQggA0kbQf8BcToAACAAQQlqIhZBsMgAai0AACEXIBZBsMgAaiADIBdB/wFxQQkgA0kbQf8BcToAACAAQQpqIhhBsMgAai0AACEZIBhBsMgAaiADIBlB/wFxQQogA0kbQf8BcToAACAAQQtqIhpBsMgAai0AACEbIBpBsMgAaiADIBtB/wFxQQsgA0kbQf8BcToAACAAQQxqIhxBsMgAai0AACEdIBxBsMgAaiADIB1B/wFxQQwgA0kbQf8BcToAACAAQQ1qIh5BsMgAai0AACEfIB5BsMgAaiADIB9B/wFxQQ0gA0kbQf8BcToAACAAQQ5qIiBBsMgAai0AACEhICBBsMgAaiADICFB/wFxQQ4gA0kbQf8BcToAACAAQQ9qIiJBsMgAai0AACEjICJBsMgAaiADICNB/wFxQQ8gA0kbQf8BcToAACAECyAAAgYgAEEAR0UNAEEAIABB/wdqQYAIbkGACCAAEA4LC5oOAU1/EAxBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgchBSAFIAUgA0lFDQAaIAUCByEGIAYDByEHIAcCByEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACByERIBEgESAQSUUNABogEQIHIRIgEgMHIRMgEwIHIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBkARqLQAAIRkgGEEQdkH/AXFBkARqLQAAIRogGEEYdkH/AXFBkARqLQAAIRsgGEH/AXFBkARqLQAAIRwgFSADbkEBa0GQyABqLQAAIR0gFkEIdkH/AXFBkARqLQAAIR4gFkEQdkH/AXFBkARqLQAAIR8gFkEYdkH/AXFBkARqLQAAISAgFkH/AXFBkARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgchJCAkICQgD0lFDQAaICQCByElICUDByEmICYCByEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJEEAAgchKiAqICogD0lFDQAaICoCByErICsDByEsICwCByEtIC1BAnRBIGooAgAhLiAtQQJ0QZACaiAuNgIAIC0LIS0gLUEBaiEvIC8gLyAPSQ0AGiAvCyEsICwLISsgKwshKkEAKAKABCEwIDBBAWohMUEAAgchMiAyIDIgMUlFDQAaIDICByEzIDMDByE0IDQCByE1IDFBAWsgNWtBAnQiNkECdEGQAmooAgAhNyA1QQJ0IjhBAnRBIGogNzYCACA2QQFqQQJ0QZACaigCACE5IDhBAWpBAnRBIGogOTYCACA2QQJqQQJ0QZACaigCACE6IDhBAmpBAnRBIGogOjYCACA2QQNqQQJ0QZACaigCACE7IDhBA2pBAnRBIGogOzYCACA1CyE1IDVBAWohPCA8IDwgMUkNABogPAshNCA0CyEzIDMLITIgD0EIayE9QQACByE+ID4gPiA9SUUNABogPgIHIT8gPwMHIUAgQAIHIUEgQUEEaiJCQQJ0QSBqKAIAIUMgQ0EIdkH/AXFBkARqLQAAIUQgQ0EQdkH/AXFBkARqLQAAIUUgQ0EYdkH/AXFBkARqLQAAIUYgQ0H/AXFBkARqLQAAIUcgR0H/AXEgREH/AXFBCHRyIEVB/wFxQRB0IEZB/wFxQRh0cnIiSEEAdkH/AXFBAnRBkChqKAIAIUkgSEEIdkH/AXFBAnRBkDBqKAIAIUogSEEQdkH/AXFBAnRBkDhqKAIAIUsgSEEYdkH/AXFBAnRBkMAAaigCACFMIEJBAnRBIGogSSBKcyBLIExzczYCACBBCyFBIEFBAWohTSBNIE0gPUkNABogTQshQCBACyE/ID8LIT4LIAACBiAAQQBHRQ0AQQAgAEH/B2pBgAhuQYAIIAAQDwsLnQkBKX8QDEEEQQZBCCAAQRhGIgIbIABBEEYiARshA0EAQQpBDEEOIAIbIAEbIgQ2AoAEQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQACByEFIAUgBSADSUUNABogBQIHIQYgBgMHIQcgBwIHIQggCEECdCIJQQFqLQAAIQogCUECai0AACELIAlBA2otAAAhDCAJLQAAIQ0gCEECdEGQAmogDUH/AXEgCkH/AXFBCHQgC0H/AXFBEHQgDEH/AXFBGHRycnI2AgAgCAshCCAIQQFqIQ4gDiAOIANJDQAaIA4LIQcgBwshBiAGCyEFIARBAWpBAnQhDyAPIANrIRBBAAIHIREgESARIBBJRQ0AGiARAgchEiASAwchEyATAgchFCAUIANqIhVBAWtBAnRBkAJqKAIAIRYgFkEYdCAWQQh2ciIYQQh2Qf8BcUGQBGotAAAhGSAYQRB2Qf8BcUGQBGotAAAhGiAYQRh2Qf8BcUGQBGotAAAhGyAYQf8BcUGQBGotAAAhHCAVIANuQQFrQZDIAGotAAAhHSAWQQh2Qf8BcUGQBGotAAAhHiAWQRB2Qf8BcUGQBGotAAAhHyAWQRh2Qf8BcUGQBGotAAAhICAWQf8BcUGQBGotAAAhISAVIANrQQJ0QZACaigCACEiIBVBAnRBkAJqICFB/wFxIB5B/wFxQQh0ciAfQf8BcUEQdCAgQf8BcUEYdHJyIBxB/wFxIBlB/wFxQQh0ciAaQf8BcUEQdCAbQf8BcUEYdHJyIB1B/wFxcyAWIBUgA3AiF0EARhsgA0EIRiAXQQRGcRsgInM2AgAgFAshFCAUQQFqISMgIyAjIBBJDQAaICMLIRMgEwshEiASCyERQQACByEkICQgJCAPSUUNABogJAIHISUgJQMHISYgJgIHIScgJ0ECdEGQAmooAgAhKCAnQQJ0QSBqICg2AgAgJwshJyAnQQFqISkgKSApIA9JDQAaICkLISYgJgshJSAlCyEkC4oKAT1/QQAoAqBIIQACBiAAQQBGRQ0AQQBBAQIKIQIhASABIAIDCiEEIQMgA0EBaiEFIAQgBEEBdCAEQQd2QQFxQRtsc0H/AXFzIQYgA0GQBmogBEH/AXE6AAAgBSAGIAVBgAJJDQAaGiAFIAYLIQQhAyADIAQLIQIhAUEAQeMAQf8BcToAkARBAAIHIQcgByAHQf8BSUUNABogBwIHIQggCAMHIQkgCQIHIQpB/wEgCmtBkAZqLQAAIQsgCkGQBmotAAAhDiAOQf8BcUGQBGogC0H/AXEiDCAMQQh0ciINIA1BBHZzIA1BBXZzIA1BBnZzIA1BB3ZzQeMAc0H/AXFB/wFxOgAAIAoLIQogCkEBaiEPIA8gD0H/AUkNABogDwshCSAJCyEIIAgLIQdBAAIHIRAgECAQQYACSUUNABogEAIHIREgEQMHIRIgEgIHIRMgE0GQJmpBAEH/AXE6AAAgEwshEyATQQFqIRQgFCAUQYACSQ0AGiAUCyESIBILIREgEQshEEEAAgchFSAVIBVBgAJJRQ0AGiAVAgchFiAWAwchFyAXAgchGCAYQZAEai0AACEZIBlB/wFxQZAmaiAYQf8BcToAACAYCyEYIBhBAWohGiAaIBpBgAJJDQAaIBoLIRcgFwshFiAWCyEVQQBBAQIKIRwhGyAbIBwDCiEeIR0gHUEBaiEfIB5BAXQgHkEHdkEBcUEbbHNB/wFxISAgHUGQyABqIB5B/wFxOgAAIB8gICAfQRBJDQAaGiAfICALIR4hHSAdIB4LIRwhG0EAAgchISAhICFBgAJJRQ0AGiAhAgchIiAiAwchIyAjAgchJCAkQZAEai0AACElICRBkCZqLQAAIScgJEECdEGQBmogJUH/AXEiJiAmQQF0ICZBB3ZBAXFBG2xzQf8BcXNBGHQgJkEQdCAmQQh0ICZBAXQgJkEHdkEBcUEbbHNB/wFxcnJyNgIAICRBAnRBkChqICdB/wFxIiggKEEBdCAoQQd2QQFxQRtsc0H/AXEiK3MgK0EBdCArQQd2QQFxQRtsc0H/AXEiLEEBdCAsQQd2QQFxQRtsc0H/AXFzQRh0ICggKEEBdCAoQQd2QQFxQRtsc0H/AXEiLUEBdCAtQQd2QQFxQRtsc0H/AXEiLnMgLkEBdCAuQQd2QQFxQRtsc0H/AXFzQRB0ICggKEEBdCAoQQd2QQFxQRtsc0H/AXEiKUEBdCApQQd2QQFxQRtsc0H/AXEiKkEBdCAqQQd2QQFxQRtsc0H/AXFzQQh0IChBAXQgKEEHdkEBcUEbbHNB/wFxIi8gL0EBdCAvQQd2QQFxQRtsc0H/AXEiMHMgMEEBdCAwQQd2QQFxQRtsc0H/AXFzcnJyNgIAICQLISQgJEEBaiExIDEgMUGAAkkNABogMQshIyAjCyEiICILISFBAAIHITIgMiAyQYACSUUNABogMgIHITMgMwMHITQgNAIHITUgNUECdEGQBmooAgAhNiA1QQJ0QZAOaiA2QQh3Ijc2AgAgNUECdEGQFmogN0EIdyI4NgIAIDVBAnRBkB5qIDhBCHc2AgAgNUECdEGQKGooAgAhOSA1QQJ0QZAwaiA5QQh3Ijo2AgAgNUECdEGQOGogOkEIdyI7NgIAIDVBAnRBkMAAaiA7QQh3NgIAIDULITUgNUEBaiE8IDwgPEGAAkkNABogPAshNCA0CyEzIDMLITJBAEEBNgKgSAsLpgIBDH8gAEGABmxBgM6ABWohAyAAQYAGbEGAz4AFaiEEIABBgAZsQYDNgAVqQQH+FwIAAgYCBiABRQ0ADAELAgYDBiAEQQD+QQIAIQUCBiAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCwIGIAVBAUZFDQBBACgCgI2CBSEHIABBgAZsQYDQgAVq/hACACEIIABBgAZsQYDRgAVq/hACACEJIABBgAZsQYDSgAVq/hACACEKIAggCSAKIAcQBAsCBiAFQQJGRQ0AQQAoAoCNggUhCyAAQYAGbEGA0IAFav4QAgAhDCAAQYAGbEGA0YAFav4QAgAhDSAAQYAGbEGA0oAFav4QAgAhDiAMIA0gDiALEAMLIANBAf4XAgAgAg0BQQENAAsLCwvrBgE7fwIGAgYgAUEBRkUNACAAIAEgAiADEAMMAQtBAEEBIAFBAUGACCACQQFraiACbiIEQQEgBE8bIgVBAWtqIAVuIgYgASACbEH/B2pBgAhuIgcgBiAHTRsiCEEBIAhPGyABRRshCQIGAgYgCUEBTUUNACAAIAEgAiADEAMMAQtBACADNgKAjYIFEAEhCiABQQAgASAKaSILIAEgC00bIgwgCSAMIAlNGyINQSAgDUEgTRsiDkEBayAOQQBGGyIPQQFqIhBBAWtqIBBuIREgACABaiESIA8gASARQQFraiARbkEBayITIA8gE00bIRRBAEEAQQACCSEXIRYhFSAVIBYgFyAVQR9JRQ0AGhoaIBUgFiAXAgkhGiEZIRggGCAZIBoDCSEdIRwhGyAbIBwgHQIJISAhHyEeIB4gHyAgICAgFE8NAhoaGiAeQQFqISEgACAgQQFqIBFsaiEiIB8gIAIKISUhJCAkICUgCkEBICF0cUEARyAiIBJJcUUNABoaICFBgAZsQYDQgAVqICL+FwIAICFBgAZsQYDRgAVqIBEgEiAiayIjIBEgI00b/hcCACAhQYAGbEGA0oAFaiAC/hcCACAkQQEgIXRyISYgJUEBaiEnICYgJwshJSEkIB4gJCAlCyEgIR8hHiAeQQFqISggKCAfICAgKEEfSQ0AGhoaICggHyAgCyEdIRwhGyAbIBwgHQshGiEZIRggGCAZIBoLIRchFiEVQQIgFhAAISkgACABIBEgASARTRsgAiADEAMgFgIHISogKiAqQQBHRQ0AGiAqAgchKyArAwchLCAsAgchLUEAIC1BAAIJITAhLyEuIC4gLyAwIC9BAEdFDQAaGhogLiAvIDACCSEzITIhMSAxIDIgMwMJITYhNSE0IDQgNSA2AgkhOSE4ITcgNyA4IDkgOEEBcUUNABoaGiA3QYAGbEGAzoAFakEA/kECACE7IC1BASA3dCI6cyA7QQBHDQQaIDkgOnIhPCA3IDggPAshOSE4ITcgN0EBaiE9IDhBAXYhPiA9ID4gOSA+QQBHDQAaGhogPSA+IDkLITYhNSE0IDQgNSA2CyEzITIhMSAxIDIgMwshMCEvIS4gLQshLSAtIC1BAEcNABogLQshLCAsCyErICsLISpBgI2CBUEAQcAA/AsACwsL6wYBO38CBgIGIAFBAUZFDQAgACABIAIgAxAEDAELQQBBASABQQFBgAggAkEBa2ogAm4iBEEBIARPGyIFQQFraiAFbiIGIAEgAmxB/wdqQYAIbiIHIAYgB00bIghBASAITxsgAUUbIQkCBgIGIAlBAU1FDQAgACABIAIgAxAEDAELQQAgAzYCgI2CBRABIQogAUEAIAEgCmkiCyABIAtNGyIMIAkgDCAJTRsiDUEgIA1BIE0bIg5BAWsgDkEARhsiD0EBaiIQQQFraiAQbiERIAAgAWohEiAPIAEgEUEBa2ogEW5BAWsiEyAPIBNNGyEUQQBBAEEAAgkhFyEWIRUgFSAWIBcgFUEfSUUNABoaGiAVIBYgFwIJIRohGSEYIBggGSAaAwkhHSEcIRsgGyAcIB0CCSEgIR8hHiAeIB8gICAgIBRPDQIaGhogHkEBaiEhIAAgIEEBaiARbGohIiAfICACCiElISQgJCAlIApBASAhdHFBAEcgIiASSXFFDQAaGiAhQYAGbEGA0IAFaiAi/hcCACAhQYAGbEGA0YAFaiARIBIgImsiIyARICNNG/4XAgAgIUGABmxBgNKABWogAv4XAgAgJEEBICF0ciEmICVBAWohJyAmICcLISUhJCAeICQgJQshICEfIR4gHkEBaiEoICggHyAgIChBH0kNABoaGiAoIB8gIAshHSEcIRsgGyAcIB0LIRohGSEYIBggGSAaCyEXIRYhFUEBIBYQACEpIAAgASARIAEgEU0bIAIgAxAEIBYCByEqICogKkEAR0UNABogKgIHISsgKwMHISwgLAIHIS1BACAtQQACCSEwIS8hLiAuIC8gMCAvQQBHRQ0AGhoaIC4gLyAwAgkhMyEyITEgMSAyIDMDCSE2ITUhNCA0IDUgNgIJITkhOCE3IDcgOCA5IDhBAXFFDQAaGhogN0GABmxBgM6ABWpBAP5BAgAhOyAtQQEgN3QiOnMgO0EARw0EGiA5IDpyITwgNyA4IDwLITkhOCE3IDdBAWohPSA4QQF2IT4gPSA+IDkgPkEARw0AGhoaID0gPiA5CyE2ITUhNCA0IDUgNgshMyEyITEgMSAyIDMLITAhLyEuIC0LIS0gLSAtQQBHDQAaIC0LISwgLAshKyArCyEqQYCNggVBAEHAAPwLAAsLCxcAQQBBAEGEBPwLAEGwyABBACAA/AsACxQAIABBgAZsQYDNgAVqQQD+FwIAC6wEARN/IABBAWtBsMgAai0AACECIABBAWtBsMgAai0AACEEIABBAmtBsMgAai0AACEFIABBA2tBsMgAai0AACEGIABBBGtBsMgAai0AACEHIABBBWtBsMgAai0AACEIIABBBmtBsMgAai0AACEJIABBB2tBsMgAai0AACEKIABBCGtBsMgAai0AACELIABBCWtBsMgAai0AACEMIABBCmtBsMgAai0AACENIABBC2tBsMgAai0AACEOIABBDGtBsMgAai0AACEPIABBDWtBsMgAai0AACEQIABBDmtBsMgAai0AACERIABBD2tBsMgAai0AACESIABBEGtBsMgAai0AACETQQAgAkH/AXEiAyAAQQBGIAAgAXBBAEdyIANBAEYgAyABS3JyQQAgA0kgBEH/AXEgA0dxQQEgA0kgBUH/AXEgA0dxckECIANJIAZB/wFxIANHcXJBAyADSSAHQf8BcSADR3FyQQQgA0kgCEH/AXEgA0dxckEFIANJIAlB/wFxIANHcXJBBiADSSAKQf8BcSADR3FyQQcgA0kgC0H/AXEgA0dxckEIIANJIAxB/wFxIANHcXJBCSADSSANQf8BcSADR3FyQQogA0kgDkH/AXEgA0dxckELIANJIA9B/wFxIANHcXJBDCADSSAQQf8BcSADR3FyQQ0gA0kgEUH/AXEgA0dxckEOIANJIBJB/wFxIANHcXJBDyADSSATQf8BcSADR3FychshFCAUCw=='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    _imports.env.initWorkers();
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 10520256);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 516),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 516, 516))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 272 + i * 240, 240))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 512 + i * 4, 4))),
        constants: new Uint8Array(memoryExport.buffer, 528, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 528, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 528, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 784, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 784 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1808, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1808 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2832, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2832 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3856, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3856 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 4880, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4880, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4880 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5136, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5136 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6160, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6160 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7184, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7184 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8208, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8208 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9232, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9232 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9248, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9248 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9264, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9264 + i * 10485760, 10485760))),
        _worker: new Uint8Array(memoryExport.buffer, 10495104, 25152),
        _worker_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495104 + i * 25152, 25152))),
        "_worker.online": new Uint8Array(memoryExport.buffer, 10495104, 4),
        "_worker.online_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495104 + i * 4, 4))),
        "_worker.next": new Uint8Array(memoryExport.buffer, 10495232, 4),
        "_worker.next_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495232 + i * 4, 4))),
        "_worker.total": new Uint8Array(memoryExport.buffer, 10495360, 4),
        "_worker.total_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495360 + i * 4, 4))),
        "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10495488, 4),
        "_worker.perBatch_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495488 + i * 4, 4))),
        "_worker.workers": new Uint8Array(memoryExport.buffer, 10495616, 24576),
        "_worker.workers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10495616 + i * 24576, 24576))),
        "_worker.stack": new Uint8Array(memoryExport.buffer, 10520192, 64),
        "_worker.stack_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 10520192 + i * 64, 64)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments, workers, initWorkers });
}
let _cache;
export default function aes_ecb(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
