// WARNING: This file is auto-generated. Any changes will be lost.
function init_module(_imports = {}, pool) {
    const _importsEmbed = { env: {} };
    _imports = { ..._importsEmbed, ..._imports, env: { ..._importsEmbed.env, ..._imports.env } };
    ;
    if (!_imports.env._memory)
        _imports.env._memory = new WebAssembly.Memory({ initial: 161, maximum: 161, shared: false });
    const code = Uint8Array.from(atob('AGFzbQEAAAABJwZgA39/fwBgAX8AYAAAYAF/AX9gBX9/f39/BX9/f39/YAJ/fwJ/fwMHBgABAAECAQUGAQGhAaEBB1sHBm1lbW9yeQIADWRlY3J5cHRCbG9ja3MAAAtkZWNyeXB0SW5pdAABDWVuY3J5cHRCbG9ja3MAAgtlbmNyeXB0SW5pdAADCmluaXRUYWJsZXMABAVyZXNldAAFCsknBgoAIAAgASACEAILnQkBKX8QBEEEQQZBCCAAQRhGIgIbIABBEEYiARshA0EAQQpBDEEOIAIbIAEbIgQ2AoAEQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQACAyEFIAUgBSADSUUNABogBQIDIQYgBgMDIQcgBwIDIQggCEECdCIJQQFqLQAAIQogCUECai0AACELIAlBA2otAAAhDCAJLQAAIQ0gCEECdEGQAmogDUH/AXEgCkH/AXFBCHQgC0H/AXFBEHQgDEH/AXFBGHRycnI2AgAgCAshCCAIQQFqIQ4gDiAOIANJDQAaIA4LIQcgBwshBiAGCyEFIARBAWpBAnQhDyAPIANrIRBBAAIDIREgESARIBBJRQ0AGiARAgMhEiASAwMhEyATAgMhFCAUIANqIhVBAWtBAnRBkAJqKAIAIRYgFkEYdCAWQQh2ciIYQQh2Qf8BcUGgBGotAAAhGSAYQRB2Qf8BcUGgBGotAAAhGiAYQRh2Qf8BcUGgBGotAAAhGyAYQf8BcUGgBGotAAAhHCAVIANuQQFrQaDIAGotAAAhHSAWQQh2Qf8BcUGgBGotAAAhHiAWQRB2Qf8BcUGgBGotAAAhHyAWQRh2Qf8BcUGgBGotAAAhICAWQf8BcUGgBGotAAAhISAVIANrQQJ0QZACaigCACEiIBVBAnRBkAJqICFB/wFxIB5B/wFxQQh0ciAfQf8BcUEQdCAgQf8BcUEYdHJyIBxB/wFxIBlB/wFxQQh0ciAaQf8BcUEQdCAbQf8BcUEYdHJyIB1B/wFxcyAWIBUgA3AiF0EARhsgA0EIRiAXQQRGcRsgInM2AgAgFAshFCAUQQFqISMgIyAjIBBJDQAaICMLIRMgEwshEiASCyERQQACAyEkICQgJCAPSUUNABogJAIDISUgJQMDISYgJgIDIScgJ0ECdEGQAmooAgAhKCAnQQJ0QSBqICg2AgAgJwshJyAnQQFqISkgKSApIA9JDQAaICkLISYgJgshJSAlCyEkC9kKAVV/QQAoAoAEIQNBAAIDIQQgBCAEIABJRQ0AGiAEAgMhBSAFAwMhBiAGAgMhByAHQQR0QcDIAGoiCCgCACEJIAhBBGoiCigCACELIApBBGoiDCgCACENIAxBBGooAgAhDkEAKAKQBCEPQQAoApQEIRBBACgCmAQhEUEAKAKcBCESQQAoAiAhE0EAKAIkIRRBACgCKCEVQQAoAiwhFiADQQFrIRdBACAPIBNzIBAgFHMgESAVcyASIBZzAgQhHCEbIRohGSEYIBggGSAaIBsgHAMEISEhICEfIR4hHSAdQQFqISIgHUEBakECdCIjQQJ0QSBqKAIAISQgHkH/AXFBAnRBoAZqKAIAISUgH0EIdkH/AXFBAnRBoA5qKAIAISYgIEEQdkH/AXFBAnRBoBZqKAIAIScgIUEYdkH/AXFBAnRBoB5qKAIAISggJCAlICZzICcgKHNzcyEpICNBAWpBAnRBIGooAgAhKiAfQf8BcUECdEGgBmooAgAhKyAgQQh2Qf8BcUECdEGgDmooAgAhLCAhQRB2Qf8BcUECdEGgFmooAgAhLSAeQRh2Qf8BcUECdEGgHmooAgAhLiAqICsgLHMgLSAuc3NzIS8gI0ECakECdEEgaigCACEwICBB/wFxQQJ0QaAGaigCACExICFBCHZB/wFxQQJ0QaAOaigCACEyIB5BEHZB/wFxQQJ0QaAWaigCACEzIB9BGHZB/wFxQQJ0QaAeaigCACE0IDAgMSAycyAzIDRzc3MhNSAjQQNqQQJ0QSBqKAIAITYgIUH/AXFBAnRBoAZqKAIAITcgHkEIdkH/AXFBAnRBoA5qKAIAITggH0EQdkH/AXFBAnRBoBZqKAIAITkgIEEYdkH/AXFBAnRBoB5qKAIAITogNiA3IDhzIDkgOnNzcyE7ICIgKSAvIDUgOyAiIBdJDQAaGhoaGiAiICkgLyA1IDsLISEhICEfIR4hHSAdIB4gHyAgICELIRwhGyEaIRkhGCADQQJ0IjxBAnRBIGooAgAhPSAaQQh2Qf8BcUGgBGotAAAhPiAbQRB2Qf8BcUGgBGotAAAhPyAcQRh2Qf8BcUGgBGotAAAhQCAZQf8BcUGgBGotAAAhQSA8QQFqQQJ0QSBqKAIAIUMgG0EIdkH/AXFBoARqLQAAIUQgHEEQdkH/AXFBoARqLQAAIUUgGUEYdkH/AXFBoARqLQAAIUYgGkH/AXFBoARqLQAAIUcgPEECakECdEEgaigCACFJIBxBCHZB/wFxQaAEai0AACFKIBlBEHZB/wFxQaAEai0AACFLIBpBGHZB/wFxQaAEai0AACFMIBtB/wFxQaAEai0AACFNIDxBA2pBAnRBIGooAgAhTyAZQQh2Qf8BcUGgBGotAAAhUCAaQRB2Qf8BcUGgBGotAAAhUSAbQRh2Qf8BcUGgBGotAAAhUiAcQf8BcUGgBGotAAAhUyAIIAkgPSBBQf8BcSA+Qf8BcUEIdHIgP0H/AXFBEHQgQEH/AXFBGHRycnMiQnM2AgAgCEEEaiJVIAsgQyBHQf8BcSBEQf8BcUEIdHIgRUH/AXFBEHQgRkH/AXFBGHRycnMiSHM2AgAgVUEEaiJWIA0gSSBNQf8BcSBKQf8BcUEIdHIgS0H/AXFBEHQgTEH/AXFBGHRycnMiTnM2AgAgVkEEaiAOIE8gU0H/AXEgUEH/AXFBCHRyIFFB/wFxQRB0IFJB/wFxQRh0cnJzIlRzNgIAQQAgQjYCkARBACBINgKUBEEAIE42ApgEQQAgVDYCnAQgBwshByAHQQFqIVcgVyBXIABJDQAaIFcLIQYgBgshBSAFCyEEC50JASl/EARBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgMhBSAFIAUgA0lFDQAaIAUCAyEGIAYDAyEHIAcCAyEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACAyERIBEgESAQSUUNABogEQIDIRIgEgMDIRMgEwIDIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBoARqLQAAIRkgGEEQdkH/AXFBoARqLQAAIRogGEEYdkH/AXFBoARqLQAAIRsgGEH/AXFBoARqLQAAIRwgFSADbkEBa0GgyABqLQAAIR0gFkEIdkH/AXFBoARqLQAAIR4gFkEQdkH/AXFBoARqLQAAIR8gFkEYdkH/AXFBoARqLQAAISAgFkH/AXFBoARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgMhJCAkICQgD0lFDQAaICQCAyElICUDAyEmICYCAyEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJAuKCgE9f0EAKAKwSCEAAgIgAEEARkUNAEEAQQECBSECIQEgASACAwUhBCEDIANBAWohBSAEIARBAXQgBEEHdkEBcUEbbHNB/wFxcyEGIANBoAZqIARB/wFxOgAAIAUgBiAFQYACSQ0AGhogBSAGCyEEIQMgAyAECyECIQFBAEHjAEH/AXE6AKAEQQACAyEHIAcgB0H/AUlFDQAaIAcCAyEIIAgDAyEJIAkCAyEKQf8BIAprQaAGai0AACELIApBoAZqLQAAIQ4gDkH/AXFBoARqIAtB/wFxIgwgDEEIdHIiDSANQQR2cyANQQV2cyANQQZ2cyANQQd2c0HjAHNB/wFxQf8BcToAACAKCyEKIApBAWohDyAPIA9B/wFJDQAaIA8LIQkgCQshCCAICyEHQQACAyEQIBAgEEGAAklFDQAaIBACAyERIBEDAyESIBICAyETIBNBoCZqQQBB/wFxOgAAIBMLIRMgE0EBaiEUIBQgFEGAAkkNABogFAshEiASCyERIBELIRBBAAIDIRUgFSAVQYACSUUNABogFQIDIRYgFgMDIRcgFwIDIRggGEGgBGotAAAhGSAZQf8BcUGgJmogGEH/AXE6AAAgGAshGCAYQQFqIRogGiAaQYACSQ0AGiAaCyEXIBcLIRYgFgshFUEAQQECBSEcIRsgGyAcAwUhHiEdIB1BAWohHyAeQQF0IB5BB3ZBAXFBG2xzQf8BcSEgIB1BoMgAaiAeQf8BcToAACAfICAgH0EQSQ0AGhogHyAgCyEeIR0gHSAeCyEcIRtBAAIDISEgISAhQYACSUUNABogIQIDISIgIgMDISMgIwIDISQgJEGgBGotAAAhJSAkQaAmai0AACEnICRBAnRBoAZqICVB/wFxIiYgJkEBdCAmQQd2QQFxQRtsc0H/AXFzQRh0ICZBEHQgJkEIdCAmQQF0ICZBB3ZBAXFBG2xzQf8BcXJycjYCACAkQQJ0QaAoaiAnQf8BcSIoIChBAXQgKEEHdkEBcUEbbHNB/wFxIitzICtBAXQgK0EHdkEBcUEbbHNB/wFxIixBAXQgLEEHdkEBcUEbbHNB/wFxc0EYdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIi1BAXQgLUEHdkEBcUEbbHNB/wFxIi5zIC5BAXQgLkEHdkEBcUEbbHNB/wFxc0EQdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIilBAXQgKUEHdkEBcUEbbHNB/wFxIipBAXQgKkEHdkEBcUEbbHNB/wFxc0EIdCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIvIC9BAXQgL0EHdkEBcUEbbHNB/wFxIjBzIDBBAXQgMEEHdkEBcUEbbHNB/wFxc3JycjYCACAkCyEkICRBAWohMSAxIDFBgAJJDQAaIDELISMgIwshIiAiCyEhQQACAyEyIDIgMkGAAklFDQAaIDICAyEzIDMDAyE0IDQCAyE1IDVBAnRBoAZqKAIAITYgNUECdEGgDmogNkEIdyI3NgIAIDVBAnRBoBZqIDdBCHciODYCACA1QQJ0QaAeaiA4QQh3NgIAIDVBAnRBoChqKAIAITkgNUECdEGgMGogOUEIdyI6NgIAIDVBAnRBoDhqIDpBCHciOzYCACA1QQJ0QaDAAGogO0EIdzYCACA1CyE1IDVBAWohPCA8IDxBgAJJDQAaIDwLITQgNAshMyAzCyEyQQBBATYCsEgLCxcAQQBBAEGgBPwLAEHAyABBACAA/AsACw=='), char => char.charCodeAt(0));
    const module = new WebAssembly.Module(code);
    const instance = new WebAssembly.Instance(module, _imports);
    ;
    const _exports = instance.exports;
    const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
    const memoryExport = new Uint8Array(buffer, 0, 10495040);
    const segments = Object.freeze({ state: new Uint8Array(memoryExport.buffer, 0, 544),
        state_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 544, 544))),
        "state.key": new Uint8Array(memoryExport.buffer, 0, 32),
        "state.key_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 0 + i * 32, 32))),
        "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240),
        "state.expandedKey_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 32 + i * 240, 240))),
        "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240),
        "state.tmp_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 272 + i * 240, 240))),
        "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4),
        "state.rounds_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 512 + i * 4, 4))),
        "state.iv": new Uint8Array(memoryExport.buffer, 528, 16),
        "state.iv_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 528 + i * 16, 16))),
        constants: new Uint8Array(memoryExport.buffer, 544, 8724),
        constants_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 8724, 8724))),
        "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352),
        "constants.encrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 4352, 4352))),
        "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256),
        "constants.encrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 544 + i * 256, 256))),
        "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024),
        "constants.encrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 800 + i * 1024, 1024))),
        "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024),
        "constants.encrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 1824 + i * 1024, 1024))),
        "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024),
        "constants.encrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 2848 + i * 1024, 1024))),
        "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024),
        "constants.encrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 3872 + i * 1024, 1024))),
        "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352),
        "constants.decrypt_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4896 + i * 4352, 4352))),
        "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256),
        "constants.decrypt.sbox_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 4896 + i * 256, 256))),
        "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024),
        "constants.decrypt.T0_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 5152 + i * 1024, 1024))),
        "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024),
        "constants.decrypt.T1_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 6176 + i * 1024, 1024))),
        "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024),
        "constants.decrypt.T2_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 7200 + i * 1024, 1024))),
        "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024),
        "constants.decrypt.T3_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 8224 + i * 1024, 1024))),
        "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16),
        "constants.xPowers_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9248 + i * 16, 16))),
        "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4),
        "constants.inited_chunks": Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9264 + i * 4, 4))),
        buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760),
        buffer_chunks: Object.freeze(Array.from({ length: 1 }, (_, i) => new Uint8Array(memoryExport.buffer, 9280 + i * 10485760, 10485760)))
    });
    return Object.freeze({ ..._exports, memory: memoryExport, segments });
}
let _cache;
export default function aes_ofb(_imports = {}, pool) {
    if (_cache)
        return _cache;
    return (_cache = init_module(_imports, pool));
}
