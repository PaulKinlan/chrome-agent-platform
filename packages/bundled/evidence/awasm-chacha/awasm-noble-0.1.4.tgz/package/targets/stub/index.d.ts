/*!
The MIT License (MIT)

Copyright (c) 2026 Paul Miller (https://paulmillr.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
import type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, HashInstance, Stub as HashStub } from '../../hashes-abstract.ts';
import type { TArg, TRet, Asyncify, KDFInput } from '../../utils.ts';
import type { BlakeOpts, Blake2Opts, Blake3Opts } from '../../hashes.ts';
import type { Cipher, CipherDef, CipherFactory, CipherStub } from '../../ciphers-abstract.ts';
import type { KDF, ScryptOpts, ArgonOpts } from '../../kdf.ts';
import { scrypt as def_scrypt } from '../../hashes.ts';
import { argon2d as def_argon2d } from '../../hashes.ts';
import { argon2i as def_argon2i } from '../../hashes.ts';
import { argon2id as def_argon2id } from '../../hashes.ts';
type MACOpts = {
    key: TArg<Uint8Array>;
} | TArg<Uint8Array>;
type SecretBox = (key: TArg<Uint8Array>, nonce: TArg<Uint8Array>) => {
    seal: Cipher['encrypt'];
    open: Cipher['decrypt'];
};
export type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, HashInstance, HashStub };
export type { TArg, TRet, Asyncify, KDFInput };
export type { BlakeOpts, Blake2Opts, Blake3Opts };
export type { Cipher, CipherDef, CipherFactory, CipherStub };
export type { KDF, ScryptOpts, ArgonOpts };
/**
 * SHA3-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_224 } from '@awasm/noble';
 * sha3_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_224: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA3-256 hash function. Different from keccak-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_256 } from '@awasm/noble';
 * sha3_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_256: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA3-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_384 } from '@awasm/noble';
 * sha3_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_384: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA3-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_512 } from '@awasm/noble';
 * sha3_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_512: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * keccak-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_224 } from '@awasm/noble';
 * keccak_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_224: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * keccak-256 hash function. Different from SHA3-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_256 } from '@awasm/noble';
 * keccak_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_256: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * keccak-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_384 } from '@awasm/noble';
 * keccak_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_384: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * keccak-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_512 } from '@awasm/noble';
 * keccak_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_512: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHAKE128 XOF with 128-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128 } from '@awasm/noble';
 * shake128(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const shake128: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHAKE256 XOF with 256-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256 } from '@awasm/noble';
 * shake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const shake256: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHAKE128 XOF with 256-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128_32 } from '@awasm/noble';
 * shake128_32(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const shake128_32: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHAKE256 XOF with 512-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256_64 } from '@awasm/noble';
 * shake256_64(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const shake256_64: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-224 hash function from RFC 4634
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha224 } from '@awasm/noble';
 * sha224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha224: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
 * - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
 * - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
 * - Each sha256 hash is executing 2^18 bit operations.
 * - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble';
 * sha256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha256: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-384 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha384 } from '@awasm/noble';
 * sha384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha384: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-512 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512 } from '@awasm/noble';
 * sha512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-512/224 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_224 } from '@awasm/noble';
 * sha512_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512_224: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA2-512/256 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_256 } from '@awasm/noble';
 * sha512_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512_256: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * SHA1 (RFC 3174) legacy hash function. It was cryptographically broken.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha1 } from '@awasm/noble';
 * sha1(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha1: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * RIPEMD-160 - a legacy hash function from 1990s.
 * *
 * *
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ripemd160 } from '@awasm/noble';
 * ripemd160(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const ripemd160: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * MD5 (RFC 1321) legacy hash function. It was cryptographically broken.
 * MD5 architecture is similar to SHA1, with some differences:
 * - Reduced output length: 16 bytes (128 bit) instead of 20
 * - 64 rounds, instead of 80
 * - Little-endian: could be faster, but will require more code
 * - Non-linear index selection: huge speed-up for unroll
 * - Per round constants: more memory accesses, additional speed-up for unroll
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { md5 } from '@awasm/noble';
 * md5(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const md5: TRet<HashInstance<undefined> & HashStub<undefined>>;
/**
 * blake1-224 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake224 } from '@awasm/noble';
 * blake224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake224: TRet<HashInstance<BlakeOpts> & HashStub<BlakeOpts>>;
/**
 * blake1-256 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake256 } from '@awasm/noble';
 * blake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake256: TRet<HashInstance<BlakeOpts> & HashStub<BlakeOpts>>;
/**
 * blake1-384 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake384 } from '@awasm/noble';
 * blake384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake384: TRet<HashInstance<BlakeOpts> & HashStub<BlakeOpts>>;
/**
 * blake1-512 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake512 } from '@awasm/noble';
 * blake512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake512: TRet<HashInstance<BlakeOpts> & HashStub<BlakeOpts>>;
/**
 * Blake2s hash function. Focuses on 8-bit to 32-bit platforms.
 * 1.5x faster than blake2b in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2s } from '@awasm/noble';
 * blake2s(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake2s: TRet<HashInstance<Blake2Opts> & HashStub<Blake2Opts>>;
/**
 * Blake2b hash function. 64-bit.
 * 1.5x slower than blake2s in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2b } from '@awasm/noble';
 * blake2b(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake2b: TRet<HashInstance<Blake2Opts> & HashStub<Blake2Opts>>;
/**
 * BLAKE3 hash function. Can be used as MAC and KDF.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake3Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake3 } from '@awasm/noble';
 * const data = new Uint8Array(32);
 * const hash = blake3(data);
 * const mac = blake3(data, { key: new Uint8Array(32) });
 * const kdf = blake3(data, { context: new Uint8Array([1, 2, 3]) });
 * ```
 */
export declare const blake3: TRet<HashInstance<Blake3Opts> & HashStub<Blake3Opts>>;
/**
 * Poly1305 MAC from RFC 8439.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { poly1305 } from '@awasm/noble';
 * poly1305(new Uint8Array([1, 2, 3]), { key: new Uint8Array(32) });
 * ```
 */
export declare const poly1305: TRet<HashInstance<MACOpts> & HashStub<MACOpts>>;
/**
 * GHash MAC for AES-GCM.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ghash } from '@awasm/noble';
 * ghash(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const ghash: TRet<HashInstance<MACOpts> & HashStub<MACOpts>>;
/**
 * Polyval MAC for AES-SIV.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { polyval } from '@awasm/noble';
 * polyval(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const polyval: TRet<HashInstance<MACOpts> & HashStub<MACOpts>>;
/**
 * AES-CMAC (Cipher-based Message Authentication Code).
 * Specs: RFC 4493.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { cmac } from '@awasm/noble';
 * cmac(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const cmac: TRet<HashInstance<MACOpts> & HashStub<MACOpts>>;
/**
 * CTR (Counter Mode): Turns a block cipher into a stream cipher using a counter and IV (nonce).
 * Efficient and parallelizable. Requires a unique nonce per encryption. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ctr } from '@awasm/noble';
 * ctr(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const ctr: TRet<CipherFactory & CipherStub>;
/**
 * CBC (Cipher Block Chaining): Each plaintext block is XORed with the
 * previous block of ciphertext before encryption.
 * Hard to use: requires proper padding and an IV. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cbc } from '@awasm/noble';
 * cbc(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const cbc: TRet<CipherFactory & CipherStub>;
/**
 * OFB mode for AES block cipher.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ofb } from '@awasm/noble';
 * ofb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const ofb: TRet<CipherFactory & CipherStub>;
/**
 * CFB: Cipher Feedback Mode. The input for the block cipher is the previous cipher output.
 * Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cfb } from '@awasm/noble';
 * cfb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const cfb: TRet<CipherFactory & CipherStub>;
/**
 * ECB (Electronic Codebook): Deterministic encryption; identical plaintext blocks yield
 * identical ciphertexts. Not secure due to pattern leakage.
 * See AES Penguin.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ecb } from '@awasm/noble';
 * ecb(new Uint8Array(16));
 * ```
 */
export declare const ecb: TRet<CipherFactory & CipherStub>;
/**
 * GCM (Galois/Counter Mode): Combines CTR mode with polynomial MAC. Efficient and widely used.
 * Not perfect:
 * a) conservative key wear-out is '232' (4B) msgs.
 * b) key wear-out under random nonces is even smaller: '223' (8M) messages for '2-50' chance.
 * c) MAC can be forged: see Poly1305 documentation.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcm } from '@awasm/noble';
 * gcm(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export declare const gcm: TRet<CipherFactory & CipherStub>;
/**
 * SIV (Synthetic IV): GCM with nonce-misuse resistance.
 * Repeating nonces reveal only the fact plaintexts are identical.
 * Also suffers from GCM issues: key wear-out limits & MAC forging.
 * See RFC 8452.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcmsiv } from '@awasm/noble';
 * gcmsiv(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export declare const gcmsiv: TRet<CipherFactory & CipherStub>;
/**
 * SIV: Synthetic Initialization Vector (SIV) Authenticated Encryption
 * Nonce is derived from the plaintext and AAD using the S2V function.
 * See RFC 5297.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aessiv } from '@awasm/noble';
 * aessiv(new Uint8Array(32));
 * ```
 */
export declare const aessiv: TRet<CipherFactory & CipherStub>;
/**
 * AES-KW (key-wrap). Injects static IV into plaintext, adds counter, encrypts 6 times.
 * Reduces block size from 16 to 8 bytes.
 * For padded version, use aeskwp.
 * RFC 3394,
 * NIST.SP.800-38F.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskw } from '@awasm/noble';
 * aeskw(new Uint8Array(16));
 * ```
 */
export declare const aeskw: TRet<CipherFactory & CipherStub>;
/**
 * AES-KW, but with padding and allows random keys.
 * Second u32 of IV is used as counter for length.
 * RFC 5649
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskwp } from '@awasm/noble';
 * aeskwp(new Uint8Array(16));
 * ```
 */
export declare const aeskwp: TRet<CipherFactory & CipherStub>;
/**
 * Salsa20 from original paper. 12-byte nonce.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { salsa20 } from '@awasm/noble';
 * salsa20(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export declare const salsa20: TRet<CipherFactory & CipherStub>;
/**
 * xsalsa20 eXtended-nonce salsa. With 24-byte nonce, it's safe to make it random (CSPRNG).
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20 } from '@awasm/noble';
 * xsalsa20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xsalsa20: TRet<CipherFactory & CipherStub>;
/**
 * Reduced 8-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha8 } from '@awasm/noble';
 * chacha8(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha8: TRet<CipherFactory & CipherStub>;
/**
 * Reduced 12-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha12 } from '@awasm/noble';
 * chacha12(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha12: TRet<CipherFactory & CipherStub>;
/**
 * ChaCha stream cipher. Conforms to RFC 8439 (IETF, TLS). 12-byte nonce, 4-byte counter.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20 } from '@awasm/noble';
 * chacha20(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha20: TRet<CipherFactory & CipherStub>;
/**
 * Original, non-RFC chacha20 from DJB. 8-byte nonce, 8-byte counter.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20orig } from '@awasm/noble';
 * chacha20orig(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export declare const chacha20orig: TRet<CipherFactory & CipherStub>;
/**
 * XChaCha eXtended-nonce ChaCha. With 24-byte nonce, it's safe to make it random (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20 } from '@awasm/noble';
 * xchacha20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xchacha20: TRet<CipherFactory & CipherStub>;
/**
 * ChaCha20-Poly1305 from RFC 8439.
 * Unsafe to use random nonces under the same key, due to collision chance.
 * Prefer XChaCha instead.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20poly1305 } from '@awasm/noble';
 * chacha20poly1305(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha20poly1305: TRet<CipherFactory & CipherStub>;
/**
 * XChaCha20-Poly1305 extended-nonce chacha.
 * Can be safely used with random nonces (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20poly1305 } from '@awasm/noble';
 * xchacha20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xchacha20poly1305: TRet<CipherFactory & CipherStub>;
/**
 * xsalsa20-poly1305 eXtended-nonce (24 bytes) salsa.
 * With 24-byte nonce, it's safe to make it random (CSPRNG).
 * Also known as 'secretbox' from libsodium / nacl.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20poly1305 } from '@awasm/noble';
 * xsalsa20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xsalsa20poly1305: TRet<CipherFactory & CipherStub>;
/**
 * Scrypt KDF
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { scrypt } from '@awasm/noble';
 * scrypt('password', 'salt', { N: 16, r: 1, p: 1, dkLen: 32 });
 * ```
 */
export declare const scrypt: ReturnType<typeof def_scrypt>;
/**
 * argon2d GPU-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2d } from '@awasm/noble';
 * argon2d('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2d: ReturnType<typeof def_argon2d>;
/**
 * argon2i side-channel-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2i } from '@awasm/noble';
 * argon2i('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2i: ReturnType<typeof def_argon2i>;
/**
 * argon2id, combining i+d, the most popular version from RFC 9106
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2id } from '@awasm/noble';
 * argon2id('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2id: ReturnType<typeof def_argon2id>;
/**
 * Alias to xsalsa20poly1305, for compatibility with libsodium / nacl.
 * Check out  for crypto_box.
 *
 * @param key - secret key bytes.
 * @param nonce - nonce bytes.
 * @returns Configured secretbox helper.
 * @example
 * ```ts
 * import { secretbox } from '@awasm/noble';
 * secretbox(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const secretbox: TRet<SecretBox>;
//# sourceMappingURL=index.d.ts.map