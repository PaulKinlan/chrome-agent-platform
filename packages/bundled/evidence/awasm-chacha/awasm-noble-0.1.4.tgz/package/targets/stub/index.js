import { mkHashStub } from "../../hashes-abstract.js";
import { sha3_224 as def_sha3_224 } from "../../hashes.js";
import { sha3_256 as def_sha3_256 } from "../../hashes.js";
import { sha3_384 as def_sha3_384 } from "../../hashes.js";
import { sha3_512 as def_sha3_512 } from "../../hashes.js";
import { keccak_224 as def_keccak_224 } from "../../hashes.js";
import { keccak_256 as def_keccak_256 } from "../../hashes.js";
import { keccak_384 as def_keccak_384 } from "../../hashes.js";
import { keccak_512 as def_keccak_512 } from "../../hashes.js";
import { shake128 as def_shake128 } from "../../hashes.js";
import { shake256 as def_shake256 } from "../../hashes.js";
import { shake128_32 as def_shake128_32 } from "../../hashes.js";
import { shake256_64 as def_shake256_64 } from "../../hashes.js";
import { sha224 as def_sha224 } from "../../hashes.js";
import { sha256 as def_sha256 } from "../../hashes.js";
import { sha384 as def_sha384 } from "../../hashes.js";
import { sha512 as def_sha512 } from "../../hashes.js";
import { sha512_224 as def_sha512_224 } from "../../hashes.js";
import { sha512_256 as def_sha512_256 } from "../../hashes.js";
import { sha1 as def_sha1 } from "../../hashes.js";
import { ripemd160 as def_ripemd160 } from "../../hashes.js";
import { md5 as def_md5 } from "../../hashes.js";
import { blake224 as def_blake224 } from "../../hashes.js";
import { blake256 as def_blake256 } from "../../hashes.js";
import { blake384 as def_blake384 } from "../../hashes.js";
import { blake512 as def_blake512 } from "../../hashes.js";
import { blake2s as def_blake2s } from "../../hashes.js";
import { blake2b as def_blake2b } from "../../hashes.js";
import { blake3 as def_blake3 } from "../../hashes.js";
import { poly1305 as def_poly1305 } from "../../hashes.js";
import { ghash as def_ghash } from "../../hashes.js";
import { polyval as def_polyval } from "../../hashes.js";
import { cmac as def_cmac } from "../../hashes.js";
import { mkCipherStub } from "../../ciphers-abstract.js";
import { ctr as def_ctr } from "../../ciphers.js";
import { cbc as def_cbc } from "../../ciphers.js";
import { ofb as def_ofb } from "../../ciphers.js";
import { cfb as def_cfb } from "../../ciphers.js";
import { ecb as def_ecb } from "../../ciphers.js";
import { gcm as def_gcm } from "../../ciphers.js";
import { gcmsiv as def_gcmsiv } from "../../ciphers.js";
import { aessiv as def_aessiv } from "../../ciphers.js";
import { aeskw as def_aeskw } from "../../ciphers.js";
import { aeskwp as def_aeskwp } from "../../ciphers.js";
import { salsa20 as def_salsa20 } from "../../ciphers.js";
import { xsalsa20 as def_xsalsa20 } from "../../ciphers.js";
import { chacha8 as def_chacha8 } from "../../ciphers.js";
import { chacha12 as def_chacha12 } from "../../ciphers.js";
import { chacha20 as def_chacha20 } from "../../ciphers.js";
import { chacha20orig as def_chacha20orig } from "../../ciphers.js";
import { xchacha20 as def_xchacha20 } from "../../ciphers.js";
import { chacha20poly1305 as def_chacha20poly1305 } from "../../ciphers.js";
import { xchacha20poly1305 as def_xchacha20poly1305 } from "../../ciphers.js";
import { xsalsa20poly1305 as def_xsalsa20poly1305 } from "../../ciphers.js";
import { scrypt as def_scrypt } from "../../hashes.js";
import { mkKDFStub } from "../../kdf.js";
import { argon2d as def_argon2d } from "../../hashes.js";
import { argon2i as def_argon2i } from "../../hashes.js";
import { argon2id as def_argon2id } from "../../hashes.js";
/**
 * SHA3-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_224 } from '@awasm/noble';
 * sha3_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_224 = /* @__PURE__ */ mkHashStub(def_sha3_224);
/**
 * SHA3-256 hash function. Different from keccak-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_256 } from '@awasm/noble';
 * sha3_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_256 = /* @__PURE__ */ mkHashStub(def_sha3_256);
/**
 * SHA3-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_384 } from '@awasm/noble';
 * sha3_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_384 = /* @__PURE__ */ mkHashStub(def_sha3_384);
/**
 * SHA3-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_512 } from '@awasm/noble';
 * sha3_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_512 = /* @__PURE__ */ mkHashStub(def_sha3_512);
/**
 * keccak-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_224 } from '@awasm/noble';
 * keccak_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_224 = /* @__PURE__ */ mkHashStub(def_keccak_224);
/**
 * keccak-256 hash function. Different from SHA3-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_256 } from '@awasm/noble';
 * keccak_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_256 = /* @__PURE__ */ mkHashStub(def_keccak_256);
/**
 * keccak-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_384 } from '@awasm/noble';
 * keccak_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_384 = /* @__PURE__ */ mkHashStub(def_keccak_384);
/**
 * keccak-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_512 } from '@awasm/noble';
 * keccak_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_512 = /* @__PURE__ */ mkHashStub(def_keccak_512);
/**
 * SHAKE128 XOF with 128-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128 } from '@awasm/noble';
 * shake128(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake128 = /* @__PURE__ */ mkHashStub(def_shake128);
/**
 * SHAKE256 XOF with 256-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256 } from '@awasm/noble';
 * shake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake256 = /* @__PURE__ */ mkHashStub(def_shake256);
/**
 * SHAKE128 XOF with 256-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128_32 } from '@awasm/noble';
 * shake128_32(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake128_32 = /* @__PURE__ */ mkHashStub(def_shake128_32);
/**
 * SHAKE256 XOF with 512-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256_64 } from '@awasm/noble';
 * shake256_64(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake256_64 = /* @__PURE__ */ mkHashStub(def_shake256_64);
/**
 * SHA2-224 hash function from RFC 4634
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha224 } from '@awasm/noble';
 * sha224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha224 = /* @__PURE__ */ mkHashStub(def_sha224);
/**
 * SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
 * - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
 * - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
 * - Each sha256 hash is executing 2^18 bit operations.
 * - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble';
 * sha256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha256 = /* @__PURE__ */ mkHashStub(def_sha256);
/**
 * SHA2-384 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha384 } from '@awasm/noble';
 * sha384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha384 = /* @__PURE__ */ mkHashStub(def_sha384);
/**
 * SHA2-512 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512 } from '@awasm/noble';
 * sha512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512 = /* @__PURE__ */ mkHashStub(def_sha512);
/**
 * SHA2-512/224 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_224 } from '@awasm/noble';
 * sha512_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512_224 = /* @__PURE__ */ mkHashStub(def_sha512_224);
/**
 * SHA2-512/256 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_256 } from '@awasm/noble';
 * sha512_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512_256 = /* @__PURE__ */ mkHashStub(def_sha512_256);
/**
 * SHA1 (RFC 3174) legacy hash function. It was cryptographically broken.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha1 } from '@awasm/noble';
 * sha1(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha1 = /* @__PURE__ */ mkHashStub(def_sha1);
/**
 * RIPEMD-160 - a legacy hash function from 1990s.
 * *
 * *
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ripemd160 } from '@awasm/noble';
 * ripemd160(new Uint8Array([1, 2, 3]));
 * ```
 */
export const ripemd160 = /* @__PURE__ */ mkHashStub(def_ripemd160);
/**
 * MD5 (RFC 1321) legacy hash function. It was cryptographically broken.
 * MD5 architecture is similar to SHA1, with some differences:
 * - Reduced output length: 16 bytes (128 bit) instead of 20
 * - 64 rounds, instead of 80
 * - Little-endian: could be faster, but will require more code
 * - Non-linear index selection: huge speed-up for unroll
 * - Per round constants: more memory accesses, additional speed-up for unroll
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { md5 } from '@awasm/noble';
 * md5(new Uint8Array([1, 2, 3]));
 * ```
 */
export const md5 = /* @__PURE__ */ mkHashStub(def_md5);
/**
 * blake1-224 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake224 } from '@awasm/noble';
 * blake224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake224 = /* @__PURE__ */ mkHashStub(def_blake224);
/**
 * blake1-256 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake256 } from '@awasm/noble';
 * blake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake256 = /* @__PURE__ */ mkHashStub(def_blake256);
/**
 * blake1-384 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake384 } from '@awasm/noble';
 * blake384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake384 = /* @__PURE__ */ mkHashStub(def_blake384);
/**
 * blake1-512 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake512 } from '@awasm/noble';
 * blake512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake512 = /* @__PURE__ */ mkHashStub(def_blake512);
/**
 * Blake2s hash function. Focuses on 8-bit to 32-bit platforms.
 * 1.5x faster than blake2b in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2s } from '@awasm/noble';
 * blake2s(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake2s = /* @__PURE__ */ mkHashStub(def_blake2s);
/**
 * Blake2b hash function. 64-bit.
 * 1.5x slower than blake2s in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2b } from '@awasm/noble';
 * blake2b(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake2b = /* @__PURE__ */ mkHashStub(def_blake2b);
/**
 * BLAKE3 hash function. Can be used as MAC and KDF.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake3Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake3 } from '@awasm/noble';
 * const data = new Uint8Array(32);
 * const hash = blake3(data);
 * const mac = blake3(data, { key: new Uint8Array(32) });
 * const kdf = blake3(data, { context: new Uint8Array([1, 2, 3]) });
 * ```
 */
export const blake3 = /* @__PURE__ */ mkHashStub(def_blake3);
/**
 * Poly1305 MAC from RFC 8439.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { poly1305 } from '@awasm/noble';
 * poly1305(new Uint8Array([1, 2, 3]), { key: new Uint8Array(32) });
 * ```
 */
export const poly1305 = /* @__PURE__ */ mkHashStub(def_poly1305);
/**
 * GHash MAC for AES-GCM.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ghash } from '@awasm/noble';
 * ghash(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const ghash = /* @__PURE__ */ mkHashStub(def_ghash);
/**
 * Polyval MAC for AES-SIV.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { polyval } from '@awasm/noble';
 * polyval(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const polyval = /* @__PURE__ */ mkHashStub(def_polyval);
/**
 * AES-CMAC (Cipher-based Message Authentication Code).
 * Specs: RFC 4493.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { cmac } from '@awasm/noble';
 * cmac(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const cmac = /* @__PURE__ */ mkHashStub(def_cmac);
/**
 * CTR (Counter Mode): Turns a block cipher into a stream cipher using a counter and IV (nonce).
 * Efficient and parallelizable. Requires a unique nonce per encryption. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ctr } from '@awasm/noble';
 * ctr(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const ctr = /* @__PURE__ */ mkCipherStub(def_ctr);
/**
 * CBC (Cipher Block Chaining): Each plaintext block is XORed with the
 * previous block of ciphertext before encryption.
 * Hard to use: requires proper padding and an IV. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cbc } from '@awasm/noble';
 * cbc(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const cbc = /* @__PURE__ */ mkCipherStub(def_cbc);
/**
 * OFB mode for AES block cipher.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ofb } from '@awasm/noble';
 * ofb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const ofb = /* @__PURE__ */ mkCipherStub(def_ofb);
/**
 * CFB: Cipher Feedback Mode. The input for the block cipher is the previous cipher output.
 * Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cfb } from '@awasm/noble';
 * cfb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const cfb = /* @__PURE__ */ mkCipherStub(def_cfb);
/**
 * ECB (Electronic Codebook): Deterministic encryption; identical plaintext blocks yield
 * identical ciphertexts. Not secure due to pattern leakage.
 * See AES Penguin.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ecb } from '@awasm/noble';
 * ecb(new Uint8Array(16));
 * ```
 */
export const ecb = /* @__PURE__ */ mkCipherStub(def_ecb);
/**
 * GCM (Galois/Counter Mode): Combines CTR mode with polynomial MAC. Efficient and widely used.
 * Not perfect:
 * a) conservative key wear-out is '232' (4B) msgs.
 * b) key wear-out under random nonces is even smaller: '223' (8M) messages for '2-50' chance.
 * c) MAC can be forged: see Poly1305 documentation.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcm } from '@awasm/noble';
 * gcm(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export const gcm = /* @__PURE__ */ mkCipherStub(def_gcm);
/**
 * SIV (Synthetic IV): GCM with nonce-misuse resistance.
 * Repeating nonces reveal only the fact plaintexts are identical.
 * Also suffers from GCM issues: key wear-out limits & MAC forging.
 * See RFC 8452.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcmsiv } from '@awasm/noble';
 * gcmsiv(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export const gcmsiv = /* @__PURE__ */ mkCipherStub(def_gcmsiv);
/**
 * SIV: Synthetic Initialization Vector (SIV) Authenticated Encryption
 * Nonce is derived from the plaintext and AAD using the S2V function.
 * See RFC 5297.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aessiv } from '@awasm/noble';
 * aessiv(new Uint8Array(32));
 * ```
 */
export const aessiv = /* @__PURE__ */ mkCipherStub(def_aessiv);
/**
 * AES-KW (key-wrap). Injects static IV into plaintext, adds counter, encrypts 6 times.
 * Reduces block size from 16 to 8 bytes.
 * For padded version, use aeskwp.
 * RFC 3394,
 * NIST.SP.800-38F.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskw } from '@awasm/noble';
 * aeskw(new Uint8Array(16));
 * ```
 */
export const aeskw = /* @__PURE__ */ mkCipherStub(def_aeskw);
/**
 * AES-KW, but with padding and allows random keys.
 * Second u32 of IV is used as counter for length.
 * RFC 5649
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskwp } from '@awasm/noble';
 * aeskwp(new Uint8Array(16));
 * ```
 */
export const aeskwp = /* @__PURE__ */ mkCipherStub(def_aeskwp);
/**
 * Salsa20 from original paper. 12-byte nonce.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { salsa20 } from '@awasm/noble';
 * salsa20(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export const salsa20 = /* @__PURE__ */ mkCipherStub(def_salsa20);
/**
 * xsalsa20 eXtended-nonce salsa. With 24-byte nonce, it's safe to make it random (CSPRNG).
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20 } from '@awasm/noble';
 * xsalsa20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xsalsa20 = /* @__PURE__ */ mkCipherStub(def_xsalsa20);
/**
 * Reduced 8-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha8 } from '@awasm/noble';
 * chacha8(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha8 = /* @__PURE__ */ mkCipherStub(def_chacha8);
/**
 * Reduced 12-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha12 } from '@awasm/noble';
 * chacha12(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha12 = /* @__PURE__ */ mkCipherStub(def_chacha12);
/**
 * ChaCha stream cipher. Conforms to RFC 8439 (IETF, TLS). 12-byte nonce, 4-byte counter.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20 } from '@awasm/noble';
 * chacha20(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha20 = /* @__PURE__ */ mkCipherStub(def_chacha20);
/**
 * Original, non-RFC chacha20 from DJB. 8-byte nonce, 8-byte counter.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20orig } from '@awasm/noble';
 * chacha20orig(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export const chacha20orig = /* @__PURE__ */ mkCipherStub(def_chacha20orig);
/**
 * XChaCha eXtended-nonce ChaCha. With 24-byte nonce, it's safe to make it random (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20 } from '@awasm/noble';
 * xchacha20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xchacha20 = /* @__PURE__ */ mkCipherStub(def_xchacha20);
/**
 * ChaCha20-Poly1305 from RFC 8439.
 * Unsafe to use random nonces under the same key, due to collision chance.
 * Prefer XChaCha instead.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20poly1305 } from '@awasm/noble';
 * chacha20poly1305(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha20poly1305 = /* @__PURE__ */ mkCipherStub(def_chacha20poly1305);
/**
 * XChaCha20-Poly1305 extended-nonce chacha.
 * Can be safely used with random nonces (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20poly1305 } from '@awasm/noble';
 * xchacha20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xchacha20poly1305 = /* @__PURE__ */ mkCipherStub(def_xchacha20poly1305);
/**
 * xsalsa20-poly1305 eXtended-nonce (24 bytes) salsa.
 * With 24-byte nonce, it's safe to make it random (CSPRNG).
 * Also known as 'secretbox' from libsodium / nacl.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20poly1305 } from '@awasm/noble';
 * xsalsa20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xsalsa20poly1305 = /* @__PURE__ */ mkCipherStub(def_xsalsa20poly1305);
/**
 * Scrypt KDF
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { scrypt } from '@awasm/noble';
 * scrypt('password', 'salt', { N: 16, r: 1, p: 1, dkLen: 32 });
 * ```
 */
export const scrypt = /* @__PURE__ */ mkKDFStub(def_scrypt);
;
/**
 * argon2d GPU-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2d } from '@awasm/noble';
 * argon2d('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2d = /* @__PURE__ */ mkKDFStub(def_argon2d);
;
/**
 * argon2i side-channel-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2i } from '@awasm/noble';
 * argon2i('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2i = /* @__PURE__ */ mkKDFStub(def_argon2i);
;
/**
 * argon2id, combining i+d, the most popular version from RFC 9106
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2id } from '@awasm/noble';
 * argon2id('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2id = /* @__PURE__ */ mkKDFStub(def_argon2id);
;
/**
 * Alias to xsalsa20poly1305, for compatibility with libsodium / nacl.
 * Check out  for crypto_box.
 *
 * @param key - secret key bytes.
 * @param nonce - nonce bytes.
 * @returns Configured secretbox helper.
 * @example
 * ```ts
 * import { secretbox } from '@awasm/noble';
 * secretbox(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const secretbox = (key, nonce) => {
    const xs = xsalsa20poly1305(key, nonce);
    return { seal: xs.encrypt, open: xs.decrypt };
};
