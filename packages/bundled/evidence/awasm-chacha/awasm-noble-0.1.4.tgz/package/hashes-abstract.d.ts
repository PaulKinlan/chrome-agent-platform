/**
 * Abstract logic for hashes.
 * @module
 */
import { type Asyncify, type TArg, type TRet } from './utils.ts';
export type HashMod = {
    readonly segments: {
        readonly buffer: Uint8Array;
        readonly 'state.state_chunks': ReadonlyArray<Uint8Array>;
        readonly state: Uint8Array;
        readonly state_chunks: ReadonlyArray<Uint8Array>;
    };
    reset(batchPos: number, batchCnt: number, maxWritten: number, blockLen: number, maxBlocks: number): void;
    padding(batchPos: number, take: number, maxBlocks: number, left: number, blockLen: number, suffix: number): number;
    processBlocks(batchPos: number, batchCnt: number, blocks: number, maxBlocks: number, blockLen: number, isLast: number, left: number, padBlocks: number): void;
    processOutBlocks(batchPos: number, batchCnt: number, blocks: number, maxBlocks: number, outBlockLen: number, isLast: number): void;
};
/** Hash algorithm definition shared by all runtime/target wrappers. */
export type HashDef<Mod extends HashMod, Opts = undefined> = {
    /** Optional domain-separation suffix byte applied before the shared padding path. */
    suffix?: number;
    /** Preferred chunk count for batch helpers. */
    chunks?: number;
    /** Compression/input block size in bytes. */
    blockLen: number;
    /** Output block size in bytes when it differs from {@link blockLen}. */
    outputBlockLen?: number;
    /** Default digest length in bytes. */
    outputLen: number;
    /** Whether the hash supports variable-length XOF output. */
    canXOF?: boolean;
    /** Optional ASN.1 object identifier for fixed-output hash variants. */
    oid?: TRet<Uint8Array>;
    /**
     * Initialize state and optionally override block count or effective output length.
     * @param batchPos - batch slot being initialized.
     * @param maxBlocks - maximum number of blocks available in the shared buffers.
     * @param mod - backend hash module implementation for this batch slot.
     * @param hash - public hash helper being configured.
     * @param opts - merged hash and output options for this initialization; see {@link MergeOpts}.
     * @returns Optional overrides for preloaded block count or effective digest length.
     */
    init?: (batchPos: number, maxBlocks: number, mod: Mod, hash: HashInstance<Opts>, opts: MergeOpts<Opts, OutputOpts>) => void | {
        blocks?: number;
        outputLen?: number;
    };
};
/** Shared output-buffer options for one-shot and streaming hash APIs. */
export type OutputOpts = {
    /** Optional destination buffer to write the digest or XOF output into. */
    out?: TArg<Uint8Array>;
    /** Starting offset inside {@link out}. */
    outPos?: number;
    /** Requested digest length in bytes. */
    dkLen?: number;
};
/** Options accepted by multi-input hash APIs: `chunks` and `parallel`. */
export type HashBatchOpts = OutputOpts & {
    /**
     * Opaque state from `create().exportState()`.
     * The only supported use is passing it back to the same hash, platform, and library version.
     */
    prefixState?: TArg<HashState>;
};
/** Options accepted by `parallel`, including caller-owned per-lane output views. */
export type HashParallelOpts = Omit<OutputOpts, 'out'> & {
    /** Optional flat output buffer or one exact-size destination view per input lane. */
    out?: TArg<Uint8Array | Uint8Array[]>;
    /**
     * Opaque state from `create().exportState()`.
     * The only supported use is passing it back to the same hash, platform, and library version.
     */
    prefixState?: TArg<HashState>;
};
type CreateOutputOpts = Pick<OutputOpts, 'dkLen'>;
type CreateOpts<Opts> = MergeOpts<Opts, CreateOutputOpts>;
declare const HASH_STATE: unique symbol;
/**
 * Opaque exported hash state; not necessarily a byte array.
 * The value is an owned cleanup handle for one hash/platform/version only.
 */
export type HashState = {
    /** Internal brand that prevents treating arbitrary values as exported hash states. */
    readonly [HASH_STATE]: true;
};
/** Streaming hash instance returned by {@link HashInstance.create}. */
export type HashStream<Opts> = {
    /** Input block size in bytes for the underlying hash. */
    blockLen: number;
    /** Current digest length in bytes, including `create()` digest-length overrides. */
    outputLen: number;
    /** Whether this stream supports variable-length XOF output via xof()/xofInto(). */
    canXOF: boolean;
    /** Absorb more message bytes into the stream and return the same stream. */
    update(msg: TArg<Uint8Array>): HashStream<Opts>;
    /**
     * Finalize the stream and return the digest bytes.
     * @param opts - optional {@link OutputOpts} controlling digest length or destination buffer.
     * @returns Digest bytes.
     */
    digest(opts?: OutputOpts): TRet<Uint8Array>;
    /** Wipe internal state and make the stream unusable. */
    destroy(): void;
    /**
     * Finalize the stream and return variable-length XOF output.
     * @param bytes - number of XOF bytes to return.
     * @param opts - optional {@link OutputOpts} controlling output length or destination buffer.
     * @returns XOF output bytes.
     */
    xof(bytes: number, opts?: OutputOpts): TRet<Uint8Array>;
    /** Copy the current stream state into another stream or a freshly created clone target. */
    _cloneInto(to?: HashStream<Opts>): HashStream<Opts>;
    /** Clone the current stream state. */
    clone(): HashStream<Opts>;
    /**
     * Export an opaque state that can be reused as `prefixState` by this exact hash/platform/version.
     * Callers must eventually pass it to `hash.cleanState(state)`.
     */
    exportState(): TRet<HashState>;
    /**
     * Finalize the stream and write the fixed-size digest into `buf`.
     * @param buf - destination buffer for the digest bytes.
     */
    digestInto(buf: TArg<Uint8Array>): void;
    /**
     * Finalize the stream and fill `buf` with XOF output.
     * @param buf - destination buffer for XOF output.
     * @returns The filled destination buffer.
     */
    xofInto(buf: TArg<Uint8Array>): TRet<Uint8Array>;
};
type MergeOpts<Opts, Out> = [Opts] extends [undefined] ? Out : Opts & Out;
/** One-shot hash helper plus streaming constructor and metadata. */
export type HashInstance<Opts> = Asyncify<(msg: TArg<Uint8Array>, opts?: MergeOpts<Opts, OutputOpts>) => TRet<Uint8Array>> & {
    chunks: Asyncify<(chunks: TArg<Uint8Array[]>, opts?: MergeOpts<Opts, HashBatchOpts>) => TRet<Uint8Array>>;
    parallel: Asyncify<(chunks: TArg<Uint8Array[]>, opts?: MergeOpts<Opts, HashParallelOpts>) => TRet<Uint8Array[]>>;
    create: (opts?: CreateOpts<Opts>) => HashStream<Opts>;
    /** Wipe and invalidate an opaque state returned by `create().exportState()`. */
    cleanState: (state: TArg<HashState>) => void;
    getPlatform: () => string | undefined;
    getDefinition: () => HashDef<any, any>;
    isSupported?: () => boolean | Promise<boolean>;
    blockLen: number;
    outputLen: number;
    canXOF: boolean;
    oid?: TRet<Uint8Array>;
};
export declare function mkHash<Mod extends HashMod, Opts>(modFn: () => Mod, def_: TArg<HashDef<Mod, Opts>>, platform?: string): TRet<HashInstance<Opts>>;
type NobleHashStream = {
    blockLen: number;
    outputLen: number;
    canXOF?: boolean;
    update(msg: TArg<Uint8Array>): NobleHashStream;
    digest(): TRet<Uint8Array>;
    digestInto(out: TArg<Uint8Array>): void;
    destroy(): void;
    xof?(bytes: number): TRet<Uint8Array>;
    xofInto?(out: TArg<Uint8Array>): TRet<Uint8Array>;
    _cloneInto(to?: NobleHashStream): NobleHashStream;
};
type NobleHashImpl<Opts> = {
    hash: (msg: TArg<Uint8Array>, opts?: TArg<MergeOpts<Opts, OutputOpts>>) => TRet<Uint8Array>;
    create?: (opts?: TArg<CreateOpts<Opts>>) => NobleHashStream;
};
export declare function mkHashNoble<Opts>(def_: TArg<HashDef<any, Opts>>, impl_: TArg<NobleHashImpl<Opts>>, platform?: string): TRet<HashInstance<Opts>>;
type AsyncHashImpl<Opts> = {
    hash: (msg: TArg<Uint8Array>, opts?: MergeOpts<Opts, OutputOpts>) => Promise<TRet<Uint8Array>>;
    chunks?: (parts: TArg<Uint8Array[]>, opts?: MergeOpts<Opts, HashBatchOpts>) => Promise<TRet<Uint8Array>>;
    parallel?: (parts: TArg<Uint8Array[]>, opts?: MergeOpts<Opts, HashParallelOpts>) => Promise<TRet<Uint8Array[]>>;
};
export declare function mkHashAsync<Opts>(def_: TArg<HashDef<any, Opts>>, impl_: TArg<AsyncHashImpl<Opts>>, platform?: string, isSupported?: () => boolean | Promise<boolean>, meta?: Record<string, unknown>): TRet<HashInstance<Opts>>;
type InstallOpts = {
    onlyMissing?: boolean;
};
/** Installable hash stub used by the `stub` platform. */
export type Stub<Opts> = {
    /**
     * Install a branded hash implementation into this stub.
     * @param impl - Hash implementation created by an awasm hash constructor.
     * @param opts - {@link InstallOpts}; `onlyMissing` leaves an existing implementation unchanged.
     */
    install: (impl: HashInstance<Opts>, opts?: InstallOpts) => void;
};
export declare function mkHashStub<Mod extends HashMod, Opts>(def_: TArg<HashDef<Mod, Opts>>): TRet<HashInstance<Opts> & Stub<Opts>>;
export {};
//# sourceMappingURL=hashes-abstract.d.ts.map