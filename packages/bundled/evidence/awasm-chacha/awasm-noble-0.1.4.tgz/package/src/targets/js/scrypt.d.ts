// WARNING: This file is auto-generated. Any changes will be lost.
export default function scrypt(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly xorInput: Uint8Array;
    readonly xorInput_chunks: ReadonlyArray<Uint8Array>;
    readonly output: Uint8Array;
    readonly output_chunks: ReadonlyArray<Uint8Array>;
  };
  blockMix(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number): void;
};