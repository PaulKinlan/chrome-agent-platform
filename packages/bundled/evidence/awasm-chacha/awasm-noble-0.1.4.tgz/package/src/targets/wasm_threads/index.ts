/*!
The MIT License (MIT)

Copyright (c) 2026 Paul Miller (https://paulmillr.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
// WARNING: This file is auto-generated. Any changes will be lost.
import type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, HashInstance } from '../../hashes-abstract.ts';
import type { TArg, TRet, Asyncify, KDFInput } from '../../utils.ts';
import type { BlakeOpts, Blake2Opts, Blake3Opts } from '../../hashes.ts';
import type { Cipher, CipherDef, CipherFactory } from '../../ciphers-abstract.ts';
import type { KDF, ScryptOpts, ArgonOpts } from '../../kdf.ts';
import { mkHash } from '../../hashes-abstract.ts';
import {sha3_224 as def_sha3_224} from '../../hashes.ts';
import {WP as pool} from '../../workers.ts';
import mod_sha3_224 from './keccak24.js';
import {sha3_256 as def_sha3_256} from '../../hashes.ts';
import mod_sha3_256 from './keccak24.js';
import {sha3_384 as def_sha3_384} from '../../hashes.ts';
import mod_sha3_384 from './keccak24.js';
import {sha3_512 as def_sha3_512} from '../../hashes.ts';
import mod_sha3_512 from './keccak24.js';
import {keccak_224 as def_keccak_224} from '../../hashes.ts';
import mod_keccak_224 from './keccak24.js';
import {keccak_256 as def_keccak_256} from '../../hashes.ts';
import mod_keccak_256 from './keccak24.js';
import {keccak_384 as def_keccak_384} from '../../hashes.ts';
import mod_keccak_384 from './keccak24.js';
import {keccak_512 as def_keccak_512} from '../../hashes.ts';
import mod_keccak_512 from './keccak24.js';
import {shake128 as def_shake128} from '../../hashes.ts';
import mod_shake128 from './keccak24.js';
import {shake256 as def_shake256} from '../../hashes.ts';
import mod_shake256 from './keccak24.js';
import {shake128_32 as def_shake128_32} from '../../hashes.ts';
import mod_shake128_32 from './keccak24.js';
import {shake256_64 as def_shake256_64} from '../../hashes.ts';
import mod_shake256_64 from './keccak24.js';
import {sha224 as def_sha224} from '../../hashes.ts';
import mod_sha224 from './sha256.js';
import {sha256 as def_sha256} from '../../hashes.ts';
import mod_sha256 from './sha256.js';
import {sha384 as def_sha384} from '../../hashes.ts';
import mod_sha384 from './sha512.js';
import {sha512 as def_sha512} from '../../hashes.ts';
import mod_sha512 from './sha512.js';
import {sha512_224 as def_sha512_224} from '../../hashes.ts';
import mod_sha512_224 from './sha512.js';
import {sha512_256 as def_sha512_256} from '../../hashes.ts';
import mod_sha512_256 from './sha512.js';
import {sha1 as def_sha1} from '../../hashes.ts';
import mod_sha1 from './sha1.js';
import {ripemd160 as def_ripemd160} from '../../hashes.ts';
import mod_ripemd160 from './ripemd160.js';
import {md5 as def_md5} from '../../hashes.ts';
import mod_md5 from './md5.js';
import {blake224 as def_blake224} from '../../hashes.ts';
import mod_blake224 from './blake256.js';
import {blake256 as def_blake256} from '../../hashes.ts';
import mod_blake256 from './blake256.js';
import {blake384 as def_blake384} from '../../hashes.ts';
import mod_blake384 from './blake512.js';
import {blake512 as def_blake512} from '../../hashes.ts';
import mod_blake512 from './blake512.js';
import {blake2s as def_blake2s} from '../../hashes.ts';
import mod_blake2s from './blake2s.js';
import {blake2b as def_blake2b} from '../../hashes.ts';
import mod_blake2b from './blake2b.js';
import {blake3 as def_blake3} from '../../hashes.ts';
import mod_blake3 from './blake3.js';
import {poly1305 as def_poly1305} from '../../hashes.ts';
import mod_poly1305 from './poly1305.js';
import {ghash as def_ghash} from '../../hashes.ts';
import mod_ghash from './ghash.js';
import {polyval as def_polyval} from '../../hashes.ts';
import mod_polyval from './polyval.js';
import {cmac as def_cmac} from '../../hashes.ts';
import mod_cmac from './cmac.js';
import { mkCipher } from '../../ciphers-abstract.ts';
import {ctr as def_ctr} from '../../ciphers.ts';
import mod_ctr from './aes_ctr.js';
import {cbc as def_cbc} from '../../ciphers.ts';
import mod_cbc from './aes_cbc.js';
import {ofb as def_ofb} from '../../ciphers.ts';
import mod_ofb from './aes_ofb.js';
import {cfb as def_cfb} from '../../ciphers.ts';
import mod_cfb from './aes_cfb.js';
import {ecb as def_ecb} from '../../ciphers.ts';
import mod_ecb from './aes_ecb.js';
import {gcm as def_gcm} from '../../ciphers.ts';
import mod_gcm from './aes_gcm.js';
import {gcmsiv as def_gcmsiv} from '../../ciphers.ts';
import mod_gcmsiv from './aes_gcmsiv.js';
import {aessiv as def_aessiv} from '../../ciphers.ts';
import mod_aessiv from './aes_siv.js';
import {aeskw as def_aeskw} from '../../ciphers.ts';
import mod_aeskw from './aes_kw.js';
import {aeskwp as def_aeskwp} from '../../ciphers.ts';
import mod_aeskwp from './aes_kwp.js';
import {salsa20 as def_salsa20} from '../../ciphers.ts';
import mod_salsa20 from './salsa20.js';
import {xsalsa20 as def_xsalsa20} from '../../ciphers.ts';
import mod_xsalsa20 from './salsa20.js';
import {chacha8 as def_chacha8} from '../../ciphers.ts';
import mod_chacha8 from './chacha8.js';
import {chacha12 as def_chacha12} from '../../ciphers.ts';
import mod_chacha12 from './chacha12.js';
import {chacha20 as def_chacha20} from '../../ciphers.ts';
import mod_chacha20 from './chacha20.js';
import {chacha20orig as def_chacha20orig} from '../../ciphers.ts';
import mod_chacha20orig from './chacha20.js';
import {xchacha20 as def_xchacha20} from '../../ciphers.ts';
import mod_xchacha20 from './chacha20.js';
import {chacha20poly1305 as def_chacha20poly1305} from '../../ciphers.ts';
import mod_chacha20poly1305 from './chacha_poly1305.js';
import {xchacha20poly1305 as def_xchacha20poly1305} from '../../ciphers.ts';
import mod_xchacha20poly1305 from './chacha_poly1305.js';
import {xsalsa20poly1305 as def_xsalsa20poly1305} from '../../ciphers.ts';
import mod_xsalsa20poly1305 from './salsa_poly1305.js';
import {scrypt as def_scrypt} from '../../hashes.ts';
import mod_scrypt from './scrypt.js';
import {argon2d as def_argon2d} from '../../hashes.ts';
import mod_argon2d from './argon2.js';
import {argon2i as def_argon2i} from '../../hashes.ts';
import mod_argon2i from './argon2.js';
import {argon2id as def_argon2id} from '../../hashes.ts';
import mod_argon2id from './argon2.js';
type MACOpts = { key: TArg<Uint8Array> } | TArg<Uint8Array>;
type SecretBox = (key: TArg<Uint8Array>, nonce: TArg<Uint8Array>) => {
  seal: Cipher['encrypt'];
  open: Cipher['decrypt'];
};
export type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, HashInstance };
export type { TArg, TRet, Asyncify, KDFInput };
export type { BlakeOpts, Blake2Opts, Blake3Opts };
export type { Cipher, CipherDef, CipherFactory };
export type { KDF, ScryptOpts, ArgonOpts };
/**
 * SHA3-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_224 } from '@awasm/noble';
 * sha3_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_224: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha3_224.bind(null, {}, pool), def_sha3_224, 'wasm_threads');
/**
 * SHA3-256 hash function. Different from keccak-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_256 } from '@awasm/noble';
 * sha3_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_256: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha3_256.bind(null, {}, pool), def_sha3_256, 'wasm_threads');
/**
 * SHA3-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_384 } from '@awasm/noble';
 * sha3_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_384: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha3_384.bind(null, {}, pool), def_sha3_384, 'wasm_threads');
/**
 * SHA3-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_512 } from '@awasm/noble';
 * sha3_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha3_512: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha3_512.bind(null, {}, pool), def_sha3_512, 'wasm_threads');
/**
 * keccak-224 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_224 } from '@awasm/noble';
 * keccak_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_224: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_keccak_224.bind(null, {}, pool), def_keccak_224, 'wasm_threads');
/**
 * keccak-256 hash function. Different from SHA3-256.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_256 } from '@awasm/noble';
 * keccak_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_256: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_keccak_256.bind(null, {}, pool), def_keccak_256, 'wasm_threads');
/**
 * keccak-384 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_384 } from '@awasm/noble';
 * keccak_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_384: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_keccak_384.bind(null, {}, pool), def_keccak_384, 'wasm_threads');
/**
 * keccak-512 hash function.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_512 } from '@awasm/noble';
 * keccak_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const keccak_512: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_keccak_512.bind(null, {}, pool), def_keccak_512, 'wasm_threads');
/**
 * SHAKE128 XOF with 128-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128 } from '@awasm/noble';
 * shake128(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake128: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_shake128.bind(null, {}, pool), def_shake128, 'wasm_threads');
/**
 * SHAKE256 XOF with 256-bit security.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256 } from '@awasm/noble';
 * shake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake256: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_shake256.bind(null, {}, pool), def_shake256, 'wasm_threads');
/**
 * SHAKE128 XOF with 256-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128_32 } from '@awasm/noble';
 * shake128_32(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake128_32: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_shake128_32.bind(null, {}, pool), def_shake128_32, 'wasm_threads');
/**
 * SHAKE256 XOF with 512-bit output (NIST version).
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256_64 } from '@awasm/noble';
 * shake256_64(new Uint8Array([1, 2, 3]));
 * ```
 */
export const shake256_64: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_shake256_64.bind(null, {}, pool), def_shake256_64, 'wasm_threads');
/**
 * SHA2-224 hash function from RFC 4634
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha224 } from '@awasm/noble';
 * sha224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha224: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha224.bind(null, {}, pool), def_sha224, 'wasm_threads');
/**
 * SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
 * - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
 * - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
 * - Each sha256 hash is executing 2^18 bit operations.
 * - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble';
 * sha256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha256: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha256.bind(null, {}, pool), def_sha256, 'wasm_threads');
/**
 * SHA2-384 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha384 } from '@awasm/noble';
 * sha384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha384: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha384.bind(null, {}, pool), def_sha384, 'wasm_threads');
/**
 * SHA2-512 hash function from RFC 4634.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512 } from '@awasm/noble';
 * sha512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha512.bind(null, {}, pool), def_sha512, 'wasm_threads');
/**
 * SHA2-512/224 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_224 } from '@awasm/noble';
 * sha512_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512_224: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha512_224.bind(null, {}, pool), def_sha512_224, 'wasm_threads');
/**
 * SHA2-512/256 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on truncated SHA512.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_256 } from '@awasm/noble';
 * sha512_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha512_256: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha512_256.bind(null, {}, pool), def_sha512_256, 'wasm_threads');
/**
 * SHA1 (RFC 3174) legacy hash function. It was cryptographically broken.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha1 } from '@awasm/noble';
 * sha1(new Uint8Array([1, 2, 3]));
 * ```
 */
export const sha1: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_sha1.bind(null, {}, pool), def_sha1, 'wasm_threads');
/**
 * RIPEMD-160 - a legacy hash function from 1990s.
 * * 
 * * 
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ripemd160 } from '@awasm/noble';
 * ripemd160(new Uint8Array([1, 2, 3]));
 * ```
 */
export const ripemd160: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_ripemd160.bind(null, {}, pool), def_ripemd160, 'wasm_threads');
/**
 * MD5 (RFC 1321) legacy hash function. It was cryptographically broken.
 * MD5 architecture is similar to SHA1, with some differences:
 * - Reduced output length: 16 bytes (128 bit) instead of 20
 * - 64 rounds, instead of 80
 * - Little-endian: could be faster, but will require more code
 * - Non-linear index selection: huge speed-up for unroll
 * - Per round constants: more memory accesses, additional speed-up for unroll
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { md5 } from '@awasm/noble';
 * md5(new Uint8Array([1, 2, 3]));
 * ```
 */
export const md5: TRet<HashInstance<undefined>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_md5.bind(null, {}, pool), def_md5, 'wasm_threads');
/**
 * blake1-224 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake224 } from '@awasm/noble';
 * blake224(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake224: TRet<HashInstance<BlakeOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake224.bind(null, {}, pool), def_blake224, 'wasm_threads');
/**
 * blake1-256 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake256 } from '@awasm/noble';
 * blake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake256: TRet<HashInstance<BlakeOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake256.bind(null, {}, pool), def_blake256, 'wasm_threads');
/**
 * blake1-384 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake384 } from '@awasm/noble';
 * blake384(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake384: TRet<HashInstance<BlakeOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake384.bind(null, {}, pool), def_blake384, 'wasm_threads');
/**
 * blake1-512 hash function
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link BlakeOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake512 } from '@awasm/noble';
 * blake512(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake512: TRet<HashInstance<BlakeOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake512.bind(null, {}, pool), def_blake512, 'wasm_threads');
/**
 * Blake2s hash function. Focuses on 8-bit to 32-bit platforms.
 * 1.5x faster than blake2b in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2s } from '@awasm/noble';
 * blake2s(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake2s: TRet<HashInstance<Blake2Opts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake2s.bind(null, {}, pool), def_blake2s, 'wasm_threads');
/**
 * Blake2b hash function. 64-bit.
 * 1.5x slower than blake2s in JS.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake2Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2b } from '@awasm/noble';
 * blake2b(new Uint8Array([1, 2, 3]));
 * ```
 */
export const blake2b: TRet<HashInstance<Blake2Opts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake2b.bind(null, {}, pool), def_blake2b, 'wasm_threads');
/**
 * BLAKE3 hash function. Can be used as MAC and KDF.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} and {@link Blake3Opts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake3 } from '@awasm/noble';
 * const data = new Uint8Array(32);
 * const hash = blake3(data);
 * const mac = blake3(data, { key: new Uint8Array(32) });
 * const kdf = blake3(data, { context: new Uint8Array([1, 2, 3]) });
 * ```
 */
export const blake3: TRet<HashInstance<Blake3Opts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_blake3.bind(null, {}, pool), def_blake3, 'wasm_threads');
/**
 * Poly1305 MAC from RFC 8439.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { poly1305 } from '@awasm/noble';
 * poly1305(new Uint8Array([1, 2, 3]), { key: new Uint8Array(32) });
 * ```
 */
export const poly1305: TRet<HashInstance<MACOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_poly1305.bind(null, {}, pool), def_poly1305, 'wasm_threads');
/**
 * GHash MAC for AES-GCM.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ghash } from '@awasm/noble';
 * ghash(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const ghash: TRet<HashInstance<MACOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_ghash.bind(null, {}, pool), def_ghash, 'wasm_threads');
/**
 * Polyval MAC for AES-SIV.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { polyval } from '@awasm/noble';
 * polyval(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const polyval: TRet<HashInstance<MACOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_polyval.bind(null, {}, pool), def_polyval, 'wasm_threads');
/**
 * AES-CMAC (Cipher-based Message Authentication Code).
 * Specs: RFC 4493.
 *
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { cmac } from '@awasm/noble';
 * cmac(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export const cmac: TRet<HashInstance<MACOpts>> = /* @__PURE__ */ mkHash(/* @__PURE__ */ mod_cmac.bind(null, {}, pool), def_cmac, 'wasm_threads');
/**
 * CTR (Counter Mode): Turns a block cipher into a stream cipher using a counter and IV (nonce).
 * Efficient and parallelizable. Requires a unique nonce per encryption. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ctr } from '@awasm/noble';
 * ctr(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const ctr: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_ctr.bind(null, {}, pool), def_ctr, 'wasm_threads');
/**
 * CBC (Cipher Block Chaining): Each plaintext block is XORed with the
 * previous block of ciphertext before encryption.
 * Hard to use: requires proper padding and an IV. Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cbc } from '@awasm/noble';
 * cbc(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const cbc: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_cbc.bind(null, {}, pool), def_cbc, 'wasm_threads');
/**
 * OFB mode for AES block cipher.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ofb } from '@awasm/noble';
 * ofb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const ofb: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_ofb.bind(null, {}, pool), def_ofb, 'wasm_threads');
/**
 * CFB: Cipher Feedback Mode. The input for the block cipher is the previous cipher output.
 * Unauthenticated: needs MAC.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cfb } from '@awasm/noble';
 * cfb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export const cfb: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_cfb.bind(null, {}, pool), def_cfb, 'wasm_threads');
/**
 * ECB (Electronic Codebook): Deterministic encryption; identical plaintext blocks yield
 * identical ciphertexts. Not secure due to pattern leakage.
 * See AES Penguin.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ecb } from '@awasm/noble';
 * ecb(new Uint8Array(16));
 * ```
 */
export const ecb: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_ecb.bind(null, {}, pool), def_ecb, 'wasm_threads');
/**
 * GCM (Galois/Counter Mode): Combines CTR mode with polynomial MAC. Efficient and widely used.
 * Not perfect:
 * a) conservative key wear-out is '232' (4B) msgs.
 * b) key wear-out under random nonces is even smaller: '223' (8M) messages for '2-50' chance.
 * c) MAC can be forged: see Poly1305 documentation.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcm } from '@awasm/noble';
 * gcm(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export const gcm: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_gcm.bind(null, {}, pool), def_gcm, 'wasm_threads');
/**
 * SIV (Synthetic IV): GCM with nonce-misuse resistance.
 * Repeating nonces reveal only the fact plaintexts are identical.
 * Also suffers from GCM issues: key wear-out limits & MAC forging.
 * See RFC 8452.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcmsiv } from '@awasm/noble';
 * gcmsiv(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export const gcmsiv: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_gcmsiv.bind(null, {}, pool), def_gcmsiv, 'wasm_threads');
/**
 * SIV: Synthetic Initialization Vector (SIV) Authenticated Encryption
 * Nonce is derived from the plaintext and AAD using the S2V function.
 * See RFC 5297.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aessiv } from '@awasm/noble';
 * aessiv(new Uint8Array(32));
 * ```
 */
export const aessiv: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_aessiv.bind(null, {}, pool), def_aessiv, 'wasm_threads');
/**
 * AES-KW (key-wrap). Injects static IV into plaintext, adds counter, encrypts 6 times.
 * Reduces block size from 16 to 8 bytes.
 * For padded version, use aeskwp.
 * RFC 3394,
 * NIST.SP.800-38F.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskw } from '@awasm/noble';
 * aeskw(new Uint8Array(16));
 * ```
 */
export const aeskw: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_aeskw.bind(null, {}, pool), def_aeskw, 'wasm_threads');
/**
 * AES-KW, but with padding and allows random keys.
 * Second u32 of IV is used as counter for length.
 * RFC 5649
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskwp } from '@awasm/noble';
 * aeskwp(new Uint8Array(16));
 * ```
 */
export const aeskwp: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_aeskwp.bind(null, {}, pool), def_aeskwp, 'wasm_threads');
/**
 * Salsa20 from original paper. 12-byte nonce.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { salsa20 } from '@awasm/noble';
 * salsa20(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export const salsa20: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_salsa20.bind(null, {}, pool), def_salsa20, 'wasm_threads');
/**
 * xsalsa20 eXtended-nonce salsa. With 24-byte nonce, it's safe to make it random (CSPRNG).
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20 } from '@awasm/noble';
 * xsalsa20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xsalsa20: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_xsalsa20.bind(null, {}, pool), def_xsalsa20, 'wasm_threads');
/**
 * Reduced 8-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha8 } from '@awasm/noble';
 * chacha8(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha8: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_chacha8.bind(null, {}, pool), def_chacha8, 'wasm_threads');
/**
 * Reduced 12-round chacha, described in original paper.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha12 } from '@awasm/noble';
 * chacha12(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha12: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_chacha12.bind(null, {}, pool), def_chacha12, 'wasm_threads');
/**
 * ChaCha stream cipher. Conforms to RFC 8439 (IETF, TLS). 12-byte nonce, 4-byte counter.
 * With smaller nonce, it's not safe to make it random (CSPRNG), due to collision chance.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20 } from '@awasm/noble';
 * chacha20(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha20: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_chacha20.bind(null, {}, pool), def_chacha20, 'wasm_threads');
/**
 * Original, non-RFC chacha20 from DJB. 8-byte nonce, 8-byte counter.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20orig } from '@awasm/noble';
 * chacha20orig(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export const chacha20orig: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_chacha20orig.bind(null, {}, pool), def_chacha20orig, 'wasm_threads');
/**
 * XChaCha eXtended-nonce ChaCha. With 24-byte nonce, it's safe to make it random (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20 } from '@awasm/noble';
 * xchacha20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xchacha20: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_xchacha20.bind(null, {}, pool), def_xchacha20, 'wasm_threads');
/**
 * ChaCha20-Poly1305 from RFC 8439.
 * Unsafe to use random nonces under the same key, due to collision chance.
 * Prefer XChaCha instead.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20poly1305 } from '@awasm/noble';
 * chacha20poly1305(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export const chacha20poly1305: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_chacha20poly1305.bind(null, {}, pool), def_chacha20poly1305, 'wasm_threads');
/**
 * XChaCha20-Poly1305 extended-nonce chacha.
 * Can be safely used with random nonces (CSPRNG).
 * See IRTF draft.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20poly1305 } from '@awasm/noble';
 * xchacha20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xchacha20poly1305: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_xchacha20poly1305.bind(null, {}, pool), def_xchacha20poly1305, 'wasm_threads');
/**
 * xsalsa20-poly1305 eXtended-nonce (24 bytes) salsa.
 * With 24-byte nonce, it's safe to make it random (CSPRNG).
 * Also known as 'secretbox' from libsodium / nacl.
 *
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce or AAD.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20poly1305 } from '@awasm/noble';
 * xsalsa20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const xsalsa20poly1305: TRet<CipherFactory> = /* @__PURE__ */ mkCipher(/* @__PURE__ */ mod_xsalsa20poly1305.bind(null, {}, pool), def_xsalsa20poly1305, 'wasm_threads');
/**
 * Scrypt KDF
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { scrypt } from '@awasm/noble';
 * scrypt('password', 'salt', { N: 16, r: 1, p: 1, dkLen: 32 });
 * ```
 */
export const scrypt: ReturnType<typeof def_scrypt> = /* @__PURE__ */ def_scrypt(/* @__PURE__ */ mod_scrypt.bind(null, {}, pool), {sha256}, 'wasm_threads');
/**
 * argon2d GPU-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2d } from '@awasm/noble';
 * argon2d('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2d: ReturnType<typeof def_argon2d> = /* @__PURE__ */ def_argon2d(/* @__PURE__ */ mod_argon2d.bind(null, {}, pool), {blake2b}, 'wasm_threads');
/**
 * argon2i side-channel-resistant version.
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2i } from '@awasm/noble';
 * argon2i('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2i: ReturnType<typeof def_argon2i> = /* @__PURE__ */ def_argon2i(/* @__PURE__ */ mod_argon2i.bind(null, {}, pool), {blake2b}, 'wasm_threads');
/**
 * argon2id, combining i+d, the most popular version from RFC 9106
 *
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2id } from '@awasm/noble';
 * argon2id('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export const argon2id: ReturnType<typeof def_argon2id> = /* @__PURE__ */ def_argon2id(/* @__PURE__ */ mod_argon2id.bind(null, {}, pool), {blake2b}, 'wasm_threads');
/**
 * Alias to xsalsa20poly1305, for compatibility with libsodium / nacl.
 * Check out  for crypto_box.
 *
 * @param key - secret key bytes.
 * @param nonce - nonce bytes.
 * @returns Configured secretbox helper.
 * @example
 * ```ts
 * import { secretbox } from '@awasm/noble';
 * secretbox(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export const secretbox: TRet<SecretBox> = (key: TArg<Uint8Array>, nonce: TArg<Uint8Array>) => {
  const xs = xsalsa20poly1305(key, nonce);
  return { seal: xs.encrypt, open: xs.decrypt };
};