// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};


const __buf = new ArrayBuffer(0);
if (!(__buf instanceof ArrayBuffer)) throw new Error('wrong buffer');




function f32_abs(v0) {
    
    const v1 = Math.abs(v0);
return v1;
}



function f32_add(v0, v1) {
    
    const v2 = Math.fround(v1 + v0);
return v2;
}



function f32_cast_i32(v0) {
    
    const v1 = (new Float32Array(new Int32Array([v0]).buffer)[0]);
return v1;
}



function f32_cast_u32(v0) {
    
    const v1 = (new Float32Array(new Int32Array([v0]).buffer)[0]);
return v1;
}



function f32_ceil(v0) {
    
    const v1 = Math.ceil(v0);
return v1;
}



function f32_copysign(v0, v1) {
    
    const v2 = Math.fround((new Uint32Array(new Float32Array([v1]).buffer)[0] >>> 31) ? -Math.abs(v0) :  Math.abs(v0));
return v2;
}



function f32_div(v0, v1) {
    
    const v2 = Math.fround(v0 / v1);
return v2;
}



function f32_eq(v0, v1) {
    
    const v2 = +(v0 === v1);
return v2;
}



function f32_eqz(v0) {
    
    const v1 = +(v0 === 0);
return v1;
}



function f32_floor(v0) {
    
    const v1 = Math.floor(v0);
return v1;
}



function f32_from_f64(v0) {
    
    const v1 = Math.fround(v0);
return v1;
}



function f32_from_i16(v0) {
    
    const v1 = Math.fround((((((v0 << 16) >> 16) << 16) >> 16)) | 0);
return v1;
}



function f32_from_i32(v0) {
    
    const v1 = Math.fround((v0) | 0);
return v1;
}



function f32_from_i64(v0, v1) {
    
    const v2 = Math.fround(((4294967296 * ((v1) | 0)) + ((v0) >>> 0)));
return v2;
}



function f32_from_i8(v0) {
    
    const v1 = Math.fround((((((v0 << 24) >> 24) << 24) >> 24)) | 0);
return v1;
}



function f32_from_u16(v0) {
    
    const v1 = Math.fround(((65535 & (65535 & v0))) >>> 0);
return v1;
}



function f32_from_u32(v0) {
    
    const v1 = Math.fround((v0) >>> 0);
return v1;
}



function f32_from_u64(v0, v1) {
    
    const v2 = Math.fround(((4294967296 * ((v1) >>> 0)) + ((v0) >>> 0)));
return v2;
}



function f32_from_u8(v0) {
    
    const v1 = Math.fround(((255 & (255 & v0))) >>> 0);
return v1;
}



function f32_ge(v0, v1) {
    
    const v2 = +(v0 >= v1);
return v2;
}



function f32_gt(v0, v1) {
    
    const v2 = +(v0 > v1);
return v2;
}



function f32_isNaN(v0) {
    
    const v1 = (Number.isNaN(v0) ? 1 : 0);
return v1;
}



function f32_le(v0, v1) {
    
    const v2 = +(v0 <= v1);
return v2;
}



function f32_lt(v0, v1) {
    
    const v2 = +(v0 < v1);
return v2;
}



function f32_max(v0, v1) {
    
    const v2 = Math.max(v1, v0);
return v2;
}



function f32_min(v0, v1) {
    
    const v2 = Math.min(v1, v0);
return v2;
}



function f32_mul(v0, v1) {
    
    const v2 = Math.fround(v1 * v0);
return v2;
}



function f32_ne(v0, v1) {
    
    const v2 = +(v0 !== v1);
return v2;
}



function f32_nearest(v0) {
    
    const v1 = Math.fround(((x)=>{if (x !== x || x === Infinity || x === -Infinity) return x;const f = Math.floor(x);const d = x - f;let r = d < 0.5 ? f : d > 0.5 ? f + 1 : ((f % 2) === 0 ? f : f + 1);return r === 0 ? ((x < 0 || 1/x === -Infinity) ? -0 : 0) : r;})(v0));
return v1;
}



function f32_neg(v0) {
    
    const v1 = (-v0);
return v1;
}



function f32_rem(v0, v1) {
    
    const v2 = Math.fround(v0 - (Math.trunc(v0 / v1) * v1));
return v2;
}



function f32_sqrt(v0) {
    
    const v1 = Math.fround(Math.sqrt(v0));
return v1;
}



function f32_sub(v0, v1) {
    
    const v2 = Math.fround(v0 - v1);
return v2;
}



function f32_swapEndianness(v0) {
    
    const v1 = (new Int32Array(new Float32Array([v0]).buffer)[0]);
const v2 = (new Float32Array(new Int32Array([(((255 & (v1 >>> 0)) << 24) | (((255 & (v1 >>> 8)) << 16) | (((255 & (v1 >>> 16)) << 8) | (255 & (v1 >>> 24)))))]).buffer)[0]);
return v2;
}



function f32_trunc(v0) {
    
    const v1 = Math.trunc(v0);
return v1;
}



function f64_abs(v0) {
    
    const v1 = Math.abs(v0);
return v1;
}



function f64_add(v0, v1) {
    
    const v2 = (v1 + v0);
return v2;
}



function f64_cast_i64(v0, v1) {
    
    const v2 = (new Float64Array(new Uint32Array([v0, v1]).buffer)[0]);
return v2;
}



function f64_cast_u64(v0, v1) {
    
    const v2 = (new Float64Array(new Uint32Array([v0, v1]).buffer)[0]);
return v2;
}



function f64_ceil(v0) {
    
    const v1 = Math.ceil(v0);
return v1;
}



function f64_copysign(v0, v1) {
    
    const v2 = (new Uint32Array(new Float64Array([v1]).buffer)[1] >>> 31) ? -Math.abs(v0) :  Math.abs(v0);
return v2;
}



function f64_div(v0, v1) {
    
    const v2 = (v0 / v1);
return v2;
}



function f64_eq(v0, v1) {
    
    const v2 = +(v0 === v1);
return v2;
}



function f64_eqz(v0) {
    
    const v1 = +(v0 === 0);
return v1;
}



function f64_floor(v0) {
    
    const v1 = Math.floor(v0);
return v1;
}



function f64_from_f32(v0) {
    
    const v1 = v0;
return v1;
}



function f64_from_i16(v0) {
    
    const v1 = ((((((v0 << 16) >> 16) << 16) >> 16)) | 0);
return v1;
}



function f64_from_i32(v0) {
    
    const v1 = ((v0) | 0);
return v1;
}



function f64_from_i64(v0, v1) {
    
    const v2 = ((4294967296 * ((v1) | 0)) + ((v0) >>> 0));
return v2;
}



function f64_from_i8(v0) {
    
    const v1 = ((((((v0 << 24) >> 24) << 24) >> 24)) | 0);
return v1;
}



function f64_from_u16(v0) {
    
    const v1 = (((65535 & (65535 & v0))) >>> 0);
return v1;
}



function f64_from_u32(v0) {
    
    const v1 = ((v0) >>> 0);
return v1;
}



function f64_from_u64(v0, v1) {
    
    const v2 = ((4294967296 * ((v1) >>> 0)) + ((v0) >>> 0));
return v2;
}



function f64_from_u8(v0) {
    
    const v1 = (((255 & (255 & v0))) >>> 0);
return v1;
}



function f64_ge(v0, v1) {
    
    const v2 = +(v0 >= v1);
return v2;
}



function f64_gt(v0, v1) {
    
    const v2 = +(v0 > v1);
return v2;
}



function f64_isNaN(v0) {
    
    const v1 = (Number.isNaN(v0) ? 1 : 0);
return v1;
}



function f64_le(v0, v1) {
    
    const v2 = +(v0 <= v1);
return v2;
}



function f64_lt(v0, v1) {
    
    const v2 = +(v0 < v1);
return v2;
}



function f64_max(v0, v1) {
    
    const v2 = Math.max(v1, v0);
return v2;
}



function f64_min(v0, v1) {
    
    const v2 = Math.min(v1, v0);
return v2;
}



function f64_mul(v0, v1) {
    
    const v2 = (v1 * v0);
return v2;
}



function f64_ne(v0, v1) {
    
    const v2 = +(v0 !== v1);
return v2;
}



function f64_nearest(v0) {
    
    const v1 = ((x)=>{if (x !== x || x === Infinity || x === -Infinity) return x;const f = Math.floor(x);const d = x - f;let r = d < 0.5 ? f : d > 0.5 ? f + 1 : ((f % 2) === 0 ? f : f + 1);return r === 0 ? ((x < 0 || 1/x === -Infinity) ? -0 : 0) : r;})(v0);
return v1;
}



function f64_neg(v0) {
    
    const v1 = (-v0);
return v1;
}



function f64_rem(v0, v1) {
    
    const v2 = (v0 - (Math.trunc(v0 / v1) * v1));
return v2;
}



function f64_sqrt(v0) {
    
    const v1 = Math.sqrt(v0);
return v1;
}



function f64_sub(v0, v1) {
    
    const v2 = (v0 - v1);
return v2;
}



function f64_swapEndianness(v0) {
    
    const v1 = (new Uint32Array(new Float64Array([v0]).buffer)[0]);
const v2 = (new Uint32Array(new Float64Array([v0]).buffer)[1]);
const v3 = (255 & (v2 >>> 16));
const v4 = (255 & (v2 >>> 8));
const v5 = (255 & v2);
const v6 = (new Float64Array(new Uint32Array([((v5 << 24) | ((v4 << 16) | ((v3 << 8) | (255 & (v2 >>> 24))))), (((255 & v1) << 24) | (((255 & ((v2 << 24) | (v1 >>> 8))) << 16) | (((255 & ((v2 << 16) | (v1 >>> 16))) << 8) | ((255 & ((v2 << 8) | (v1 >>> 24))) | ((v5 >>> 8) | ((v4 >>> 16) | (v3 >>> 24)))))))]).buffer)[0]);
return v6;
}



function f64_trunc(v0) {
    
    const v1 = Math.trunc(v0);
return v1;
}



function i16_abs(v0) {
    
    const v1 = (((Math.abs(((v0 << 16) >> 16)) | 0) << 16) >> 16);
return v1;
}



function i16_add(v0, v1) {
    
    const v2 = ((((((v1 << 16) >> 16) + ((v0 << 16) >> 16)) | 0) << 16) >> 16);
return v2;
}



function i16_and(v0, v1) {
    
    const v2 = (((((v1 << 16) >> 16) & ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_andnot(v0, v1) {
    
    const v2 = (((((v0 << 16) >> 16) & ~((v1 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_cast_i32(v0) {
    
    const v1 = ((v0 << 16) >> 16);
return v1;
}



function i16_cast_u16(v0) {
    
    const v1 = (((65535 & v0) << 16) >> 16);
return v1;
}



function i16_cast_u32(v0) {
    
    const v1 = ((v0 << 16) >> 16);
return v1;
}



function i16_clz(v0) {
    
    const v1 = (((((Math.clz32(((65535 & ((v0 << 16) >> 16)))>>>0)|0) - 16) | 0) << 16) >> 16);
return v1;
}



function i16_ctz(v0) {
    
    const v1 = (()=>{const x=(((65535 & ((v0 << 16) >> 16)))>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
const v2 = ((((((((v1) >>> 0) > ((16) >>> 0)) | 0)) ? (16) : (v1)) << 16) >> 16);
return v2;
}



function i16_div(v0, v1) {
    
    const v2 = (((((((((v0 << 16) >> 16))|0)/(((((v1 << 16) >> 16))|0)))|0)) << 16) >> 16);
return v2;
}



function i16_eq(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) === ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_eqz(v0) {
    
    const v1 = ((((((v0 << 16) >> 16)) | 0) === 0) | 0);
return v1;
}



function i16_from_f32(v0) {
    
    const v1 = (((Math.trunc(v0) | 0) << 16) >> 16);
return v1;
}



function i16_from_f64(v0) {
    
    const v1 = (((Math.trunc(v0) | 0) << 16) >> 16);
return v1;
}



function i16_from_i32(v0) {
    
    const v1 = ((v0 << 16) >> 16);
const v2 = (((v0 >> 16) << 16) >> 16);
return {r0: v1, r1: v2};
}



function i16_from_i64(v0, v1) {
    
    const v2 = ((v0 << 16) >> 16);
const v3 = ((((v1 << 16) | (v0 >>> 16)) << 16) >> 16);
const v4 = (((v1 >> 0) << 16) >> 16);
const v5 = (((v1 >> 16) << 16) >> 16);
return {r0: v2, r1: v3, r2: v4, r3: v5};
}



function i16_from_i8(v0) {
    
    const v1 = ((((((v0 << 24) >> 24) << 24) >> 24) << 16) >> 16);
return v1;
}



function i16_from_u16(v0) {
    
    const v1 = (((65535 & (65535 & v0)) << 16) >> 16);
return v1;
}



function i16_from_u32(v0) {
    
    const v1 = ((v0 << 16) >> 16);
const v2 = (((v0 >>> 16) << 16) >> 16);
return {r0: v1, r1: v2};
}



function i16_from_u64(v0, v1) {
    
    const v2 = ((v0 << 16) >> 16);
const v3 = ((((v1 << 16) | (v0 >>> 16)) << 16) >> 16);
const v4 = ((v1 << 16) >> 16);
const v5 = (((v1 >>> 16) << 16) >> 16);
return {r0: v2, r1: v3, r2: v4, r3: v5};
}



function i16_from_u8(v0) {
    
    const v1 = (((255 & (255 & v0)) << 16) >> 16);
return v1;
}



function i16_ge(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) >= ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_gt(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) > ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_le(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) <= ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_lt(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) < ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_max(v0, v1) {
    
    const v2 = ((Math.max(((v1 << 16) >> 16), ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_min(v0, v1) {
    
    const v2 = ((Math.min(((v1 << 16) >> 16), ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_mul(v0, v1) {
    
    const v2 = ((Math.imul(((v1 << 16) >> 16), ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_ne(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16)) | 0) !== ((((v1 << 16) >> 16)) | 0)) | 0);
return v2;
}



function i16_neg(v0) {
    
    const v1 = (((-((v0 << 16) >> 16)) << 16) >> 16);
return v1;
}



function i16_not(v0) {
    
    const v1 = (((~((v0 << 16) >> 16)) << 16) >> 16);
return v1;
}



function i16_or(v0, v1) {
    
    const v2 = (((((v1 << 16) >> 16) | ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i16_popcnt(v0) {
    
    const v1 = (((()=>{let x=(((65535 & ((v0 << 16) >> 16)))>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})() << 16) >> 16);
return v1;
}



function i16_rem(v0, v1) {
    
    const v2 = (((((((((v0 << 16) >> 16))|0)%(((((v1 << 16) >> 16))|0)))|0)) << 16) >> 16);
return v2;
}



function i16_rotl(v0, v1) {
    
    const v2 = (15 & v1);
const v3 = (65535 & ((v0 << 16) >> 16));
const v4 = ((((v3 >>> ((16 - v2) | 0)) | (v3 << v2)) << 16) >> 16);
return v4;
}



function i16_rotr(v0, v1) {
    
    const v2 = (15 & v1);
const v3 = (65535 & ((v0 << 16) >> 16));
const v4 = ((((v3 << ((16 - v2) | 0)) | (v3 >>> v2)) << 16) >> 16);
return v4;
}



function i16_shl(v0, v1) {
    
    const v2 = (((((v0 << 16) >> 16) << (15 & v1)) << 16) >> 16);
return v2;
}



function i16_shr(v0, v1) {
    
    const v2 = (((((v0 << 16) >> 16) >> (15 & v1)) << 16) >> 16);
return v2;
}



function i16_sub(v0, v1) {
    
    const v2 = ((((((v0 << 16) >> 16) - ((v1 << 16) >> 16)) | 0) << 16) >> 16);
return v2;
}



function i16_swapEndianness(v0) {
    
    const v1 = (65535 & ((v0 << 16) >> 16));
const v2 = ((((255 & (v1 >>> 8)) | ((255 & v1) << 8)) << 16) >> 16);
return v2;
}



function i16_xor(v0, v1) {
    
    const v2 = (((((v1 << 16) >> 16) ^ ((v0 << 16) >> 16)) << 16) >> 16);
return v2;
}



function i32_abs(v0) {
    
    const v1 = (Math.abs(v0) | 0);
return v1;
}



function i32_add(v0, v1) {
    
    const v2 = ((v1 + v0) | 0);
return v2;
}



function i32_and(v0, v1) {
    
    const v2 = (v1 & v0);
return v2;
}



function i32_andnot(v0, v1) {
    
    const v2 = (v0 & ~v1);
return v2;
}



function i32_cast_f32(v0) {
    
    return (new Int32Array(new Float32Array([v0]).buffer)[0]);
}



function i32_cast_i16(v0) {
    
    return ((v0 << 16) >> 16);
}



function i32_cast_i8(v0) {
    
    return ((v0 << 24) >> 24);
}



function i32_cast_u16(v0) {
    
    return (65535 & v0);
}



function i32_cast_u32(v0) {
    
    return v0;
}



function i32_cast_u8(v0) {
    
    return (255 & v0);
}



function i32_clz(v0) {
    
    const v1 = (Math.clz32((v0)>>>0)|0);
return v1;
}



function i32_ctz(v0) {
    
    const v1 = (()=>{const x=((v0)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
return v1;
}



function i32_div(v0, v1) {
    
    const v2 = (((((v0)|0)/(((v1)|0)))|0));
return v2;
}



function i32_eq(v0, v1) {
    
    const v2 = ((((v0) | 0) === ((v1) | 0)) | 0);
return v2;
}



function i32_eqz(v0) {
    
    const v1 = ((((v0) | 0) === 0) | 0);
return v1;
}



function i32_from_f32(v0) {
    
    const v1 = (Math.trunc(v0) | 0);
return v1;
}



function i32_from_f64(v0) {
    
    const v1 = (Math.trunc(v0) | 0);
return v1;
}



function i32_from_i16(v0) {
    
    const v1 = ((((v0 << 16) >> 16) << 16) >> 16);
return v1;
}



function i32_from_i64(v0, v1) {
    
    const v2 = (v1 >> 0);
return {r0: v0, r1: v2};
}



function i32_from_i8(v0) {
    
    const v1 = ((((v0 << 24) >> 24) << 24) >> 24);
return v1;
}



function i32_from_u16(v0) {
    
    const v1 = (65535 & (65535 & v0));
return v1;
}



function i32_from_u32(v0) {
    
    return v0;
}



function i32_from_u64(v0, v1) {
    
    return {r0: v0, r1: v1};
}



function i32_from_u8(v0) {
    
    const v1 = (255 & (255 & v0));
return v1;
}



function i32_ge(v0, v1) {
    
    const v2 = ((((v0) | 0) >= ((v1) | 0)) | 0);
return v2;
}



function i32_gt(v0, v1) {
    
    const v2 = ((((v0) | 0) > ((v1) | 0)) | 0);
return v2;
}



function i32_le(v0, v1) {
    
    const v2 = ((((v0) | 0) <= ((v1) | 0)) | 0);
return v2;
}



function i32_lt(v0, v1) {
    
    const v2 = ((((v0) | 0) < ((v1) | 0)) | 0);
return v2;
}



function i32_max(v0, v1) {
    
    const v2 = Math.max(v1, v0);
return v2;
}



function i32_min(v0, v1) {
    
    const v2 = Math.min(v1, v0);
return v2;
}



function i32_mul(v0, v1) {
    
    const v2 = Math.imul(v1, v0);
return v2;
}



function i32_ne(v0, v1) {
    
    const v2 = ((((v0) | 0) !== ((v1) | 0)) | 0);
return v2;
}



function i32_neg(v0) {
    
    const v1 = (-v0);
return v1;
}



function i32_not(v0) {
    
    const v1 = (~v0);
return v1;
}



function i32_or(v0, v1) {
    
    const v2 = (v1 | v0);
return v2;
}



function i32_popcnt(v0) {
    
    const v1 = (()=>{let x=((v0)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})();
return v1;
}



function i32_rem(v0, v1) {
    
    const v2 = (((((v0)|0)%(((v1)|0)))|0));
return v2;
}



function i32_rotl(v0, v1) {
    
    const v2 = ((v0 << v1) | ((v0 >>> (32 - v1)) >>> 0));
return v2;
}



function i32_rotr(v0, v1) {
    
    const v2 = (((v0 >>> v1) | (v0 << (32 - v1))));
return v2;
}



function i32_shl(v0, v1) {
    
    const v2 = (v0 << v1);
return v2;
}



function i32_shr(v0, v1) {
    
    const v2 = (v0 >> v1);
return v2;
}



function i32_sub(v0, v1) {
    
    const v2 = ((v0 - v1) | 0);
return v2;
}



function i32_swapEndianness(v0) {
    
    const v1 = (((255 & (v0 >>> 0)) << 24) | (((255 & (v0 >>> 8)) << 16) | (((255 & (v0 >>> 16)) << 8) | (255 & (v0 >>> 24)))));
return v1;
}



function i32_xor(v0, v1) {
    
    const v2 = (v1 ^ v0);
return v2;
}



function i64_abs(v0, v1) {
    
    const v2 = (v1 >> 31);
const v3 = ((0 - v2) | 0);
const v4 = ((v3 + (v2 ^ v0)) | 0);
const v5 = ((((((((v0) | 0) === 0) | 0) & v3) + (v2 ^ v1)) | 0) >> 0);
return {r0: v4, r1: v5};
}



function i64_add(v0, v1, v2, v3) {
    
    const v4 = ((v2 + v0) | 0);
const v5 = (((((((-1 ^ v4) & (v2 | v0)) | (v2 & v0)) >>> 31) + ((v3 + v1) | 0)) | 0) >> 0);
return {r0: v4, r1: v5};
}



function i64_and(v0, v1, v2, v3) {
    
    const v4 = (v2 & v0);
const v5 = ((v3 & v1) >> 0);
return {r0: v4, r1: v5};
}



function i64_andnot(v0, v1, v2, v3) {
    
    const v4 = (v0 & ~v2);
const v5 = ((v1 & ~v3) >> 0);
return {r0: v4, r1: v5};
}



function i64_cast_f64(v0) {
    
    const v1 = (new Uint32Array(new Float64Array([v0]).buffer)[0]);
const v2 = ((new Uint32Array(new Float64Array([v0]).buffer)[1]) >> 0);
return {r0: v1, r1: v2};
}



function i64_cast_u64(v0, v1) {
    
    const v2 = (v1 >> 0);
return {r0: v0, r1: v2};
}



function i64_clz(v0, v1) {
    
    const v2 = ((((((v1) | 0) === 0) | 0)) ? ((((Math.clz32((v0)>>>0)|0) + 32) | 0)) : ((Math.clz32((v1)>>>0)|0)));
return {r0: v2, r1: 0};
}



function i64_ctz(v0, v1) {
    
    const v2 = ((((((v0) | 0) === 0) | 0)) ? ((((()=>{const x=((v1)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})() + 32) | 0)) : ((()=>{const x=((v0)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})()));
return {r0: v2, r1: 0};
}



function i64_div(v0, v1, v2, v3) {
    
    const v4 = ((((v1) | 0) < ((0) | 0)) | 0);
const v5 = ((((v3) | 0) < ((0) | 0)) | 0);
const v6 = (-v4);
const v7 = (v6 ^ v0);
const v8 = (((1 & v6) + v7) | 0);
const v9 = ((((((v8) >>> 0) < ((v7) >>> 0)) | 0) + (v6 ^ v1)) | 0);
const v10 = (-v5);
const v11 = (v10 ^ v2);
const v12 = (((1 & v10) + v11) | 0);
const v13 = ((((((v12) >>> 0) < ((v11) >>> 0)) | 0) + (v10 ^ v3)) | 0);
const v14 = (1 & (1 & (v9 >>> 31)));
const v15 = ((((((((((v14) >>> 0) < ((v12) >>> 0)) | 0) & ((((0) | 0) === ((v13) | 0)) | 0)) | ((((0) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v16 = (-v15);
const v17 = (v16 & v12);
const v18 = ((v14 - v17) | 0);
const v19 = ((v18 >>> 31) | (((((0 - (v16 & v13)) | 0) - ((((v14) >>> 0) < ((v17) >>> 0)) | 0)) | 0) << 1));
const v20 = ((1 & (1 & (v9 >>> 30))) | (v18 << 1));
const v21 = ((((((((((v20) >>> 0) < ((v12) >>> 0)) | 0) & ((((v19) | 0) === ((v13) | 0)) | 0)) | ((((v19) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v22 = (-v21);
const v23 = (v22 & v12);
const v24 = ((v20 - v23) | 0);
const v25 = ((v24 >>> 31) | (((((v19 - (v22 & v13)) | 0) - ((((v20) >>> 0) < ((v23) >>> 0)) | 0)) | 0) << 1));
const v26 = ((1 & (1 & (v9 >>> 29))) | (v24 << 1));
const v27 = ((((((((((v26) >>> 0) < ((v12) >>> 0)) | 0) & ((((v25) | 0) === ((v13) | 0)) | 0)) | ((((v25) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v28 = (-v27);
const v29 = (v28 & v12);
const v30 = ((v26 - v29) | 0);
const v31 = ((v30 >>> 31) | (((((v25 - (v28 & v13)) | 0) - ((((v26) >>> 0) < ((v29) >>> 0)) | 0)) | 0) << 1));
const v32 = ((1 & (1 & (v9 >>> 28))) | (v30 << 1));
const v33 = ((((((((((v32) >>> 0) < ((v12) >>> 0)) | 0) & ((((v31) | 0) === ((v13) | 0)) | 0)) | ((((v31) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v34 = (-v33);
const v35 = (v34 & v12);
const v36 = ((v32 - v35) | 0);
const v37 = ((v36 >>> 31) | (((((v31 - (v34 & v13)) | 0) - ((((v32) >>> 0) < ((v35) >>> 0)) | 0)) | 0) << 1));
const v38 = ((1 & (1 & (v9 >>> 27))) | (v36 << 1));
const v39 = ((((((((((v38) >>> 0) < ((v12) >>> 0)) | 0) & ((((v37) | 0) === ((v13) | 0)) | 0)) | ((((v37) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v40 = (-v39);
const v41 = (v40 & v12);
const v42 = ((v38 - v41) | 0);
const v43 = ((v42 >>> 31) | (((((v37 - (v40 & v13)) | 0) - ((((v38) >>> 0) < ((v41) >>> 0)) | 0)) | 0) << 1));
const v44 = ((1 & (1 & (v9 >>> 26))) | (v42 << 1));
const v45 = ((((((((((v44) >>> 0) < ((v12) >>> 0)) | 0) & ((((v43) | 0) === ((v13) | 0)) | 0)) | ((((v43) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v46 = (-v45);
const v47 = (v46 & v12);
const v48 = ((v44 - v47) | 0);
const v49 = ((v48 >>> 31) | (((((v43 - (v46 & v13)) | 0) - ((((v44) >>> 0) < ((v47) >>> 0)) | 0)) | 0) << 1));
const v50 = ((1 & (1 & (v9 >>> 25))) | (v48 << 1));
const v51 = ((((((((((v50) >>> 0) < ((v12) >>> 0)) | 0) & ((((v49) | 0) === ((v13) | 0)) | 0)) | ((((v49) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v52 = (-v51);
const v53 = (v52 & v12);
const v54 = ((v50 - v53) | 0);
const v55 = ((v54 >>> 31) | (((((v49 - (v52 & v13)) | 0) - ((((v50) >>> 0) < ((v53) >>> 0)) | 0)) | 0) << 1));
const v56 = ((1 & (1 & (v9 >>> 24))) | (v54 << 1));
const v57 = ((((((((((v56) >>> 0) < ((v12) >>> 0)) | 0) & ((((v55) | 0) === ((v13) | 0)) | 0)) | ((((v55) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v58 = (-v57);
const v59 = (v58 & v12);
const v60 = ((v56 - v59) | 0);
const v61 = ((v60 >>> 31) | (((((v55 - (v58 & v13)) | 0) - ((((v56) >>> 0) < ((v59) >>> 0)) | 0)) | 0) << 1));
const v62 = ((1 & (1 & (v9 >>> 23))) | (v60 << 1));
const v63 = ((((((((((v62) >>> 0) < ((v12) >>> 0)) | 0) & ((((v61) | 0) === ((v13) | 0)) | 0)) | ((((v61) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v64 = (-v63);
const v65 = (v64 & v12);
const v66 = ((v62 - v65) | 0);
const v67 = ((v66 >>> 31) | (((((v61 - (v64 & v13)) | 0) - ((((v62) >>> 0) < ((v65) >>> 0)) | 0)) | 0) << 1));
const v68 = ((1 & (1 & (v9 >>> 22))) | (v66 << 1));
const v69 = ((((((((((v68) >>> 0) < ((v12) >>> 0)) | 0) & ((((v67) | 0) === ((v13) | 0)) | 0)) | ((((v67) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v70 = (-v69);
const v71 = (v70 & v12);
const v72 = ((v68 - v71) | 0);
const v73 = ((v72 >>> 31) | (((((v67 - (v70 & v13)) | 0) - ((((v68) >>> 0) < ((v71) >>> 0)) | 0)) | 0) << 1));
const v74 = ((1 & (1 & (v9 >>> 21))) | (v72 << 1));
const v75 = ((((((((((v74) >>> 0) < ((v12) >>> 0)) | 0) & ((((v73) | 0) === ((v13) | 0)) | 0)) | ((((v73) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v76 = (-v75);
const v77 = (v76 & v12);
const v78 = ((v74 - v77) | 0);
const v79 = ((v78 >>> 31) | (((((v73 - (v76 & v13)) | 0) - ((((v74) >>> 0) < ((v77) >>> 0)) | 0)) | 0) << 1));
const v80 = ((1 & (1 & (v9 >>> 20))) | (v78 << 1));
const v81 = ((((((((((v80) >>> 0) < ((v12) >>> 0)) | 0) & ((((v79) | 0) === ((v13) | 0)) | 0)) | ((((v79) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v82 = (-v81);
const v83 = (v82 & v12);
const v84 = ((v80 - v83) | 0);
const v85 = ((v84 >>> 31) | (((((v79 - (v82 & v13)) | 0) - ((((v80) >>> 0) < ((v83) >>> 0)) | 0)) | 0) << 1));
const v86 = ((1 & (1 & (v9 >>> 19))) | (v84 << 1));
const v87 = ((((((((((v86) >>> 0) < ((v12) >>> 0)) | 0) & ((((v85) | 0) === ((v13) | 0)) | 0)) | ((((v85) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v88 = (-v87);
const v89 = (v88 & v12);
const v90 = ((v86 - v89) | 0);
const v91 = ((v90 >>> 31) | (((((v85 - (v88 & v13)) | 0) - ((((v86) >>> 0) < ((v89) >>> 0)) | 0)) | 0) << 1));
const v92 = ((1 & (1 & (v9 >>> 18))) | (v90 << 1));
const v93 = ((((((((((v92) >>> 0) < ((v12) >>> 0)) | 0) & ((((v91) | 0) === ((v13) | 0)) | 0)) | ((((v91) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v94 = (-v93);
const v95 = (v94 & v12);
const v96 = ((v92 - v95) | 0);
const v97 = ((v96 >>> 31) | (((((v91 - (v94 & v13)) | 0) - ((((v92) >>> 0) < ((v95) >>> 0)) | 0)) | 0) << 1));
const v98 = ((1 & (1 & (v9 >>> 17))) | (v96 << 1));
const v99 = ((((((((((v98) >>> 0) < ((v12) >>> 0)) | 0) & ((((v97) | 0) === ((v13) | 0)) | 0)) | ((((v97) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v100 = (-v99);
const v101 = (v100 & v12);
const v102 = ((v98 - v101) | 0);
const v103 = ((v102 >>> 31) | (((((v97 - (v100 & v13)) | 0) - ((((v98) >>> 0) < ((v101) >>> 0)) | 0)) | 0) << 1));
const v104 = ((1 & (1 & (v9 >>> 16))) | (v102 << 1));
const v105 = ((((((((((v104) >>> 0) < ((v12) >>> 0)) | 0) & ((((v103) | 0) === ((v13) | 0)) | 0)) | ((((v103) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v106 = (-v105);
const v107 = (v106 & v12);
const v108 = ((v104 - v107) | 0);
const v109 = ((v108 >>> 31) | (((((v103 - (v106 & v13)) | 0) - ((((v104) >>> 0) < ((v107) >>> 0)) | 0)) | 0) << 1));
const v110 = ((1 & (1 & (v9 >>> 15))) | (v108 << 1));
const v111 = ((((((((((v110) >>> 0) < ((v12) >>> 0)) | 0) & ((((v109) | 0) === ((v13) | 0)) | 0)) | ((((v109) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v112 = (-v111);
const v113 = (v112 & v12);
const v114 = ((v110 - v113) | 0);
const v115 = ((v114 >>> 31) | (((((v109 - (v112 & v13)) | 0) - ((((v110) >>> 0) < ((v113) >>> 0)) | 0)) | 0) << 1));
const v116 = ((1 & (1 & (v9 >>> 14))) | (v114 << 1));
const v117 = ((((((((((v116) >>> 0) < ((v12) >>> 0)) | 0) & ((((v115) | 0) === ((v13) | 0)) | 0)) | ((((v115) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v118 = (-v117);
const v119 = (v118 & v12);
const v120 = ((v116 - v119) | 0);
const v121 = ((v120 >>> 31) | (((((v115 - (v118 & v13)) | 0) - ((((v116) >>> 0) < ((v119) >>> 0)) | 0)) | 0) << 1));
const v122 = ((1 & (1 & (v9 >>> 13))) | (v120 << 1));
const v123 = ((((((((((v122) >>> 0) < ((v12) >>> 0)) | 0) & ((((v121) | 0) === ((v13) | 0)) | 0)) | ((((v121) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v124 = (-v123);
const v125 = (v124 & v12);
const v126 = ((v122 - v125) | 0);
const v127 = ((v126 >>> 31) | (((((v121 - (v124 & v13)) | 0) - ((((v122) >>> 0) < ((v125) >>> 0)) | 0)) | 0) << 1));
const v128 = ((1 & (1 & (v9 >>> 12))) | (v126 << 1));
const v129 = ((((((((((v128) >>> 0) < ((v12) >>> 0)) | 0) & ((((v127) | 0) === ((v13) | 0)) | 0)) | ((((v127) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v130 = (-v129);
const v131 = (v130 & v12);
const v132 = ((v128 - v131) | 0);
const v133 = ((v132 >>> 31) | (((((v127 - (v130 & v13)) | 0) - ((((v128) >>> 0) < ((v131) >>> 0)) | 0)) | 0) << 1));
const v134 = ((1 & (1 & (v9 >>> 11))) | (v132 << 1));
const v135 = ((((((((((v134) >>> 0) < ((v12) >>> 0)) | 0) & ((((v133) | 0) === ((v13) | 0)) | 0)) | ((((v133) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v136 = (-v135);
const v137 = (v136 & v12);
const v138 = ((v134 - v137) | 0);
const v139 = ((v138 >>> 31) | (((((v133 - (v136 & v13)) | 0) - ((((v134) >>> 0) < ((v137) >>> 0)) | 0)) | 0) << 1));
const v140 = ((1 & (1 & (v9 >>> 10))) | (v138 << 1));
const v141 = ((((((((((v140) >>> 0) < ((v12) >>> 0)) | 0) & ((((v139) | 0) === ((v13) | 0)) | 0)) | ((((v139) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v142 = (-v141);
const v143 = (v142 & v12);
const v144 = ((v140 - v143) | 0);
const v145 = ((v144 >>> 31) | (((((v139 - (v142 & v13)) | 0) - ((((v140) >>> 0) < ((v143) >>> 0)) | 0)) | 0) << 1));
const v146 = ((1 & (1 & (v9 >>> 9))) | (v144 << 1));
const v147 = ((((((((((v146) >>> 0) < ((v12) >>> 0)) | 0) & ((((v145) | 0) === ((v13) | 0)) | 0)) | ((((v145) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v148 = (-v147);
const v149 = (v148 & v12);
const v150 = ((v146 - v149) | 0);
const v151 = ((v150 >>> 31) | (((((v145 - (v148 & v13)) | 0) - ((((v146) >>> 0) < ((v149) >>> 0)) | 0)) | 0) << 1));
const v152 = ((1 & (1 & (v9 >>> 8))) | (v150 << 1));
const v153 = ((((((((((v152) >>> 0) < ((v12) >>> 0)) | 0) & ((((v151) | 0) === ((v13) | 0)) | 0)) | ((((v151) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v154 = (-v153);
const v155 = (v154 & v12);
const v156 = ((v152 - v155) | 0);
const v157 = ((v156 >>> 31) | (((((v151 - (v154 & v13)) | 0) - ((((v152) >>> 0) < ((v155) >>> 0)) | 0)) | 0) << 1));
const v158 = ((1 & (1 & (v9 >>> 7))) | (v156 << 1));
const v159 = ((((((((((v158) >>> 0) < ((v12) >>> 0)) | 0) & ((((v157) | 0) === ((v13) | 0)) | 0)) | ((((v157) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v160 = (-v159);
const v161 = (v160 & v12);
const v162 = ((v158 - v161) | 0);
const v163 = ((v162 >>> 31) | (((((v157 - (v160 & v13)) | 0) - ((((v158) >>> 0) < ((v161) >>> 0)) | 0)) | 0) << 1));
const v164 = ((1 & (1 & (v9 >>> 6))) | (v162 << 1));
const v165 = ((((((((((v164) >>> 0) < ((v12) >>> 0)) | 0) & ((((v163) | 0) === ((v13) | 0)) | 0)) | ((((v163) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v166 = (-v165);
const v167 = (v166 & v12);
const v168 = ((v164 - v167) | 0);
const v169 = ((v168 >>> 31) | (((((v163 - (v166 & v13)) | 0) - ((((v164) >>> 0) < ((v167) >>> 0)) | 0)) | 0) << 1));
const v170 = ((1 & (1 & (v9 >>> 5))) | (v168 << 1));
const v171 = ((((((((((v170) >>> 0) < ((v12) >>> 0)) | 0) & ((((v169) | 0) === ((v13) | 0)) | 0)) | ((((v169) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v172 = (-v171);
const v173 = (v172 & v12);
const v174 = ((v170 - v173) | 0);
const v175 = ((v174 >>> 31) | (((((v169 - (v172 & v13)) | 0) - ((((v170) >>> 0) < ((v173) >>> 0)) | 0)) | 0) << 1));
const v176 = ((1 & (1 & (v9 >>> 4))) | (v174 << 1));
const v177 = ((((((((((v176) >>> 0) < ((v12) >>> 0)) | 0) & ((((v175) | 0) === ((v13) | 0)) | 0)) | ((((v175) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v178 = (-v177);
const v179 = (v178 & v12);
const v180 = ((v176 - v179) | 0);
const v181 = ((v180 >>> 31) | (((((v175 - (v178 & v13)) | 0) - ((((v176) >>> 0) < ((v179) >>> 0)) | 0)) | 0) << 1));
const v182 = ((1 & (1 & (v9 >>> 3))) | (v180 << 1));
const v183 = ((((((((((v182) >>> 0) < ((v12) >>> 0)) | 0) & ((((v181) | 0) === ((v13) | 0)) | 0)) | ((((v181) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v184 = (-v183);
const v185 = (v184 & v12);
const v186 = ((v182 - v185) | 0);
const v187 = ((v186 >>> 31) | (((((v181 - (v184 & v13)) | 0) - ((((v182) >>> 0) < ((v185) >>> 0)) | 0)) | 0) << 1));
const v188 = ((1 & (1 & (v9 >>> 2))) | (v186 << 1));
const v189 = ((((((((((v188) >>> 0) < ((v12) >>> 0)) | 0) & ((((v187) | 0) === ((v13) | 0)) | 0)) | ((((v187) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v190 = (-v189);
const v191 = (v190 & v12);
const v192 = ((v188 - v191) | 0);
const v193 = ((v192 >>> 31) | (((((v187 - (v190 & v13)) | 0) - ((((v188) >>> 0) < ((v191) >>> 0)) | 0)) | 0) << 1));
const v194 = ((1 & (1 & (v9 >>> 1))) | (v192 << 1));
const v195 = ((((((((((v194) >>> 0) < ((v12) >>> 0)) | 0) & ((((v193) | 0) === ((v13) | 0)) | 0)) | ((((v193) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v196 = (-v195);
const v197 = (v196 & v12);
const v198 = ((v194 - v197) | 0);
const v199 = ((v198 >>> 31) | (((((v193 - (v196 & v13)) | 0) - ((((v194) >>> 0) < ((v197) >>> 0)) | 0)) | 0) << 1));
const v200 = ((1 & (1 & (v9 >>> 0))) | (v198 << 1));
const v201 = ((((((((((v200) >>> 0) < ((v12) >>> 0)) | 0) & ((((v199) | 0) === ((v13) | 0)) | 0)) | ((((v199) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v202 = (-v201);
const v203 = (v202 & v12);
const v204 = ((v200 - v203) | 0);
const v205 = ((v204 >>> 31) | (((((v199 - (v202 & v13)) | 0) - ((((v200) >>> 0) < ((v203) >>> 0)) | 0)) | 0) << 1));
const v206 = ((1 & (1 & (v8 >>> 31))) | (v204 << 1));
const v207 = ((((((((((v206) >>> 0) < ((v12) >>> 0)) | 0) & ((((v205) | 0) === ((v13) | 0)) | 0)) | ((((v205) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v208 = (-v207);
const v209 = (v208 & v12);
const v210 = ((v206 - v209) | 0);
const v211 = ((v210 >>> 31) | (((((v205 - (v208 & v13)) | 0) - ((((v206) >>> 0) < ((v209) >>> 0)) | 0)) | 0) << 1));
const v212 = ((1 & (1 & (v8 >>> 30))) | (v210 << 1));
const v213 = ((((((((((v212) >>> 0) < ((v12) >>> 0)) | 0) & ((((v211) | 0) === ((v13) | 0)) | 0)) | ((((v211) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v214 = (-v213);
const v215 = (v214 & v12);
const v216 = ((v212 - v215) | 0);
const v217 = ((v216 >>> 31) | (((((v211 - (v214 & v13)) | 0) - ((((v212) >>> 0) < ((v215) >>> 0)) | 0)) | 0) << 1));
const v218 = ((1 & (1 & (v8 >>> 29))) | (v216 << 1));
const v219 = ((((((((((v218) >>> 0) < ((v12) >>> 0)) | 0) & ((((v217) | 0) === ((v13) | 0)) | 0)) | ((((v217) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v220 = (-v219);
const v221 = (v220 & v12);
const v222 = ((v218 - v221) | 0);
const v223 = ((v222 >>> 31) | (((((v217 - (v220 & v13)) | 0) - ((((v218) >>> 0) < ((v221) >>> 0)) | 0)) | 0) << 1));
const v224 = ((1 & (1 & (v8 >>> 28))) | (v222 << 1));
const v225 = ((((((((((v224) >>> 0) < ((v12) >>> 0)) | 0) & ((((v223) | 0) === ((v13) | 0)) | 0)) | ((((v223) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v226 = (-v225);
const v227 = (v226 & v12);
const v228 = ((v224 - v227) | 0);
const v229 = ((v228 >>> 31) | (((((v223 - (v226 & v13)) | 0) - ((((v224) >>> 0) < ((v227) >>> 0)) | 0)) | 0) << 1));
const v230 = ((1 & (1 & (v8 >>> 27))) | (v228 << 1));
const v231 = ((((((((((v230) >>> 0) < ((v12) >>> 0)) | 0) & ((((v229) | 0) === ((v13) | 0)) | 0)) | ((((v229) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v232 = (-v231);
const v233 = (v232 & v12);
const v234 = ((v230 - v233) | 0);
const v235 = ((v234 >>> 31) | (((((v229 - (v232 & v13)) | 0) - ((((v230) >>> 0) < ((v233) >>> 0)) | 0)) | 0) << 1));
const v236 = ((1 & (1 & (v8 >>> 26))) | (v234 << 1));
const v237 = ((((((((((v236) >>> 0) < ((v12) >>> 0)) | 0) & ((((v235) | 0) === ((v13) | 0)) | 0)) | ((((v235) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v238 = (-v237);
const v239 = (v238 & v12);
const v240 = ((v236 - v239) | 0);
const v241 = ((v240 >>> 31) | (((((v235 - (v238 & v13)) | 0) - ((((v236) >>> 0) < ((v239) >>> 0)) | 0)) | 0) << 1));
const v242 = ((1 & (1 & (v8 >>> 25))) | (v240 << 1));
const v243 = ((((((((((v242) >>> 0) < ((v12) >>> 0)) | 0) & ((((v241) | 0) === ((v13) | 0)) | 0)) | ((((v241) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v244 = (-v243);
const v245 = (v244 & v12);
const v246 = ((v242 - v245) | 0);
const v247 = ((v246 >>> 31) | (((((v241 - (v244 & v13)) | 0) - ((((v242) >>> 0) < ((v245) >>> 0)) | 0)) | 0) << 1));
const v248 = ((1 & (1 & (v8 >>> 24))) | (v246 << 1));
const v249 = ((((((((((v248) >>> 0) < ((v12) >>> 0)) | 0) & ((((v247) | 0) === ((v13) | 0)) | 0)) | ((((v247) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v250 = (-v249);
const v251 = (v250 & v12);
const v252 = ((v248 - v251) | 0);
const v253 = ((v252 >>> 31) | (((((v247 - (v250 & v13)) | 0) - ((((v248) >>> 0) < ((v251) >>> 0)) | 0)) | 0) << 1));
const v254 = ((1 & (1 & (v8 >>> 23))) | (v252 << 1));
const v255 = ((((((((((v254) >>> 0) < ((v12) >>> 0)) | 0) & ((((v253) | 0) === ((v13) | 0)) | 0)) | ((((v253) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v256 = (-v255);
const v257 = (v256 & v12);
const v258 = ((v254 - v257) | 0);
const v259 = ((v258 >>> 31) | (((((v253 - (v256 & v13)) | 0) - ((((v254) >>> 0) < ((v257) >>> 0)) | 0)) | 0) << 1));
const v260 = ((1 & (1 & (v8 >>> 22))) | (v258 << 1));
const v261 = ((((((((((v260) >>> 0) < ((v12) >>> 0)) | 0) & ((((v259) | 0) === ((v13) | 0)) | 0)) | ((((v259) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v262 = (-v261);
const v263 = (v262 & v12);
const v264 = ((v260 - v263) | 0);
const v265 = ((v264 >>> 31) | (((((v259 - (v262 & v13)) | 0) - ((((v260) >>> 0) < ((v263) >>> 0)) | 0)) | 0) << 1));
const v266 = ((1 & (1 & (v8 >>> 21))) | (v264 << 1));
const v267 = ((((((((((v266) >>> 0) < ((v12) >>> 0)) | 0) & ((((v265) | 0) === ((v13) | 0)) | 0)) | ((((v265) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v268 = (-v267);
const v269 = (v268 & v12);
const v270 = ((v266 - v269) | 0);
const v271 = ((v270 >>> 31) | (((((v265 - (v268 & v13)) | 0) - ((((v266) >>> 0) < ((v269) >>> 0)) | 0)) | 0) << 1));
const v272 = ((1 & (1 & (v8 >>> 20))) | (v270 << 1));
const v273 = ((((((((((v272) >>> 0) < ((v12) >>> 0)) | 0) & ((((v271) | 0) === ((v13) | 0)) | 0)) | ((((v271) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v274 = (-v273);
const v275 = (v274 & v12);
const v276 = ((v272 - v275) | 0);
const v277 = ((v276 >>> 31) | (((((v271 - (v274 & v13)) | 0) - ((((v272) >>> 0) < ((v275) >>> 0)) | 0)) | 0) << 1));
const v278 = ((1 & (1 & (v8 >>> 19))) | (v276 << 1));
const v279 = ((((((((((v278) >>> 0) < ((v12) >>> 0)) | 0) & ((((v277) | 0) === ((v13) | 0)) | 0)) | ((((v277) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v280 = (-v279);
const v281 = (v280 & v12);
const v282 = ((v278 - v281) | 0);
const v283 = ((v282 >>> 31) | (((((v277 - (v280 & v13)) | 0) - ((((v278) >>> 0) < ((v281) >>> 0)) | 0)) | 0) << 1));
const v284 = ((1 & (1 & (v8 >>> 18))) | (v282 << 1));
const v285 = ((((((((((v284) >>> 0) < ((v12) >>> 0)) | 0) & ((((v283) | 0) === ((v13) | 0)) | 0)) | ((((v283) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v286 = (-v285);
const v287 = (v286 & v12);
const v288 = ((v284 - v287) | 0);
const v289 = ((v288 >>> 31) | (((((v283 - (v286 & v13)) | 0) - ((((v284) >>> 0) < ((v287) >>> 0)) | 0)) | 0) << 1));
const v290 = ((1 & (1 & (v8 >>> 17))) | (v288 << 1));
const v291 = ((((((((((v290) >>> 0) < ((v12) >>> 0)) | 0) & ((((v289) | 0) === ((v13) | 0)) | 0)) | ((((v289) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v292 = (-v291);
const v293 = (v292 & v12);
const v294 = ((v290 - v293) | 0);
const v295 = ((v294 >>> 31) | (((((v289 - (v292 & v13)) | 0) - ((((v290) >>> 0) < ((v293) >>> 0)) | 0)) | 0) << 1));
const v296 = ((1 & (1 & (v8 >>> 16))) | (v294 << 1));
const v297 = ((((((((((v296) >>> 0) < ((v12) >>> 0)) | 0) & ((((v295) | 0) === ((v13) | 0)) | 0)) | ((((v295) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v298 = (-v297);
const v299 = (v298 & v12);
const v300 = ((v296 - v299) | 0);
const v301 = ((v300 >>> 31) | (((((v295 - (v298 & v13)) | 0) - ((((v296) >>> 0) < ((v299) >>> 0)) | 0)) | 0) << 1));
const v302 = ((1 & (1 & (v8 >>> 15))) | (v300 << 1));
const v303 = ((((((((((v302) >>> 0) < ((v12) >>> 0)) | 0) & ((((v301) | 0) === ((v13) | 0)) | 0)) | ((((v301) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v304 = (-v303);
const v305 = (v304 & v12);
const v306 = ((v302 - v305) | 0);
const v307 = ((v306 >>> 31) | (((((v301 - (v304 & v13)) | 0) - ((((v302) >>> 0) < ((v305) >>> 0)) | 0)) | 0) << 1));
const v308 = ((1 & (1 & (v8 >>> 14))) | (v306 << 1));
const v309 = ((((((((((v308) >>> 0) < ((v12) >>> 0)) | 0) & ((((v307) | 0) === ((v13) | 0)) | 0)) | ((((v307) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v310 = (-v309);
const v311 = (v310 & v12);
const v312 = ((v308 - v311) | 0);
const v313 = ((v312 >>> 31) | (((((v307 - (v310 & v13)) | 0) - ((((v308) >>> 0) < ((v311) >>> 0)) | 0)) | 0) << 1));
const v314 = ((1 & (1 & (v8 >>> 13))) | (v312 << 1));
const v315 = ((((((((((v314) >>> 0) < ((v12) >>> 0)) | 0) & ((((v313) | 0) === ((v13) | 0)) | 0)) | ((((v313) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v316 = (-v315);
const v317 = (v316 & v12);
const v318 = ((v314 - v317) | 0);
const v319 = ((v318 >>> 31) | (((((v313 - (v316 & v13)) | 0) - ((((v314) >>> 0) < ((v317) >>> 0)) | 0)) | 0) << 1));
const v320 = ((1 & (1 & (v8 >>> 12))) | (v318 << 1));
const v321 = ((((((((((v320) >>> 0) < ((v12) >>> 0)) | 0) & ((((v319) | 0) === ((v13) | 0)) | 0)) | ((((v319) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v322 = (-v321);
const v323 = (v322 & v12);
const v324 = ((v320 - v323) | 0);
const v325 = ((v324 >>> 31) | (((((v319 - (v322 & v13)) | 0) - ((((v320) >>> 0) < ((v323) >>> 0)) | 0)) | 0) << 1));
const v326 = ((1 & (1 & (v8 >>> 11))) | (v324 << 1));
const v327 = ((((((((((v326) >>> 0) < ((v12) >>> 0)) | 0) & ((((v325) | 0) === ((v13) | 0)) | 0)) | ((((v325) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v328 = (-v327);
const v329 = (v328 & v12);
const v330 = ((v326 - v329) | 0);
const v331 = ((v330 >>> 31) | (((((v325 - (v328 & v13)) | 0) - ((((v326) >>> 0) < ((v329) >>> 0)) | 0)) | 0) << 1));
const v332 = ((1 & (1 & (v8 >>> 10))) | (v330 << 1));
const v333 = ((((((((((v332) >>> 0) < ((v12) >>> 0)) | 0) & ((((v331) | 0) === ((v13) | 0)) | 0)) | ((((v331) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v334 = (-v333);
const v335 = (v334 & v12);
const v336 = ((v332 - v335) | 0);
const v337 = ((v336 >>> 31) | (((((v331 - (v334 & v13)) | 0) - ((((v332) >>> 0) < ((v335) >>> 0)) | 0)) | 0) << 1));
const v338 = ((1 & (1 & (v8 >>> 9))) | (v336 << 1));
const v339 = ((((((((((v338) >>> 0) < ((v12) >>> 0)) | 0) & ((((v337) | 0) === ((v13) | 0)) | 0)) | ((((v337) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v340 = (-v339);
const v341 = (v340 & v12);
const v342 = ((v338 - v341) | 0);
const v343 = ((v342 >>> 31) | (((((v337 - (v340 & v13)) | 0) - ((((v338) >>> 0) < ((v341) >>> 0)) | 0)) | 0) << 1));
const v344 = ((1 & (1 & (v8 >>> 8))) | (v342 << 1));
const v345 = ((((((((((v344) >>> 0) < ((v12) >>> 0)) | 0) & ((((v343) | 0) === ((v13) | 0)) | 0)) | ((((v343) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v346 = (-v345);
const v347 = (v346 & v12);
const v348 = ((v344 - v347) | 0);
const v349 = ((v348 >>> 31) | (((((v343 - (v346 & v13)) | 0) - ((((v344) >>> 0) < ((v347) >>> 0)) | 0)) | 0) << 1));
const v350 = ((1 & (1 & (v8 >>> 7))) | (v348 << 1));
const v351 = ((((((((((v350) >>> 0) < ((v12) >>> 0)) | 0) & ((((v349) | 0) === ((v13) | 0)) | 0)) | ((((v349) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v352 = (-v351);
const v353 = (v352 & v12);
const v354 = ((v350 - v353) | 0);
const v355 = ((v354 >>> 31) | (((((v349 - (v352 & v13)) | 0) - ((((v350) >>> 0) < ((v353) >>> 0)) | 0)) | 0) << 1));
const v356 = ((1 & (1 & (v8 >>> 6))) | (v354 << 1));
const v357 = ((((((((((v356) >>> 0) < ((v12) >>> 0)) | 0) & ((((v355) | 0) === ((v13) | 0)) | 0)) | ((((v355) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v358 = (-v357);
const v359 = (v358 & v12);
const v360 = ((v356 - v359) | 0);
const v361 = ((v360 >>> 31) | (((((v355 - (v358 & v13)) | 0) - ((((v356) >>> 0) < ((v359) >>> 0)) | 0)) | 0) << 1));
const v362 = ((1 & (1 & (v8 >>> 5))) | (v360 << 1));
const v363 = ((((((((((v362) >>> 0) < ((v12) >>> 0)) | 0) & ((((v361) | 0) === ((v13) | 0)) | 0)) | ((((v361) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v364 = (-v363);
const v365 = (v364 & v12);
const v366 = ((v362 - v365) | 0);
const v367 = ((v366 >>> 31) | (((((v361 - (v364 & v13)) | 0) - ((((v362) >>> 0) < ((v365) >>> 0)) | 0)) | 0) << 1));
const v368 = ((1 & (1 & (v8 >>> 4))) | (v366 << 1));
const v369 = ((((((((((v368) >>> 0) < ((v12) >>> 0)) | 0) & ((((v367) | 0) === ((v13) | 0)) | 0)) | ((((v367) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v370 = (-v369);
const v371 = (v370 & v12);
const v372 = ((v368 - v371) | 0);
const v373 = ((v372 >>> 31) | (((((v367 - (v370 & v13)) | 0) - ((((v368) >>> 0) < ((v371) >>> 0)) | 0)) | 0) << 1));
const v374 = ((1 & (1 & (v8 >>> 3))) | (v372 << 1));
const v375 = ((((((((((v374) >>> 0) < ((v12) >>> 0)) | 0) & ((((v373) | 0) === ((v13) | 0)) | 0)) | ((((v373) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v376 = (-v375);
const v377 = (v376 & v12);
const v378 = ((v374 - v377) | 0);
const v379 = ((v378 >>> 31) | (((((v373 - (v376 & v13)) | 0) - ((((v374) >>> 0) < ((v377) >>> 0)) | 0)) | 0) << 1));
const v380 = ((1 & (1 & (v8 >>> 2))) | (v378 << 1));
const v381 = ((((((((((v380) >>> 0) < ((v12) >>> 0)) | 0) & ((((v379) | 0) === ((v13) | 0)) | 0)) | ((((v379) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v382 = (-v381);
const v383 = (v382 & v12);
const v384 = ((v380 - v383) | 0);
const v385 = ((v384 >>> 31) | (((((v379 - (v382 & v13)) | 0) - ((((v380) >>> 0) < ((v383) >>> 0)) | 0)) | 0) << 1));
const v386 = ((1 & (1 & (v8 >>> 1))) | (v384 << 1));
const v387 = ((((((((((v386) >>> 0) < ((v12) >>> 0)) | 0) & ((((v385) | 0) === ((v13) | 0)) | 0)) | ((((v385) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0);
const v388 = (-v387);
const v389 = (v388 & v12);
const v390 = ((v386 - v389) | 0);
const v391 = ((v390 >>> 31) | (((((v385 - (v388 & v13)) | 0) - ((((v386) >>> 0) < ((v389) >>> 0)) | 0)) | 0) << 1));
const v392 = (-(v5 ^ v4));
const v393 = (v392 ^ ((((((((((((((1 & (1 & (v8 >>> 0))) | (v390 << 1))) >>> 0) < ((v12) >>> 0)) | 0) & ((((v391) | 0) === ((v13) | 0)) | 0)) | ((((v391) >>> 0) < ((v13) >>> 0)) | 0))) | 0) === 0) | 0) << 0) | ((v387 << 1) | ((v381 << 2) | ((v375 << 3) | ((v369 << 4) | ((v363 << 5) | ((v357 << 6) | ((v351 << 7) | ((v345 << 8) | ((v339 << 9) | ((v333 << 10) | ((v327 << 11) | ((v321 << 12) | ((v315 << 13) | ((v309 << 14) | ((v303 << 15) | ((v297 << 16) | ((v291 << 17) | ((v285 << 18) | ((v279 << 19) | ((v273 << 20) | ((v267 << 21) | ((v261 << 22) | ((v255 << 23) | ((v249 << 24) | ((v243 << 25) | ((v237 << 26) | ((v231 << 27) | ((v225 << 28) | ((v219 << 29) | ((v213 << 30) | (v207 << 31)))))))))))))))))))))))))))))))));
const v394 = (((1 & v392) + v393) | 0);
const v395 = (((((((v394) >>> 0) < ((v393) >>> 0)) | 0) + (v392 ^ ((v201 << 0) | ((v195 << 1) | ((v189 << 2) | ((v183 << 3) | ((v177 << 4) | ((v171 << 5) | ((v165 << 6) | ((v159 << 7) | ((v153 << 8) | ((v147 << 9) | ((v141 << 10) | ((v135 << 11) | ((v129 << 12) | ((v123 << 13) | ((v117 << 14) | ((v111 << 15) | ((v105 << 16) | ((v99 << 17) | ((v93 << 18) | ((v87 << 19) | ((v81 << 20) | ((v75 << 21) | ((v69 << 22) | ((v63 << 23) | ((v57 << 24) | ((v51 << 25) | ((v45 << 26) | ((v39 << 27) | ((v33 << 28) | ((v27 << 29) | ((v21 << 30) | (v15 << 31)))))))))))))))))))))))))))))))))) | 0) >> 0);
return {r0: v394, r1: v395};
}



function i64_eq(v0, v1, v2, v3) {
    
    const v4 = (((((v0) | 0) === ((v2) | 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0));
return v4;
}



function i64_eqz(v0, v1) {
    
    const v2 = (((((v0 | v1)) | 0) === ((0) | 0)) | 0);
return v2;
}



function i64_from_f32(v0) {
    
    const v1 = Math.trunc(v0);
const v2 = Math.floor((v1 / 4294967296));
const v3 = (Math.trunc((v1 - (4294967296 * v2))) >>> 0) | 0;
const v4 = ((Math.trunc(v2) | 0) >> 0);
return {r0: v3, r1: v4};
}



function i64_from_f64(v0) {
    
    const v1 = Math.trunc(v0);
const v2 = Math.floor((v1 / 4294967296));
const v3 = (Math.trunc((v1 - (4294967296 * v2))) >>> 0) | 0;
const v4 = ((Math.trunc(v2) | 0) >> 0);
return {r0: v3, r1: v4};
}



function i64_from_i16(v0) {
    
    const v1 = ((((v0 << 16) >> 16) << 16) >> 16);
const v2 = ((v1 >> 31) >> 0);
return {r0: v1, r1: v2};
}



function i64_from_i32(v0) {
    
    const v1 = ((v0 >> 31) >> 0);
return {r0: v0, r1: v1};
}



function i64_from_i8(v0) {
    
    const v1 = ((((v0 << 24) >> 24) << 24) >> 24);
const v2 = ((v1 >> 31) >> 0);
return {r0: v1, r1: v2};
}



function i64_from_u16(v0) {
    
    const v1 = (65535 & (65535 & v0));
return {r0: v1, r1: 0};
}



function i64_from_u32(v0) {
    
    return {r0: v0, r1: 0};
}



function i64_from_u64(v0, v1) {
    
    return {r0: v0, r1: v1};
}



function i64_from_u8(v0) {
    
    const v1 = (255 & (255 & v0));
return {r0: v1, r1: 0};
}



function i64_ge(v0, v1, v2, v3) {
    
    const v4 = ((((((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) | 0) < ((v3) | 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function i64_gt(v0, v1, v2, v3) {
    
    const v4 = ((((((v2) >>> 0) < ((v0) >>> 0)) | 0) & ((((v3) | 0) === ((v1) | 0)) | 0)) | ((((v3) | 0) < ((v1) | 0)) | 0));
return v4;
}



function i64_le(v0, v1, v2, v3) {
    
    const v4 = ((((((((((v2) >>> 0) < ((v0) >>> 0)) | 0) & ((((v3) | 0) === ((v1) | 0)) | 0)) | ((((v3) | 0) < ((v1) | 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function i64_lt(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) | 0) < ((v3) | 0)) | 0));
return v4;
}



function i64_max(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) | 0) < ((v3) | 0)) | 0));
const v5 = ((v4) ? (v2) : (v0));
const v6 = (((v4) ? (v3) : (v1)) >> 0);
return {r0: v5, r1: v6};
}



function i64_min(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) | 0) < ((v3) | 0)) | 0));
const v5 = ((v4) ? (v0) : (v2));
const v6 = (((v4) ? (v1) : (v3)) >> 0);
return {r0: v5, r1: v6};
}



function i64_mul(v0, v1, v2, v3) {
    
    const v4 = Math.imul(v2, v0);
const v5 = (65535 & v0);
const v6 = (v0 >>> 16);
const v7 = (65535 & v2);
const v8 = (v2 >>> 16);
const v9 = Math.imul(v7, v5);
const v10 = Math.imul(v7, v6);
const v11 = Math.imul(v8, v5);
const v12 = ((v11 + v10) | 0);
const v13 = (v12 << 16);
const v14 = (((((Math.imul(v2, v1) + Math.imul(v3, v0)) | 0) + ((((((((((-1 ^ ((v13 + v9) | 0)) & (v13 | v9)) | (v13 & v9)) >>> 31) + (((((-1 ^ v12) & (v11 | v10)) | (v11 & v10)) >>> 31) << 16)) | 0) + (v12 >>> 16)) | 0) + Math.imul(v8, v6)) | 0)) | 0) >> 0);
return {r0: v4, r1: v14};
}



function i64_ne(v0, v1, v2, v3) {
    
    const v4 = (((((((((v0) | 0) === ((v2) | 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function i64_neg(v0, v1) {
    
    const v2 = ((1 + (-1 ^ v0)) | 0);
const v3 = (((((((v0) | 0) === 0) | 0) + (-1 ^ v1)) | 0) >> 0);
return {r0: v2, r1: v3};
}



function i64_not(v0, v1) {
    
    const v2 = (~v0);
const v3 = ((~v1) >> 0);
return {r0: v2, r1: v3};
}



function i64_or(v0, v1, v2, v3) {
    
    const v4 = (v2 | v0);
const v5 = ((v3 | v1) >> 0);
return {r0: v4, r1: v5};
}



function i64_popcnt(v0, v1) {
    
    const v2 = (((()=>{let x=((v1)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})() + (()=>{let x=((v0)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})()) | 0);
return {r0: v2, r1: 0};
}



function i64_rem(v0, v1, v2, v3) {
    
    const v4 = (-((((v1) | 0) < ((0) | 0)) | 0));
const v5 = (v4 ^ v0);
const v6 = (((1 & v4) + v5) | 0);
const v7 = ((((((v6) >>> 0) < ((v5) >>> 0)) | 0) + (v4 ^ v1)) | 0);
const v8 = (-((((v3) | 0) < ((0) | 0)) | 0));
const v9 = (v8 ^ v2);
const v10 = (((1 & v8) + v9) | 0);
const v11 = ((((((v10) >>> 0) < ((v9) >>> 0)) | 0) + (v8 ^ v3)) | 0);
const v12 = (1 & (1 & (v7 >>> 31)));
const v13 = (-((((((((((v12) >>> 0) < ((v10) >>> 0)) | 0) & ((((0) | 0) === ((v11) | 0)) | 0)) | ((((0) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v14 = (v13 & v10);
const v15 = ((v12 - v14) | 0);
const v16 = ((v15 >>> 31) | (((((0 - (v13 & v11)) | 0) - ((((v12) >>> 0) < ((v14) >>> 0)) | 0)) | 0) << 1));
const v17 = ((1 & (1 & (v7 >>> 30))) | (v15 << 1));
const v18 = (-((((((((((v17) >>> 0) < ((v10) >>> 0)) | 0) & ((((v16) | 0) === ((v11) | 0)) | 0)) | ((((v16) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v19 = (v18 & v10);
const v20 = ((v17 - v19) | 0);
const v21 = ((v20 >>> 31) | (((((v16 - (v18 & v11)) | 0) - ((((v17) >>> 0) < ((v19) >>> 0)) | 0)) | 0) << 1));
const v22 = ((1 & (1 & (v7 >>> 29))) | (v20 << 1));
const v23 = (-((((((((((v22) >>> 0) < ((v10) >>> 0)) | 0) & ((((v21) | 0) === ((v11) | 0)) | 0)) | ((((v21) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v24 = (v23 & v10);
const v25 = ((v22 - v24) | 0);
const v26 = ((v25 >>> 31) | (((((v21 - (v23 & v11)) | 0) - ((((v22) >>> 0) < ((v24) >>> 0)) | 0)) | 0) << 1));
const v27 = ((1 & (1 & (v7 >>> 28))) | (v25 << 1));
const v28 = (-((((((((((v27) >>> 0) < ((v10) >>> 0)) | 0) & ((((v26) | 0) === ((v11) | 0)) | 0)) | ((((v26) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v29 = (v28 & v10);
const v30 = ((v27 - v29) | 0);
const v31 = ((v30 >>> 31) | (((((v26 - (v28 & v11)) | 0) - ((((v27) >>> 0) < ((v29) >>> 0)) | 0)) | 0) << 1));
const v32 = ((1 & (1 & (v7 >>> 27))) | (v30 << 1));
const v33 = (-((((((((((v32) >>> 0) < ((v10) >>> 0)) | 0) & ((((v31) | 0) === ((v11) | 0)) | 0)) | ((((v31) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v34 = (v33 & v10);
const v35 = ((v32 - v34) | 0);
const v36 = ((v35 >>> 31) | (((((v31 - (v33 & v11)) | 0) - ((((v32) >>> 0) < ((v34) >>> 0)) | 0)) | 0) << 1));
const v37 = ((1 & (1 & (v7 >>> 26))) | (v35 << 1));
const v38 = (-((((((((((v37) >>> 0) < ((v10) >>> 0)) | 0) & ((((v36) | 0) === ((v11) | 0)) | 0)) | ((((v36) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v39 = (v38 & v10);
const v40 = ((v37 - v39) | 0);
const v41 = ((v40 >>> 31) | (((((v36 - (v38 & v11)) | 0) - ((((v37) >>> 0) < ((v39) >>> 0)) | 0)) | 0) << 1));
const v42 = ((1 & (1 & (v7 >>> 25))) | (v40 << 1));
const v43 = (-((((((((((v42) >>> 0) < ((v10) >>> 0)) | 0) & ((((v41) | 0) === ((v11) | 0)) | 0)) | ((((v41) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v44 = (v43 & v10);
const v45 = ((v42 - v44) | 0);
const v46 = ((v45 >>> 31) | (((((v41 - (v43 & v11)) | 0) - ((((v42) >>> 0) < ((v44) >>> 0)) | 0)) | 0) << 1));
const v47 = ((1 & (1 & (v7 >>> 24))) | (v45 << 1));
const v48 = (-((((((((((v47) >>> 0) < ((v10) >>> 0)) | 0) & ((((v46) | 0) === ((v11) | 0)) | 0)) | ((((v46) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v49 = (v48 & v10);
const v50 = ((v47 - v49) | 0);
const v51 = ((v50 >>> 31) | (((((v46 - (v48 & v11)) | 0) - ((((v47) >>> 0) < ((v49) >>> 0)) | 0)) | 0) << 1));
const v52 = ((1 & (1 & (v7 >>> 23))) | (v50 << 1));
const v53 = (-((((((((((v52) >>> 0) < ((v10) >>> 0)) | 0) & ((((v51) | 0) === ((v11) | 0)) | 0)) | ((((v51) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v54 = (v53 & v10);
const v55 = ((v52 - v54) | 0);
const v56 = ((v55 >>> 31) | (((((v51 - (v53 & v11)) | 0) - ((((v52) >>> 0) < ((v54) >>> 0)) | 0)) | 0) << 1));
const v57 = ((1 & (1 & (v7 >>> 22))) | (v55 << 1));
const v58 = (-((((((((((v57) >>> 0) < ((v10) >>> 0)) | 0) & ((((v56) | 0) === ((v11) | 0)) | 0)) | ((((v56) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v59 = (v58 & v10);
const v60 = ((v57 - v59) | 0);
const v61 = ((v60 >>> 31) | (((((v56 - (v58 & v11)) | 0) - ((((v57) >>> 0) < ((v59) >>> 0)) | 0)) | 0) << 1));
const v62 = ((1 & (1 & (v7 >>> 21))) | (v60 << 1));
const v63 = (-((((((((((v62) >>> 0) < ((v10) >>> 0)) | 0) & ((((v61) | 0) === ((v11) | 0)) | 0)) | ((((v61) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v64 = (v63 & v10);
const v65 = ((v62 - v64) | 0);
const v66 = ((v65 >>> 31) | (((((v61 - (v63 & v11)) | 0) - ((((v62) >>> 0) < ((v64) >>> 0)) | 0)) | 0) << 1));
const v67 = ((1 & (1 & (v7 >>> 20))) | (v65 << 1));
const v68 = (-((((((((((v67) >>> 0) < ((v10) >>> 0)) | 0) & ((((v66) | 0) === ((v11) | 0)) | 0)) | ((((v66) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v69 = (v68 & v10);
const v70 = ((v67 - v69) | 0);
const v71 = ((v70 >>> 31) | (((((v66 - (v68 & v11)) | 0) - ((((v67) >>> 0) < ((v69) >>> 0)) | 0)) | 0) << 1));
const v72 = ((1 & (1 & (v7 >>> 19))) | (v70 << 1));
const v73 = (-((((((((((v72) >>> 0) < ((v10) >>> 0)) | 0) & ((((v71) | 0) === ((v11) | 0)) | 0)) | ((((v71) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v74 = (v73 & v10);
const v75 = ((v72 - v74) | 0);
const v76 = ((v75 >>> 31) | (((((v71 - (v73 & v11)) | 0) - ((((v72) >>> 0) < ((v74) >>> 0)) | 0)) | 0) << 1));
const v77 = ((1 & (1 & (v7 >>> 18))) | (v75 << 1));
const v78 = (-((((((((((v77) >>> 0) < ((v10) >>> 0)) | 0) & ((((v76) | 0) === ((v11) | 0)) | 0)) | ((((v76) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v79 = (v78 & v10);
const v80 = ((v77 - v79) | 0);
const v81 = ((v80 >>> 31) | (((((v76 - (v78 & v11)) | 0) - ((((v77) >>> 0) < ((v79) >>> 0)) | 0)) | 0) << 1));
const v82 = ((1 & (1 & (v7 >>> 17))) | (v80 << 1));
const v83 = (-((((((((((v82) >>> 0) < ((v10) >>> 0)) | 0) & ((((v81) | 0) === ((v11) | 0)) | 0)) | ((((v81) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v84 = (v83 & v10);
const v85 = ((v82 - v84) | 0);
const v86 = ((v85 >>> 31) | (((((v81 - (v83 & v11)) | 0) - ((((v82) >>> 0) < ((v84) >>> 0)) | 0)) | 0) << 1));
const v87 = ((1 & (1 & (v7 >>> 16))) | (v85 << 1));
const v88 = (-((((((((((v87) >>> 0) < ((v10) >>> 0)) | 0) & ((((v86) | 0) === ((v11) | 0)) | 0)) | ((((v86) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v89 = (v88 & v10);
const v90 = ((v87 - v89) | 0);
const v91 = ((v90 >>> 31) | (((((v86 - (v88 & v11)) | 0) - ((((v87) >>> 0) < ((v89) >>> 0)) | 0)) | 0) << 1));
const v92 = ((1 & (1 & (v7 >>> 15))) | (v90 << 1));
const v93 = (-((((((((((v92) >>> 0) < ((v10) >>> 0)) | 0) & ((((v91) | 0) === ((v11) | 0)) | 0)) | ((((v91) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v94 = (v93 & v10);
const v95 = ((v92 - v94) | 0);
const v96 = ((v95 >>> 31) | (((((v91 - (v93 & v11)) | 0) - ((((v92) >>> 0) < ((v94) >>> 0)) | 0)) | 0) << 1));
const v97 = ((1 & (1 & (v7 >>> 14))) | (v95 << 1));
const v98 = (-((((((((((v97) >>> 0) < ((v10) >>> 0)) | 0) & ((((v96) | 0) === ((v11) | 0)) | 0)) | ((((v96) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v99 = (v98 & v10);
const v100 = ((v97 - v99) | 0);
const v101 = ((v100 >>> 31) | (((((v96 - (v98 & v11)) | 0) - ((((v97) >>> 0) < ((v99) >>> 0)) | 0)) | 0) << 1));
const v102 = ((1 & (1 & (v7 >>> 13))) | (v100 << 1));
const v103 = (-((((((((((v102) >>> 0) < ((v10) >>> 0)) | 0) & ((((v101) | 0) === ((v11) | 0)) | 0)) | ((((v101) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v104 = (v103 & v10);
const v105 = ((v102 - v104) | 0);
const v106 = ((v105 >>> 31) | (((((v101 - (v103 & v11)) | 0) - ((((v102) >>> 0) < ((v104) >>> 0)) | 0)) | 0) << 1));
const v107 = ((1 & (1 & (v7 >>> 12))) | (v105 << 1));
const v108 = (-((((((((((v107) >>> 0) < ((v10) >>> 0)) | 0) & ((((v106) | 0) === ((v11) | 0)) | 0)) | ((((v106) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v109 = (v108 & v10);
const v110 = ((v107 - v109) | 0);
const v111 = ((v110 >>> 31) | (((((v106 - (v108 & v11)) | 0) - ((((v107) >>> 0) < ((v109) >>> 0)) | 0)) | 0) << 1));
const v112 = ((1 & (1 & (v7 >>> 11))) | (v110 << 1));
const v113 = (-((((((((((v112) >>> 0) < ((v10) >>> 0)) | 0) & ((((v111) | 0) === ((v11) | 0)) | 0)) | ((((v111) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v114 = (v113 & v10);
const v115 = ((v112 - v114) | 0);
const v116 = ((v115 >>> 31) | (((((v111 - (v113 & v11)) | 0) - ((((v112) >>> 0) < ((v114) >>> 0)) | 0)) | 0) << 1));
const v117 = ((1 & (1 & (v7 >>> 10))) | (v115 << 1));
const v118 = (-((((((((((v117) >>> 0) < ((v10) >>> 0)) | 0) & ((((v116) | 0) === ((v11) | 0)) | 0)) | ((((v116) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v119 = (v118 & v10);
const v120 = ((v117 - v119) | 0);
const v121 = ((v120 >>> 31) | (((((v116 - (v118 & v11)) | 0) - ((((v117) >>> 0) < ((v119) >>> 0)) | 0)) | 0) << 1));
const v122 = ((1 & (1 & (v7 >>> 9))) | (v120 << 1));
const v123 = (-((((((((((v122) >>> 0) < ((v10) >>> 0)) | 0) & ((((v121) | 0) === ((v11) | 0)) | 0)) | ((((v121) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v124 = (v123 & v10);
const v125 = ((v122 - v124) | 0);
const v126 = ((v125 >>> 31) | (((((v121 - (v123 & v11)) | 0) - ((((v122) >>> 0) < ((v124) >>> 0)) | 0)) | 0) << 1));
const v127 = ((1 & (1 & (v7 >>> 8))) | (v125 << 1));
const v128 = (-((((((((((v127) >>> 0) < ((v10) >>> 0)) | 0) & ((((v126) | 0) === ((v11) | 0)) | 0)) | ((((v126) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v129 = (v128 & v10);
const v130 = ((v127 - v129) | 0);
const v131 = ((v130 >>> 31) | (((((v126 - (v128 & v11)) | 0) - ((((v127) >>> 0) < ((v129) >>> 0)) | 0)) | 0) << 1));
const v132 = ((1 & (1 & (v7 >>> 7))) | (v130 << 1));
const v133 = (-((((((((((v132) >>> 0) < ((v10) >>> 0)) | 0) & ((((v131) | 0) === ((v11) | 0)) | 0)) | ((((v131) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v134 = (v133 & v10);
const v135 = ((v132 - v134) | 0);
const v136 = ((v135 >>> 31) | (((((v131 - (v133 & v11)) | 0) - ((((v132) >>> 0) < ((v134) >>> 0)) | 0)) | 0) << 1));
const v137 = ((1 & (1 & (v7 >>> 6))) | (v135 << 1));
const v138 = (-((((((((((v137) >>> 0) < ((v10) >>> 0)) | 0) & ((((v136) | 0) === ((v11) | 0)) | 0)) | ((((v136) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v139 = (v138 & v10);
const v140 = ((v137 - v139) | 0);
const v141 = ((v140 >>> 31) | (((((v136 - (v138 & v11)) | 0) - ((((v137) >>> 0) < ((v139) >>> 0)) | 0)) | 0) << 1));
const v142 = ((1 & (1 & (v7 >>> 5))) | (v140 << 1));
const v143 = (-((((((((((v142) >>> 0) < ((v10) >>> 0)) | 0) & ((((v141) | 0) === ((v11) | 0)) | 0)) | ((((v141) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v144 = (v143 & v10);
const v145 = ((v142 - v144) | 0);
const v146 = ((v145 >>> 31) | (((((v141 - (v143 & v11)) | 0) - ((((v142) >>> 0) < ((v144) >>> 0)) | 0)) | 0) << 1));
const v147 = ((1 & (1 & (v7 >>> 4))) | (v145 << 1));
const v148 = (-((((((((((v147) >>> 0) < ((v10) >>> 0)) | 0) & ((((v146) | 0) === ((v11) | 0)) | 0)) | ((((v146) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v149 = (v148 & v10);
const v150 = ((v147 - v149) | 0);
const v151 = ((v150 >>> 31) | (((((v146 - (v148 & v11)) | 0) - ((((v147) >>> 0) < ((v149) >>> 0)) | 0)) | 0) << 1));
const v152 = ((1 & (1 & (v7 >>> 3))) | (v150 << 1));
const v153 = (-((((((((((v152) >>> 0) < ((v10) >>> 0)) | 0) & ((((v151) | 0) === ((v11) | 0)) | 0)) | ((((v151) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v154 = (v153 & v10);
const v155 = ((v152 - v154) | 0);
const v156 = ((v155 >>> 31) | (((((v151 - (v153 & v11)) | 0) - ((((v152) >>> 0) < ((v154) >>> 0)) | 0)) | 0) << 1));
const v157 = ((1 & (1 & (v7 >>> 2))) | (v155 << 1));
const v158 = (-((((((((((v157) >>> 0) < ((v10) >>> 0)) | 0) & ((((v156) | 0) === ((v11) | 0)) | 0)) | ((((v156) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v159 = (v158 & v10);
const v160 = ((v157 - v159) | 0);
const v161 = ((v160 >>> 31) | (((((v156 - (v158 & v11)) | 0) - ((((v157) >>> 0) < ((v159) >>> 0)) | 0)) | 0) << 1));
const v162 = ((1 & (1 & (v7 >>> 1))) | (v160 << 1));
const v163 = (-((((((((((v162) >>> 0) < ((v10) >>> 0)) | 0) & ((((v161) | 0) === ((v11) | 0)) | 0)) | ((((v161) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v164 = (v163 & v10);
const v165 = ((v162 - v164) | 0);
const v166 = ((v165 >>> 31) | (((((v161 - (v163 & v11)) | 0) - ((((v162) >>> 0) < ((v164) >>> 0)) | 0)) | 0) << 1));
const v167 = ((1 & (1 & (v7 >>> 0))) | (v165 << 1));
const v168 = (-((((((((((v167) >>> 0) < ((v10) >>> 0)) | 0) & ((((v166) | 0) === ((v11) | 0)) | 0)) | ((((v166) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v169 = (v168 & v10);
const v170 = ((v167 - v169) | 0);
const v171 = ((v170 >>> 31) | (((((v166 - (v168 & v11)) | 0) - ((((v167) >>> 0) < ((v169) >>> 0)) | 0)) | 0) << 1));
const v172 = ((1 & (1 & (v6 >>> 31))) | (v170 << 1));
const v173 = (-((((((((((v172) >>> 0) < ((v10) >>> 0)) | 0) & ((((v171) | 0) === ((v11) | 0)) | 0)) | ((((v171) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v174 = (v173 & v10);
const v175 = ((v172 - v174) | 0);
const v176 = ((v175 >>> 31) | (((((v171 - (v173 & v11)) | 0) - ((((v172) >>> 0) < ((v174) >>> 0)) | 0)) | 0) << 1));
const v177 = ((1 & (1 & (v6 >>> 30))) | (v175 << 1));
const v178 = (-((((((((((v177) >>> 0) < ((v10) >>> 0)) | 0) & ((((v176) | 0) === ((v11) | 0)) | 0)) | ((((v176) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v179 = (v178 & v10);
const v180 = ((v177 - v179) | 0);
const v181 = ((v180 >>> 31) | (((((v176 - (v178 & v11)) | 0) - ((((v177) >>> 0) < ((v179) >>> 0)) | 0)) | 0) << 1));
const v182 = ((1 & (1 & (v6 >>> 29))) | (v180 << 1));
const v183 = (-((((((((((v182) >>> 0) < ((v10) >>> 0)) | 0) & ((((v181) | 0) === ((v11) | 0)) | 0)) | ((((v181) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v184 = (v183 & v10);
const v185 = ((v182 - v184) | 0);
const v186 = ((v185 >>> 31) | (((((v181 - (v183 & v11)) | 0) - ((((v182) >>> 0) < ((v184) >>> 0)) | 0)) | 0) << 1));
const v187 = ((1 & (1 & (v6 >>> 28))) | (v185 << 1));
const v188 = (-((((((((((v187) >>> 0) < ((v10) >>> 0)) | 0) & ((((v186) | 0) === ((v11) | 0)) | 0)) | ((((v186) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v189 = (v188 & v10);
const v190 = ((v187 - v189) | 0);
const v191 = ((v190 >>> 31) | (((((v186 - (v188 & v11)) | 0) - ((((v187) >>> 0) < ((v189) >>> 0)) | 0)) | 0) << 1));
const v192 = ((1 & (1 & (v6 >>> 27))) | (v190 << 1));
const v193 = (-((((((((((v192) >>> 0) < ((v10) >>> 0)) | 0) & ((((v191) | 0) === ((v11) | 0)) | 0)) | ((((v191) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v194 = (v193 & v10);
const v195 = ((v192 - v194) | 0);
const v196 = ((v195 >>> 31) | (((((v191 - (v193 & v11)) | 0) - ((((v192) >>> 0) < ((v194) >>> 0)) | 0)) | 0) << 1));
const v197 = ((1 & (1 & (v6 >>> 26))) | (v195 << 1));
const v198 = (-((((((((((v197) >>> 0) < ((v10) >>> 0)) | 0) & ((((v196) | 0) === ((v11) | 0)) | 0)) | ((((v196) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v199 = (v198 & v10);
const v200 = ((v197 - v199) | 0);
const v201 = ((v200 >>> 31) | (((((v196 - (v198 & v11)) | 0) - ((((v197) >>> 0) < ((v199) >>> 0)) | 0)) | 0) << 1));
const v202 = ((1 & (1 & (v6 >>> 25))) | (v200 << 1));
const v203 = (-((((((((((v202) >>> 0) < ((v10) >>> 0)) | 0) & ((((v201) | 0) === ((v11) | 0)) | 0)) | ((((v201) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v204 = (v203 & v10);
const v205 = ((v202 - v204) | 0);
const v206 = ((v205 >>> 31) | (((((v201 - (v203 & v11)) | 0) - ((((v202) >>> 0) < ((v204) >>> 0)) | 0)) | 0) << 1));
const v207 = ((1 & (1 & (v6 >>> 24))) | (v205 << 1));
const v208 = (-((((((((((v207) >>> 0) < ((v10) >>> 0)) | 0) & ((((v206) | 0) === ((v11) | 0)) | 0)) | ((((v206) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v209 = (v208 & v10);
const v210 = ((v207 - v209) | 0);
const v211 = ((v210 >>> 31) | (((((v206 - (v208 & v11)) | 0) - ((((v207) >>> 0) < ((v209) >>> 0)) | 0)) | 0) << 1));
const v212 = ((1 & (1 & (v6 >>> 23))) | (v210 << 1));
const v213 = (-((((((((((v212) >>> 0) < ((v10) >>> 0)) | 0) & ((((v211) | 0) === ((v11) | 0)) | 0)) | ((((v211) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v214 = (v213 & v10);
const v215 = ((v212 - v214) | 0);
const v216 = ((v215 >>> 31) | (((((v211 - (v213 & v11)) | 0) - ((((v212) >>> 0) < ((v214) >>> 0)) | 0)) | 0) << 1));
const v217 = ((1 & (1 & (v6 >>> 22))) | (v215 << 1));
const v218 = (-((((((((((v217) >>> 0) < ((v10) >>> 0)) | 0) & ((((v216) | 0) === ((v11) | 0)) | 0)) | ((((v216) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v219 = (v218 & v10);
const v220 = ((v217 - v219) | 0);
const v221 = ((v220 >>> 31) | (((((v216 - (v218 & v11)) | 0) - ((((v217) >>> 0) < ((v219) >>> 0)) | 0)) | 0) << 1));
const v222 = ((1 & (1 & (v6 >>> 21))) | (v220 << 1));
const v223 = (-((((((((((v222) >>> 0) < ((v10) >>> 0)) | 0) & ((((v221) | 0) === ((v11) | 0)) | 0)) | ((((v221) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v224 = (v223 & v10);
const v225 = ((v222 - v224) | 0);
const v226 = ((v225 >>> 31) | (((((v221 - (v223 & v11)) | 0) - ((((v222) >>> 0) < ((v224) >>> 0)) | 0)) | 0) << 1));
const v227 = ((1 & (1 & (v6 >>> 20))) | (v225 << 1));
const v228 = (-((((((((((v227) >>> 0) < ((v10) >>> 0)) | 0) & ((((v226) | 0) === ((v11) | 0)) | 0)) | ((((v226) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v229 = (v228 & v10);
const v230 = ((v227 - v229) | 0);
const v231 = ((v230 >>> 31) | (((((v226 - (v228 & v11)) | 0) - ((((v227) >>> 0) < ((v229) >>> 0)) | 0)) | 0) << 1));
const v232 = ((1 & (1 & (v6 >>> 19))) | (v230 << 1));
const v233 = (-((((((((((v232) >>> 0) < ((v10) >>> 0)) | 0) & ((((v231) | 0) === ((v11) | 0)) | 0)) | ((((v231) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v234 = (v233 & v10);
const v235 = ((v232 - v234) | 0);
const v236 = ((v235 >>> 31) | (((((v231 - (v233 & v11)) | 0) - ((((v232) >>> 0) < ((v234) >>> 0)) | 0)) | 0) << 1));
const v237 = ((1 & (1 & (v6 >>> 18))) | (v235 << 1));
const v238 = (-((((((((((v237) >>> 0) < ((v10) >>> 0)) | 0) & ((((v236) | 0) === ((v11) | 0)) | 0)) | ((((v236) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v239 = (v238 & v10);
const v240 = ((v237 - v239) | 0);
const v241 = ((v240 >>> 31) | (((((v236 - (v238 & v11)) | 0) - ((((v237) >>> 0) < ((v239) >>> 0)) | 0)) | 0) << 1));
const v242 = ((1 & (1 & (v6 >>> 17))) | (v240 << 1));
const v243 = (-((((((((((v242) >>> 0) < ((v10) >>> 0)) | 0) & ((((v241) | 0) === ((v11) | 0)) | 0)) | ((((v241) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v244 = (v243 & v10);
const v245 = ((v242 - v244) | 0);
const v246 = ((v245 >>> 31) | (((((v241 - (v243 & v11)) | 0) - ((((v242) >>> 0) < ((v244) >>> 0)) | 0)) | 0) << 1));
const v247 = ((1 & (1 & (v6 >>> 16))) | (v245 << 1));
const v248 = (-((((((((((v247) >>> 0) < ((v10) >>> 0)) | 0) & ((((v246) | 0) === ((v11) | 0)) | 0)) | ((((v246) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v249 = (v248 & v10);
const v250 = ((v247 - v249) | 0);
const v251 = ((v250 >>> 31) | (((((v246 - (v248 & v11)) | 0) - ((((v247) >>> 0) < ((v249) >>> 0)) | 0)) | 0) << 1));
const v252 = ((1 & (1 & (v6 >>> 15))) | (v250 << 1));
const v253 = (-((((((((((v252) >>> 0) < ((v10) >>> 0)) | 0) & ((((v251) | 0) === ((v11) | 0)) | 0)) | ((((v251) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v254 = (v253 & v10);
const v255 = ((v252 - v254) | 0);
const v256 = ((v255 >>> 31) | (((((v251 - (v253 & v11)) | 0) - ((((v252) >>> 0) < ((v254) >>> 0)) | 0)) | 0) << 1));
const v257 = ((1 & (1 & (v6 >>> 14))) | (v255 << 1));
const v258 = (-((((((((((v257) >>> 0) < ((v10) >>> 0)) | 0) & ((((v256) | 0) === ((v11) | 0)) | 0)) | ((((v256) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v259 = (v258 & v10);
const v260 = ((v257 - v259) | 0);
const v261 = ((v260 >>> 31) | (((((v256 - (v258 & v11)) | 0) - ((((v257) >>> 0) < ((v259) >>> 0)) | 0)) | 0) << 1));
const v262 = ((1 & (1 & (v6 >>> 13))) | (v260 << 1));
const v263 = (-((((((((((v262) >>> 0) < ((v10) >>> 0)) | 0) & ((((v261) | 0) === ((v11) | 0)) | 0)) | ((((v261) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v264 = (v263 & v10);
const v265 = ((v262 - v264) | 0);
const v266 = ((v265 >>> 31) | (((((v261 - (v263 & v11)) | 0) - ((((v262) >>> 0) < ((v264) >>> 0)) | 0)) | 0) << 1));
const v267 = ((1 & (1 & (v6 >>> 12))) | (v265 << 1));
const v268 = (-((((((((((v267) >>> 0) < ((v10) >>> 0)) | 0) & ((((v266) | 0) === ((v11) | 0)) | 0)) | ((((v266) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v269 = (v268 & v10);
const v270 = ((v267 - v269) | 0);
const v271 = ((v270 >>> 31) | (((((v266 - (v268 & v11)) | 0) - ((((v267) >>> 0) < ((v269) >>> 0)) | 0)) | 0) << 1));
const v272 = ((1 & (1 & (v6 >>> 11))) | (v270 << 1));
const v273 = (-((((((((((v272) >>> 0) < ((v10) >>> 0)) | 0) & ((((v271) | 0) === ((v11) | 0)) | 0)) | ((((v271) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v274 = (v273 & v10);
const v275 = ((v272 - v274) | 0);
const v276 = ((v275 >>> 31) | (((((v271 - (v273 & v11)) | 0) - ((((v272) >>> 0) < ((v274) >>> 0)) | 0)) | 0) << 1));
const v277 = ((1 & (1 & (v6 >>> 10))) | (v275 << 1));
const v278 = (-((((((((((v277) >>> 0) < ((v10) >>> 0)) | 0) & ((((v276) | 0) === ((v11) | 0)) | 0)) | ((((v276) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v279 = (v278 & v10);
const v280 = ((v277 - v279) | 0);
const v281 = ((v280 >>> 31) | (((((v276 - (v278 & v11)) | 0) - ((((v277) >>> 0) < ((v279) >>> 0)) | 0)) | 0) << 1));
const v282 = ((1 & (1 & (v6 >>> 9))) | (v280 << 1));
const v283 = (-((((((((((v282) >>> 0) < ((v10) >>> 0)) | 0) & ((((v281) | 0) === ((v11) | 0)) | 0)) | ((((v281) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v284 = (v283 & v10);
const v285 = ((v282 - v284) | 0);
const v286 = ((v285 >>> 31) | (((((v281 - (v283 & v11)) | 0) - ((((v282) >>> 0) < ((v284) >>> 0)) | 0)) | 0) << 1));
const v287 = ((1 & (1 & (v6 >>> 8))) | (v285 << 1));
const v288 = (-((((((((((v287) >>> 0) < ((v10) >>> 0)) | 0) & ((((v286) | 0) === ((v11) | 0)) | 0)) | ((((v286) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v289 = (v288 & v10);
const v290 = ((v287 - v289) | 0);
const v291 = ((v290 >>> 31) | (((((v286 - (v288 & v11)) | 0) - ((((v287) >>> 0) < ((v289) >>> 0)) | 0)) | 0) << 1));
const v292 = ((1 & (1 & (v6 >>> 7))) | (v290 << 1));
const v293 = (-((((((((((v292) >>> 0) < ((v10) >>> 0)) | 0) & ((((v291) | 0) === ((v11) | 0)) | 0)) | ((((v291) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v294 = (v293 & v10);
const v295 = ((v292 - v294) | 0);
const v296 = ((v295 >>> 31) | (((((v291 - (v293 & v11)) | 0) - ((((v292) >>> 0) < ((v294) >>> 0)) | 0)) | 0) << 1));
const v297 = ((1 & (1 & (v6 >>> 6))) | (v295 << 1));
const v298 = (-((((((((((v297) >>> 0) < ((v10) >>> 0)) | 0) & ((((v296) | 0) === ((v11) | 0)) | 0)) | ((((v296) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v299 = (v298 & v10);
const v300 = ((v297 - v299) | 0);
const v301 = ((v300 >>> 31) | (((((v296 - (v298 & v11)) | 0) - ((((v297) >>> 0) < ((v299) >>> 0)) | 0)) | 0) << 1));
const v302 = ((1 & (1 & (v6 >>> 5))) | (v300 << 1));
const v303 = (-((((((((((v302) >>> 0) < ((v10) >>> 0)) | 0) & ((((v301) | 0) === ((v11) | 0)) | 0)) | ((((v301) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v304 = (v303 & v10);
const v305 = ((v302 - v304) | 0);
const v306 = ((v305 >>> 31) | (((((v301 - (v303 & v11)) | 0) - ((((v302) >>> 0) < ((v304) >>> 0)) | 0)) | 0) << 1));
const v307 = ((1 & (1 & (v6 >>> 4))) | (v305 << 1));
const v308 = (-((((((((((v307) >>> 0) < ((v10) >>> 0)) | 0) & ((((v306) | 0) === ((v11) | 0)) | 0)) | ((((v306) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v309 = (v308 & v10);
const v310 = ((v307 - v309) | 0);
const v311 = ((v310 >>> 31) | (((((v306 - (v308 & v11)) | 0) - ((((v307) >>> 0) < ((v309) >>> 0)) | 0)) | 0) << 1));
const v312 = ((1 & (1 & (v6 >>> 3))) | (v310 << 1));
const v313 = (-((((((((((v312) >>> 0) < ((v10) >>> 0)) | 0) & ((((v311) | 0) === ((v11) | 0)) | 0)) | ((((v311) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v314 = (v313 & v10);
const v315 = ((v312 - v314) | 0);
const v316 = ((v315 >>> 31) | (((((v311 - (v313 & v11)) | 0) - ((((v312) >>> 0) < ((v314) >>> 0)) | 0)) | 0) << 1));
const v317 = ((1 & (1 & (v6 >>> 2))) | (v315 << 1));
const v318 = (-((((((((((v317) >>> 0) < ((v10) >>> 0)) | 0) & ((((v316) | 0) === ((v11) | 0)) | 0)) | ((((v316) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v319 = (v318 & v10);
const v320 = ((v317 - v319) | 0);
const v321 = ((v320 >>> 31) | (((((v316 - (v318 & v11)) | 0) - ((((v317) >>> 0) < ((v319) >>> 0)) | 0)) | 0) << 1));
const v322 = ((1 & (1 & (v6 >>> 1))) | (v320 << 1));
const v323 = (-((((((((((v322) >>> 0) < ((v10) >>> 0)) | 0) & ((((v321) | 0) === ((v11) | 0)) | 0)) | ((((v321) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v324 = (v323 & v10);
const v325 = ((v322 - v324) | 0);
const v326 = ((v325 >>> 31) | (((((v321 - (v323 & v11)) | 0) - ((((v322) >>> 0) < ((v324) >>> 0)) | 0)) | 0) << 1));
const v327 = ((1 & (1 & (v6 >>> 0))) | (v325 << 1));
const v328 = (-((((((((((v327) >>> 0) < ((v10) >>> 0)) | 0) & ((((v326) | 0) === ((v11) | 0)) | 0)) | ((((v326) >>> 0) < ((v11) >>> 0)) | 0))) | 0) === 0) | 0));
const v329 = (v328 & v10);
const v330 = (v4 ^ ((v327 - v329) | 0));
const v331 = (((1 & v4) + v330) | 0);
const v332 = (((((((v331) >>> 0) < ((v330) >>> 0)) | 0) + (v4 ^ ((((v326 - (v328 & v11)) | 0) - ((((v327) >>> 0) < ((v329) >>> 0)) | 0)) | 0))) | 0) >> 0);
return {r0: v331, r1: v332};
}



function i64_rotl(v0, v1, v2) {
    
    const v3 = (63 & (63 & ((0 - (63 & v2)) | 0)));
const v4 = (31 & v3);
const v5 = ((32 - v4) | 0);
const v6 = (v3 >>> 5);
const v7 = ((((v3) | 0) === 0) | 0);
const v8 = ((((v3) | 0) === ((32) | 0)) | 0);
const v9 = (v1 >>> v4);
const v10 = (v0 >>> v4);
const v11 = (v1 << v5);
const v12 = (v0 << v5);
const v13 = ((v7) ? (v0) : (((v8) ? (v1) : (((v6) ? ((v12 | v9)) : ((v11 | v10)))))));
const v14 = (((v7) ? (v1) : (((v8) ? (v0) : (((v6) ? ((v11 | v10)) : ((v12 | v9))))))) >> 0);
return {r0: v13, r1: v14};
}



function i64_rotr(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = ((32 - v4) | 0);
const v6 = (v3 >>> 5);
const v7 = ((((v3) | 0) === 0) | 0);
const v8 = ((((v3) | 0) === ((32) | 0)) | 0);
const v9 = (v1 >>> v4);
const v10 = (v0 >>> v4);
const v11 = (v1 << v5);
const v12 = (v0 << v5);
const v13 = ((v7) ? (v0) : (((v8) ? (v1) : (((v6) ? ((v12 | v9)) : ((v11 | v10)))))));
const v14 = (((v7) ? (v1) : (((v8) ? (v0) : (((v6) ? ((v11 | v10)) : ((v12 | v9))))))) >> 0);
return {r0: v13, r1: v14};
}



function i64_shl(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = (v3 >>> 5);
const v6 = ((((v3) | 0) === 0) | 0);
const v7 = ((v6) ? (v0) : (((v5) ? (0) : ((v0 << v4)))));
const v8 = (((v6) ? (v1) : (((v5) ? ((v0 << v4)) : (((v0 >>> ((32 - v4) | 0)) | (v1 << v4)))))) >> 0);
return {r0: v7, r1: v8};
}



function i64_shr(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = (v3 >>> 5);
const v6 = ((((v3) | 0) === 0) | 0);
const v7 = ((v6) ? (v0) : (((v5) ? ((v1 >> v4)) : (((v1 << ((32 - v4) | 0)) | (v0 >>> v4))))));
const v8 = (((v6) ? (v1) : (((v5) ? ((v1 >> 31)) : ((v1 >> v4))))) >> 0);
return {r0: v7, r1: v8};
}



function i64_sub(v0, v1, v2, v3) {
    
    const v4 = ((v0 - v2) | 0);
const v5 = (((((v1 - v3) | 0) - (((v4 & (-1 ^ (v2 ^ v0))) | (v2 & (-1 ^ v0))) >>> 31)) | 0) >> 0);
return {r0: v4, r1: v5};
}



function i64_swapEndianness(v0, v1) {
    
    const v2 = ((((255 & (v0 >>> 0)) << 24) | (((255 & (v0 >>> 8)) << 16) | (((255 & (v0 >>> 16)) << 8) | (255 & (v0 >>> 24))))) >> 0);
const v3 = (((255 & (v1 >>> 0)) << 24) | (((255 & (v1 >>> 8)) << 16) | (((255 & (v1 >>> 16)) << 8) | (255 & (v1 >>> 24)))));
return {r0: v3, r1: v2};
}



function i64_xor(v0, v1, v2, v3) {
    
    const v4 = (v2 ^ v0);
const v5 = ((v3 ^ v1) >> 0);
return {r0: v4, r1: v5};
}



function i8_abs(v0) {
    
    const v1 = (((Math.abs(((v0 << 24) >> 24)) | 0) << 24) >> 24);
return v1;
}



function i8_add(v0, v1) {
    
    const v2 = ((((((v1 << 24) >> 24) + ((v0 << 24) >> 24)) | 0) << 24) >> 24);
return v2;
}



function i8_and(v0, v1) {
    
    const v2 = (((((v1 << 24) >> 24) & ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_andnot(v0, v1) {
    
    const v2 = (((((v0 << 24) >> 24) & ~((v1 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_cast_i32(v0) {
    
    const v1 = ((v0 << 24) >> 24);
return v1;
}



function i8_cast_u32(v0) {
    
    const v1 = ((v0 << 24) >> 24);
return v1;
}



function i8_cast_u8(v0) {
    
    const v1 = (((255 & v0) << 24) >> 24);
return v1;
}



function i8_clz(v0) {
    
    const v1 = (((((Math.clz32(((255 & ((v0 << 24) >> 24)))>>>0)|0) - 24) | 0) << 24) >> 24);
return v1;
}



function i8_ctz(v0) {
    
    const v1 = (()=>{const x=(((255 & ((v0 << 24) >> 24)))>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
const v2 = ((((((((v1) >>> 0) > ((8) >>> 0)) | 0)) ? (8) : (v1)) << 24) >> 24);
return v2;
}



function i8_div(v0, v1) {
    
    const v2 = (((((((((v0 << 24) >> 24))|0)/(((((v1 << 24) >> 24))|0)))|0)) << 24) >> 24);
return v2;
}



function i8_eq(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) === ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_eqz(v0) {
    
    const v1 = ((((((v0 << 24) >> 24)) | 0) === 0) | 0);
return v1;
}



function i8_from_f32(v0) {
    
    const v1 = (((Math.trunc(v0) | 0) << 24) >> 24);
return v1;
}



function i8_from_f64(v0) {
    
    const v1 = (((Math.trunc(v0) | 0) << 24) >> 24);
return v1;
}



function i8_from_i16(v0) {
    
    const v1 = ((v0 << 16) >> 16);
const v2 = ((((v1 << 16) >> 16) << 24) >> 24);
const v3 = (((((((v1 >> 8) << 16) >> 16) << 16) >> 16) << 24) >> 24);
return {r0: v2, r1: v3};
}



function i8_from_i32(v0) {
    
    const v1 = ((v0 << 24) >> 24);
const v2 = (((v0 >> 8) << 24) >> 24);
const v3 = (((v0 >> 16) << 24) >> 24);
const v4 = (((v0 >> 24) << 24) >> 24);
return {r0: v1, r1: v2, r2: v3, r3: v4};
}



function i8_from_i64(v0, v1) {
    
    const v2 = ((v0 << 24) >> 24);
const v3 = ((((v1 << 24) | (v0 >>> 8)) << 24) >> 24);
const v4 = ((((v1 << 16) | (v0 >>> 16)) << 24) >> 24);
const v5 = ((((v1 << 8) | (v0 >>> 24)) << 24) >> 24);
const v6 = (((v1 >> 0) << 24) >> 24);
const v7 = (((v1 >> 8) << 24) >> 24);
const v8 = (((v1 >> 16) << 24) >> 24);
const v9 = (((v1 >> 24) << 24) >> 24);
return {r0: v2, r1: v3, r2: v4, r3: v5, r4: v6, r5: v7, r6: v8, r7: v9};
}



function i8_from_u16(v0) {
    
    const v1 = (65535 & v0);
const v2 = (((65535 & v1) << 24) >> 24);
const v3 = (((65535 & (65535 & (v1 >>> 8))) << 24) >> 24);
return {r0: v2, r1: v3};
}



function i8_from_u32(v0) {
    
    const v1 = ((v0 << 24) >> 24);
const v2 = (((v0 >>> 8) << 24) >> 24);
const v3 = (((v0 >>> 16) << 24) >> 24);
const v4 = (((v0 >>> 24) << 24) >> 24);
return {r0: v1, r1: v2, r2: v3, r3: v4};
}



function i8_from_u64(v0, v1) {
    
    const v2 = ((v0 << 24) >> 24);
const v3 = ((((v1 << 24) | (v0 >>> 8)) << 24) >> 24);
const v4 = ((((v1 << 16) | (v0 >>> 16)) << 24) >> 24);
const v5 = ((((v1 << 8) | (v0 >>> 24)) << 24) >> 24);
const v6 = ((v1 << 24) >> 24);
const v7 = (((v1 >>> 8) << 24) >> 24);
const v8 = (((v1 >>> 16) << 24) >> 24);
const v9 = (((v1 >>> 24) << 24) >> 24);
return {r0: v2, r1: v3, r2: v4, r3: v5, r4: v6, r5: v7, r6: v8, r7: v9};
}



function i8_from_u8(v0) {
    
    const v1 = (((255 & (255 & v0)) << 24) >> 24);
return v1;
}



function i8_ge(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) >= ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_gt(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) > ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_le(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) <= ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_lt(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) < ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_max(v0, v1) {
    
    const v2 = ((Math.max(((v1 << 24) >> 24), ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_min(v0, v1) {
    
    const v2 = ((Math.min(((v1 << 24) >> 24), ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_mul(v0, v1) {
    
    const v2 = ((Math.imul(((v1 << 24) >> 24), ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_ne(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24)) | 0) !== ((((v1 << 24) >> 24)) | 0)) | 0);
return v2;
}



function i8_neg(v0) {
    
    const v1 = (((-((v0 << 24) >> 24)) << 24) >> 24);
return v1;
}



function i8_not(v0) {
    
    const v1 = (((~((v0 << 24) >> 24)) << 24) >> 24);
return v1;
}



function i8_or(v0, v1) {
    
    const v2 = (((((v1 << 24) >> 24) | ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function i8_popcnt(v0) {
    
    const v1 = (((()=>{let x=(((255 & ((v0 << 24) >> 24)))>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})() << 24) >> 24);
return v1;
}



function i8_rem(v0, v1) {
    
    const v2 = (((((((((v0 << 24) >> 24))|0)%(((((v1 << 24) >> 24))|0)))|0)) << 24) >> 24);
return v2;
}



function i8_rotl(v0, v1) {
    
    const v2 = (7 & v1);
const v3 = (255 & ((v0 << 24) >> 24));
const v4 = ((((v3 >>> ((8 - v2) | 0)) | (v3 << v2)) << 24) >> 24);
return v4;
}



function i8_rotr(v0, v1) {
    
    const v2 = (7 & v1);
const v3 = (255 & ((v0 << 24) >> 24));
const v4 = ((((v3 << ((8 - v2) | 0)) | (v3 >>> v2)) << 24) >> 24);
return v4;
}



function i8_shl(v0, v1) {
    
    const v2 = (((((v0 << 24) >> 24) << (7 & v1)) << 24) >> 24);
return v2;
}



function i8_shr(v0, v1) {
    
    const v2 = (((((v0 << 24) >> 24) >> (7 & v1)) << 24) >> 24);
return v2;
}



function i8_sub(v0, v1) {
    
    const v2 = ((((((v0 << 24) >> 24) - ((v1 << 24) >> 24)) | 0) << 24) >> 24);
return v2;
}



function i8_swapEndianness(v0) {
    
    const v1 = ((((v0 << 24) >> 24) << 24) >> 24);
return v1;
}



function i8_xor(v0, v1) {
    
    const v2 = (((((v1 << 24) >> 24) ^ ((v0 << 24) >> 24)) << 24) >> 24);
return v2;
}



function u16_add(v0, v1) {
    
    const v2 = (65535 & (((65535 & v1) + (65535 & v0)) | 0));
return v2;
}



function u16_and(v0, v1) {
    
    const v2 = (65535 & ((65535 & v1) & (65535 & v0)));
return v2;
}



function u16_andnot(v0, v1) {
    
    const v2 = (65535 & ((65535 & v0) & ~(65535 & v1)));
return v2;
}



function u16_cast_i16(v0) {
    
    const v1 = (65535 & ((v0 << 16) >> 16));
return v1;
}



function u16_cast_i32(v0) {
    
    const v1 = (65535 & v0);
return v1;
}



function u16_cast_u32(v0) {
    
    const v1 = (65535 & v0);
return v1;
}



function u16_clz(v0) {
    
    const v1 = (65535 & (((Math.clz32(((65535 & (65535 & v0)))>>>0)|0) - 16) | 0));
return v1;
}



function u16_ctz(v0) {
    
    const v1 = (()=>{const x=(((65535 & (65535 & v0)))>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
const v2 = (65535 & ((((((v1) >>> 0) > ((16) >>> 0)) | 0)) ? (16) : (v1)));
return v2;
}



function u16_div(v0, v1) {
    
    const v2 = (65535 & (((((((65535 & v0))>>>0)/((((65535 & v1))>>>0))))>>>0)));
return v2;
}



function u16_eq(v0, v1) {
    
    const v2 = (((((65535 & v0)) | 0) === (((65535 & v1)) | 0)) | 0);
return v2;
}



function u16_eqz(v0) {
    
    const v1 = (((((65535 & v0)) | 0) === 0) | 0);
return v1;
}



function u16_from_f32(v0) {
    
    const v1 = (65535 & (Math.trunc(v0) >>> 0) | 0);
return v1;
}



function u16_from_f64(v0) {
    
    const v1 = (65535 & (Math.trunc(v0) >>> 0) | 0);
return v1;
}



function u16_from_i16(v0) {
    
    const v1 = (65535 & ((((v0 << 16) >> 16) << 16) >> 16));
return v1;
}



function u16_from_i32(v0) {
    
    const v1 = (65535 & v0);
const v2 = (65535 & (v0 >> 16));
return {r0: v1, r1: v2};
}



function u16_from_i64(v0, v1) {
    
    const v2 = (65535 & v0);
const v3 = (65535 & ((v1 << 16) | (v0 >>> 16)));
const v4 = (65535 & (v1 >> 0));
const v5 = (65535 & (v1 >> 16));
return {r0: v2, r1: v3, r2: v4, r3: v5};
}



function u16_from_i8(v0) {
    
    const v1 = (65535 & ((((v0 << 24) >> 24) << 24) >> 24));
return v1;
}



function u16_from_u32(v0) {
    
    const v1 = (65535 & v0);
const v2 = (65535 & (v0 >>> 16));
return {r0: v1, r1: v2};
}



function u16_from_u64(v0, v1) {
    
    const v2 = (65535 & v0);
const v3 = (65535 & ((v1 << 16) | (v0 >>> 16)));
const v4 = (65535 & v1);
const v5 = (65535 & (v1 >>> 16));
return {r0: v2, r1: v3, r2: v4, r3: v5};
}



function u16_from_u8(v0) {
    
    const v1 = (65535 & (255 & (255 & v0)));
return v1;
}



function u16_ge(v0, v1) {
    
    const v2 = (((((65535 & v0)) >>> 0) >= (((65535 & v1)) >>> 0)) | 0);
return v2;
}



function u16_gt(v0, v1) {
    
    const v2 = (((((65535 & v0)) >>> 0) > (((65535 & v1)) >>> 0)) | 0);
return v2;
}



function u16_le(v0, v1) {
    
    const v2 = (((((65535 & v0)) >>> 0) <= (((65535 & v1)) >>> 0)) | 0);
return v2;
}



function u16_lt(v0, v1) {
    
    const v2 = (((((65535 & v0)) >>> 0) < (((65535 & v1)) >>> 0)) | 0);
return v2;
}



function u16_max(v0, v1) {
    
    const v2 = (65535 & (Math.max((65535 & v1) >>> 0, (65535 & v0) >>> 0) | 0));
return v2;
}



function u16_min(v0, v1) {
    
    const v2 = (65535 & (Math.min((65535 & v1) >>> 0, (65535 & v0) >>> 0) | 0));
return v2;
}



function u16_mul(v0, v1) {
    
    const v2 = (65535 & Math.imul((65535 & v1), (65535 & v0)));
return v2;
}



function u16_ne(v0, v1) {
    
    const v2 = (((((65535 & v0)) | 0) !== (((65535 & v1)) | 0)) | 0);
return v2;
}



function u16_not(v0) {
    
    const v1 = (65535 & (~(65535 & v0)));
return v1;
}



function u16_or(v0, v1) {
    
    const v2 = (65535 & ((65535 & v1) | (65535 & v0)));
return v2;
}



function u16_popcnt(v0) {
    
    const v1 = (65535 & (()=>{let x=(((65535 & (65535 & v0)))>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})());
return v1;
}



function u16_rem(v0, v1) {
    
    const v2 = (65535 & (((((((65535 & v0))>>>0)%((((65535 & v1))>>>0))))>>>0)));
return v2;
}



function u16_rotl(v0, v1) {
    
    const v2 = (15 & v1);
const v3 = (65535 & (65535 & v0));
const v4 = (65535 & ((v3 >>> ((16 - v2) | 0)) | (v3 << v2)));
return v4;
}



function u16_rotr(v0, v1) {
    
    const v2 = (15 & v1);
const v3 = (65535 & (65535 & v0));
const v4 = (65535 & ((v3 << ((16 - v2) | 0)) | (v3 >>> v2)));
return v4;
}



function u16_shl(v0, v1) {
    
    const v2 = (65535 & ((65535 & v0) << (15 & v1)));
return v2;
}



function u16_shr(v0, v1) {
    
    const v2 = (65535 & ((65535 & v0) >>> (15 & v1)));
return v2;
}



function u16_sub(v0, v1) {
    
    const v2 = (65535 & (((65535 & v0) - (65535 & v1)) | 0));
return v2;
}



function u16_swapEndianness(v0) {
    
    const v1 = (65535 & (65535 & v0));
const v2 = (65535 & ((255 & (v1 >>> 8)) | ((255 & v1) << 8)));
return v2;
}



function u16_xor(v0, v1) {
    
    const v2 = (65535 & ((65535 & v1) ^ (65535 & v0)));
return v2;
}



function u32_add(v0, v1) {
    
    const v2 = ((v1 + v0) | 0);
return v2;
}



function u32_and(v0, v1) {
    
    const v2 = (v1 & v0);
return v2;
}



function u32_andnot(v0, v1) {
    
    const v2 = (v0 & ~v1);
return v2;
}



function u32_cast_f32(v0) {
    
    return (new Int32Array(new Float32Array([v0]).buffer)[0]);
}



function u32_cast_i16(v0) {
    
    return ((v0 << 16) >> 16);
}



function u32_cast_i32(v0) {
    
    return v0;
}



function u32_cast_i8(v0) {
    
    return ((v0 << 24) >> 24);
}



function u32_cast_u16(v0) {
    
    return (65535 & v0);
}



function u32_cast_u8(v0) {
    
    return (255 & v0);
}



function u32_clz(v0) {
    
    const v1 = (Math.clz32((v0)>>>0)|0);
return v1;
}



function u32_ctz(v0) {
    
    const v1 = (()=>{const x=((v0)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
return v1;
}



function u32_div(v0, v1) {
    
    const v2 = ((((((v0)>>>0)/(((v1)>>>0))))>>>0));
return v2;
}



function u32_eq(v0, v1) {
    
    const v2 = ((((v0) | 0) === ((v1) | 0)) | 0);
return v2;
}



function u32_eqz(v0) {
    
    const v1 = ((((v0) | 0) === 0) | 0);
return v1;
}



function u32_from_f32(v0) {
    
    const v1 = (Math.trunc(v0) >>> 0) | 0;
return v1;
}



function u32_from_f64(v0) {
    
    const v1 = (Math.trunc(v0) >>> 0) | 0;
return v1;
}



function u32_from_i16(v0) {
    
    const v1 = ((((v0 << 16) >> 16) << 16) >> 16);
return v1;
}



function u32_from_i32(v0) {
    
    return v0;
}



function u32_from_i64(v0, v1) {
    
    const v2 = (v1 >> 0);
return {r0: v0, r1: v2};
}



function u32_from_i8(v0) {
    
    const v1 = ((((v0 << 24) >> 24) << 24) >> 24);
return v1;
}



function u32_from_u16(v0) {
    
    const v1 = (65535 & (65535 & v0));
return v1;
}



function u32_from_u64(v0, v1) {
    
    return {r0: v0, r1: v1};
}



function u32_from_u8(v0) {
    
    const v1 = (255 & (255 & v0));
return v1;
}



function u32_ge(v0, v1) {
    
    const v2 = ((((v0) >>> 0) >= ((v1) >>> 0)) | 0);
return v2;
}



function u32_gt(v0, v1) {
    
    const v2 = ((((v0) >>> 0) > ((v1) >>> 0)) | 0);
return v2;
}



function u32_le(v0, v1) {
    
    const v2 = ((((v0) >>> 0) <= ((v1) >>> 0)) | 0);
return v2;
}



function u32_lt(v0, v1) {
    
    const v2 = ((((v0) >>> 0) < ((v1) >>> 0)) | 0);
return v2;
}



function u32_max(v0, v1) {
    
    const v2 = (Math.max(v1 >>> 0, v0 >>> 0) | 0);
return v2;
}



function u32_min(v0, v1) {
    
    const v2 = (Math.min(v1 >>> 0, v0 >>> 0) | 0);
return v2;
}



function u32_mul(v0, v1) {
    
    const v2 = Math.imul(v1, v0);
return v2;
}



function u32_ne(v0, v1) {
    
    const v2 = ((((v0) | 0) !== ((v1) | 0)) | 0);
return v2;
}



function u32_not(v0) {
    
    const v1 = (~v0);
return v1;
}



function u32_or(v0, v1) {
    
    const v2 = (v1 | v0);
return v2;
}



function u32_popcnt(v0) {
    
    const v1 = (()=>{let x=((v0)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})();
return v1;
}



function u32_rem(v0, v1) {
    
    const v2 = ((((((v0)>>>0)%(((v1)>>>0))))>>>0));
return v2;
}



function u32_rotl(v0, v1) {
    
    const v2 = ((v0 << v1) | ((v0 >>> (32 - v1)) >>> 0));
return v2;
}



function u32_rotr(v0, v1) {
    
    const v2 = (((v0 >>> v1) | (v0 << (32 - v1))));
return v2;
}



function u32_shl(v0, v1) {
    
    const v2 = (v0 << v1);
return v2;
}



function u32_shr(v0, v1) {
    
    const v2 = (v0 >>> v1);
return v2;
}



function u32_sub(v0, v1) {
    
    const v2 = ((v0 - v1) | 0);
return v2;
}



function u32_swapEndianness(v0) {
    
    const v1 = (((255 & (v0 >>> 0)) << 24) | (((255 & (v0 >>> 8)) << 16) | (((255 & (v0 >>> 16)) << 8) | (255 & (v0 >>> 24)))));
return v1;
}



function u32_xor(v0, v1) {
    
    const v2 = (v1 ^ v0);
return v2;
}



function u64_add(v0, v1, v2, v3) {
    
    const v4 = ((v2 + v0) | 0);
const v5 = ((((((-1 ^ v4) & (v2 | v0)) | (v2 & v0)) >>> 31) + ((v3 + v1) | 0)) | 0);
return {r0: v4, r1: v5};
}



function u64_and(v0, v1, v2, v3) {
    
    const v4 = (v2 & v0);
const v5 = (v3 & v1);
return {r0: v4, r1: v5};
}



function u64_andnot(v0, v1, v2, v3) {
    
    const v4 = (v0 & ~v2);
const v5 = (v1 & ~v3);
return {r0: v4, r1: v5};
}



function u64_cast_f64(v0) {
    
    const v1 = (new Uint32Array(new Float64Array([v0]).buffer)[0]);
const v2 = (new Uint32Array(new Float64Array([v0]).buffer)[1]);
return {r0: v1, r1: v2};
}



function u64_cast_i64(v0, v1) {
    
    return {r0: v0, r1: v1};
}



function u64_clz(v0, v1) {
    
    const v2 = ((((((v1) | 0) === 0) | 0)) ? ((((Math.clz32((v0)>>>0)|0) + 32) | 0)) : ((Math.clz32((v1)>>>0)|0)));
return {r0: v2, r1: 0};
}



function u64_ctz(v0, v1) {
    
    const v2 = ((((((v0) | 0) === 0) | 0)) ? ((((()=>{const x=((v1)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})() + 32) | 0)) : ((()=>{const x=((v0)>>>0);return x?((31-Math.clz32(x&-x))|0):32;})()));
return {r0: v2, r1: 0};
}



function u64_div(v0, v1, v2, v3) {
    
    const v4 = (1 & (1 & (v1 >>> 31)));
const v5 = ((((((((((v4) >>> 0) < ((v2) >>> 0)) | 0) & ((((0) | 0) === ((v3) | 0)) | 0)) | ((((0) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v6 = (-v5);
const v7 = (v6 & v2);
const v8 = ((v4 - v7) | 0);
const v9 = ((v8 >>> 31) | (((((0 - (v6 & v3)) | 0) - ((((v4) >>> 0) < ((v7) >>> 0)) | 0)) | 0) << 1));
const v10 = ((1 & (1 & (v1 >>> 30))) | (v8 << 1));
const v11 = ((((((((((v10) >>> 0) < ((v2) >>> 0)) | 0) & ((((v9) | 0) === ((v3) | 0)) | 0)) | ((((v9) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v12 = (-v11);
const v13 = (v12 & v2);
const v14 = ((v10 - v13) | 0);
const v15 = ((v14 >>> 31) | (((((v9 - (v12 & v3)) | 0) - ((((v10) >>> 0) < ((v13) >>> 0)) | 0)) | 0) << 1));
const v16 = ((1 & (1 & (v1 >>> 29))) | (v14 << 1));
const v17 = ((((((((((v16) >>> 0) < ((v2) >>> 0)) | 0) & ((((v15) | 0) === ((v3) | 0)) | 0)) | ((((v15) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v18 = (-v17);
const v19 = (v18 & v2);
const v20 = ((v16 - v19) | 0);
const v21 = ((v20 >>> 31) | (((((v15 - (v18 & v3)) | 0) - ((((v16) >>> 0) < ((v19) >>> 0)) | 0)) | 0) << 1));
const v22 = ((1 & (1 & (v1 >>> 28))) | (v20 << 1));
const v23 = ((((((((((v22) >>> 0) < ((v2) >>> 0)) | 0) & ((((v21) | 0) === ((v3) | 0)) | 0)) | ((((v21) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v24 = (-v23);
const v25 = (v24 & v2);
const v26 = ((v22 - v25) | 0);
const v27 = ((v26 >>> 31) | (((((v21 - (v24 & v3)) | 0) - ((((v22) >>> 0) < ((v25) >>> 0)) | 0)) | 0) << 1));
const v28 = ((1 & (1 & (v1 >>> 27))) | (v26 << 1));
const v29 = ((((((((((v28) >>> 0) < ((v2) >>> 0)) | 0) & ((((v27) | 0) === ((v3) | 0)) | 0)) | ((((v27) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v30 = (-v29);
const v31 = (v30 & v2);
const v32 = ((v28 - v31) | 0);
const v33 = ((v32 >>> 31) | (((((v27 - (v30 & v3)) | 0) - ((((v28) >>> 0) < ((v31) >>> 0)) | 0)) | 0) << 1));
const v34 = ((1 & (1 & (v1 >>> 26))) | (v32 << 1));
const v35 = ((((((((((v34) >>> 0) < ((v2) >>> 0)) | 0) & ((((v33) | 0) === ((v3) | 0)) | 0)) | ((((v33) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v36 = (-v35);
const v37 = (v36 & v2);
const v38 = ((v34 - v37) | 0);
const v39 = ((v38 >>> 31) | (((((v33 - (v36 & v3)) | 0) - ((((v34) >>> 0) < ((v37) >>> 0)) | 0)) | 0) << 1));
const v40 = ((1 & (1 & (v1 >>> 25))) | (v38 << 1));
const v41 = ((((((((((v40) >>> 0) < ((v2) >>> 0)) | 0) & ((((v39) | 0) === ((v3) | 0)) | 0)) | ((((v39) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v42 = (-v41);
const v43 = (v42 & v2);
const v44 = ((v40 - v43) | 0);
const v45 = ((v44 >>> 31) | (((((v39 - (v42 & v3)) | 0) - ((((v40) >>> 0) < ((v43) >>> 0)) | 0)) | 0) << 1));
const v46 = ((1 & (1 & (v1 >>> 24))) | (v44 << 1));
const v47 = ((((((((((v46) >>> 0) < ((v2) >>> 0)) | 0) & ((((v45) | 0) === ((v3) | 0)) | 0)) | ((((v45) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v48 = (-v47);
const v49 = (v48 & v2);
const v50 = ((v46 - v49) | 0);
const v51 = ((v50 >>> 31) | (((((v45 - (v48 & v3)) | 0) - ((((v46) >>> 0) < ((v49) >>> 0)) | 0)) | 0) << 1));
const v52 = ((1 & (1 & (v1 >>> 23))) | (v50 << 1));
const v53 = ((((((((((v52) >>> 0) < ((v2) >>> 0)) | 0) & ((((v51) | 0) === ((v3) | 0)) | 0)) | ((((v51) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v54 = (-v53);
const v55 = (v54 & v2);
const v56 = ((v52 - v55) | 0);
const v57 = ((v56 >>> 31) | (((((v51 - (v54 & v3)) | 0) - ((((v52) >>> 0) < ((v55) >>> 0)) | 0)) | 0) << 1));
const v58 = ((1 & (1 & (v1 >>> 22))) | (v56 << 1));
const v59 = ((((((((((v58) >>> 0) < ((v2) >>> 0)) | 0) & ((((v57) | 0) === ((v3) | 0)) | 0)) | ((((v57) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v60 = (-v59);
const v61 = (v60 & v2);
const v62 = ((v58 - v61) | 0);
const v63 = ((v62 >>> 31) | (((((v57 - (v60 & v3)) | 0) - ((((v58) >>> 0) < ((v61) >>> 0)) | 0)) | 0) << 1));
const v64 = ((1 & (1 & (v1 >>> 21))) | (v62 << 1));
const v65 = ((((((((((v64) >>> 0) < ((v2) >>> 0)) | 0) & ((((v63) | 0) === ((v3) | 0)) | 0)) | ((((v63) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v66 = (-v65);
const v67 = (v66 & v2);
const v68 = ((v64 - v67) | 0);
const v69 = ((v68 >>> 31) | (((((v63 - (v66 & v3)) | 0) - ((((v64) >>> 0) < ((v67) >>> 0)) | 0)) | 0) << 1));
const v70 = ((1 & (1 & (v1 >>> 20))) | (v68 << 1));
const v71 = ((((((((((v70) >>> 0) < ((v2) >>> 0)) | 0) & ((((v69) | 0) === ((v3) | 0)) | 0)) | ((((v69) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v72 = (-v71);
const v73 = (v72 & v2);
const v74 = ((v70 - v73) | 0);
const v75 = ((v74 >>> 31) | (((((v69 - (v72 & v3)) | 0) - ((((v70) >>> 0) < ((v73) >>> 0)) | 0)) | 0) << 1));
const v76 = ((1 & (1 & (v1 >>> 19))) | (v74 << 1));
const v77 = ((((((((((v76) >>> 0) < ((v2) >>> 0)) | 0) & ((((v75) | 0) === ((v3) | 0)) | 0)) | ((((v75) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v78 = (-v77);
const v79 = (v78 & v2);
const v80 = ((v76 - v79) | 0);
const v81 = ((v80 >>> 31) | (((((v75 - (v78 & v3)) | 0) - ((((v76) >>> 0) < ((v79) >>> 0)) | 0)) | 0) << 1));
const v82 = ((1 & (1 & (v1 >>> 18))) | (v80 << 1));
const v83 = ((((((((((v82) >>> 0) < ((v2) >>> 0)) | 0) & ((((v81) | 0) === ((v3) | 0)) | 0)) | ((((v81) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v84 = (-v83);
const v85 = (v84 & v2);
const v86 = ((v82 - v85) | 0);
const v87 = ((v86 >>> 31) | (((((v81 - (v84 & v3)) | 0) - ((((v82) >>> 0) < ((v85) >>> 0)) | 0)) | 0) << 1));
const v88 = ((1 & (1 & (v1 >>> 17))) | (v86 << 1));
const v89 = ((((((((((v88) >>> 0) < ((v2) >>> 0)) | 0) & ((((v87) | 0) === ((v3) | 0)) | 0)) | ((((v87) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v90 = (-v89);
const v91 = (v90 & v2);
const v92 = ((v88 - v91) | 0);
const v93 = ((v92 >>> 31) | (((((v87 - (v90 & v3)) | 0) - ((((v88) >>> 0) < ((v91) >>> 0)) | 0)) | 0) << 1));
const v94 = ((1 & (1 & (v1 >>> 16))) | (v92 << 1));
const v95 = ((((((((((v94) >>> 0) < ((v2) >>> 0)) | 0) & ((((v93) | 0) === ((v3) | 0)) | 0)) | ((((v93) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v96 = (-v95);
const v97 = (v96 & v2);
const v98 = ((v94 - v97) | 0);
const v99 = ((v98 >>> 31) | (((((v93 - (v96 & v3)) | 0) - ((((v94) >>> 0) < ((v97) >>> 0)) | 0)) | 0) << 1));
const v100 = ((1 & (1 & (v1 >>> 15))) | (v98 << 1));
const v101 = ((((((((((v100) >>> 0) < ((v2) >>> 0)) | 0) & ((((v99) | 0) === ((v3) | 0)) | 0)) | ((((v99) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v102 = (-v101);
const v103 = (v102 & v2);
const v104 = ((v100 - v103) | 0);
const v105 = ((v104 >>> 31) | (((((v99 - (v102 & v3)) | 0) - ((((v100) >>> 0) < ((v103) >>> 0)) | 0)) | 0) << 1));
const v106 = ((1 & (1 & (v1 >>> 14))) | (v104 << 1));
const v107 = ((((((((((v106) >>> 0) < ((v2) >>> 0)) | 0) & ((((v105) | 0) === ((v3) | 0)) | 0)) | ((((v105) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v108 = (-v107);
const v109 = (v108 & v2);
const v110 = ((v106 - v109) | 0);
const v111 = ((v110 >>> 31) | (((((v105 - (v108 & v3)) | 0) - ((((v106) >>> 0) < ((v109) >>> 0)) | 0)) | 0) << 1));
const v112 = ((1 & (1 & (v1 >>> 13))) | (v110 << 1));
const v113 = ((((((((((v112) >>> 0) < ((v2) >>> 0)) | 0) & ((((v111) | 0) === ((v3) | 0)) | 0)) | ((((v111) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v114 = (-v113);
const v115 = (v114 & v2);
const v116 = ((v112 - v115) | 0);
const v117 = ((v116 >>> 31) | (((((v111 - (v114 & v3)) | 0) - ((((v112) >>> 0) < ((v115) >>> 0)) | 0)) | 0) << 1));
const v118 = ((1 & (1 & (v1 >>> 12))) | (v116 << 1));
const v119 = ((((((((((v118) >>> 0) < ((v2) >>> 0)) | 0) & ((((v117) | 0) === ((v3) | 0)) | 0)) | ((((v117) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v120 = (-v119);
const v121 = (v120 & v2);
const v122 = ((v118 - v121) | 0);
const v123 = ((v122 >>> 31) | (((((v117 - (v120 & v3)) | 0) - ((((v118) >>> 0) < ((v121) >>> 0)) | 0)) | 0) << 1));
const v124 = ((1 & (1 & (v1 >>> 11))) | (v122 << 1));
const v125 = ((((((((((v124) >>> 0) < ((v2) >>> 0)) | 0) & ((((v123) | 0) === ((v3) | 0)) | 0)) | ((((v123) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v126 = (-v125);
const v127 = (v126 & v2);
const v128 = ((v124 - v127) | 0);
const v129 = ((v128 >>> 31) | (((((v123 - (v126 & v3)) | 0) - ((((v124) >>> 0) < ((v127) >>> 0)) | 0)) | 0) << 1));
const v130 = ((1 & (1 & (v1 >>> 10))) | (v128 << 1));
const v131 = ((((((((((v130) >>> 0) < ((v2) >>> 0)) | 0) & ((((v129) | 0) === ((v3) | 0)) | 0)) | ((((v129) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v132 = (-v131);
const v133 = (v132 & v2);
const v134 = ((v130 - v133) | 0);
const v135 = ((v134 >>> 31) | (((((v129 - (v132 & v3)) | 0) - ((((v130) >>> 0) < ((v133) >>> 0)) | 0)) | 0) << 1));
const v136 = ((1 & (1 & (v1 >>> 9))) | (v134 << 1));
const v137 = ((((((((((v136) >>> 0) < ((v2) >>> 0)) | 0) & ((((v135) | 0) === ((v3) | 0)) | 0)) | ((((v135) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v138 = (-v137);
const v139 = (v138 & v2);
const v140 = ((v136 - v139) | 0);
const v141 = ((v140 >>> 31) | (((((v135 - (v138 & v3)) | 0) - ((((v136) >>> 0) < ((v139) >>> 0)) | 0)) | 0) << 1));
const v142 = ((1 & (1 & (v1 >>> 8))) | (v140 << 1));
const v143 = ((((((((((v142) >>> 0) < ((v2) >>> 0)) | 0) & ((((v141) | 0) === ((v3) | 0)) | 0)) | ((((v141) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v144 = (-v143);
const v145 = (v144 & v2);
const v146 = ((v142 - v145) | 0);
const v147 = ((v146 >>> 31) | (((((v141 - (v144 & v3)) | 0) - ((((v142) >>> 0) < ((v145) >>> 0)) | 0)) | 0) << 1));
const v148 = ((1 & (1 & (v1 >>> 7))) | (v146 << 1));
const v149 = ((((((((((v148) >>> 0) < ((v2) >>> 0)) | 0) & ((((v147) | 0) === ((v3) | 0)) | 0)) | ((((v147) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v150 = (-v149);
const v151 = (v150 & v2);
const v152 = ((v148 - v151) | 0);
const v153 = ((v152 >>> 31) | (((((v147 - (v150 & v3)) | 0) - ((((v148) >>> 0) < ((v151) >>> 0)) | 0)) | 0) << 1));
const v154 = ((1 & (1 & (v1 >>> 6))) | (v152 << 1));
const v155 = ((((((((((v154) >>> 0) < ((v2) >>> 0)) | 0) & ((((v153) | 0) === ((v3) | 0)) | 0)) | ((((v153) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v156 = (-v155);
const v157 = (v156 & v2);
const v158 = ((v154 - v157) | 0);
const v159 = ((v158 >>> 31) | (((((v153 - (v156 & v3)) | 0) - ((((v154) >>> 0) < ((v157) >>> 0)) | 0)) | 0) << 1));
const v160 = ((1 & (1 & (v1 >>> 5))) | (v158 << 1));
const v161 = ((((((((((v160) >>> 0) < ((v2) >>> 0)) | 0) & ((((v159) | 0) === ((v3) | 0)) | 0)) | ((((v159) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v162 = (-v161);
const v163 = (v162 & v2);
const v164 = ((v160 - v163) | 0);
const v165 = ((v164 >>> 31) | (((((v159 - (v162 & v3)) | 0) - ((((v160) >>> 0) < ((v163) >>> 0)) | 0)) | 0) << 1));
const v166 = ((1 & (1 & (v1 >>> 4))) | (v164 << 1));
const v167 = ((((((((((v166) >>> 0) < ((v2) >>> 0)) | 0) & ((((v165) | 0) === ((v3) | 0)) | 0)) | ((((v165) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v168 = (-v167);
const v169 = (v168 & v2);
const v170 = ((v166 - v169) | 0);
const v171 = ((v170 >>> 31) | (((((v165 - (v168 & v3)) | 0) - ((((v166) >>> 0) < ((v169) >>> 0)) | 0)) | 0) << 1));
const v172 = ((1 & (1 & (v1 >>> 3))) | (v170 << 1));
const v173 = ((((((((((v172) >>> 0) < ((v2) >>> 0)) | 0) & ((((v171) | 0) === ((v3) | 0)) | 0)) | ((((v171) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v174 = (-v173);
const v175 = (v174 & v2);
const v176 = ((v172 - v175) | 0);
const v177 = ((v176 >>> 31) | (((((v171 - (v174 & v3)) | 0) - ((((v172) >>> 0) < ((v175) >>> 0)) | 0)) | 0) << 1));
const v178 = ((1 & (1 & (v1 >>> 2))) | (v176 << 1));
const v179 = ((((((((((v178) >>> 0) < ((v2) >>> 0)) | 0) & ((((v177) | 0) === ((v3) | 0)) | 0)) | ((((v177) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v180 = (-v179);
const v181 = (v180 & v2);
const v182 = ((v178 - v181) | 0);
const v183 = ((v182 >>> 31) | (((((v177 - (v180 & v3)) | 0) - ((((v178) >>> 0) < ((v181) >>> 0)) | 0)) | 0) << 1));
const v184 = ((1 & (1 & (v1 >>> 1))) | (v182 << 1));
const v185 = ((((((((((v184) >>> 0) < ((v2) >>> 0)) | 0) & ((((v183) | 0) === ((v3) | 0)) | 0)) | ((((v183) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v186 = (-v185);
const v187 = (v186 & v2);
const v188 = ((v184 - v187) | 0);
const v189 = ((v188 >>> 31) | (((((v183 - (v186 & v3)) | 0) - ((((v184) >>> 0) < ((v187) >>> 0)) | 0)) | 0) << 1));
const v190 = ((1 & (1 & (v1 >>> 0))) | (v188 << 1));
const v191 = ((((((((((v190) >>> 0) < ((v2) >>> 0)) | 0) & ((((v189) | 0) === ((v3) | 0)) | 0)) | ((((v189) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v192 = (-v191);
const v193 = (v192 & v2);
const v194 = ((v190 - v193) | 0);
const v195 = ((v191 << 0) | ((v185 << 1) | ((v179 << 2) | ((v173 << 3) | ((v167 << 4) | ((v161 << 5) | ((v155 << 6) | ((v149 << 7) | ((v143 << 8) | ((v137 << 9) | ((v131 << 10) | ((v125 << 11) | ((v119 << 12) | ((v113 << 13) | ((v107 << 14) | ((v101 << 15) | ((v95 << 16) | ((v89 << 17) | ((v83 << 18) | ((v77 << 19) | ((v71 << 20) | ((v65 << 21) | ((v59 << 22) | ((v53 << 23) | ((v47 << 24) | ((v41 << 25) | ((v35 << 26) | ((v29 << 27) | ((v23 << 28) | ((v17 << 29) | ((v11 << 30) | (v5 << 31))))))))))))))))))))))))))))))));
const v196 = ((v194 >>> 31) | (((((v189 - (v192 & v3)) | 0) - ((((v190) >>> 0) < ((v193) >>> 0)) | 0)) | 0) << 1));
const v197 = ((1 & (1 & (v0 >>> 31))) | (v194 << 1));
const v198 = ((((((((((v197) >>> 0) < ((v2) >>> 0)) | 0) & ((((v196) | 0) === ((v3) | 0)) | 0)) | ((((v196) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v199 = (-v198);
const v200 = (v199 & v2);
const v201 = ((v197 - v200) | 0);
const v202 = ((v201 >>> 31) | (((((v196 - (v199 & v3)) | 0) - ((((v197) >>> 0) < ((v200) >>> 0)) | 0)) | 0) << 1));
const v203 = ((1 & (1 & (v0 >>> 30))) | (v201 << 1));
const v204 = ((((((((((v203) >>> 0) < ((v2) >>> 0)) | 0) & ((((v202) | 0) === ((v3) | 0)) | 0)) | ((((v202) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v205 = (-v204);
const v206 = (v205 & v2);
const v207 = ((v203 - v206) | 0);
const v208 = ((v207 >>> 31) | (((((v202 - (v205 & v3)) | 0) - ((((v203) >>> 0) < ((v206) >>> 0)) | 0)) | 0) << 1));
const v209 = ((1 & (1 & (v0 >>> 29))) | (v207 << 1));
const v210 = ((((((((((v209) >>> 0) < ((v2) >>> 0)) | 0) & ((((v208) | 0) === ((v3) | 0)) | 0)) | ((((v208) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v211 = (-v210);
const v212 = (v211 & v2);
const v213 = ((v209 - v212) | 0);
const v214 = ((v213 >>> 31) | (((((v208 - (v211 & v3)) | 0) - ((((v209) >>> 0) < ((v212) >>> 0)) | 0)) | 0) << 1));
const v215 = ((1 & (1 & (v0 >>> 28))) | (v213 << 1));
const v216 = ((((((((((v215) >>> 0) < ((v2) >>> 0)) | 0) & ((((v214) | 0) === ((v3) | 0)) | 0)) | ((((v214) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v217 = (-v216);
const v218 = (v217 & v2);
const v219 = ((v215 - v218) | 0);
const v220 = ((v219 >>> 31) | (((((v214 - (v217 & v3)) | 0) - ((((v215) >>> 0) < ((v218) >>> 0)) | 0)) | 0) << 1));
const v221 = ((1 & (1 & (v0 >>> 27))) | (v219 << 1));
const v222 = ((((((((((v221) >>> 0) < ((v2) >>> 0)) | 0) & ((((v220) | 0) === ((v3) | 0)) | 0)) | ((((v220) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v223 = (-v222);
const v224 = (v223 & v2);
const v225 = ((v221 - v224) | 0);
const v226 = ((v225 >>> 31) | (((((v220 - (v223 & v3)) | 0) - ((((v221) >>> 0) < ((v224) >>> 0)) | 0)) | 0) << 1));
const v227 = ((1 & (1 & (v0 >>> 26))) | (v225 << 1));
const v228 = ((((((((((v227) >>> 0) < ((v2) >>> 0)) | 0) & ((((v226) | 0) === ((v3) | 0)) | 0)) | ((((v226) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v229 = (-v228);
const v230 = (v229 & v2);
const v231 = ((v227 - v230) | 0);
const v232 = ((v231 >>> 31) | (((((v226 - (v229 & v3)) | 0) - ((((v227) >>> 0) < ((v230) >>> 0)) | 0)) | 0) << 1));
const v233 = ((1 & (1 & (v0 >>> 25))) | (v231 << 1));
const v234 = ((((((((((v233) >>> 0) < ((v2) >>> 0)) | 0) & ((((v232) | 0) === ((v3) | 0)) | 0)) | ((((v232) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v235 = (-v234);
const v236 = (v235 & v2);
const v237 = ((v233 - v236) | 0);
const v238 = ((v237 >>> 31) | (((((v232 - (v235 & v3)) | 0) - ((((v233) >>> 0) < ((v236) >>> 0)) | 0)) | 0) << 1));
const v239 = ((1 & (1 & (v0 >>> 24))) | (v237 << 1));
const v240 = ((((((((((v239) >>> 0) < ((v2) >>> 0)) | 0) & ((((v238) | 0) === ((v3) | 0)) | 0)) | ((((v238) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v241 = (-v240);
const v242 = (v241 & v2);
const v243 = ((v239 - v242) | 0);
const v244 = ((v243 >>> 31) | (((((v238 - (v241 & v3)) | 0) - ((((v239) >>> 0) < ((v242) >>> 0)) | 0)) | 0) << 1));
const v245 = ((1 & (1 & (v0 >>> 23))) | (v243 << 1));
const v246 = ((((((((((v245) >>> 0) < ((v2) >>> 0)) | 0) & ((((v244) | 0) === ((v3) | 0)) | 0)) | ((((v244) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v247 = (-v246);
const v248 = (v247 & v2);
const v249 = ((v245 - v248) | 0);
const v250 = ((v249 >>> 31) | (((((v244 - (v247 & v3)) | 0) - ((((v245) >>> 0) < ((v248) >>> 0)) | 0)) | 0) << 1));
const v251 = ((1 & (1 & (v0 >>> 22))) | (v249 << 1));
const v252 = ((((((((((v251) >>> 0) < ((v2) >>> 0)) | 0) & ((((v250) | 0) === ((v3) | 0)) | 0)) | ((((v250) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v253 = (-v252);
const v254 = (v253 & v2);
const v255 = ((v251 - v254) | 0);
const v256 = ((v255 >>> 31) | (((((v250 - (v253 & v3)) | 0) - ((((v251) >>> 0) < ((v254) >>> 0)) | 0)) | 0) << 1));
const v257 = ((1 & (1 & (v0 >>> 21))) | (v255 << 1));
const v258 = ((((((((((v257) >>> 0) < ((v2) >>> 0)) | 0) & ((((v256) | 0) === ((v3) | 0)) | 0)) | ((((v256) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v259 = (-v258);
const v260 = (v259 & v2);
const v261 = ((v257 - v260) | 0);
const v262 = ((v261 >>> 31) | (((((v256 - (v259 & v3)) | 0) - ((((v257) >>> 0) < ((v260) >>> 0)) | 0)) | 0) << 1));
const v263 = ((1 & (1 & (v0 >>> 20))) | (v261 << 1));
const v264 = ((((((((((v263) >>> 0) < ((v2) >>> 0)) | 0) & ((((v262) | 0) === ((v3) | 0)) | 0)) | ((((v262) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v265 = (-v264);
const v266 = (v265 & v2);
const v267 = ((v263 - v266) | 0);
const v268 = ((v267 >>> 31) | (((((v262 - (v265 & v3)) | 0) - ((((v263) >>> 0) < ((v266) >>> 0)) | 0)) | 0) << 1));
const v269 = ((1 & (1 & (v0 >>> 19))) | (v267 << 1));
const v270 = ((((((((((v269) >>> 0) < ((v2) >>> 0)) | 0) & ((((v268) | 0) === ((v3) | 0)) | 0)) | ((((v268) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v271 = (-v270);
const v272 = (v271 & v2);
const v273 = ((v269 - v272) | 0);
const v274 = ((v273 >>> 31) | (((((v268 - (v271 & v3)) | 0) - ((((v269) >>> 0) < ((v272) >>> 0)) | 0)) | 0) << 1));
const v275 = ((1 & (1 & (v0 >>> 18))) | (v273 << 1));
const v276 = ((((((((((v275) >>> 0) < ((v2) >>> 0)) | 0) & ((((v274) | 0) === ((v3) | 0)) | 0)) | ((((v274) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v277 = (-v276);
const v278 = (v277 & v2);
const v279 = ((v275 - v278) | 0);
const v280 = ((v279 >>> 31) | (((((v274 - (v277 & v3)) | 0) - ((((v275) >>> 0) < ((v278) >>> 0)) | 0)) | 0) << 1));
const v281 = ((1 & (1 & (v0 >>> 17))) | (v279 << 1));
const v282 = ((((((((((v281) >>> 0) < ((v2) >>> 0)) | 0) & ((((v280) | 0) === ((v3) | 0)) | 0)) | ((((v280) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v283 = (-v282);
const v284 = (v283 & v2);
const v285 = ((v281 - v284) | 0);
const v286 = ((v285 >>> 31) | (((((v280 - (v283 & v3)) | 0) - ((((v281) >>> 0) < ((v284) >>> 0)) | 0)) | 0) << 1));
const v287 = ((1 & (1 & (v0 >>> 16))) | (v285 << 1));
const v288 = ((((((((((v287) >>> 0) < ((v2) >>> 0)) | 0) & ((((v286) | 0) === ((v3) | 0)) | 0)) | ((((v286) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v289 = (-v288);
const v290 = (v289 & v2);
const v291 = ((v287 - v290) | 0);
const v292 = ((v291 >>> 31) | (((((v286 - (v289 & v3)) | 0) - ((((v287) >>> 0) < ((v290) >>> 0)) | 0)) | 0) << 1));
const v293 = ((1 & (1 & (v0 >>> 15))) | (v291 << 1));
const v294 = ((((((((((v293) >>> 0) < ((v2) >>> 0)) | 0) & ((((v292) | 0) === ((v3) | 0)) | 0)) | ((((v292) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v295 = (-v294);
const v296 = (v295 & v2);
const v297 = ((v293 - v296) | 0);
const v298 = ((v297 >>> 31) | (((((v292 - (v295 & v3)) | 0) - ((((v293) >>> 0) < ((v296) >>> 0)) | 0)) | 0) << 1));
const v299 = ((1 & (1 & (v0 >>> 14))) | (v297 << 1));
const v300 = ((((((((((v299) >>> 0) < ((v2) >>> 0)) | 0) & ((((v298) | 0) === ((v3) | 0)) | 0)) | ((((v298) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v301 = (-v300);
const v302 = (v301 & v2);
const v303 = ((v299 - v302) | 0);
const v304 = ((v303 >>> 31) | (((((v298 - (v301 & v3)) | 0) - ((((v299) >>> 0) < ((v302) >>> 0)) | 0)) | 0) << 1));
const v305 = ((1 & (1 & (v0 >>> 13))) | (v303 << 1));
const v306 = ((((((((((v305) >>> 0) < ((v2) >>> 0)) | 0) & ((((v304) | 0) === ((v3) | 0)) | 0)) | ((((v304) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v307 = (-v306);
const v308 = (v307 & v2);
const v309 = ((v305 - v308) | 0);
const v310 = ((v309 >>> 31) | (((((v304 - (v307 & v3)) | 0) - ((((v305) >>> 0) < ((v308) >>> 0)) | 0)) | 0) << 1));
const v311 = ((1 & (1 & (v0 >>> 12))) | (v309 << 1));
const v312 = ((((((((((v311) >>> 0) < ((v2) >>> 0)) | 0) & ((((v310) | 0) === ((v3) | 0)) | 0)) | ((((v310) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v313 = (-v312);
const v314 = (v313 & v2);
const v315 = ((v311 - v314) | 0);
const v316 = ((v315 >>> 31) | (((((v310 - (v313 & v3)) | 0) - ((((v311) >>> 0) < ((v314) >>> 0)) | 0)) | 0) << 1));
const v317 = ((1 & (1 & (v0 >>> 11))) | (v315 << 1));
const v318 = ((((((((((v317) >>> 0) < ((v2) >>> 0)) | 0) & ((((v316) | 0) === ((v3) | 0)) | 0)) | ((((v316) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v319 = (-v318);
const v320 = (v319 & v2);
const v321 = ((v317 - v320) | 0);
const v322 = ((v321 >>> 31) | (((((v316 - (v319 & v3)) | 0) - ((((v317) >>> 0) < ((v320) >>> 0)) | 0)) | 0) << 1));
const v323 = ((1 & (1 & (v0 >>> 10))) | (v321 << 1));
const v324 = ((((((((((v323) >>> 0) < ((v2) >>> 0)) | 0) & ((((v322) | 0) === ((v3) | 0)) | 0)) | ((((v322) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v325 = (-v324);
const v326 = (v325 & v2);
const v327 = ((v323 - v326) | 0);
const v328 = ((v327 >>> 31) | (((((v322 - (v325 & v3)) | 0) - ((((v323) >>> 0) < ((v326) >>> 0)) | 0)) | 0) << 1));
const v329 = ((1 & (1 & (v0 >>> 9))) | (v327 << 1));
const v330 = ((((((((((v329) >>> 0) < ((v2) >>> 0)) | 0) & ((((v328) | 0) === ((v3) | 0)) | 0)) | ((((v328) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v331 = (-v330);
const v332 = (v331 & v2);
const v333 = ((v329 - v332) | 0);
const v334 = ((v333 >>> 31) | (((((v328 - (v331 & v3)) | 0) - ((((v329) >>> 0) < ((v332) >>> 0)) | 0)) | 0) << 1));
const v335 = ((1 & (1 & (v0 >>> 8))) | (v333 << 1));
const v336 = ((((((((((v335) >>> 0) < ((v2) >>> 0)) | 0) & ((((v334) | 0) === ((v3) | 0)) | 0)) | ((((v334) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v337 = (-v336);
const v338 = (v337 & v2);
const v339 = ((v335 - v338) | 0);
const v340 = ((v339 >>> 31) | (((((v334 - (v337 & v3)) | 0) - ((((v335) >>> 0) < ((v338) >>> 0)) | 0)) | 0) << 1));
const v341 = ((1 & (1 & (v0 >>> 7))) | (v339 << 1));
const v342 = ((((((((((v341) >>> 0) < ((v2) >>> 0)) | 0) & ((((v340) | 0) === ((v3) | 0)) | 0)) | ((((v340) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v343 = (-v342);
const v344 = (v343 & v2);
const v345 = ((v341 - v344) | 0);
const v346 = ((v345 >>> 31) | (((((v340 - (v343 & v3)) | 0) - ((((v341) >>> 0) < ((v344) >>> 0)) | 0)) | 0) << 1));
const v347 = ((1 & (1 & (v0 >>> 6))) | (v345 << 1));
const v348 = ((((((((((v347) >>> 0) < ((v2) >>> 0)) | 0) & ((((v346) | 0) === ((v3) | 0)) | 0)) | ((((v346) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v349 = (-v348);
const v350 = (v349 & v2);
const v351 = ((v347 - v350) | 0);
const v352 = ((v351 >>> 31) | (((((v346 - (v349 & v3)) | 0) - ((((v347) >>> 0) < ((v350) >>> 0)) | 0)) | 0) << 1));
const v353 = ((1 & (1 & (v0 >>> 5))) | (v351 << 1));
const v354 = ((((((((((v353) >>> 0) < ((v2) >>> 0)) | 0) & ((((v352) | 0) === ((v3) | 0)) | 0)) | ((((v352) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v355 = (-v354);
const v356 = (v355 & v2);
const v357 = ((v353 - v356) | 0);
const v358 = ((v357 >>> 31) | (((((v352 - (v355 & v3)) | 0) - ((((v353) >>> 0) < ((v356) >>> 0)) | 0)) | 0) << 1));
const v359 = ((1 & (1 & (v0 >>> 4))) | (v357 << 1));
const v360 = ((((((((((v359) >>> 0) < ((v2) >>> 0)) | 0) & ((((v358) | 0) === ((v3) | 0)) | 0)) | ((((v358) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v361 = (-v360);
const v362 = (v361 & v2);
const v363 = ((v359 - v362) | 0);
const v364 = ((v363 >>> 31) | (((((v358 - (v361 & v3)) | 0) - ((((v359) >>> 0) < ((v362) >>> 0)) | 0)) | 0) << 1));
const v365 = ((1 & (1 & (v0 >>> 3))) | (v363 << 1));
const v366 = ((((((((((v365) >>> 0) < ((v2) >>> 0)) | 0) & ((((v364) | 0) === ((v3) | 0)) | 0)) | ((((v364) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v367 = (-v366);
const v368 = (v367 & v2);
const v369 = ((v365 - v368) | 0);
const v370 = ((v369 >>> 31) | (((((v364 - (v367 & v3)) | 0) - ((((v365) >>> 0) < ((v368) >>> 0)) | 0)) | 0) << 1));
const v371 = ((1 & (1 & (v0 >>> 2))) | (v369 << 1));
const v372 = ((((((((((v371) >>> 0) < ((v2) >>> 0)) | 0) & ((((v370) | 0) === ((v3) | 0)) | 0)) | ((((v370) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v373 = (-v372);
const v374 = (v373 & v2);
const v375 = ((v371 - v374) | 0);
const v376 = ((v375 >>> 31) | (((((v370 - (v373 & v3)) | 0) - ((((v371) >>> 0) < ((v374) >>> 0)) | 0)) | 0) << 1));
const v377 = ((1 & (1 & (v0 >>> 1))) | (v375 << 1));
const v378 = ((((((((((v377) >>> 0) < ((v2) >>> 0)) | 0) & ((((v376) | 0) === ((v3) | 0)) | 0)) | ((((v376) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
const v379 = (-v378);
const v380 = (v379 & v2);
const v381 = ((v377 - v380) | 0);
const v382 = ((v381 >>> 31) | (((((v376 - (v379 & v3)) | 0) - ((((v377) >>> 0) < ((v380) >>> 0)) | 0)) | 0) << 1));
const v383 = ((((((((((((((1 & (1 & (v0 >>> 0))) | (v381 << 1))) >>> 0) < ((v2) >>> 0)) | 0) & ((((v382) | 0) === ((v3) | 0)) | 0)) | ((((v382) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0) << 0) | ((v378 << 1) | ((v372 << 2) | ((v366 << 3) | ((v360 << 4) | ((v354 << 5) | ((v348 << 6) | ((v342 << 7) | ((v336 << 8) | ((v330 << 9) | ((v324 << 10) | ((v318 << 11) | ((v312 << 12) | ((v306 << 13) | ((v300 << 14) | ((v294 << 15) | ((v288 << 16) | ((v282 << 17) | ((v276 << 18) | ((v270 << 19) | ((v264 << 20) | ((v258 << 21) | ((v252 << 22) | ((v246 << 23) | ((v240 << 24) | ((v234 << 25) | ((v228 << 26) | ((v222 << 27) | ((v216 << 28) | ((v210 << 29) | ((v204 << 30) | (v198 << 31))))))))))))))))))))))))))))))));
return {r0: v383, r1: v195};
}



function u64_eq(v0, v1, v2, v3) {
    
    const v4 = (((((v0) | 0) === ((v2) | 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0));
return v4;
}



function u64_eqz(v0, v1) {
    
    const v2 = (((((v0 | v1)) | 0) === ((0) | 0)) | 0);
return v2;
}



function u64_from_f32(v0) {
    
    const v1 = Math.trunc(v0);
const v2 = Math.floor((v1 / 4294967296));
const v3 = (Math.trunc((v1 - (4294967296 * v2))) >>> 0) | 0;
const v4 = ((Math.trunc(v2) >>> 0) | 0 >> 0);
return {r0: v3, r1: v4};
}



function u64_from_f64(v0) {
    
    const v1 = Math.trunc(v0);
const v2 = Math.floor((v1 / 4294967296));
const v3 = (Math.trunc((v1 - (4294967296 * v2))) >>> 0) | 0;
const v4 = ((Math.trunc(v2) >>> 0) | 0 >> 0);
return {r0: v3, r1: v4};
}



function u64_from_i16(v0) {
    
    const v1 = ((((v0 << 16) >> 16) << 16) >> 16);
const v2 = (v1 >> 31);
return {r0: v1, r1: v2};
}



function u64_from_i32(v0) {
    
    const v1 = (v0 >> 31);
return {r0: v0, r1: v1};
}



function u64_from_i64(v0, v1) {
    
    const v2 = (v1 >> 0);
return {r0: v0, r1: v2};
}



function u64_from_i8(v0) {
    
    const v1 = ((((v0 << 24) >> 24) << 24) >> 24);
const v2 = (v1 >> 31);
return {r0: v1, r1: v2};
}



function u64_from_u16(v0) {
    
    const v1 = (65535 & (65535 & v0));
return {r0: v1, r1: 0};
}



function u64_from_u32(v0) {
    
    return {r0: v0, r1: 0};
}



function u64_from_u8(v0) {
    
    const v1 = (255 & (255 & v0));
return {r0: v1, r1: 0};
}



function u64_ge(v0, v1, v2, v3) {
    
    const v4 = ((((((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function u64_gt(v0, v1, v2, v3) {
    
    const v4 = ((((((v2) >>> 0) < ((v0) >>> 0)) | 0) & ((((v3) | 0) === ((v1) | 0)) | 0)) | ((((v3) >>> 0) < ((v1) >>> 0)) | 0));
return v4;
}



function u64_le(v0, v1, v2, v3) {
    
    const v4 = ((((((((((v2) >>> 0) < ((v0) >>> 0)) | 0) & ((((v3) | 0) === ((v1) | 0)) | 0)) | ((((v3) >>> 0) < ((v1) >>> 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function u64_lt(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) >>> 0) < ((v3) >>> 0)) | 0));
return v4;
}



function u64_max(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) >>> 0) < ((v3) >>> 0)) | 0));
const v5 = ((v4) ? (v2) : (v0));
const v6 = ((v4) ? (v3) : (v1));
return {r0: v5, r1: v6};
}



function u64_min(v0, v1, v2, v3) {
    
    const v4 = ((((((v0) >>> 0) < ((v2) >>> 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0)) | ((((v1) >>> 0) < ((v3) >>> 0)) | 0));
const v5 = ((v4) ? (v0) : (v2));
const v6 = ((v4) ? (v1) : (v3));
return {r0: v5, r1: v6};
}



function u64_mul(v0, v1, v2, v3) {
    
    const v4 = Math.imul(v2, v0);
const v5 = (65535 & v0);
const v6 = (v0 >>> 16);
const v7 = (65535 & v2);
const v8 = (v2 >>> 16);
const v9 = Math.imul(v7, v5);
const v10 = Math.imul(v7, v6);
const v11 = Math.imul(v8, v5);
const v12 = ((v11 + v10) | 0);
const v13 = (v12 << 16);
const v14 = ((((Math.imul(v2, v1) + Math.imul(v3, v0)) | 0) + ((((((((((-1 ^ ((v13 + v9) | 0)) & (v13 | v9)) | (v13 & v9)) >>> 31) + (((((-1 ^ v12) & (v11 | v10)) | (v11 & v10)) >>> 31) << 16)) | 0) + (v12 >>> 16)) | 0) + Math.imul(v8, v6)) | 0)) | 0);
return {r0: v4, r1: v14};
}



function u64_ne(v0, v1, v2, v3) {
    
    const v4 = (((((((((v0) | 0) === ((v2) | 0)) | 0) & ((((v1) | 0) === ((v3) | 0)) | 0))) | 0) === 0) | 0);
return v4;
}



function u64_not(v0, v1) {
    
    const v2 = (~v0);
const v3 = (~v1);
return {r0: v2, r1: v3};
}



function u64_or(v0, v1, v2, v3) {
    
    const v4 = (v2 | v0);
const v5 = (v3 | v1);
return {r0: v4, r1: v5};
}



function u64_popcnt(v0, v1) {
    
    const v2 = (((()=>{let x=((v1)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})() + (()=>{let x=((v0)>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})()) | 0);
return {r0: v2, r1: 0};
}



function u64_rem(v0, v1, v2, v3) {
    
    const v4 = (1 & (1 & (v1 >>> 31)));
const v5 = (-((((((((((v4) >>> 0) < ((v2) >>> 0)) | 0) & ((((0) | 0) === ((v3) | 0)) | 0)) | ((((0) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v6 = (v5 & v2);
const v7 = ((v4 - v6) | 0);
const v8 = ((v7 >>> 31) | (((((0 - (v5 & v3)) | 0) - ((((v4) >>> 0) < ((v6) >>> 0)) | 0)) | 0) << 1));
const v9 = ((1 & (1 & (v1 >>> 30))) | (v7 << 1));
const v10 = (-((((((((((v9) >>> 0) < ((v2) >>> 0)) | 0) & ((((v8) | 0) === ((v3) | 0)) | 0)) | ((((v8) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v11 = (v10 & v2);
const v12 = ((v9 - v11) | 0);
const v13 = ((v12 >>> 31) | (((((v8 - (v10 & v3)) | 0) - ((((v9) >>> 0) < ((v11) >>> 0)) | 0)) | 0) << 1));
const v14 = ((1 & (1 & (v1 >>> 29))) | (v12 << 1));
const v15 = (-((((((((((v14) >>> 0) < ((v2) >>> 0)) | 0) & ((((v13) | 0) === ((v3) | 0)) | 0)) | ((((v13) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v16 = (v15 & v2);
const v17 = ((v14 - v16) | 0);
const v18 = ((v17 >>> 31) | (((((v13 - (v15 & v3)) | 0) - ((((v14) >>> 0) < ((v16) >>> 0)) | 0)) | 0) << 1));
const v19 = ((1 & (1 & (v1 >>> 28))) | (v17 << 1));
const v20 = (-((((((((((v19) >>> 0) < ((v2) >>> 0)) | 0) & ((((v18) | 0) === ((v3) | 0)) | 0)) | ((((v18) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v21 = (v20 & v2);
const v22 = ((v19 - v21) | 0);
const v23 = ((v22 >>> 31) | (((((v18 - (v20 & v3)) | 0) - ((((v19) >>> 0) < ((v21) >>> 0)) | 0)) | 0) << 1));
const v24 = ((1 & (1 & (v1 >>> 27))) | (v22 << 1));
const v25 = (-((((((((((v24) >>> 0) < ((v2) >>> 0)) | 0) & ((((v23) | 0) === ((v3) | 0)) | 0)) | ((((v23) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v26 = (v25 & v2);
const v27 = ((v24 - v26) | 0);
const v28 = ((v27 >>> 31) | (((((v23 - (v25 & v3)) | 0) - ((((v24) >>> 0) < ((v26) >>> 0)) | 0)) | 0) << 1));
const v29 = ((1 & (1 & (v1 >>> 26))) | (v27 << 1));
const v30 = (-((((((((((v29) >>> 0) < ((v2) >>> 0)) | 0) & ((((v28) | 0) === ((v3) | 0)) | 0)) | ((((v28) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v31 = (v30 & v2);
const v32 = ((v29 - v31) | 0);
const v33 = ((v32 >>> 31) | (((((v28 - (v30 & v3)) | 0) - ((((v29) >>> 0) < ((v31) >>> 0)) | 0)) | 0) << 1));
const v34 = ((1 & (1 & (v1 >>> 25))) | (v32 << 1));
const v35 = (-((((((((((v34) >>> 0) < ((v2) >>> 0)) | 0) & ((((v33) | 0) === ((v3) | 0)) | 0)) | ((((v33) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v36 = (v35 & v2);
const v37 = ((v34 - v36) | 0);
const v38 = ((v37 >>> 31) | (((((v33 - (v35 & v3)) | 0) - ((((v34) >>> 0) < ((v36) >>> 0)) | 0)) | 0) << 1));
const v39 = ((1 & (1 & (v1 >>> 24))) | (v37 << 1));
const v40 = (-((((((((((v39) >>> 0) < ((v2) >>> 0)) | 0) & ((((v38) | 0) === ((v3) | 0)) | 0)) | ((((v38) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v41 = (v40 & v2);
const v42 = ((v39 - v41) | 0);
const v43 = ((v42 >>> 31) | (((((v38 - (v40 & v3)) | 0) - ((((v39) >>> 0) < ((v41) >>> 0)) | 0)) | 0) << 1));
const v44 = ((1 & (1 & (v1 >>> 23))) | (v42 << 1));
const v45 = (-((((((((((v44) >>> 0) < ((v2) >>> 0)) | 0) & ((((v43) | 0) === ((v3) | 0)) | 0)) | ((((v43) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v46 = (v45 & v2);
const v47 = ((v44 - v46) | 0);
const v48 = ((v47 >>> 31) | (((((v43 - (v45 & v3)) | 0) - ((((v44) >>> 0) < ((v46) >>> 0)) | 0)) | 0) << 1));
const v49 = ((1 & (1 & (v1 >>> 22))) | (v47 << 1));
const v50 = (-((((((((((v49) >>> 0) < ((v2) >>> 0)) | 0) & ((((v48) | 0) === ((v3) | 0)) | 0)) | ((((v48) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v51 = (v50 & v2);
const v52 = ((v49 - v51) | 0);
const v53 = ((v52 >>> 31) | (((((v48 - (v50 & v3)) | 0) - ((((v49) >>> 0) < ((v51) >>> 0)) | 0)) | 0) << 1));
const v54 = ((1 & (1 & (v1 >>> 21))) | (v52 << 1));
const v55 = (-((((((((((v54) >>> 0) < ((v2) >>> 0)) | 0) & ((((v53) | 0) === ((v3) | 0)) | 0)) | ((((v53) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v56 = (v55 & v2);
const v57 = ((v54 - v56) | 0);
const v58 = ((v57 >>> 31) | (((((v53 - (v55 & v3)) | 0) - ((((v54) >>> 0) < ((v56) >>> 0)) | 0)) | 0) << 1));
const v59 = ((1 & (1 & (v1 >>> 20))) | (v57 << 1));
const v60 = (-((((((((((v59) >>> 0) < ((v2) >>> 0)) | 0) & ((((v58) | 0) === ((v3) | 0)) | 0)) | ((((v58) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v61 = (v60 & v2);
const v62 = ((v59 - v61) | 0);
const v63 = ((v62 >>> 31) | (((((v58 - (v60 & v3)) | 0) - ((((v59) >>> 0) < ((v61) >>> 0)) | 0)) | 0) << 1));
const v64 = ((1 & (1 & (v1 >>> 19))) | (v62 << 1));
const v65 = (-((((((((((v64) >>> 0) < ((v2) >>> 0)) | 0) & ((((v63) | 0) === ((v3) | 0)) | 0)) | ((((v63) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v66 = (v65 & v2);
const v67 = ((v64 - v66) | 0);
const v68 = ((v67 >>> 31) | (((((v63 - (v65 & v3)) | 0) - ((((v64) >>> 0) < ((v66) >>> 0)) | 0)) | 0) << 1));
const v69 = ((1 & (1 & (v1 >>> 18))) | (v67 << 1));
const v70 = (-((((((((((v69) >>> 0) < ((v2) >>> 0)) | 0) & ((((v68) | 0) === ((v3) | 0)) | 0)) | ((((v68) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v71 = (v70 & v2);
const v72 = ((v69 - v71) | 0);
const v73 = ((v72 >>> 31) | (((((v68 - (v70 & v3)) | 0) - ((((v69) >>> 0) < ((v71) >>> 0)) | 0)) | 0) << 1));
const v74 = ((1 & (1 & (v1 >>> 17))) | (v72 << 1));
const v75 = (-((((((((((v74) >>> 0) < ((v2) >>> 0)) | 0) & ((((v73) | 0) === ((v3) | 0)) | 0)) | ((((v73) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v76 = (v75 & v2);
const v77 = ((v74 - v76) | 0);
const v78 = ((v77 >>> 31) | (((((v73 - (v75 & v3)) | 0) - ((((v74) >>> 0) < ((v76) >>> 0)) | 0)) | 0) << 1));
const v79 = ((1 & (1 & (v1 >>> 16))) | (v77 << 1));
const v80 = (-((((((((((v79) >>> 0) < ((v2) >>> 0)) | 0) & ((((v78) | 0) === ((v3) | 0)) | 0)) | ((((v78) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v81 = (v80 & v2);
const v82 = ((v79 - v81) | 0);
const v83 = ((v82 >>> 31) | (((((v78 - (v80 & v3)) | 0) - ((((v79) >>> 0) < ((v81) >>> 0)) | 0)) | 0) << 1));
const v84 = ((1 & (1 & (v1 >>> 15))) | (v82 << 1));
const v85 = (-((((((((((v84) >>> 0) < ((v2) >>> 0)) | 0) & ((((v83) | 0) === ((v3) | 0)) | 0)) | ((((v83) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v86 = (v85 & v2);
const v87 = ((v84 - v86) | 0);
const v88 = ((v87 >>> 31) | (((((v83 - (v85 & v3)) | 0) - ((((v84) >>> 0) < ((v86) >>> 0)) | 0)) | 0) << 1));
const v89 = ((1 & (1 & (v1 >>> 14))) | (v87 << 1));
const v90 = (-((((((((((v89) >>> 0) < ((v2) >>> 0)) | 0) & ((((v88) | 0) === ((v3) | 0)) | 0)) | ((((v88) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v91 = (v90 & v2);
const v92 = ((v89 - v91) | 0);
const v93 = ((v92 >>> 31) | (((((v88 - (v90 & v3)) | 0) - ((((v89) >>> 0) < ((v91) >>> 0)) | 0)) | 0) << 1));
const v94 = ((1 & (1 & (v1 >>> 13))) | (v92 << 1));
const v95 = (-((((((((((v94) >>> 0) < ((v2) >>> 0)) | 0) & ((((v93) | 0) === ((v3) | 0)) | 0)) | ((((v93) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v96 = (v95 & v2);
const v97 = ((v94 - v96) | 0);
const v98 = ((v97 >>> 31) | (((((v93 - (v95 & v3)) | 0) - ((((v94) >>> 0) < ((v96) >>> 0)) | 0)) | 0) << 1));
const v99 = ((1 & (1 & (v1 >>> 12))) | (v97 << 1));
const v100 = (-((((((((((v99) >>> 0) < ((v2) >>> 0)) | 0) & ((((v98) | 0) === ((v3) | 0)) | 0)) | ((((v98) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v101 = (v100 & v2);
const v102 = ((v99 - v101) | 0);
const v103 = ((v102 >>> 31) | (((((v98 - (v100 & v3)) | 0) - ((((v99) >>> 0) < ((v101) >>> 0)) | 0)) | 0) << 1));
const v104 = ((1 & (1 & (v1 >>> 11))) | (v102 << 1));
const v105 = (-((((((((((v104) >>> 0) < ((v2) >>> 0)) | 0) & ((((v103) | 0) === ((v3) | 0)) | 0)) | ((((v103) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v106 = (v105 & v2);
const v107 = ((v104 - v106) | 0);
const v108 = ((v107 >>> 31) | (((((v103 - (v105 & v3)) | 0) - ((((v104) >>> 0) < ((v106) >>> 0)) | 0)) | 0) << 1));
const v109 = ((1 & (1 & (v1 >>> 10))) | (v107 << 1));
const v110 = (-((((((((((v109) >>> 0) < ((v2) >>> 0)) | 0) & ((((v108) | 0) === ((v3) | 0)) | 0)) | ((((v108) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v111 = (v110 & v2);
const v112 = ((v109 - v111) | 0);
const v113 = ((v112 >>> 31) | (((((v108 - (v110 & v3)) | 0) - ((((v109) >>> 0) < ((v111) >>> 0)) | 0)) | 0) << 1));
const v114 = ((1 & (1 & (v1 >>> 9))) | (v112 << 1));
const v115 = (-((((((((((v114) >>> 0) < ((v2) >>> 0)) | 0) & ((((v113) | 0) === ((v3) | 0)) | 0)) | ((((v113) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v116 = (v115 & v2);
const v117 = ((v114 - v116) | 0);
const v118 = ((v117 >>> 31) | (((((v113 - (v115 & v3)) | 0) - ((((v114) >>> 0) < ((v116) >>> 0)) | 0)) | 0) << 1));
const v119 = ((1 & (1 & (v1 >>> 8))) | (v117 << 1));
const v120 = (-((((((((((v119) >>> 0) < ((v2) >>> 0)) | 0) & ((((v118) | 0) === ((v3) | 0)) | 0)) | ((((v118) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v121 = (v120 & v2);
const v122 = ((v119 - v121) | 0);
const v123 = ((v122 >>> 31) | (((((v118 - (v120 & v3)) | 0) - ((((v119) >>> 0) < ((v121) >>> 0)) | 0)) | 0) << 1));
const v124 = ((1 & (1 & (v1 >>> 7))) | (v122 << 1));
const v125 = (-((((((((((v124) >>> 0) < ((v2) >>> 0)) | 0) & ((((v123) | 0) === ((v3) | 0)) | 0)) | ((((v123) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v126 = (v125 & v2);
const v127 = ((v124 - v126) | 0);
const v128 = ((v127 >>> 31) | (((((v123 - (v125 & v3)) | 0) - ((((v124) >>> 0) < ((v126) >>> 0)) | 0)) | 0) << 1));
const v129 = ((1 & (1 & (v1 >>> 6))) | (v127 << 1));
const v130 = (-((((((((((v129) >>> 0) < ((v2) >>> 0)) | 0) & ((((v128) | 0) === ((v3) | 0)) | 0)) | ((((v128) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v131 = (v130 & v2);
const v132 = ((v129 - v131) | 0);
const v133 = ((v132 >>> 31) | (((((v128 - (v130 & v3)) | 0) - ((((v129) >>> 0) < ((v131) >>> 0)) | 0)) | 0) << 1));
const v134 = ((1 & (1 & (v1 >>> 5))) | (v132 << 1));
const v135 = (-((((((((((v134) >>> 0) < ((v2) >>> 0)) | 0) & ((((v133) | 0) === ((v3) | 0)) | 0)) | ((((v133) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v136 = (v135 & v2);
const v137 = ((v134 - v136) | 0);
const v138 = ((v137 >>> 31) | (((((v133 - (v135 & v3)) | 0) - ((((v134) >>> 0) < ((v136) >>> 0)) | 0)) | 0) << 1));
const v139 = ((1 & (1 & (v1 >>> 4))) | (v137 << 1));
const v140 = (-((((((((((v139) >>> 0) < ((v2) >>> 0)) | 0) & ((((v138) | 0) === ((v3) | 0)) | 0)) | ((((v138) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v141 = (v140 & v2);
const v142 = ((v139 - v141) | 0);
const v143 = ((v142 >>> 31) | (((((v138 - (v140 & v3)) | 0) - ((((v139) >>> 0) < ((v141) >>> 0)) | 0)) | 0) << 1));
const v144 = ((1 & (1 & (v1 >>> 3))) | (v142 << 1));
const v145 = (-((((((((((v144) >>> 0) < ((v2) >>> 0)) | 0) & ((((v143) | 0) === ((v3) | 0)) | 0)) | ((((v143) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v146 = (v145 & v2);
const v147 = ((v144 - v146) | 0);
const v148 = ((v147 >>> 31) | (((((v143 - (v145 & v3)) | 0) - ((((v144) >>> 0) < ((v146) >>> 0)) | 0)) | 0) << 1));
const v149 = ((1 & (1 & (v1 >>> 2))) | (v147 << 1));
const v150 = (-((((((((((v149) >>> 0) < ((v2) >>> 0)) | 0) & ((((v148) | 0) === ((v3) | 0)) | 0)) | ((((v148) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v151 = (v150 & v2);
const v152 = ((v149 - v151) | 0);
const v153 = ((v152 >>> 31) | (((((v148 - (v150 & v3)) | 0) - ((((v149) >>> 0) < ((v151) >>> 0)) | 0)) | 0) << 1));
const v154 = ((1 & (1 & (v1 >>> 1))) | (v152 << 1));
const v155 = (-((((((((((v154) >>> 0) < ((v2) >>> 0)) | 0) & ((((v153) | 0) === ((v3) | 0)) | 0)) | ((((v153) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v156 = (v155 & v2);
const v157 = ((v154 - v156) | 0);
const v158 = ((v157 >>> 31) | (((((v153 - (v155 & v3)) | 0) - ((((v154) >>> 0) < ((v156) >>> 0)) | 0)) | 0) << 1));
const v159 = ((1 & (1 & (v1 >>> 0))) | (v157 << 1));
const v160 = (-((((((((((v159) >>> 0) < ((v2) >>> 0)) | 0) & ((((v158) | 0) === ((v3) | 0)) | 0)) | ((((v158) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v161 = (v160 & v2);
const v162 = ((v159 - v161) | 0);
const v163 = ((v162 >>> 31) | (((((v158 - (v160 & v3)) | 0) - ((((v159) >>> 0) < ((v161) >>> 0)) | 0)) | 0) << 1));
const v164 = ((1 & (1 & (v0 >>> 31))) | (v162 << 1));
const v165 = (-((((((((((v164) >>> 0) < ((v2) >>> 0)) | 0) & ((((v163) | 0) === ((v3) | 0)) | 0)) | ((((v163) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v166 = (v165 & v2);
const v167 = ((v164 - v166) | 0);
const v168 = ((v167 >>> 31) | (((((v163 - (v165 & v3)) | 0) - ((((v164) >>> 0) < ((v166) >>> 0)) | 0)) | 0) << 1));
const v169 = ((1 & (1 & (v0 >>> 30))) | (v167 << 1));
const v170 = (-((((((((((v169) >>> 0) < ((v2) >>> 0)) | 0) & ((((v168) | 0) === ((v3) | 0)) | 0)) | ((((v168) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v171 = (v170 & v2);
const v172 = ((v169 - v171) | 0);
const v173 = ((v172 >>> 31) | (((((v168 - (v170 & v3)) | 0) - ((((v169) >>> 0) < ((v171) >>> 0)) | 0)) | 0) << 1));
const v174 = ((1 & (1 & (v0 >>> 29))) | (v172 << 1));
const v175 = (-((((((((((v174) >>> 0) < ((v2) >>> 0)) | 0) & ((((v173) | 0) === ((v3) | 0)) | 0)) | ((((v173) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v176 = (v175 & v2);
const v177 = ((v174 - v176) | 0);
const v178 = ((v177 >>> 31) | (((((v173 - (v175 & v3)) | 0) - ((((v174) >>> 0) < ((v176) >>> 0)) | 0)) | 0) << 1));
const v179 = ((1 & (1 & (v0 >>> 28))) | (v177 << 1));
const v180 = (-((((((((((v179) >>> 0) < ((v2) >>> 0)) | 0) & ((((v178) | 0) === ((v3) | 0)) | 0)) | ((((v178) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v181 = (v180 & v2);
const v182 = ((v179 - v181) | 0);
const v183 = ((v182 >>> 31) | (((((v178 - (v180 & v3)) | 0) - ((((v179) >>> 0) < ((v181) >>> 0)) | 0)) | 0) << 1));
const v184 = ((1 & (1 & (v0 >>> 27))) | (v182 << 1));
const v185 = (-((((((((((v184) >>> 0) < ((v2) >>> 0)) | 0) & ((((v183) | 0) === ((v3) | 0)) | 0)) | ((((v183) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v186 = (v185 & v2);
const v187 = ((v184 - v186) | 0);
const v188 = ((v187 >>> 31) | (((((v183 - (v185 & v3)) | 0) - ((((v184) >>> 0) < ((v186) >>> 0)) | 0)) | 0) << 1));
const v189 = ((1 & (1 & (v0 >>> 26))) | (v187 << 1));
const v190 = (-((((((((((v189) >>> 0) < ((v2) >>> 0)) | 0) & ((((v188) | 0) === ((v3) | 0)) | 0)) | ((((v188) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v191 = (v190 & v2);
const v192 = ((v189 - v191) | 0);
const v193 = ((v192 >>> 31) | (((((v188 - (v190 & v3)) | 0) - ((((v189) >>> 0) < ((v191) >>> 0)) | 0)) | 0) << 1));
const v194 = ((1 & (1 & (v0 >>> 25))) | (v192 << 1));
const v195 = (-((((((((((v194) >>> 0) < ((v2) >>> 0)) | 0) & ((((v193) | 0) === ((v3) | 0)) | 0)) | ((((v193) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v196 = (v195 & v2);
const v197 = ((v194 - v196) | 0);
const v198 = ((v197 >>> 31) | (((((v193 - (v195 & v3)) | 0) - ((((v194) >>> 0) < ((v196) >>> 0)) | 0)) | 0) << 1));
const v199 = ((1 & (1 & (v0 >>> 24))) | (v197 << 1));
const v200 = (-((((((((((v199) >>> 0) < ((v2) >>> 0)) | 0) & ((((v198) | 0) === ((v3) | 0)) | 0)) | ((((v198) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v201 = (v200 & v2);
const v202 = ((v199 - v201) | 0);
const v203 = ((v202 >>> 31) | (((((v198 - (v200 & v3)) | 0) - ((((v199) >>> 0) < ((v201) >>> 0)) | 0)) | 0) << 1));
const v204 = ((1 & (1 & (v0 >>> 23))) | (v202 << 1));
const v205 = (-((((((((((v204) >>> 0) < ((v2) >>> 0)) | 0) & ((((v203) | 0) === ((v3) | 0)) | 0)) | ((((v203) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v206 = (v205 & v2);
const v207 = ((v204 - v206) | 0);
const v208 = ((v207 >>> 31) | (((((v203 - (v205 & v3)) | 0) - ((((v204) >>> 0) < ((v206) >>> 0)) | 0)) | 0) << 1));
const v209 = ((1 & (1 & (v0 >>> 22))) | (v207 << 1));
const v210 = (-((((((((((v209) >>> 0) < ((v2) >>> 0)) | 0) & ((((v208) | 0) === ((v3) | 0)) | 0)) | ((((v208) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v211 = (v210 & v2);
const v212 = ((v209 - v211) | 0);
const v213 = ((v212 >>> 31) | (((((v208 - (v210 & v3)) | 0) - ((((v209) >>> 0) < ((v211) >>> 0)) | 0)) | 0) << 1));
const v214 = ((1 & (1 & (v0 >>> 21))) | (v212 << 1));
const v215 = (-((((((((((v214) >>> 0) < ((v2) >>> 0)) | 0) & ((((v213) | 0) === ((v3) | 0)) | 0)) | ((((v213) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v216 = (v215 & v2);
const v217 = ((v214 - v216) | 0);
const v218 = ((v217 >>> 31) | (((((v213 - (v215 & v3)) | 0) - ((((v214) >>> 0) < ((v216) >>> 0)) | 0)) | 0) << 1));
const v219 = ((1 & (1 & (v0 >>> 20))) | (v217 << 1));
const v220 = (-((((((((((v219) >>> 0) < ((v2) >>> 0)) | 0) & ((((v218) | 0) === ((v3) | 0)) | 0)) | ((((v218) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v221 = (v220 & v2);
const v222 = ((v219 - v221) | 0);
const v223 = ((v222 >>> 31) | (((((v218 - (v220 & v3)) | 0) - ((((v219) >>> 0) < ((v221) >>> 0)) | 0)) | 0) << 1));
const v224 = ((1 & (1 & (v0 >>> 19))) | (v222 << 1));
const v225 = (-((((((((((v224) >>> 0) < ((v2) >>> 0)) | 0) & ((((v223) | 0) === ((v3) | 0)) | 0)) | ((((v223) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v226 = (v225 & v2);
const v227 = ((v224 - v226) | 0);
const v228 = ((v227 >>> 31) | (((((v223 - (v225 & v3)) | 0) - ((((v224) >>> 0) < ((v226) >>> 0)) | 0)) | 0) << 1));
const v229 = ((1 & (1 & (v0 >>> 18))) | (v227 << 1));
const v230 = (-((((((((((v229) >>> 0) < ((v2) >>> 0)) | 0) & ((((v228) | 0) === ((v3) | 0)) | 0)) | ((((v228) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v231 = (v230 & v2);
const v232 = ((v229 - v231) | 0);
const v233 = ((v232 >>> 31) | (((((v228 - (v230 & v3)) | 0) - ((((v229) >>> 0) < ((v231) >>> 0)) | 0)) | 0) << 1));
const v234 = ((1 & (1 & (v0 >>> 17))) | (v232 << 1));
const v235 = (-((((((((((v234) >>> 0) < ((v2) >>> 0)) | 0) & ((((v233) | 0) === ((v3) | 0)) | 0)) | ((((v233) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v236 = (v235 & v2);
const v237 = ((v234 - v236) | 0);
const v238 = ((v237 >>> 31) | (((((v233 - (v235 & v3)) | 0) - ((((v234) >>> 0) < ((v236) >>> 0)) | 0)) | 0) << 1));
const v239 = ((1 & (1 & (v0 >>> 16))) | (v237 << 1));
const v240 = (-((((((((((v239) >>> 0) < ((v2) >>> 0)) | 0) & ((((v238) | 0) === ((v3) | 0)) | 0)) | ((((v238) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v241 = (v240 & v2);
const v242 = ((v239 - v241) | 0);
const v243 = ((v242 >>> 31) | (((((v238 - (v240 & v3)) | 0) - ((((v239) >>> 0) < ((v241) >>> 0)) | 0)) | 0) << 1));
const v244 = ((1 & (1 & (v0 >>> 15))) | (v242 << 1));
const v245 = (-((((((((((v244) >>> 0) < ((v2) >>> 0)) | 0) & ((((v243) | 0) === ((v3) | 0)) | 0)) | ((((v243) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v246 = (v245 & v2);
const v247 = ((v244 - v246) | 0);
const v248 = ((v247 >>> 31) | (((((v243 - (v245 & v3)) | 0) - ((((v244) >>> 0) < ((v246) >>> 0)) | 0)) | 0) << 1));
const v249 = ((1 & (1 & (v0 >>> 14))) | (v247 << 1));
const v250 = (-((((((((((v249) >>> 0) < ((v2) >>> 0)) | 0) & ((((v248) | 0) === ((v3) | 0)) | 0)) | ((((v248) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v251 = (v250 & v2);
const v252 = ((v249 - v251) | 0);
const v253 = ((v252 >>> 31) | (((((v248 - (v250 & v3)) | 0) - ((((v249) >>> 0) < ((v251) >>> 0)) | 0)) | 0) << 1));
const v254 = ((1 & (1 & (v0 >>> 13))) | (v252 << 1));
const v255 = (-((((((((((v254) >>> 0) < ((v2) >>> 0)) | 0) & ((((v253) | 0) === ((v3) | 0)) | 0)) | ((((v253) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v256 = (v255 & v2);
const v257 = ((v254 - v256) | 0);
const v258 = ((v257 >>> 31) | (((((v253 - (v255 & v3)) | 0) - ((((v254) >>> 0) < ((v256) >>> 0)) | 0)) | 0) << 1));
const v259 = ((1 & (1 & (v0 >>> 12))) | (v257 << 1));
const v260 = (-((((((((((v259) >>> 0) < ((v2) >>> 0)) | 0) & ((((v258) | 0) === ((v3) | 0)) | 0)) | ((((v258) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v261 = (v260 & v2);
const v262 = ((v259 - v261) | 0);
const v263 = ((v262 >>> 31) | (((((v258 - (v260 & v3)) | 0) - ((((v259) >>> 0) < ((v261) >>> 0)) | 0)) | 0) << 1));
const v264 = ((1 & (1 & (v0 >>> 11))) | (v262 << 1));
const v265 = (-((((((((((v264) >>> 0) < ((v2) >>> 0)) | 0) & ((((v263) | 0) === ((v3) | 0)) | 0)) | ((((v263) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v266 = (v265 & v2);
const v267 = ((v264 - v266) | 0);
const v268 = ((v267 >>> 31) | (((((v263 - (v265 & v3)) | 0) - ((((v264) >>> 0) < ((v266) >>> 0)) | 0)) | 0) << 1));
const v269 = ((1 & (1 & (v0 >>> 10))) | (v267 << 1));
const v270 = (-((((((((((v269) >>> 0) < ((v2) >>> 0)) | 0) & ((((v268) | 0) === ((v3) | 0)) | 0)) | ((((v268) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v271 = (v270 & v2);
const v272 = ((v269 - v271) | 0);
const v273 = ((v272 >>> 31) | (((((v268 - (v270 & v3)) | 0) - ((((v269) >>> 0) < ((v271) >>> 0)) | 0)) | 0) << 1));
const v274 = ((1 & (1 & (v0 >>> 9))) | (v272 << 1));
const v275 = (-((((((((((v274) >>> 0) < ((v2) >>> 0)) | 0) & ((((v273) | 0) === ((v3) | 0)) | 0)) | ((((v273) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v276 = (v275 & v2);
const v277 = ((v274 - v276) | 0);
const v278 = ((v277 >>> 31) | (((((v273 - (v275 & v3)) | 0) - ((((v274) >>> 0) < ((v276) >>> 0)) | 0)) | 0) << 1));
const v279 = ((1 & (1 & (v0 >>> 8))) | (v277 << 1));
const v280 = (-((((((((((v279) >>> 0) < ((v2) >>> 0)) | 0) & ((((v278) | 0) === ((v3) | 0)) | 0)) | ((((v278) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v281 = (v280 & v2);
const v282 = ((v279 - v281) | 0);
const v283 = ((v282 >>> 31) | (((((v278 - (v280 & v3)) | 0) - ((((v279) >>> 0) < ((v281) >>> 0)) | 0)) | 0) << 1));
const v284 = ((1 & (1 & (v0 >>> 7))) | (v282 << 1));
const v285 = (-((((((((((v284) >>> 0) < ((v2) >>> 0)) | 0) & ((((v283) | 0) === ((v3) | 0)) | 0)) | ((((v283) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v286 = (v285 & v2);
const v287 = ((v284 - v286) | 0);
const v288 = ((v287 >>> 31) | (((((v283 - (v285 & v3)) | 0) - ((((v284) >>> 0) < ((v286) >>> 0)) | 0)) | 0) << 1));
const v289 = ((1 & (1 & (v0 >>> 6))) | (v287 << 1));
const v290 = (-((((((((((v289) >>> 0) < ((v2) >>> 0)) | 0) & ((((v288) | 0) === ((v3) | 0)) | 0)) | ((((v288) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v291 = (v290 & v2);
const v292 = ((v289 - v291) | 0);
const v293 = ((v292 >>> 31) | (((((v288 - (v290 & v3)) | 0) - ((((v289) >>> 0) < ((v291) >>> 0)) | 0)) | 0) << 1));
const v294 = ((1 & (1 & (v0 >>> 5))) | (v292 << 1));
const v295 = (-((((((((((v294) >>> 0) < ((v2) >>> 0)) | 0) & ((((v293) | 0) === ((v3) | 0)) | 0)) | ((((v293) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v296 = (v295 & v2);
const v297 = ((v294 - v296) | 0);
const v298 = ((v297 >>> 31) | (((((v293 - (v295 & v3)) | 0) - ((((v294) >>> 0) < ((v296) >>> 0)) | 0)) | 0) << 1));
const v299 = ((1 & (1 & (v0 >>> 4))) | (v297 << 1));
const v300 = (-((((((((((v299) >>> 0) < ((v2) >>> 0)) | 0) & ((((v298) | 0) === ((v3) | 0)) | 0)) | ((((v298) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v301 = (v300 & v2);
const v302 = ((v299 - v301) | 0);
const v303 = ((v302 >>> 31) | (((((v298 - (v300 & v3)) | 0) - ((((v299) >>> 0) < ((v301) >>> 0)) | 0)) | 0) << 1));
const v304 = ((1 & (1 & (v0 >>> 3))) | (v302 << 1));
const v305 = (-((((((((((v304) >>> 0) < ((v2) >>> 0)) | 0) & ((((v303) | 0) === ((v3) | 0)) | 0)) | ((((v303) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v306 = (v305 & v2);
const v307 = ((v304 - v306) | 0);
const v308 = ((v307 >>> 31) | (((((v303 - (v305 & v3)) | 0) - ((((v304) >>> 0) < ((v306) >>> 0)) | 0)) | 0) << 1));
const v309 = ((1 & (1 & (v0 >>> 2))) | (v307 << 1));
const v310 = (-((((((((((v309) >>> 0) < ((v2) >>> 0)) | 0) & ((((v308) | 0) === ((v3) | 0)) | 0)) | ((((v308) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v311 = (v310 & v2);
const v312 = ((v309 - v311) | 0);
const v313 = ((v312 >>> 31) | (((((v308 - (v310 & v3)) | 0) - ((((v309) >>> 0) < ((v311) >>> 0)) | 0)) | 0) << 1));
const v314 = ((1 & (1 & (v0 >>> 1))) | (v312 << 1));
const v315 = (-((((((((((v314) >>> 0) < ((v2) >>> 0)) | 0) & ((((v313) | 0) === ((v3) | 0)) | 0)) | ((((v313) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v316 = (v315 & v2);
const v317 = ((v314 - v316) | 0);
const v318 = ((v317 >>> 31) | (((((v313 - (v315 & v3)) | 0) - ((((v314) >>> 0) < ((v316) >>> 0)) | 0)) | 0) << 1));
const v319 = ((1 & (1 & (v0 >>> 0))) | (v317 << 1));
const v320 = (-((((((((((v319) >>> 0) < ((v2) >>> 0)) | 0) & ((((v318) | 0) === ((v3) | 0)) | 0)) | ((((v318) >>> 0) < ((v3) >>> 0)) | 0))) | 0) === 0) | 0));
const v321 = (v320 & v2);
const v322 = ((v319 - v321) | 0);
const v323 = ((((v318 - (v320 & v3)) | 0) - ((((v319) >>> 0) < ((v321) >>> 0)) | 0)) | 0);
return {r0: v322, r1: v323};
}



function u64_rotl(v0, v1, v2) {
    
    const v3 = (63 & (63 & ((0 - (63 & v2)) | 0)));
const v4 = (31 & v3);
const v5 = ((32 - v4) | 0);
const v6 = (v3 >>> 5);
const v7 = ((((v3) | 0) === 0) | 0);
const v8 = ((((v3) | 0) === ((32) | 0)) | 0);
const v9 = (v1 >>> v4);
const v10 = (v0 >>> v4);
const v11 = (v1 << v5);
const v12 = (v0 << v5);
const v13 = ((v7) ? (v1) : (((v8) ? (v0) : (((v6) ? ((v11 | v10)) : ((v12 | v9)))))));
const v14 = ((v7) ? (v0) : (((v8) ? (v1) : (((v6) ? ((v12 | v9)) : ((v11 | v10)))))));
return {r0: v14, r1: v13};
}



function u64_rotr(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = ((32 - v4) | 0);
const v6 = (v3 >>> 5);
const v7 = ((((v3) | 0) === 0) | 0);
const v8 = ((((v3) | 0) === ((32) | 0)) | 0);
const v9 = (v1 >>> v4);
const v10 = (v0 >>> v4);
const v11 = (v1 << v5);
const v12 = (v0 << v5);
const v13 = ((v7) ? (v1) : (((v8) ? (v0) : (((v6) ? ((v11 | v10)) : ((v12 | v9)))))));
const v14 = ((v7) ? (v0) : (((v8) ? (v1) : (((v6) ? ((v12 | v9)) : ((v11 | v10)))))));
return {r0: v14, r1: v13};
}



function u64_shl(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = (v3 >>> 5);
const v6 = ((((v3) | 0) === 0) | 0);
const v7 = ((v6) ? (v1) : (((v5) ? ((v0 << v4)) : (((v0 >>> ((32 - v4) | 0)) | (v1 << v4))))));
const v8 = ((v6) ? (v0) : (((v5) ? (0) : ((v0 << v4)))));
return {r0: v8, r1: v7};
}



function u64_shr(v0, v1, v2) {
    
    const v3 = (63 & v2);
const v4 = (31 & v3);
const v5 = (v3 >>> 5);
const v6 = ((((v3) | 0) === 0) | 0);
const v7 = ((v6) ? (v1) : (((v5) ? (0) : ((v1 >>> v4)))));
const v8 = ((v6) ? (v0) : (((v5) ? ((v1 >>> v4)) : (((v1 << ((32 - v4) | 0)) | (v0 >>> v4))))));
return {r0: v8, r1: v7};
}



function u64_sub(v0, v1, v2, v3) {
    
    const v4 = ((v0 - v2) | 0);
const v5 = ((((v1 - v3) | 0) - (((v4 & (-1 ^ (v2 ^ v0))) | (v2 & (-1 ^ v0))) >>> 31)) | 0);
return {r0: v4, r1: v5};
}



function u64_swapEndianness(v0, v1) {
    
    const v2 = (((255 & (v1 >>> 0)) << 24) | (((255 & (v1 >>> 8)) << 16) | (((255 & (v1 >>> 16)) << 8) | (255 & (v1 >>> 24)))));
const v3 = (((255 & (v0 >>> 0)) << 24) | (((255 & (v0 >>> 8)) << 16) | (((255 & (v0 >>> 16)) << 8) | (255 & (v0 >>> 24)))));
return {r0: v2, r1: v3};
}



function u64_xor(v0, v1, v2, v3) {
    
    const v4 = (v2 ^ v0);
const v5 = (v3 ^ v1);
return {r0: v4, r1: v5};
}



function u8_add(v0, v1) {
    
    const v2 = (255 & (((255 & v1) + (255 & v0)) | 0));
return v2;
}



function u8_and(v0, v1) {
    
    const v2 = (255 & ((255 & v1) & (255 & v0)));
return v2;
}



function u8_andnot(v0, v1) {
    
    const v2 = (255 & ((255 & v0) & ~(255 & v1)));
return v2;
}



function u8_cast_i32(v0) {
    
    const v1 = (255 & v0);
return v1;
}



function u8_cast_i8(v0) {
    
    const v1 = (255 & ((v0 << 24) >> 24));
return v1;
}



function u8_cast_u32(v0) {
    
    const v1 = (255 & v0);
return v1;
}



function u8_clz(v0) {
    
    const v1 = (255 & (((Math.clz32(((255 & (255 & v0)))>>>0)|0) - 24) | 0));
return v1;
}



function u8_ctz(v0) {
    
    const v1 = (()=>{const x=(((255 & (255 & v0)))>>>0);return x?((31-Math.clz32(x&-x))|0):32;})();
const v2 = (255 & ((((((v1) >>> 0) > ((8) >>> 0)) | 0)) ? (8) : (v1)));
return v2;
}



function u8_div(v0, v1) {
    
    const v2 = (255 & (((((((255 & v0))>>>0)/((((255 & v1))>>>0))))>>>0)));
return v2;
}



function u8_eq(v0, v1) {
    
    const v2 = (((((255 & v0)) | 0) === (((255 & v1)) | 0)) | 0);
return v2;
}



function u8_eqz(v0) {
    
    const v1 = (((((255 & v0)) | 0) === 0) | 0);
return v1;
}



function u8_from_f32(v0) {
    
    const v1 = (255 & (Math.trunc(v0) >>> 0) | 0);
return v1;
}



function u8_from_f64(v0) {
    
    const v1 = (255 & (Math.trunc(v0) >>> 0) | 0);
return v1;
}



function u8_from_i16(v0) {
    
    const v1 = ((v0 << 16) >> 16);
const v2 = (255 & ((v1 << 16) >> 16));
const v3 = (255 & (((((v1 >> 8) << 16) >> 16) << 16) >> 16));
return {r0: v2, r1: v3};
}



function u8_from_i32(v0) {
    
    const v1 = (255 & v0);
const v2 = (255 & (v0 >> 8));
const v3 = (255 & (v0 >> 16));
const v4 = (255 & (v0 >> 24));
return {r0: v1, r1: v2, r2: v3, r3: v4};
}



function u8_from_i64(v0, v1) {
    
    const v2 = (255 & v0);
const v3 = (255 & ((v1 << 24) | (v0 >>> 8)));
const v4 = (255 & ((v1 << 16) | (v0 >>> 16)));
const v5 = (255 & ((v1 << 8) | (v0 >>> 24)));
const v6 = (255 & (v1 >> 0));
const v7 = (255 & (v1 >> 8));
const v8 = (255 & (v1 >> 16));
const v9 = (255 & (v1 >> 24));
return {r0: v2, r1: v3, r2: v4, r3: v5, r4: v6, r5: v7, r6: v8, r7: v9};
}



function u8_from_i8(v0) {
    
    const v1 = (255 & ((((v0 << 24) >> 24) << 24) >> 24));
return v1;
}



function u8_from_u16(v0) {
    
    const v1 = (65535 & v0);
const v2 = (255 & (65535 & v1));
const v3 = (255 & (65535 & (65535 & (v1 >>> 8))));
return {r0: v2, r1: v3};
}



function u8_from_u32(v0) {
    
    const v1 = (255 & v0);
const v2 = (255 & (v0 >>> 8));
const v3 = (255 & (v0 >>> 16));
const v4 = (255 & (v0 >>> 24));
return {r0: v1, r1: v2, r2: v3, r3: v4};
}



function u8_from_u64(v0, v1) {
    
    const v2 = (255 & v0);
const v3 = (255 & ((v1 << 24) | (v0 >>> 8)));
const v4 = (255 & ((v1 << 16) | (v0 >>> 16)));
const v5 = (255 & ((v1 << 8) | (v0 >>> 24)));
const v6 = (255 & v1);
const v7 = (255 & (v1 >>> 8));
const v8 = (255 & (v1 >>> 16));
const v9 = (255 & (v1 >>> 24));
return {r0: v2, r1: v3, r2: v4, r3: v5, r4: v6, r5: v7, r6: v8, r7: v9};
}



function u8_ge(v0, v1) {
    
    const v2 = (((((255 & v0)) >>> 0) >= (((255 & v1)) >>> 0)) | 0);
return v2;
}



function u8_gt(v0, v1) {
    
    const v2 = (((((255 & v0)) >>> 0) > (((255 & v1)) >>> 0)) | 0);
return v2;
}



function u8_le(v0, v1) {
    
    const v2 = (((((255 & v0)) >>> 0) <= (((255 & v1)) >>> 0)) | 0);
return v2;
}



function u8_lt(v0, v1) {
    
    const v2 = (((((255 & v0)) >>> 0) < (((255 & v1)) >>> 0)) | 0);
return v2;
}



function u8_max(v0, v1) {
    
    const v2 = (255 & (Math.max((255 & v1) >>> 0, (255 & v0) >>> 0) | 0));
return v2;
}



function u8_min(v0, v1) {
    
    const v2 = (255 & (Math.min((255 & v1) >>> 0, (255 & v0) >>> 0) | 0));
return v2;
}



function u8_mul(v0, v1) {
    
    const v2 = (255 & Math.imul((255 & v1), (255 & v0)));
return v2;
}



function u8_ne(v0, v1) {
    
    const v2 = (((((255 & v0)) | 0) !== (((255 & v1)) | 0)) | 0);
return v2;
}



function u8_not(v0) {
    
    const v1 = (255 & (~(255 & v0)));
return v1;
}



function u8_or(v0, v1) {
    
    const v2 = (255 & ((255 & v1) | (255 & v0)));
return v2;
}



function u8_popcnt(v0) {
    
    const v1 = (255 & (()=>{let x=(((255 & (255 & v0)))>>>0);x-=((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);x=(x+(x>>>4))&0x0f0f0f0f;return (Math.imul(x,0x01010101)>>>24)|0;})());
return v1;
}



function u8_rem(v0, v1) {
    
    const v2 = (255 & (((((((255 & v0))>>>0)%((((255 & v1))>>>0))))>>>0)));
return v2;
}



function u8_rotl(v0, v1) {
    
    const v2 = (7 & v1);
const v3 = (255 & (255 & v0));
const v4 = (255 & ((v3 >>> ((8 - v2) | 0)) | (v3 << v2)));
return v4;
}



function u8_rotr(v0, v1) {
    
    const v2 = (7 & v1);
const v3 = (255 & (255 & v0));
const v4 = (255 & ((v3 << ((8 - v2) | 0)) | (v3 >>> v2)));
return v4;
}



function u8_shl(v0, v1) {
    
    const v2 = (255 & ((255 & v0) << (7 & v1)));
return v2;
}



function u8_shr(v0, v1) {
    
    const v2 = (255 & ((255 & v0) >>> (7 & v1)));
return v2;
}



function u8_sub(v0, v1) {
    
    const v2 = (255 & (((255 & v0) - (255 & v1)) | 0));
return v2;
}



function u8_swapEndianness(v0) {
    
    const v1 = (255 & (255 & v0));
return v1;
}



function u8_xor(v0, v1) {
    
    const v2 = (255 & ((255 & v1) ^ (255 & v0)));
return v2;
}
const instance = { exports: {f32_abs: f32_abs, f32_add: f32_add, f32_cast_i32: f32_cast_i32, f32_cast_u32: f32_cast_u32, f32_ceil: f32_ceil, f32_copysign: f32_copysign, f32_div: f32_div, f32_eq: f32_eq, f32_eqz: f32_eqz, f32_floor: f32_floor, f32_from_f64: f32_from_f64, f32_from_i16: f32_from_i16, f32_from_i32: f32_from_i32, f32_from_i64: f32_from_i64, f32_from_i8: f32_from_i8, f32_from_u16: f32_from_u16, f32_from_u32: f32_from_u32, f32_from_u64: f32_from_u64, f32_from_u8: f32_from_u8, f32_ge: f32_ge, f32_gt: f32_gt, f32_isNaN: f32_isNaN, f32_le: f32_le, f32_lt: f32_lt, f32_max: f32_max, f32_min: f32_min, f32_mul: f32_mul, f32_ne: f32_ne, f32_nearest: f32_nearest, f32_neg: f32_neg, f32_rem: f32_rem, f32_sqrt: f32_sqrt, f32_sub: f32_sub, f32_swapEndianness: f32_swapEndianness, f32_trunc: f32_trunc, f64_abs: f64_abs, f64_add: f64_add, f64_cast_i64: f64_cast_i64, f64_cast_u64: f64_cast_u64, f64_ceil: f64_ceil, f64_copysign: f64_copysign, f64_div: f64_div, f64_eq: f64_eq, f64_eqz: f64_eqz, f64_floor: f64_floor, f64_from_f32: f64_from_f32, f64_from_i16: f64_from_i16, f64_from_i32: f64_from_i32, f64_from_i64: f64_from_i64, f64_from_i8: f64_from_i8, f64_from_u16: f64_from_u16, f64_from_u32: f64_from_u32, f64_from_u64: f64_from_u64, f64_from_u8: f64_from_u8, f64_ge: f64_ge, f64_gt: f64_gt, f64_isNaN: f64_isNaN, f64_le: f64_le, f64_lt: f64_lt, f64_max: f64_max, f64_min: f64_min, f64_mul: f64_mul, f64_ne: f64_ne, f64_nearest: f64_nearest, f64_neg: f64_neg, f64_rem: f64_rem, f64_sqrt: f64_sqrt, f64_sub: f64_sub, f64_swapEndianness: f64_swapEndianness, f64_trunc: f64_trunc, i16_abs: i16_abs, i16_add: i16_add, i16_and: i16_and, i16_andnot: i16_andnot, i16_cast_i32: i16_cast_i32, i16_cast_u16: i16_cast_u16, i16_cast_u32: i16_cast_u32, i16_clz: i16_clz, i16_ctz: i16_ctz, i16_div: i16_div, i16_eq: i16_eq, i16_eqz: i16_eqz, i16_from_f32: i16_from_f32, i16_from_f64: i16_from_f64, i16_from_i32: i16_from_i32, i16_from_i64: i16_from_i64, i16_from_i8: i16_from_i8, i16_from_u16: i16_from_u16, i16_from_u32: i16_from_u32, i16_from_u64: i16_from_u64, i16_from_u8: i16_from_u8, i16_ge: i16_ge, i16_gt: i16_gt, i16_le: i16_le, i16_lt: i16_lt, i16_max: i16_max, i16_min: i16_min, i16_mul: i16_mul, i16_ne: i16_ne, i16_neg: i16_neg, i16_not: i16_not, i16_or: i16_or, i16_popcnt: i16_popcnt, i16_rem: i16_rem, i16_rotl: i16_rotl, i16_rotr: i16_rotr, i16_shl: i16_shl, i16_shr: i16_shr, i16_sub: i16_sub, i16_swapEndianness: i16_swapEndianness, i16_xor: i16_xor, i32_abs: i32_abs, i32_add: i32_add, i32_and: i32_and, i32_andnot: i32_andnot, i32_cast_f32: i32_cast_f32, i32_cast_i16: i32_cast_i16, i32_cast_i8: i32_cast_i8, i32_cast_u16: i32_cast_u16, i32_cast_u32: i32_cast_u32, i32_cast_u8: i32_cast_u8, i32_clz: i32_clz, i32_ctz: i32_ctz, i32_div: i32_div, i32_eq: i32_eq, i32_eqz: i32_eqz, i32_from_f32: i32_from_f32, i32_from_f64: i32_from_f64, i32_from_i16: i32_from_i16, i32_from_i64: i32_from_i64, i32_from_i8: i32_from_i8, i32_from_u16: i32_from_u16, i32_from_u32: i32_from_u32, i32_from_u64: i32_from_u64, i32_from_u8: i32_from_u8, i32_ge: i32_ge, i32_gt: i32_gt, i32_le: i32_le, i32_lt: i32_lt, i32_max: i32_max, i32_min: i32_min, i32_mul: i32_mul, i32_ne: i32_ne, i32_neg: i32_neg, i32_not: i32_not, i32_or: i32_or, i32_popcnt: i32_popcnt, i32_rem: i32_rem, i32_rotl: i32_rotl, i32_rotr: i32_rotr, i32_shl: i32_shl, i32_shr: i32_shr, i32_sub: i32_sub, i32_swapEndianness: i32_swapEndianness, i32_xor: i32_xor, i64_abs: i64_abs, i64_add: i64_add, i64_and: i64_and, i64_andnot: i64_andnot, i64_cast_f64: i64_cast_f64, i64_cast_u64: i64_cast_u64, i64_clz: i64_clz, i64_ctz: i64_ctz, i64_div: i64_div, i64_eq: i64_eq, i64_eqz: i64_eqz, i64_from_f32: i64_from_f32, i64_from_f64: i64_from_f64, i64_from_i16: i64_from_i16, i64_from_i32: i64_from_i32, i64_from_i8: i64_from_i8, i64_from_u16: i64_from_u16, i64_from_u32: i64_from_u32, i64_from_u64: i64_from_u64, i64_from_u8: i64_from_u8, i64_ge: i64_ge, i64_gt: i64_gt, i64_le: i64_le, i64_lt: i64_lt, i64_max: i64_max, i64_min: i64_min, i64_mul: i64_mul, i64_ne: i64_ne, i64_neg: i64_neg, i64_not: i64_not, i64_or: i64_or, i64_popcnt: i64_popcnt, i64_rem: i64_rem, i64_rotl: i64_rotl, i64_rotr: i64_rotr, i64_shl: i64_shl, i64_shr: i64_shr, i64_sub: i64_sub, i64_swapEndianness: i64_swapEndianness, i64_xor: i64_xor, i8_abs: i8_abs, i8_add: i8_add, i8_and: i8_and, i8_andnot: i8_andnot, i8_cast_i32: i8_cast_i32, i8_cast_u32: i8_cast_u32, i8_cast_u8: i8_cast_u8, i8_clz: i8_clz, i8_ctz: i8_ctz, i8_div: i8_div, i8_eq: i8_eq, i8_eqz: i8_eqz, i8_from_f32: i8_from_f32, i8_from_f64: i8_from_f64, i8_from_i16: i8_from_i16, i8_from_i32: i8_from_i32, i8_from_i64: i8_from_i64, i8_from_u16: i8_from_u16, i8_from_u32: i8_from_u32, i8_from_u64: i8_from_u64, i8_from_u8: i8_from_u8, i8_ge: i8_ge, i8_gt: i8_gt, i8_le: i8_le, i8_lt: i8_lt, i8_max: i8_max, i8_min: i8_min, i8_mul: i8_mul, i8_ne: i8_ne, i8_neg: i8_neg, i8_not: i8_not, i8_or: i8_or, i8_popcnt: i8_popcnt, i8_rem: i8_rem, i8_rotl: i8_rotl, i8_rotr: i8_rotr, i8_shl: i8_shl, i8_shr: i8_shr, i8_sub: i8_sub, i8_swapEndianness: i8_swapEndianness, i8_xor: i8_xor, u16_add: u16_add, u16_and: u16_and, u16_andnot: u16_andnot, u16_cast_i16: u16_cast_i16, u16_cast_i32: u16_cast_i32, u16_cast_u32: u16_cast_u32, u16_clz: u16_clz, u16_ctz: u16_ctz, u16_div: u16_div, u16_eq: u16_eq, u16_eqz: u16_eqz, u16_from_f32: u16_from_f32, u16_from_f64: u16_from_f64, u16_from_i16: u16_from_i16, u16_from_i32: u16_from_i32, u16_from_i64: u16_from_i64, u16_from_i8: u16_from_i8, u16_from_u32: u16_from_u32, u16_from_u64: u16_from_u64, u16_from_u8: u16_from_u8, u16_ge: u16_ge, u16_gt: u16_gt, u16_le: u16_le, u16_lt: u16_lt, u16_max: u16_max, u16_min: u16_min, u16_mul: u16_mul, u16_ne: u16_ne, u16_not: u16_not, u16_or: u16_or, u16_popcnt: u16_popcnt, u16_rem: u16_rem, u16_rotl: u16_rotl, u16_rotr: u16_rotr, u16_shl: u16_shl, u16_shr: u16_shr, u16_sub: u16_sub, u16_swapEndianness: u16_swapEndianness, u16_xor: u16_xor, u32_add: u32_add, u32_and: u32_and, u32_andnot: u32_andnot, u32_cast_f32: u32_cast_f32, u32_cast_i16: u32_cast_i16, u32_cast_i32: u32_cast_i32, u32_cast_i8: u32_cast_i8, u32_cast_u16: u32_cast_u16, u32_cast_u8: u32_cast_u8, u32_clz: u32_clz, u32_ctz: u32_ctz, u32_div: u32_div, u32_eq: u32_eq, u32_eqz: u32_eqz, u32_from_f32: u32_from_f32, u32_from_f64: u32_from_f64, u32_from_i16: u32_from_i16, u32_from_i32: u32_from_i32, u32_from_i64: u32_from_i64, u32_from_i8: u32_from_i8, u32_from_u16: u32_from_u16, u32_from_u64: u32_from_u64, u32_from_u8: u32_from_u8, u32_ge: u32_ge, u32_gt: u32_gt, u32_le: u32_le, u32_lt: u32_lt, u32_max: u32_max, u32_min: u32_min, u32_mul: u32_mul, u32_ne: u32_ne, u32_not: u32_not, u32_or: u32_or, u32_popcnt: u32_popcnt, u32_rem: u32_rem, u32_rotl: u32_rotl, u32_rotr: u32_rotr, u32_shl: u32_shl, u32_shr: u32_shr, u32_sub: u32_sub, u32_swapEndianness: u32_swapEndianness, u32_xor: u32_xor, u64_add: u64_add, u64_and: u64_and, u64_andnot: u64_andnot, u64_cast_f64: u64_cast_f64, u64_cast_i64: u64_cast_i64, u64_clz: u64_clz, u64_ctz: u64_ctz, u64_div: u64_div, u64_eq: u64_eq, u64_eqz: u64_eqz, u64_from_f32: u64_from_f32, u64_from_f64: u64_from_f64, u64_from_i16: u64_from_i16, u64_from_i32: u64_from_i32, u64_from_i64: u64_from_i64, u64_from_i8: u64_from_i8, u64_from_u16: u64_from_u16, u64_from_u32: u64_from_u32, u64_from_u8: u64_from_u8, u64_ge: u64_ge, u64_gt: u64_gt, u64_le: u64_le, u64_lt: u64_lt, u64_max: u64_max, u64_min: u64_min, u64_mul: u64_mul, u64_ne: u64_ne, u64_not: u64_not, u64_or: u64_or, u64_popcnt: u64_popcnt, u64_rem: u64_rem, u64_rotl: u64_rotl, u64_rotr: u64_rotr, u64_shl: u64_shl, u64_shr: u64_shr, u64_sub: u64_sub, u64_swapEndianness: u64_swapEndianness, u64_xor: u64_xor, u8_add: u8_add, u8_and: u8_and, u8_andnot: u8_andnot, u8_cast_i32: u8_cast_i32, u8_cast_i8: u8_cast_i8, u8_cast_u32: u8_cast_u32, u8_clz: u8_clz, u8_ctz: u8_ctz, u8_div: u8_div, u8_eq: u8_eq, u8_eqz: u8_eqz, u8_from_f32: u8_from_f32, u8_from_f64: u8_from_f64, u8_from_i16: u8_from_i16, u8_from_i32: u8_from_i32, u8_from_i64: u8_from_i64, u8_from_i8: u8_from_i8, u8_from_u16: u8_from_u16, u8_from_u32: u8_from_u32, u8_from_u64: u8_from_u64, u8_ge: u8_ge, u8_gt: u8_gt, u8_le: u8_le, u8_lt: u8_lt, u8_max: u8_max, u8_min: u8_min, u8_mul: u8_mul, u8_ne: u8_ne, u8_not: u8_not, u8_or: u8_or, u8_popcnt: u8_popcnt, u8_rem: u8_rem, u8_rotl: u8_rotl, u8_rotr: u8_rotr, u8_shl: u8_shl, u8_shr: u8_shr, u8_sub: u8_sub, u8_swapEndianness: u8_swapEndianness, u8_xor: u8_xor, memory: { buffer: __buf }}};

;
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 0);
const segments = Object.freeze({});

return Object.freeze({ ..._exports, memory: memoryExport, segments  });}
let _cache;
export default function runtimeTypes(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}