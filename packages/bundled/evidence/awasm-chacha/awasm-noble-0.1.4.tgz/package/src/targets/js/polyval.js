// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};


const __buf = new ArrayBuffer(2687168);
if (!(__buf instanceof ArrayBuffer)) throw new Error('wrong buffer');

const memory = new Uint8Array(__buf);
const memory_i32 = new Int32Array(__buf);



function macInit(v0) {
    
    let s0 = 0;
L0:  {const v1 = s0;

if (((((((((v1) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v1;break L0;
}
let s1 = v1;
L1:  {const v2 = s1;

let s2 = v2;
L2: for (;;) {const v3 = s2;

let s3 = v3;
L3:  {const v4 = s3;

const v5 = ((15 - v4) | 0);
const v6 = memory[((((((48 + v4) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0];
const v7 = memory[((((((48 + v5) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0];
memory[((((((48 + v4) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0] = v7;
memory[((((((48 + v5) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0] = v6;
s3 = v4;}
const v4 = s3;

const v8 = ((1 + v4) | 0);
if (((((v8) >>> 0) < ((8) >>> 0)) | 0)) {
s2 = v8;continue L2;
}
s2 = v8;break L2;}
const v3 = s2;

s1 = v3;}
const v2 = s1;

s0 = v2;}

const v9 = memory[((((63 + Math.imul(65728, v0)) | 0)) >>> 0) + 0];
let s4 = 0, s5 = 0;
L4:  {const v10 = s4;
const v11 = s5;

let s6 = v10, s7 = v11;
L5: for (;;) {const v12 = s6;
const v13 = s7;

const v14 = ((1 + v12) | 0);
const v15 = memory[((((((48 + v12) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0];
memory[((((((48 + v12) | 0) + Math.imul(65728, v0)) | 0)) >>> 0) + 0] = (255 & (v13 | (v15 >>> 1)));
const v16 = ((1 & v15) << 7);
if (((((v14) >>> 0) < ((16) >>> 0)) | 0)) {
s6 = v14;
s7 = v16;continue L5;
}
s6 = v14;
s7 = v16;break L5;}
const v12 = s6;
const v13 = s7;

s4 = v12;
s5 = v13;}

const v17 = memory[((((48 + Math.imul(65728, v0)) | 0)) >>> 0) + 0];
memory[((((48 + Math.imul(65728, v0)) | 0)) >>> 0) + 0] = ((225 & ((0 - (1 & v9)) | 0)) ^ v17);
const v18 = ((16 + Math.imul(65728, v0)) | 0);
memory_i32[(((v18) >>> 0) + 0) >>> 2] = 0;
const v19 = ((4 + v18) | 0);
memory_i32[(((v19) >>> 0) + 0) >>> 2] = 0;
const v20 = ((4 + v19) | 0);
memory_i32[(((v20) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((((4 + v20) | 0)) >>> 0) + 0) >>> 2] = 0;
const v21 = ((32 + Math.imul(65728, v0)) | 0);
const v22 = Math.imul(65728, v0);
memory_i32[(((v21) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((v21) >>> 0) + 4) >>> 2] = 0;
memory_i32[(((v21) >>> 0) + 8) >>> 2] = 0;
memory_i32[(((v21) >>> 0) + 12) >>> 2] = 0;
memory_i32[(((v22) >>> 0) + 0) >>> 2] = 0;
const v23 = ((4 + v22) | 0);
memory_i32[(((v23) >>> 0) + 0) >>> 2] = 0;
const v24 = ((4 + v23) | 0);
memory_i32[(((v24) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((((4 + v24) | 0)) >>> 0) + 0) >>> 2] = 0;
const v25 = ((48 + Math.imul(65728, v0)) | 0);
const v26 = memory_i32[(((v25) >>> 0) + 0) >>> 2];
const v27 = ((4 + v25) | 0);
const v28 = memory_i32[(((v27) >>> 0) + 0) >>> 2];
const v29 = ((4 + v27) | 0);
const v30 = memory_i32[(((v29) >>> 0) + 0) >>> 2];
const v31 = memory_i32[(((((4 + v29) | 0)) >>> 0) + 0) >>> 2];
const v32 = (16711935 & v26);
const v33 = (63 & 8);
const v34 = ((((v33) | 0) === 0) | 0);
const v35 = (v33 >>> 5);
const v36 = (31 & v33);
const v37 = (63 & 8);
const v38 = ((((v37) | 0) === 0) | 0);
const v39 = (v37 >>> 5);
const v40 = (31 & v37);
const v41 = ((16711935 & ((v38) ? (v26) : (((v39) ? ((v28 >>> v40)) : (((v28 << ((32 - v40) | 0)) | (v26 >>> v40))))))) | ((v34) ? (v32) : (((v35) ? (0) : ((v32 << v36))))));
const v42 = (65535 & v41);
const v43 = (63 & 16);
const v44 = ((((v43) | 0) === 0) | 0);
const v45 = (v43 >>> 5);
const v46 = (31 & v43);
const v47 = (63 & 16);
const v48 = ((((v47) | 0) === 0) | 0);
const v49 = (v47 >>> 5);
const v50 = (31 & v47);
const v51 = (16711935 & v28);
const v52 = ((16711935 & ((v38) ? (v28) : (((v39) ? (0) : ((v28 >>> v40)))))) | ((v34) ? (v51) : (((v35) ? ((v32 << v36)) : (((v32 >>> ((32 - v36) | 0)) | (v51 << v36)))))));
const v53 = ((65535 & ((v48) ? (v41) : (((v49) ? ((v52 >>> v50)) : (((v52 << ((32 - v50) | 0)) | (v41 >>> v50))))))) | ((v44) ? (v42) : (((v45) ? (0) : ((v42 << v46))))));
const v54 = (63 & 32);
const v55 = ((((v54) | 0) === 0) | 0);
const v56 = (v54 >>> 5);
const v57 = (31 & v54);
const v58 = (63 & 32);
const v59 = ((((v58) | 0) === 0) | 0);
const v60 = (v58 >>> 5);
const v61 = (31 & v58);
const v62 = (65535 & v52);
const v63 = ((65535 & ((v48) ? (v52) : (((v49) ? (0) : ((v52 >>> v50)))))) | ((v44) ? (v62) : (((v45) ? ((v42 << v46)) : (((v42 >>> ((32 - v46) | 0)) | (v62 << v46)))))));
const v64 = (16711935 & v30);
const v65 = (63 & 8);
const v66 = ((((v65) | 0) === 0) | 0);
const v67 = (v65 >>> 5);
const v68 = (31 & v65);
const v69 = (63 & 8);
const v70 = ((((v69) | 0) === 0) | 0);
const v71 = (v69 >>> 5);
const v72 = (31 & v69);
const v73 = ((16711935 & ((v70) ? (v30) : (((v71) ? ((v31 >>> v72)) : (((v31 << ((32 - v72) | 0)) | (v30 >>> v72))))))) | ((v66) ? (v64) : (((v67) ? (0) : ((v64 << v68))))));
const v74 = (65535 & v73);
const v75 = (63 & 16);
const v76 = ((((v75) | 0) === 0) | 0);
const v77 = (v75 >>> 5);
const v78 = (31 & v75);
const v79 = (63 & 16);
const v80 = ((((v79) | 0) === 0) | 0);
const v81 = (v79 >>> 5);
const v82 = (31 & v79);
const v83 = (16711935 & v31);
const v84 = ((16711935 & ((v70) ? (v31) : (((v71) ? (0) : ((v31 >>> v72)))))) | ((v66) ? (v83) : (((v67) ? ((v64 << v68)) : (((v64 >>> ((32 - v68) | 0)) | (v83 << v68)))))));
const v85 = ((65535 & ((v80) ? (v73) : (((v81) ? ((v84 >>> v82)) : (((v84 << ((32 - v82) | 0)) | (v73 >>> v82))))))) | ((v76) ? (v74) : (((v77) ? (0) : ((v74 << v78))))));
const v86 = (63 & 32);
const v87 = ((((v86) | 0) === 0) | 0);
const v88 = (v86 >>> 5);
const v89 = (31 & v86);
const v90 = (63 & 32);
const v91 = ((((v90) | 0) === 0) | 0);
const v92 = (v90 >>> 5);
const v93 = (31 & v90);
const v94 = (65535 & v84);
const v95 = ((65535 & ((v80) ? (v84) : (((v81) ? (0) : ((v84 >>> v82)))))) | ((v76) ? (v94) : (((v77) ? ((v74 << v78)) : (((v74 >>> ((32 - v78) | 0)) | (v94 << v78)))))));
let s8 = 0, s9 = (((v59) ? (v53) : (((v60) ? ((v63 >>> v61)) : (((v63 << ((32 - v61) | 0)) | (v53 >>> v61)))))) | ((v55) ? (v53) : (((v56) ? (0) : ((v53 << v57)))))), s10 = (((v59) ? (v63) : (((v60) ? (0) : ((v63 >>> v61))))) | ((v55) ? (v63) : (((v56) ? ((v53 << v57)) : (((v53 >>> ((32 - v57) | 0)) | (v63 << v57))))))), s11 = (((v91) ? (v85) : (((v92) ? ((v95 >>> v93)) : (((v95 << ((32 - v93) | 0)) | (v85 >>> v93)))))) | ((v87) ? (v85) : (((v88) ? (0) : ((v85 << v89)))))), s12 = (((v91) ? (v95) : (((v92) ? (0) : ((v95 >>> v93))))) | ((v87) ? (v95) : (((v88) ? ((v85 << v89)) : (((v85 >>> ((32 - v89) | 0)) | (v95 << v89)))))));
L6:  {const v96 = s8;
const v97 = s9;
const v98 = s10;
const v99 = s11;
const v100 = s12;

if (((((((((v96) >>> 0) < ((16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v96;
s9 = v97;
s10 = v98;
s11 = v99;
s12 = v100;break L6;
}
let s13 = v96, s14 = v97, s15 = v98, s16 = v99, s17 = v100;
L7:  {const v101 = s13;
const v102 = s14;
const v103 = s15;
const v104 = s16;
const v105 = s17;

let s18 = v101, s19 = v102, s20 = v103, s21 = v104, s22 = v105;
L8: for (;;) {const v106 = s18;
const v107 = s19;
const v108 = s20;
const v109 = s21;
const v110 = s22;

let s23 = v106, s24 = v107, s25 = v108, s26 = v109, s27 = v110;
L9:  {const v111 = s23;
const v112 = s24;
const v113 = s25;
const v114 = s26;
const v115 = s27;

let s28 = 0, s29 = v112, s30 = v113, s31 = v114, s32 = v115;
L10:  {const v116 = s28;
const v117 = s29;
const v118 = s30;
const v119 = s31;
const v120 = s32;

if (((((((((v116) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
s28 = v116;
s29 = v117;
s30 = v118;
s31 = v119;
s32 = v120;break L10;
}
let s33 = v116, s34 = v117, s35 = v118, s36 = v119, s37 = v120;
L11:  {const v121 = s33;
const v122 = s34;
const v123 = s35;
const v124 = s36;
const v125 = s37;

let s38 = v121, s39 = v122, s40 = v123, s41 = v124, s42 = v125;
L12: for (;;) {const v126 = s38;
const v127 = s39;
const v128 = s40;
const v129 = s41;
const v130 = s42;

let s43 = v126, s44 = v127, s45 = v128, s46 = v129, s47 = v130;
L13:  {const v131 = s43;
const v132 = s44;
const v133 = s45;
const v134 = s46;
const v135 = s47;

const v136 = ((((65600 + (v131 << 4)) | 0) + Math.imul(65728, v0)) | 0);
const v137 = (16711935 & v132);
const v138 = (16711935 & v133);
const v139 = (63 & 8);
const v140 = (31 & v139);
const v141 = (v139 >>> 5);
const v142 = ((((v139) | 0) === 0) | 0);
const v143 = (63 & 8);
const v144 = (31 & v143);
const v145 = (v143 >>> 5);
const v146 = ((((v143) | 0) === 0) | 0);
const v147 = ((16711935 & ((v146) ? (v132) : (((v145) ? ((v133 >>> v144)) : (((v133 << ((32 - v144) | 0)) | (v132 >>> v144))))))) | ((v142) ? (v137) : (((v141) ? (0) : ((v137 << v140))))));
const v148 = ((16711935 & ((v146) ? (v133) : (((v145) ? (0) : ((v133 >>> v144)))))) | ((v142) ? (v138) : (((v141) ? ((v137 << v140)) : (((v137 >>> ((32 - v140) | 0)) | (v138 << v140)))))));
const v149 = (65535 & v147);
const v150 = (65535 & v148);
const v151 = (63 & 16);
const v152 = (31 & v151);
const v153 = (v151 >>> 5);
const v154 = ((((v151) | 0) === 0) | 0);
const v155 = (63 & 16);
const v156 = (31 & v155);
const v157 = (v155 >>> 5);
const v158 = ((((v155) | 0) === 0) | 0);
const v159 = ((65535 & ((v158) ? (v147) : (((v157) ? ((v148 >>> v156)) : (((v148 << ((32 - v156) | 0)) | (v147 >>> v156))))))) | ((v154) ? (v149) : (((v153) ? (0) : ((v149 << v152))))));
const v160 = ((65535 & ((v158) ? (v148) : (((v157) ? (0) : ((v148 >>> v156)))))) | ((v154) ? (v150) : (((v153) ? ((v149 << v152)) : (((v149 >>> ((32 - v152) | 0)) | (v150 << v152)))))));
const v161 = (63 & 32);
const v162 = (31 & v161);
const v163 = (v161 >>> 5);
const v164 = ((((v161) | 0) === 0) | 0);
const v165 = (63 & 32);
const v166 = (31 & v165);
const v167 = (v165 >>> 5);
const v168 = ((((v165) | 0) === 0) | 0);
const v169 = (16711935 & v134);
const v170 = (16711935 & v135);
const v171 = (63 & 8);
const v172 = (31 & v171);
const v173 = (v171 >>> 5);
const v174 = ((((v171) | 0) === 0) | 0);
const v175 = (63 & 8);
const v176 = (31 & v175);
const v177 = (v175 >>> 5);
const v178 = ((((v175) | 0) === 0) | 0);
const v179 = ((16711935 & ((v178) ? (v134) : (((v177) ? ((v135 >>> v176)) : (((v135 << ((32 - v176) | 0)) | (v134 >>> v176))))))) | ((v174) ? (v169) : (((v173) ? (0) : ((v169 << v172))))));
const v180 = ((16711935 & ((v178) ? (v135) : (((v177) ? (0) : ((v135 >>> v176)))))) | ((v174) ? (v170) : (((v173) ? ((v169 << v172)) : (((v169 >>> ((32 - v172) | 0)) | (v170 << v172)))))));
const v181 = (65535 & v179);
const v182 = (65535 & v180);
const v183 = (63 & 16);
const v184 = (31 & v183);
const v185 = (v183 >>> 5);
const v186 = ((((v183) | 0) === 0) | 0);
const v187 = (63 & 16);
const v188 = (31 & v187);
const v189 = (v187 >>> 5);
const v190 = ((((v187) | 0) === 0) | 0);
const v191 = ((65535 & ((v190) ? (v179) : (((v189) ? ((v180 >>> v188)) : (((v180 << ((32 - v188) | 0)) | (v179 >>> v188))))))) | ((v186) ? (v181) : (((v185) ? (0) : ((v181 << v184))))));
const v192 = ((65535 & ((v190) ? (v180) : (((v189) ? (0) : ((v180 >>> v188)))))) | ((v186) ? (v182) : (((v185) ? ((v181 << v184)) : (((v181 >>> ((32 - v184) | 0)) | (v182 << v184)))))));
const v193 = (63 & 32);
const v194 = (31 & v193);
const v195 = (v193 >>> 5);
const v196 = ((((v193) | 0) === 0) | 0);
const v197 = (63 & 32);
const v198 = (31 & v197);
const v199 = (v197 >>> 5);
const v200 = ((((v197) | 0) === 0) | 0);
const v201 = (1 & v134);
const v202 = ((v135 << 31) | (v134 >>> 1));
const v203 = ((v135 >>> 1) | (v132 << 31));
const v204 = ((v133 << 31) | (v132 >>> 1));
const v205 = ((((0 - (((((0 - v201) | 0) & (-1 ^ v201)) | v201) >>> 31)) | 0) & -520093696) ^ (v133 >>> 1));
memory_i32[(((v136) >>> 0) + 0) >>> 2] = (((v168) ? (v159) : (((v167) ? ((v160 >>> v166)) : (((v160 << ((32 - v166) | 0)) | (v159 >>> v166)))))) | ((v164) ? (v159) : (((v163) ? (0) : ((v159 << v162))))));
memory_i32[(((v136) >>> 0) + 4) >>> 2] = (((v168) ? (v160) : (((v167) ? (0) : ((v160 >>> v166))))) | ((v164) ? (v160) : (((v163) ? ((v159 << v162)) : (((v159 >>> ((32 - v162) | 0)) | (v160 << v162)))))));
memory_i32[(((v136) >>> 0) + 8) >>> 2] = (((v200) ? (v191) : (((v199) ? ((v192 >>> v198)) : (((v192 << ((32 - v198) | 0)) | (v191 >>> v198)))))) | ((v196) ? (v191) : (((v195) ? (0) : ((v191 << v194))))));
memory_i32[(((v136) >>> 0) + 12) >>> 2] = (((v200) ? (v192) : (((v199) ? (0) : ((v192 >>> v198))))) | ((v196) ? (v192) : (((v195) ? ((v191 << v194)) : (((v191 >>> ((32 - v194) | 0)) | (v192 << v194)))))));
s43 = v131;
s44 = v204;
s45 = v205;
s46 = v202;
s47 = v203;}
const v131 = s43;
const v132 = s44;
const v133 = s45;
const v134 = s46;
const v135 = s47;

const v206 = ((1 + v131) | 0);
if (((((v206) >>> 0) < ((8) >>> 0)) | 0)) {
s38 = v206;
s39 = v132;
s40 = v133;
s41 = v134;
s42 = v135;continue L12;
}
s38 = v206;
s39 = v132;
s40 = v133;
s41 = v134;
s42 = v135;break L12;}
const v126 = s38;
const v127 = s39;
const v128 = s40;
const v129 = s41;
const v130 = s42;

s33 = v126;
s34 = v127;
s35 = v128;
s36 = v129;
s37 = v130;}
const v121 = s33;
const v122 = s34;
const v123 = s35;
const v124 = s36;
const v125 = s37;

s28 = v121;
s29 = v122;
s30 = v123;
s31 = v124;
s32 = v125;}
const v117 = s29;
const v118 = s30;
const v119 = s31;
const v120 = s32;

let s48 = 0;
L14:  {const v207 = s48;

if (((((((((v207) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s48 = v207;break L14;
}
let s49 = v207;
L15:  {const v208 = s49;

let s50 = v208;
L16: for (;;) {const v209 = s50;

let s51 = v209;
L17:  {const v210 = s51;

let s52 = 0, s53 = 0, s54 = 0, s55 = 0, s56 = 0;
L18:  {const v211 = s52;
const v212 = s53;
const v213 = s54;
const v214 = s55;
const v215 = s56;

if (((((((((v211) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
s52 = v211;
s53 = v212;
s54 = v213;
s55 = v214;
s56 = v215;break L18;
}
let s57 = v211, s58 = v212, s59 = v213, s60 = v214, s61 = v215;
L19:  {const v216 = s57;
const v217 = s58;
const v218 = s59;
const v219 = s60;
const v220 = s61;

let s62 = v216, s63 = v217, s64 = v218, s65 = v219, s66 = v220;
L20: for (;;) {const v221 = s62;
const v222 = s63;
const v223 = s64;
const v224 = s65;
const v225 = s66;

let s67 = v221, s68 = v222, s69 = v223, s70 = v224, s71 = v225;
L21:  {const v226 = s67;
const v227 = s68;
const v228 = s69;
const v229 = s70;
const v230 = s71;

const v231 = (1 & (v210 >>> ((7 - v226) | 0)));
const v232 = ((((65600 + (v226 << 4)) | 0) + Math.imul(65728, v0)) | 0);
const v233 = ((0 - v231) | 0);
const v234 = ((0 - (((v233 & (-1 ^ v231)) | v231) >>> 31)) | 0);
const v235 = memory_i32[(((v232) >>> 0) + 0) >>> 2];
const v236 = memory_i32[(((v232) >>> 0) + 4) >>> 2];
const v237 = memory_i32[(((v232) >>> 0) + 8) >>> 2];
const v238 = memory_i32[(((v232) >>> 0) + 12) >>> 2];
const v239 = ((v233 & v235) ^ v227);
const v240 = ((v234 & v236) ^ v228);
const v241 = ((v233 & v237) ^ v229);
const v242 = ((v234 & v238) ^ v230);
s67 = v226;
s68 = v239;
s69 = v240;
s70 = v241;
s71 = v242;}
const v226 = s67;
const v227 = s68;
const v228 = s69;
const v229 = s70;
const v230 = s71;

const v243 = ((1 + v226) | 0);
if (((((v243) >>> 0) < ((8) >>> 0)) | 0)) {
s62 = v243;
s63 = v227;
s64 = v228;
s65 = v229;
s66 = v230;continue L20;
}
s62 = v243;
s63 = v227;
s64 = v228;
s65 = v229;
s66 = v230;break L20;}
const v221 = s62;
const v222 = s63;
const v223 = s64;
const v224 = s65;
const v225 = s66;

s57 = v221;
s58 = v222;
s59 = v223;
s60 = v224;
s61 = v225;}
const v216 = s57;
const v217 = s58;
const v218 = s59;
const v219 = s60;
const v220 = s61;

s52 = v216;
s53 = v217;
s54 = v218;
s55 = v219;
s56 = v220;}
const v212 = s53;
const v213 = s54;
const v214 = s55;
const v215 = s56;

const v244 = ((((64 + (((v210 + (v111 << 8)) | 0) << 4)) | 0) + Math.imul(65728, v0)) | 0);
const v245 = (16711935 & v214);
const v246 = (16711935 & v215);
const v247 = (63 & 8);
const v248 = (31 & v247);
const v249 = (v247 >>> 5);
const v250 = ((((v247) | 0) === 0) | 0);
const v251 = (63 & 8);
const v252 = (31 & v251);
const v253 = (v251 >>> 5);
const v254 = ((((v251) | 0) === 0) | 0);
const v255 = ((16711935 & ((v254) ? (v214) : (((v253) ? ((v215 >>> v252)) : (((v215 << ((32 - v252) | 0)) | (v214 >>> v252))))))) | ((v250) ? (v245) : (((v249) ? (0) : ((v245 << v248))))));
const v256 = ((16711935 & ((v254) ? (v215) : (((v253) ? (0) : ((v215 >>> v252)))))) | ((v250) ? (v246) : (((v249) ? ((v245 << v248)) : (((v245 >>> ((32 - v248) | 0)) | (v246 << v248)))))));
const v257 = (65535 & v255);
const v258 = (65535 & v256);
const v259 = (63 & 16);
const v260 = (31 & v259);
const v261 = (v259 >>> 5);
const v262 = ((((v259) | 0) === 0) | 0);
const v263 = (63 & 16);
const v264 = (31 & v263);
const v265 = (v263 >>> 5);
const v266 = ((((v263) | 0) === 0) | 0);
const v267 = ((65535 & ((v266) ? (v255) : (((v265) ? ((v256 >>> v264)) : (((v256 << ((32 - v264) | 0)) | (v255 >>> v264))))))) | ((v262) ? (v257) : (((v261) ? (0) : ((v257 << v260))))));
const v268 = ((65535 & ((v266) ? (v256) : (((v265) ? (0) : ((v256 >>> v264)))))) | ((v262) ? (v258) : (((v261) ? ((v257 << v260)) : (((v257 >>> ((32 - v260) | 0)) | (v258 << v260)))))));
const v269 = (63 & 32);
const v270 = (31 & v269);
const v271 = (v269 >>> 5);
const v272 = ((((v269) | 0) === 0) | 0);
const v273 = (63 & 32);
const v274 = (31 & v273);
const v275 = (v273 >>> 5);
const v276 = ((((v273) | 0) === 0) | 0);
const v277 = (16711935 & v212);
const v278 = (16711935 & v213);
const v279 = (63 & 8);
const v280 = (31 & v279);
const v281 = (v279 >>> 5);
const v282 = ((((v279) | 0) === 0) | 0);
const v283 = (63 & 8);
const v284 = (31 & v283);
const v285 = (v283 >>> 5);
const v286 = ((((v283) | 0) === 0) | 0);
const v287 = ((16711935 & ((v286) ? (v212) : (((v285) ? ((v213 >>> v284)) : (((v213 << ((32 - v284) | 0)) | (v212 >>> v284))))))) | ((v282) ? (v277) : (((v281) ? (0) : ((v277 << v280))))));
const v288 = ((16711935 & ((v286) ? (v213) : (((v285) ? (0) : ((v213 >>> v284)))))) | ((v282) ? (v278) : (((v281) ? ((v277 << v280)) : (((v277 >>> ((32 - v280) | 0)) | (v278 << v280)))))));
const v289 = (65535 & v287);
const v290 = (65535 & v288);
const v291 = (63 & 16);
const v292 = (31 & v291);
const v293 = (v291 >>> 5);
const v294 = ((((v291) | 0) === 0) | 0);
const v295 = (63 & 16);
const v296 = (31 & v295);
const v297 = (v295 >>> 5);
const v298 = ((((v295) | 0) === 0) | 0);
const v299 = ((65535 & ((v298) ? (v287) : (((v297) ? ((v288 >>> v296)) : (((v288 << ((32 - v296) | 0)) | (v287 >>> v296))))))) | ((v294) ? (v289) : (((v293) ? (0) : ((v289 << v292))))));
const v300 = ((65535 & ((v298) ? (v288) : (((v297) ? (0) : ((v288 >>> v296)))))) | ((v294) ? (v290) : (((v293) ? ((v289 << v292)) : (((v289 >>> ((32 - v292) | 0)) | (v290 << v292)))))));
const v301 = (63 & 32);
const v302 = (31 & v301);
const v303 = (v301 >>> 5);
const v304 = ((((v301) | 0) === 0) | 0);
const v305 = (63 & 32);
const v306 = (31 & v305);
const v307 = (v305 >>> 5);
const v308 = ((((v305) | 0) === 0) | 0);
memory_i32[(((v244) >>> 0) + 0) >>> 2] = (((v276) ? (v267) : (((v275) ? ((v268 >>> v274)) : (((v268 << ((32 - v274) | 0)) | (v267 >>> v274)))))) | ((v272) ? (v267) : (((v271) ? (0) : ((v267 << v270))))));
memory_i32[(((v244) >>> 0) + 4) >>> 2] = (((v276) ? (v268) : (((v275) ? (0) : ((v268 >>> v274))))) | ((v272) ? (v268) : (((v271) ? ((v267 << v270)) : (((v267 >>> ((32 - v270) | 0)) | (v268 << v270)))))));
memory_i32[(((v244) >>> 0) + 8) >>> 2] = (((v308) ? (v299) : (((v307) ? ((v300 >>> v306)) : (((v300 << ((32 - v306) | 0)) | (v299 >>> v306)))))) | ((v304) ? (v299) : (((v303) ? (0) : ((v299 << v302))))));
memory_i32[(((v244) >>> 0) + 12) >>> 2] = (((v308) ? (v300) : (((v307) ? (0) : ((v300 >>> v306))))) | ((v304) ? (v300) : (((v303) ? ((v299 << v302)) : (((v299 >>> ((32 - v302) | 0)) | (v300 << v302)))))));
s51 = v210;}
const v210 = s51;

const v309 = ((1 + v210) | 0);
if (((((v309) >>> 0) < ((256) >>> 0)) | 0)) {
s50 = v309;continue L16;
}
s50 = v309;break L16;}
const v209 = s50;

s49 = v209;}
const v208 = s49;

s48 = v208;}

s23 = v111;
s24 = v117;
s25 = v118;
s26 = v119;
s27 = v120;}
const v111 = s23;
const v112 = s24;
const v113 = s25;
const v114 = s26;
const v115 = s27;

const v310 = ((1 + v111) | 0);
if (((((v310) >>> 0) < ((16) >>> 0)) | 0)) {
s18 = v310;
s19 = v112;
s20 = v113;
s21 = v114;
s22 = v115;continue L8;
}
s18 = v310;
s19 = v112;
s20 = v113;
s21 = v114;
s22 = v115;break L8;}
const v106 = s18;
const v107 = s19;
const v108 = s20;
const v109 = s21;
const v110 = s22;

s13 = v106;
s14 = v107;
s15 = v108;
s16 = v109;
s17 = v110;}
const v101 = s13;
const v102 = s14;
const v103 = s15;
const v104 = s16;
const v105 = s17;

s8 = v101;
s9 = v102;
s10 = v103;
s11 = v104;
s12 = v105;}

return ;
}



function padding(v0, v1, v2, v3, v4, v5) {
    
    const v6 = ((((((v4)>>>0)/(((4)>>>0))))>>>0));
L0:  {
if (((((((((v3) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L0;
}
let s0 = 0;
L1:  {const v7 = s0;

if (((((((((v7) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v7;break L1;
}
let s1 = v7;
L2:  {const v8 = s1;

let s2 = v8;
L3: for (;;) {const v9 = s2;

let s3 = v9;
L4:  {const v10 = s3;

memory[((((((65728 + ((v10 + v1) | 0)) | 0) + (Math.imul(Math.imul(v6, v2), v0) << 2)) | 0)) >>> 0) + 0] = 0;
s3 = v10;}
const v10 = s3;

const v11 = ((1 + v10) | 0);
if (((((v11) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v11;continue L3;
}
s2 = v11;break L3;}
const v9 = s2;

s1 = v9;}
const v8 = s1;

s0 = v8;}

}

const v12 = ((((((v1) | 0) === ((0) | 0)) | 0)) ? (1) : (0));
return v12;
}



function processBlocks(v0, v1, v2, v3, v4, v5, v6, v7) {
    
    let s0 = 0;
L0:  {const v8 = s0;

if (((((((((v8) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v8;break L0;
}
let s1 = v8;
L1:  {const v9 = s1;

let s2 = v9;
L2: for (;;) {const v10 = s2;

let s3 = v10;
L3:  {const v11 = s3;

const v12 = ((v11 + v0) | 0);
const v13 = ((v2 - v7) | 0);
let s4 = 0;
L4:  {const v14 = s4;

if (((((((((v14) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v14;break L4;
}
let s5 = v14;
L5:  {const v15 = s5;

let s6 = v15;
L6: for (;;) {const v16 = s6;

let s7 = v16;
L7:  {const v17 = s7;

const v18 = ((v17 + v12) | 0);
const v19 = ((32 + Math.imul(65728, v18)) | 0);
const v20 = memory_i32[(((v19) >>> 0) + 0) >>> 2];
const v21 = memory_i32[(((v19) >>> 0) + 4) >>> 2];
const v22 = memory_i32[(((v19) >>> 0) + 8) >>> 2];
const v23 = memory_i32[(((v19) >>> 0) + 12) >>> 2];
let s8 = 0, s9 = v20, s10 = v21, s11 = v22, s12 = v23;
L8:  {const v24 = s8;
const v25 = s9;
const v26 = s10;
const v27 = s11;
const v28 = s12;

if (((((((((v24) >>> 0) < ((v13) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v24;
s9 = v25;
s10 = v26;
s11 = v27;
s12 = v28;break L8;
}
let s13 = v24, s14 = v25, s15 = v26, s16 = v27, s17 = v28;
L9:  {const v29 = s13;
const v30 = s14;
const v31 = s15;
const v32 = s16;
const v33 = s17;

let s18 = v29, s19 = v30, s20 = v31, s21 = v32, s22 = v33;
L10: for (;;) {const v34 = s18;
const v35 = s19;
const v36 = s20;
const v37 = s21;
const v38 = s22;

let s23 = v34, s24 = v35, s25 = v36, s26 = v37, s27 = v38;
L11:  {const v39 = s23;
const v40 = s24;
const v41 = s25;
const v42 = s26;
const v43 = s27;

const v44 = ((((65728 + (v39 << 4)) | 0) + (Math.imul(v3, v18) << 4)) | 0);
const v45 = ((((65728 + (v39 << 4)) | 0) + (Math.imul(v3, v18) << 4)) | 0);
const v46 = memory_i32[(((v44) >>> 0) + 12) >>> 2];
const v47 = (v46 ^ v43);
const v48 = ((((64 + ((255 & ((255 & (v47 >>> 24)) >>> 0)) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v49 = ((((64 + ((((255 & ((255 & (v47 >>> 16)) >>> 0)) + 256) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v50 = ((((64 + ((((255 & ((255 & (v47 >>> 8)) >>> 0)) + 512) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v51 = ((((64 + ((((255 & ((255 & v47) >>> 0)) + 768) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v52 = memory_i32[(((v44) >>> 0) + 8) >>> 2];
const v53 = (v52 ^ v42);
const v54 = ((((64 + ((((255 & ((255 & ((v47 << 8) | (v53 >>> 24))) >>> 0)) + 1024) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v55 = ((((64 + ((((255 & ((255 & ((v47 << 16) | (v53 >>> 16))) >>> 0)) + 1280) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v56 = ((((64 + ((((255 & ((255 & ((v47 << 24) | (v53 >>> 8))) >>> 0)) + 1536) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v57 = ((((64 + ((((255 & ((255 & v53) >>> 0)) + 1792) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v58 = memory_i32[(((v44) >>> 0) + 4) >>> 2];
const v59 = (v58 ^ v41);
const v60 = ((((64 + ((((255 & ((255 & (v59 >>> 24)) >>> 0)) + 2048) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v61 = ((((64 + ((((255 & ((255 & (v59 >>> 16)) >>> 0)) + 2304) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v62 = ((((64 + ((((255 & ((255 & (v59 >>> 8)) >>> 0)) + 2560) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v63 = ((((64 + ((((255 & ((255 & v59) >>> 0)) + 2816) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v64 = memory_i32[(((v44) >>> 0) + 0) >>> 2];
const v65 = (v64 ^ v40);
const v66 = ((((64 + ((((255 & ((255 & ((v59 << 8) | (v65 >>> 24))) >>> 0)) + 3072) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v67 = ((((64 + ((((255 & ((255 & ((v59 << 16) | (v65 >>> 16))) >>> 0)) + 3328) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v68 = ((((64 + ((((255 & ((255 & ((v59 << 24) | (v65 >>> 8))) >>> 0)) + 3584) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v69 = ((((64 + ((((255 & ((255 & v65) >>> 0)) + 3840) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v70 = memory_i32[(((v48) >>> 0) + 0) >>> 2];
const v71 = memory_i32[(((v48) >>> 0) + 4) >>> 2];
const v72 = memory_i32[(((v48) >>> 0) + 8) >>> 2];
const v73 = memory_i32[(((v48) >>> 0) + 12) >>> 2];
const v74 = memory_i32[(((v49) >>> 0) + 0) >>> 2];
const v75 = memory_i32[(((v49) >>> 0) + 4) >>> 2];
const v76 = memory_i32[(((v49) >>> 0) + 8) >>> 2];
const v77 = memory_i32[(((v49) >>> 0) + 12) >>> 2];
const v78 = memory_i32[(((v50) >>> 0) + 0) >>> 2];
const v79 = memory_i32[(((v50) >>> 0) + 4) >>> 2];
const v80 = memory_i32[(((v50) >>> 0) + 8) >>> 2];
const v81 = memory_i32[(((v50) >>> 0) + 12) >>> 2];
const v82 = memory_i32[(((v51) >>> 0) + 0) >>> 2];
const v83 = memory_i32[(((v51) >>> 0) + 4) >>> 2];
const v84 = memory_i32[(((v51) >>> 0) + 8) >>> 2];
const v85 = memory_i32[(((v51) >>> 0) + 12) >>> 2];
const v86 = memory_i32[(((v54) >>> 0) + 0) >>> 2];
const v87 = memory_i32[(((v54) >>> 0) + 4) >>> 2];
const v88 = memory_i32[(((v54) >>> 0) + 8) >>> 2];
const v89 = memory_i32[(((v54) >>> 0) + 12) >>> 2];
const v90 = memory_i32[(((v55) >>> 0) + 0) >>> 2];
const v91 = memory_i32[(((v55) >>> 0) + 4) >>> 2];
const v92 = memory_i32[(((v55) >>> 0) + 8) >>> 2];
const v93 = memory_i32[(((v55) >>> 0) + 12) >>> 2];
const v94 = memory_i32[(((v56) >>> 0) + 0) >>> 2];
const v95 = memory_i32[(((v56) >>> 0) + 4) >>> 2];
const v96 = memory_i32[(((v56) >>> 0) + 8) >>> 2];
const v97 = memory_i32[(((v56) >>> 0) + 12) >>> 2];
const v98 = memory_i32[(((v57) >>> 0) + 0) >>> 2];
const v99 = memory_i32[(((v57) >>> 0) + 4) >>> 2];
const v100 = memory_i32[(((v57) >>> 0) + 8) >>> 2];
const v101 = memory_i32[(((v57) >>> 0) + 12) >>> 2];
const v102 = memory_i32[(((v60) >>> 0) + 0) >>> 2];
const v103 = memory_i32[(((v60) >>> 0) + 4) >>> 2];
const v104 = memory_i32[(((v60) >>> 0) + 8) >>> 2];
const v105 = memory_i32[(((v60) >>> 0) + 12) >>> 2];
const v106 = memory_i32[(((v61) >>> 0) + 0) >>> 2];
const v107 = memory_i32[(((v61) >>> 0) + 4) >>> 2];
const v108 = memory_i32[(((v61) >>> 0) + 8) >>> 2];
const v109 = memory_i32[(((v61) >>> 0) + 12) >>> 2];
const v110 = memory_i32[(((v62) >>> 0) + 0) >>> 2];
const v111 = memory_i32[(((v62) >>> 0) + 4) >>> 2];
const v112 = memory_i32[(((v62) >>> 0) + 8) >>> 2];
const v113 = memory_i32[(((v62) >>> 0) + 12) >>> 2];
const v114 = memory_i32[(((v63) >>> 0) + 0) >>> 2];
const v115 = memory_i32[(((v63) >>> 0) + 4) >>> 2];
const v116 = memory_i32[(((v63) >>> 0) + 8) >>> 2];
const v117 = memory_i32[(((v63) >>> 0) + 12) >>> 2];
const v118 = memory_i32[(((v66) >>> 0) + 0) >>> 2];
const v119 = memory_i32[(((v66) >>> 0) + 4) >>> 2];
const v120 = memory_i32[(((v66) >>> 0) + 8) >>> 2];
const v121 = memory_i32[(((v66) >>> 0) + 12) >>> 2];
const v122 = memory_i32[(((v67) >>> 0) + 0) >>> 2];
const v123 = memory_i32[(((v67) >>> 0) + 4) >>> 2];
const v124 = memory_i32[(((v67) >>> 0) + 8) >>> 2];
const v125 = memory_i32[(((v67) >>> 0) + 12) >>> 2];
const v126 = memory_i32[(((v68) >>> 0) + 0) >>> 2];
const v127 = memory_i32[(((v68) >>> 0) + 4) >>> 2];
const v128 = memory_i32[(((v68) >>> 0) + 8) >>> 2];
const v129 = memory_i32[(((v68) >>> 0) + 12) >>> 2];
const v130 = memory_i32[(((v69) >>> 0) + 0) >>> 2];
const v131 = memory_i32[(((v69) >>> 0) + 4) >>> 2];
const v132 = memory_i32[(((v69) >>> 0) + 8) >>> 2];
const v133 = memory_i32[(((v69) >>> 0) + 12) >>> 2];
const v134 = (v130 ^ (v126 ^ (v122 ^ (v118 ^ (v114 ^ (v110 ^ (v106 ^ (v102 ^ (v98 ^ (v94 ^ (v90 ^ (v86 ^ (v82 ^ (v78 ^ (v74 ^ v70)))))))))))))));
const v135 = (v131 ^ (v127 ^ (v123 ^ (v119 ^ (v115 ^ (v111 ^ (v107 ^ (v103 ^ (v99 ^ (v95 ^ (v91 ^ (v87 ^ (v83 ^ (v79 ^ (v75 ^ v71)))))))))))))));
const v136 = (v132 ^ (v128 ^ (v124 ^ (v120 ^ (v116 ^ (v112 ^ (v108 ^ (v104 ^ (v100 ^ (v96 ^ (v92 ^ (v88 ^ (v84 ^ (v80 ^ (v76 ^ v72)))))))))))))));
const v137 = (v133 ^ (v129 ^ (v125 ^ (v121 ^ (v117 ^ (v113 ^ (v109 ^ (v105 ^ (v101 ^ (v97 ^ (v93 ^ (v89 ^ (v85 ^ (v81 ^ (v77 ^ v73)))))))))))))));
memory_i32[(((v45) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 4) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 8) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 12) >>> 2] = 0;
s23 = v39;
s24 = v134;
s25 = v135;
s26 = v136;
s27 = v137;}
const v39 = s23;
const v40 = s24;
const v41 = s25;
const v42 = s26;
const v43 = s27;

const v138 = ((1 + v39) | 0);
if (((((v138) >>> 0) < ((v13) >>> 0)) | 0)) {
s18 = v138;
s19 = v40;
s20 = v41;
s21 = v42;
s22 = v43;continue L10;
}
s18 = v138;
s19 = v40;
s20 = v41;
s21 = v42;
s22 = v43;break L10;}
const v34 = s18;
const v35 = s19;
const v36 = s20;
const v37 = s21;
const v38 = s22;

s13 = v34;
s14 = v35;
s15 = v36;
s16 = v37;
s17 = v38;}
const v29 = s13;
const v30 = s14;
const v31 = s15;
const v32 = s16;
const v33 = s17;

s8 = v29;
s9 = v30;
s10 = v31;
s11 = v32;
s12 = v33;}
const v25 = s9;
const v26 = s10;
const v27 = s11;
const v28 = s12;

const v139 = ((32 + Math.imul(65728, v18)) | 0);
memory_i32[(((v139) >>> 0) + 0) >>> 2] = v25;
memory_i32[(((v139) >>> 0) + 4) >>> 2] = v26;
memory_i32[(((v139) >>> 0) + 8) >>> 2] = v27;
memory_i32[(((v139) >>> 0) + 12) >>> 2] = v28;
s7 = v17;}
const v17 = s7;

const v140 = ((1 + v17) | 0);
if (((((v140) >>> 0) < ((1) >>> 0)) | 0)) {
s6 = v140;continue L6;
}
s6 = v140;break L6;}
const v16 = s6;

s5 = v16;}
const v15 = s5;

s4 = v15;}

s3 = v11;}
const v11 = s3;

const v141 = ((1 + v11) | 0);
if (((((v141) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v141;continue L2;
}
s2 = v141;break L2;}
const v10 = s2;

s1 = v10;}
const v9 = s1;

s0 = v9;}

return ;
}



function processOutBlocks(v0, v1, v2, v3, v4, v5) {
    
    let s0 = 0;
L0:  {const v6 = s0;

if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v6;break L0;
}
let s1 = v6;
L1:  {const v7 = s1;

let s2 = v7;
L2: for (;;) {const v8 = s2;

let s3 = v8;
L3:  {const v9 = s3;

const v10 = ((v9 + v0) | 0);
let s4 = 0;
L4:  {const v11 = s4;

if (((((((((v11) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v11;break L4;
}
let s5 = v11;
L5:  {const v12 = s5;

let s6 = v12;
L6: for (;;) {const v13 = s6;

let s7 = v13;
L7:  {const v14 = s7;

const v15 = ((v14 + v10) | 0);
const v16 = ((32 + Math.imul(65728, v15)) | 0);
const v17 = memory_i32[(((v16) >>> 0) + 0) >>> 2];
const v18 = memory_i32[(((v16) >>> 0) + 4) >>> 2];
const v19 = memory_i32[(((v16) >>> 0) + 8) >>> 2];
const v20 = memory_i32[(((v16) >>> 0) + 12) >>> 2];
let s8 = 0;
L8:  {const v21 = s8;

if (((((((((v21) >>> 0) < ((v2) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v21;break L8;
}
let s9 = v21;
L9:  {const v22 = s9;

let s10 = v22;
L10: for (;;) {const v23 = s10;

let s11 = v23;
L11:  {const v24 = s11;

const v25 = ((((65728 + (v24 << 4)) | 0) + (Math.imul(v3, v15) << 4)) | 0);
memory_i32[(((v25) >>> 0) + 0) >>> 2] = v17;
memory_i32[(((v25) >>> 0) + 4) >>> 2] = v18;
memory_i32[(((v25) >>> 0) + 8) >>> 2] = v19;
memory_i32[(((v25) >>> 0) + 12) >>> 2] = v20;
s11 = v24;}
const v24 = s11;

const v26 = ((1 + v24) | 0);
if (((((v26) >>> 0) < ((v2) >>> 0)) | 0)) {
s10 = v26;continue L10;
}
s10 = v26;break L10;}
const v23 = s10;

s9 = v23;}
const v22 = s9;

s8 = v22;}

s7 = v14;}
const v14 = s7;

const v27 = ((1 + v14) | 0);
if (((((v27) >>> 0) < ((1) >>> 0)) | 0)) {
s6 = v27;continue L6;
}
s6 = v27;break L6;}
const v13 = s6;

s5 = v13;}
const v12 = s5;

s4 = v12;}

s3 = v9;}
const v9 = s3;

const v28 = ((1 + v9) | 0);
if (((((v28) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v28;continue L2;
}
s2 = v28;break L2;}
const v8 = s2;

s1 = v8;}
const v7 = s1;

s0 = v7;}

return ;
}



function reset(v0, v1, v2, v3, v4) {
    
    const v5 = ((((((v3)>>>0)/(((4)>>>0))))>>>0));
memory.fill(0, ((Math.imul(65728, v0)) >>> 0), ((Math.imul(65728, v0)) >>> 0) + ((Math.imul(v1, 65728)) >>> 0))
let s0 = 0;
L0:  {const v6 = s0;

if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v6;break L0;
}
let s1 = v6;
L1:  {const v7 = s1;

let s2 = v7;
L2: for (;;) {const v8 = s2;

let s3 = v8;
L3:  {const v9 = s3;

memory.fill(0, ((((65728 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0), ((((65728 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0) + ((v2) >>> 0))
s3 = v9;}
const v9 = s3;

const v10 = ((1 + v9) | 0);
if (((((v10) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v10;continue L2;
}
s2 = v10;break L2;}
const v8 = s2;

s1 = v8;}
const v7 = s1;

s0 = v7;}

return ;
}
const instance = { exports: {macInit: macInit, padding: padding, processBlocks: processBlocks, processOutBlocks: processOutBlocks, reset: reset, memory: { buffer: __buf }}};

;
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 2687168);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 65728)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 65728)))
, "state.state_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 16)))
, "state.ghash_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 48)))
, "state.ghash.y_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 16)))
, "state.ghash.y64_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*65728, 16)))
, "state.ghash.h_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 48 + i*65728, 16)))
, "state.table64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 64 + i*65728, 65536)))
, "state.tmp64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 65600 + i*65728, 128)))
, buffer: new Uint8Array(memoryExport.buffer, 65728, 2621440)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 65728 + i*2621440, 2621440)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments  });}
let _cache;
export default function polyval(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}