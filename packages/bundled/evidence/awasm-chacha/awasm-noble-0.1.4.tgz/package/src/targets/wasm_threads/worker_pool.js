// WARNING: This file is auto-generated. Any changes will be lost.
export default function workerPool(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {workerProcess: (id, modId) => {
        if (!registry[modId])
            throw new Error('unknown modId');
        registry[modId].exports.initWorker(id, 0, 1);
    }, workerNotify: (id, modId) => {
        if (!registry[modId])
            throw new Error('unknown cmd');
        registry[modId].exports.initWorker(id, 1, 0);
    }}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  const registry = {};;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {workerProcess: (id, modId) => {\n        if (!registry[modId])\n            throw new Error('unknown modId');\n        registry[modId].exports.initWorker(id, 0, 1);\n    }, workerNotify: (id, modId) => {\n        if (!registry[modId])\n            throw new Error('unknown cmd');\n        registry[modId].exports.initWorker(id, 1, 0);\n    }}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      \nif (msg.data.type==='install') {\n  if (!instance) throw new Error('instance not started yet');\n  for (const k in msg.data.registry) {\n    if (registry[k]) throw new Error('worker('+workerId+') module '+k+' already installed');\n    const {code, memory} = msg.data.registry[k];\n    const getInstanceJS = (code, _imports)=>(new Function('_imports', \"return (\"+code+\")(_imports)\"))(_imports);\n    const getInstanceWASM = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);\n    registry[k] = (typeof code==='string' ? getInstanceJS : getInstanceWASM)(code, {env: {..._imports.env, _memory: memory}});\n    const r1 = instance.exports.workerInstalled(workerId, +k);\n  }\n  instance.exports.initWorker(workerId, 0, 0);\n  instance.exports.stopWorker(workerId);\n  return false;\n}\n  ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 1, maximum: 1, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABLQhgAn9/AX9gAAF/YAF/AGACf38AYAAAYAF/An9/YAN/f38Df39/YAJ/fwJ/fwKAAQYDZW52B19tZW1vcnkCAwEBA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACA2Vudgx3b3JrZXJOb3RpZnkAAwNlbnYNd29ya2VyUHJvY2VzcwADAwkIAAECAgQFAgAHgwEJBm1lbW9yeQIADl93b3JrZXJfbm90aWZ5AAUOX3dvcmtlcl9vbmxpbmUABgppbml0V29ya2VyAAcNbWFpbkluc3RhbGxlZAAICW1haW5SZXNldAAJDHJlZ2lzdHJ5SW5mbwAKCnN0b3BXb3JrZXIACw93b3JrZXJJbnN0YWxsZWQADArJDAjgAQEQf0EAIAFBAAIGIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCBiEHIQYhBSAFIAYgBwMGIQohCSEIIAggCSAKAgYhDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAxgBqIAD+FwIAIAtBgAZsQYDGAGpBAf4AAgAhDiANQQEgC3RyIQ8gCyAMIA8LIQ0hDCELIAtBAWohECAMQQF2IREgECARIA0gEUEARw0AGhoaIBAgESANCyEKIQkhCCAIIAkgCgshByEGIQUgBSAGIAcLIQQhAyECIAQLmQEBDH9BAEEAAgchASEAIAAgASAAQR9JRQ0AGhogACABAgchAyECIAIgAwMHIQUhBCAEIAUCByEHIQYgBkEBaiIIQYAGbEGAxABq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQusAQEHfyAAQYAGbEGAxABqIQEgAEGABmxBgMUAaiECIABBgAZsQYDGAGohAyAAQQh0/hACACEEAgQCBCAEQQBHRQ0ADAELIAFBAf4XAgACBAMEIANBAP5BAgAhBQIEIAVFRQ0AIANBAEJ//gECACEGDAELAgQgBUEBRkUNACAAQQh0/hACACEHIAdFDQEMAgsgACAFEAQgAkEB/hcCAEEBDQALCyABQQD+FwIACwvrAgEhf0EAQQH+HgIAIQFBgAJBAf4eAgAhAkGABEEB/h4CACEDQYAGQQH+HgIAIQRBgAhBAf4eAgAhBUGACkEB/h4CACEGQYAMQQH+HgIAIQdBgA5BAf4eAgAhCEGAEEEB/h4CACEJQYASQQH+HgIAIQpBgBRBAf4eAgAhC0GAFkEB/h4CACEMQYAYQQH+HgIAIQ1BgBpBAf4eAgAhDkGAHEEB/h4CACEPQYAeQQH+HgIAIRBBgCBBAf4eAgAhEUGAIkEB/h4CACESQYAkQQH+HgIAIRNBgCZBAf4eAgAhFEGAKEEB/h4CACEVQYAqQQH+HgIAIRZBgCxBAf4eAgAhF0GALkEB/h4CACEYQYAwQQH+HgIAIRlBgDJBAf4eAgAhGkGANEEB/h4CACEbQYA2QQH+HgIAIRxBgDhBAf4eAgAhHUGAOkEB/h4CACEeQYA8QQH+HgIAIR9BgD5BAf4eAgAhIEEBQX8QBSEhC8EEAEEAQQD+FwIAQYABQQD+FwIAQYACQQD+FwIAQYADQQD+FwIAQYAEQQD+FwIAQYAFQQD+FwIAQYAGQQD+FwIAQYAHQQD+FwIAQYAIQQD+FwIAQYAJQQD+FwIAQYAKQQD+FwIAQYALQQD+FwIAQYAMQQD+FwIAQYANQQD+FwIAQYAOQQD+FwIAQYAPQQD+FwIAQYAQQQD+FwIAQYARQQD+FwIAQYASQQD+FwIAQYATQQD+FwIAQYAUQQD+FwIAQYAVQQD+FwIAQYAWQQD+FwIAQYAXQQD+FwIAQYAYQQD+FwIAQYAZQQD+FwIAQYAaQQD+FwIAQYAbQQD+FwIAQYAcQQD+FwIAQYAdQQD+FwIAQYAeQQD+FwIAQYAfQQD+FwIAQYAgQQD+FwIAQYAhQQD+FwIAQYAiQQD+FwIAQYAjQQD+FwIAQYAkQQD+FwIAQYAlQQD+FwIAQYAmQQD+FwIAQYAnQQD+FwIAQYAoQQD+FwIAQYApQQD+FwIAQYAqQQD+FwIAQYArQQD+FwIAQYAsQQD+FwIAQYAtQQD+FwIAQYAuQQD+FwIAQYAvQQD+FwIAQYAwQQD+FwIAQYAxQQD+FwIAQYAyQQD+FwIAQYAzQQD+FwIAQYA0QQD+FwIAQYA1QQD+FwIAQYA2QQD+FwIAQYA3QQD+FwIAQYA4QQD+FwIAQYA5QQD+FwIAQYA6QQD+FwIAQYA7QQD+FwIAQYA8QQD+FwIAQYA9QQD+FwIAQYA+QQD+FwIAQYA/QQD+FwIACyIBAn8gAEEIdP4QAgAhASAAQQh0QYABav4QAgAhAiABIAILEwAgAEGABmxBgMQAakEA/hcCAAs1AQN/IAAgARADIABBCHRBAf4lAgAhAiAAQQh0QYABakEB/h4CACEDIABBCHT+EAIAIQQgBAs='), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 33296);
const segments = Object.freeze({registry: new Uint8Array(memoryExport.buffer, 0, 8192)
, registry_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*8192, 8192)))
, _worker: new Uint8Array(memoryExport.buffer, 8192, 25104)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8192 + i*25104, 25104)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 8192, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8192 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 8320, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8320 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 8448, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8448 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 8576, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8576 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 8704, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8704 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 33280, 4)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 33280 + i*4, 4)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}