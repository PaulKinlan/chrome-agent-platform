// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 161, maximum: 161, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABQQpgAn9/AX9gAAF/YAF/AGAEf39/fwBgA39/fwBgAABgAX8Bf2AFf39/f38Ff39/f39gA39/fwN/f39gAn9/An9/AlsEA2VudgdfbWVtb3J5AgOhAaEBA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAw0MAwABBAIEAgUEAwICB8MBDQZtZW1vcnkCABlfcHJvY2Vzc0Jsb2Nrc190aHJlYWRfaW50AAMOX3dvcmtlcl9ub3RpZnkABA5fd29ya2VyX29ubGluZQAFDWRlY3J5cHRCbG9ja3MABgtkZWNyeXB0SW5pdAAHDWVuY3J5cHRCbG9ja3MACAtlbmNyeXB0SW5pdAAJCmluaXRUYWJsZXMACgppbml0V29ya2VyAAsNcHJvY2Vzc0Jsb2NrcwAMBXJlc2V0AA0Kc3RvcFdvcmtlcgAOCsNaDO0qAZQCfyAAIAFqIQQgBCABQQFwayEFIAACBiEGIAYgBiAFSUUNABogBgIGIQcgBwMGIQggCAIGIQkgCSACbCEKIAMgCmsiCyACIAsgAkkbIQxBACgCgAQhDUEAKAKQBCEOQQAoApQEIQ9BACgCmAQhEEEAKAKcBCERIAkgAmwgDiAPIBAgEQIHIRYhFSEUIRMhEiAWQf8BcUEYdCAWQYD+A3FBCHRyIBZBgID8B3FBCHYgFkEYdnJyIhcgEmoiGEH/AXFBGHQgGEGA/gNxQQh0ciAYQYCA/AdxQQh2IBhBGHZyciEZIBggF0lBAXEiGiATIBQgFSAZIBpBAEYNABoaGhoaIBVB/wFxQRh0IBVBgP4DcUEIdHIgFUGAgPwHcUEIdiAVQRh2cnIiGyAaaiIcQf8BcUEYdCAcQYD+A3FBCHRyIBxBgID8B3FBCHYgHEEYdnJyIR0gHCAbSUEBcSIeIBMgFCAdIBkgHkEARg0AGhoaGhogFEH/AXFBGHQgFEGA/gNxQQh0ciAUQYCA/AdxQQh2IBRBGHZyciIfIB5qIiBB/wFxQRh0ICBBgP4DcUEIdHIgIEGAgPwHcUEIdiAgQRh2cnIhISAgIB9JQQFxIiIgEyAhIB0gGSAiQQBGDQAaGhoaGiATQf8BcUEYdCATQYD+A3FBCHRyIBNBgID8B3FBCHYgE0EYdnJyIiMgImoiJEH/AXFBGHQgJEGA/gNxQQh0ciAkQYCA/AdxQQh2ICRBGHZyciElICQgI0lBAXEhJiAmICUgISAdIBkgJkEARg0AGhoaGhogJiAlICEgHSAZCyEWIRUhFCETIRJBACATIBQgFSAWAgchKyEqISkhKCEnICcgKCApICogKwMHITAhLyEuIS0hLCAsQQFqITFBACgCICEyQQAoAiQhM0EAKAIoITRBACgCLCE1IA1BAWshNkEAIC0gMnMgLiAzcyAvIDRzIDAgNXMCByE7ITohOSE4ITcgNyA4IDkgOiA7AwchQCE/IT4hPSE8IDxBAWohQSA8QQFqQQJ0IkJBAnRBIGooAgAhQyA9Qf8BcUECdEGgBmooAgAhRCA+QQh2Qf8BcUECdEGgDmooAgAhRSA/QRB2Qf8BcUECdEGgFmooAgAhRiBAQRh2Qf8BcUECdEGgHmooAgAhRyBDIEQgRXMgRiBHc3NzIUggQkEBakECdEEgaigCACFJID5B/wFxQQJ0QaAGaigCACFKID9BCHZB/wFxQQJ0QaAOaigCACFLIEBBEHZB/wFxQQJ0QaAWaigCACFMID1BGHZB/wFxQQJ0QaAeaigCACFNIEkgSiBLcyBMIE1zc3MhTiBCQQJqQQJ0QSBqKAIAIU8gP0H/AXFBAnRBoAZqKAIAIVAgQEEIdkH/AXFBAnRBoA5qKAIAIVEgPUEQdkH/AXFBAnRBoBZqKAIAIVIgPkEYdkH/AXFBAnRBoB5qKAIAIVMgTyBQIFFzIFIgU3NzcyFUIEJBA2pBAnRBIGooAgAhVSBAQf8BcUECdEGgBmooAgAhViA9QQh2Qf8BcUECdEGgDmooAgAhVyA+QRB2Qf8BcUECdEGgFmooAgAhWCA/QRh2Qf8BcUECdEGgHmooAgAhWSBVIFYgV3MgWCBZc3NzIVogQSBIIE4gVCBaIEEgNkkNABoaGhoaIEEgSCBOIFQgWgshQCE/IT4hPSE8IDwgPSA+ID8gQAshOyE6ITkhOCE3IA1BAnQiW0ECdEEgaigCACFcIDlBCHZB/wFxQaAEai0AACFdIDpBEHZB/wFxQaAEai0AACFeIDtBGHZB/wFxQaAEai0AACFfIDhB/wFxQaAEai0AACFgIFtBAWpBAnRBIGooAgAhYSA6QQh2Qf8BcUGgBGotAAAhYiA7QRB2Qf8BcUGgBGotAAAhYyA4QRh2Qf8BcUGgBGotAAAhZCA5Qf8BcUGgBGotAAAhZSBbQQJqQQJ0QSBqKAIAIWYgO0EIdkH/AXFBoARqLQAAIWcgOEEQdkH/AXFBoARqLQAAIWggOUEYdkH/AXFBoARqLQAAIWkgOkH/AXFBoARqLQAAIWogW0EDakECdEEgaigCACFrIDhBCHZB/wFxQaAEai0AACFsIDlBEHZB/wFxQaAEai0AACFtIDpBGHZB/wFxQaAEai0AACFuIDtB/wFxQaAEai0AACFvIAogLGpBBHRBwMgAaiJwKAIAIXEgcEEEaiJyKAIAIXMgckEEaiJ0KAIAIXUgdEEEaigCACF2IHAgcSBcIGBB/wFxIF1B/wFxQQh0ciBeQf8BcUEQdCBfQf8BcUEYdHJyc3M2AgAgcEEEaiJ3IHMgYSBlQf8BcSBiQf8BcUEIdHIgY0H/AXFBEHQgZEH/AXFBGHRycnNzNgIAIHdBBGoieCB1IGYgakH/AXEgZ0H/AXFBCHRyIGhB/wFxQRB0IGlB/wFxQRh0cnJzczYCACB4QQRqIHYgayBvQf8BcSBsQf8BcUEIdHIgbUH/AXFBEHQgbkH/AXFBGHRycnNzNgIAQQEgLSAuIC8gMAIHIX0hfCF7IXoheSB9Qf8BcUEYdCB9QYD+A3FBCHRyIH1BgID8B3FBCHYgfUEYdnJyIn4geWoif0H/AXFBGHQgf0GA/gNxQQh0ciB/QYCA/AdxQQh2IH9BGHZyciGAASB/IH5JQQFxIoEBIHogeyB8IIABIIEBQQBGDQAaGhoaGiB8Qf8BcUEYdCB8QYD+A3FBCHRyIHxBgID8B3FBCHYgfEEYdnJyIoIBIIEBaiKDAUH/AXFBGHQggwFBgP4DcUEIdHIggwFBgID8B3FBCHYggwFBGHZyciGEASCDASCCAUlBAXEihQEgeiB7IIQBIIABIIUBQQBGDQAaGhoaGiB7Qf8BcUEYdCB7QYD+A3FBCHRyIHtBgID8B3FBCHYge0EYdnJyIoYBIIUBaiKHAUH/AXFBGHQghwFBgP4DcUEIdHIghwFBgID8B3FBCHYghwFBGHZyciGIASCHASCGAUlBAXEiiQEgeiCIASCEASCAASCJAUEARg0AGhoaGhogekH/AXFBGHQgekGA/gNxQQh0ciB6QYCA/AdxQQh2IHpBGHZyciKKASCJAWoiiwFB/wFxQRh0IIsBQYD+A3FBCHRyIIsBQYCA/AdxQQh2IIsBQRh2cnIhjAEgiwEgigFJQQFxIY0BII0BIIwBIIgBIIQBIIABII0BQQBGDQAaGhoaGiCNASCMASCIASCEASCAAQshfSF8IXsheiF5IDEgeiB7IHwgfSAxIAxJDQAaGhoaGiAxIHogeyB8IH0LITAhLyEuIS0hLCAsIC0gLiAvIDALISshKiEpISghJyAJCyEJIAlBAWohjgEgjgEgjgEgBUkNABogjgELIQggCAshByAHCyEGIAUCBiGPASCPASCPASAESUUNABogjwECBiGQASCQAQMGIZEBIJEBAgYhkgEgkgEgAmwhkwEgAyCTAWsilAEgAiCUASACSRshlQFBACgCgAQhlgFBACgCkAQhlwFBACgClAQhmAFBACgCmAQhmQFBACgCnAQhmgEgkgEgAmwglwEgmAEgmQEgmgECByGfASGeASGdASGcASGbASCfAUH/AXFBGHQgnwFBgP4DcUEIdHIgnwFBgID8B3FBCHYgnwFBGHZyciKgASCbAWoioQFB/wFxQRh0IKEBQYD+A3FBCHRyIKEBQYCA/AdxQQh2IKEBQRh2cnIhogEgoQEgoAFJQQFxIqMBIJwBIJ0BIJ4BIKIBIKMBQQBGDQAaGhoaGiCeAUH/AXFBGHQgngFBgP4DcUEIdHIgngFBgID8B3FBCHYgngFBGHZyciKkASCjAWoipQFB/wFxQRh0IKUBQYD+A3FBCHRyIKUBQYCA/AdxQQh2IKUBQRh2cnIhpgEgpQEgpAFJQQFxIqcBIJwBIJ0BIKYBIKIBIKcBQQBGDQAaGhoaGiCdAUH/AXFBGHQgnQFBgP4DcUEIdHIgnQFBgID8B3FBCHYgnQFBGHZyciKoASCnAWoiqQFB/wFxQRh0IKkBQYD+A3FBCHRyIKkBQYCA/AdxQQh2IKkBQRh2cnIhqgEgqQEgqAFJQQFxIqsBIJwBIKoBIKYBIKIBIKsBQQBGDQAaGhoaGiCcAUH/AXFBGHQgnAFBgP4DcUEIdHIgnAFBgID8B3FBCHYgnAFBGHZyciKsASCrAWoirQFB/wFxQRh0IK0BQYD+A3FBCHRyIK0BQYCA/AdxQQh2IK0BQRh2cnIhrgEgrQEgrAFJQQFxIa8BIK8BIK4BIKoBIKYBIKIBIK8BQQBGDQAaGhoaGiCvASCuASCqASCmASCiAQshnwEhngEhnQEhnAEhmwFBACCcASCdASCeASCfAQIHIbQBIbMBIbIBIbEBIbABILABILEBILIBILMBILQBAwchuQEhuAEhtwEhtgEhtQEgtQFBAWohugFBACgCICG7AUEAKAIkIbwBQQAoAighvQFBACgCLCG+ASCWAUEBayG/AUEAILYBILsBcyC3ASC8AXMguAEgvQFzILkBIL4BcwIHIcQBIcMBIcIBIcEBIcABIMABIMEBIMIBIMMBIMQBAwchyQEhyAEhxwEhxgEhxQEgxQFBAWohygEgxQFBAWpBAnQiywFBAnRBIGooAgAhzAEgxgFB/wFxQQJ0QaAGaigCACHNASDHAUEIdkH/AXFBAnRBoA5qKAIAIc4BIMgBQRB2Qf8BcUECdEGgFmooAgAhzwEgyQFBGHZB/wFxQQJ0QaAeaigCACHQASDMASDNASDOAXMgzwEg0AFzc3Mh0QEgywFBAWpBAnRBIGooAgAh0gEgxwFB/wFxQQJ0QaAGaigCACHTASDIAUEIdkH/AXFBAnRBoA5qKAIAIdQBIMkBQRB2Qf8BcUECdEGgFmooAgAh1QEgxgFBGHZB/wFxQQJ0QaAeaigCACHWASDSASDTASDUAXMg1QEg1gFzc3Mh1wEgywFBAmpBAnRBIGooAgAh2AEgyAFB/wFxQQJ0QaAGaigCACHZASDJAUEIdkH/AXFBAnRBoA5qKAIAIdoBIMYBQRB2Qf8BcUECdEGgFmooAgAh2wEgxwFBGHZB/wFxQQJ0QaAeaigCACHcASDYASDZASDaAXMg2wEg3AFzc3Mh3QEgywFBA2pBAnRBIGooAgAh3gEgyQFB/wFxQQJ0QaAGaigCACHfASDGAUEIdkH/AXFBAnRBoA5qKAIAIeABIMcBQRB2Qf8BcUECdEGgFmooAgAh4QEgyAFBGHZB/wFxQQJ0QaAeaigCACHiASDeASDfASDgAXMg4QEg4gFzc3Mh4wEgygEg0QEg1wEg3QEg4wEgygEgvwFJDQAaGhoaGiDKASDRASDXASDdASDjAQshyQEhyAEhxwEhxgEhxQEgxQEgxgEgxwEgyAEgyQELIcQBIcMBIcIBIcEBIcABIJYBQQJ0IuQBQQJ0QSBqKAIAIeUBIMIBQQh2Qf8BcUGgBGotAAAh5gEgwwFBEHZB/wFxQaAEai0AACHnASDEAUEYdkH/AXFBoARqLQAAIegBIMEBQf8BcUGgBGotAAAh6QEg5AFBAWpBAnRBIGooAgAh6gEgwwFBCHZB/wFxQaAEai0AACHrASDEAUEQdkH/AXFBoARqLQAAIewBIMEBQRh2Qf8BcUGgBGotAAAh7QEgwgFB/wFxQaAEai0AACHuASDkAUECakECdEEgaigCACHvASDEAUEIdkH/AXFBoARqLQAAIfABIMEBQRB2Qf8BcUGgBGotAAAh8QEgwgFBGHZB/wFxQaAEai0AACHyASDDAUH/AXFBoARqLQAAIfMBIOQBQQNqQQJ0QSBqKAIAIfQBIMEBQQh2Qf8BcUGgBGotAAAh9QEgwgFBEHZB/wFxQaAEai0AACH2ASDDAUEYdkH/AXFBoARqLQAAIfcBIMQBQf8BcUGgBGotAAAh+AEgkwEgtQFqQQR0QcDIAGoi+QEoAgAh+gEg+QFBBGoi+wEoAgAh/AEg+wFBBGoi/QEoAgAh/gEg/QFBBGooAgAh/wEg+QEg+gEg5QEg6QFB/wFxIOYBQf8BcUEIdHIg5wFB/wFxQRB0IOgBQf8BcUEYdHJyc3M2AgAg+QFBBGoigAIg/AEg6gEg7gFB/wFxIOsBQf8BcUEIdHIg7AFB/wFxQRB0IO0BQf8BcUEYdHJyc3M2AgAggAJBBGoigQIg/gEg7wEg8wFB/wFxIPABQf8BcUEIdHIg8QFB/wFxQRB0IPIBQf8BcUEYdHJyc3M2AgAggQJBBGog/wEg9AEg+AFB/wFxIPUBQf8BcUEIdHIg9gFB/wFxQRB0IPcBQf8BcUEYdHJyc3M2AgBBASC2ASC3ASC4ASC5AQIHIYYCIYUCIYQCIYMCIYICIIYCQf8BcUEYdCCGAkGA/gNxQQh0ciCGAkGAgPwHcUEIdiCGAkEYdnJyIocCIIICaiKIAkH/AXFBGHQgiAJBgP4DcUEIdHIgiAJBgID8B3FBCHYgiAJBGHZyciGJAiCIAiCHAklBAXEiigIggwIghAIghQIgiQIgigJBAEYNABoaGhoaIIUCQf8BcUEYdCCFAkGA/gNxQQh0ciCFAkGAgPwHcUEIdiCFAkEYdnJyIosCIIoCaiKMAkH/AXFBGHQgjAJBgP4DcUEIdHIgjAJBgID8B3FBCHYgjAJBGHZyciGNAiCMAiCLAklBAXEijgIggwIghAIgjQIgiQIgjgJBAEYNABoaGhoaIIQCQf8BcUEYdCCEAkGA/gNxQQh0ciCEAkGAgPwHcUEIdiCEAkEYdnJyIo8CII4CaiKQAkH/AXFBGHQgkAJBgP4DcUEIdHIgkAJBgID8B3FBCHYgkAJBGHZyciGRAiCQAiCPAklBAXEikgIggwIgkQIgjQIgiQIgkgJBAEYNABoaGhoaIIMCQf8BcUEYdCCDAkGA/gNxQQh0ciCDAkGAgPwHcUEIdiCDAkEYdnJyIpMCIJICaiKUAkH/AXFBGHQglAJBgP4DcUEIdHIglAJBgID8B3FBCHYglAJBGHZyciGVAiCUAiCTAklBAXEhlgIglgIglQIgkQIgjQIgiQIglgJBAEYNABoaGhoaIJYCIJUCIJECII0CIIkCCyGGAiGFAiGEAiGDAiGCAiC6ASCDAiCEAiCFAiCGAiC6ASCVAUkNABoaGhoaILoBIIMCIIQCIIUCIIYCCyG5ASG4ASG3ASG2ASG1ASC1ASC2ASC3ASC4ASC5AQshtAEhswEhsgEhsQEhsAEgkgELIZIBIJIBQQFqIZcCIJcCIJcCIARJDQAaIJcCCyGRASCRAQshkAEgkAELIY8BC+IBARB/QQAgAUEAAgghBCEDIQIgAiADIAQgA0EAR0UNABoaGiACIAMgBAIIIQchBiEFIAUgBiAHAwghCiEJIQggCCAJIAoCCCENIQwhCyALIAwgDSAMQQFxRQ0AGhoaIAtBgAZsQYDPgAVqIAD+FwIAIAtBgAZsQYDPgAVqQQH+AAIAIQ4gDUEBIAt0ciEPIAsgDCAPCyENIQwhCyALQQFqIRAgDEEBdiERIBAgESANIBFBAEcNABoaGiAQIBEgDQshCiEJIQggCCAJIAoLIQchBiEFIAUgBiAHCyEEIQMhAiAEC5oBAQx/QQBBAAIJIQEhACAAIAEgAEEfSUUNABoaIAAgAQIJIQMhAiACIAMDCSEFIQQgBCAFAgkhByEGIAZBAWoiCEGABmxBgM2ABWr+EAIAIQkgB0EBIAh0QQAgCRtyIQogBiAKCyEHIQYgBkEBaiELIAsgByALQR9JDQAaGiALIAcLIQUhBCAEIAULIQMhAiACIAMLIQEhACABCwoAIAAgASACEAgLnQkBKX8QCkEEQQZBCCAAQRhGIgIbIABBEEYiARshA0EAQQpBDEEOIAIbIAEbIgQ2AoAEQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQACBiEFIAUgBSADSUUNABogBQIGIQYgBgMGIQcgBwIGIQggCEECdCIJQQFqLQAAIQogCUECai0AACELIAlBA2otAAAhDCAJLQAAIQ0gCEECdEGQAmogDUH/AXEgCkH/AXFBCHQgC0H/AXFBEHQgDEH/AXFBGHRycnI2AgAgCAshCCAIQQFqIQ4gDiAOIANJDQAaIA4LIQcgBwshBiAGCyEFIARBAWpBAnQhDyAPIANrIRBBAAIGIREgESARIBBJRQ0AGiARAgYhEiASAwYhEyATAgYhFCAUIANqIhVBAWtBAnRBkAJqKAIAIRYgFkEYdCAWQQh2ciIYQQh2Qf8BcUGgBGotAAAhGSAYQRB2Qf8BcUGgBGotAAAhGiAYQRh2Qf8BcUGgBGotAAAhGyAYQf8BcUGgBGotAAAhHCAVIANuQQFrQaDIAGotAAAhHSAWQQh2Qf8BcUGgBGotAAAhHiAWQRB2Qf8BcUGgBGotAAAhHyAWQRh2Qf8BcUGgBGotAAAhICAWQf8BcUGgBGotAAAhISAVIANrQQJ0QZACaigCACEiIBVBAnRBkAJqICFB/wFxIB5B/wFxQQh0ciAfQf8BcUEQdCAgQf8BcUEYdHJyIBxB/wFxIBlB/wFxQQh0ciAaQf8BcUEQdCAbQf8BcUEYdHJyIB1B/wFxcyAWIBUgA3AiF0EARhsgA0EIRiAXQQRGcRsgInM2AgAgFAshFCAUQQFqISMgIyAjIBBJDQAaICMLIRMgEwshEiASCyERQQACBiEkICQgJCAPSUUNABogJAIGISUgJQMGISYgJgIGIScgJ0ECdEGQAmooAgAhKCAnQQJ0QSBqICg2AgAgJwshJyAnQQFqISkgKSApIA9JDQAaICkLISYgJgshJSAlCyEkC48HATF/AgUgAEEAR0UNAEEAIABB/wdqQYAIbkGACCAAEAwLIAACBiEDQZ8ELQAAIQRBnwQgBEH/AXEgA0H/AXFqIgVB/wFxOgAAIANBCHYgBUEIdmoiBiAGQQBGDQAaQZ4ELQAAIQdBngQgB0H/AXEgBkH/AXFqIghB/wFxOgAAIAZBCHYgCEEIdmoiCSAJQQBGDQAaQZ0ELQAAIQpBnQQgCkH/AXEgCUH/AXFqIgtB/wFxOgAAIAlBCHYgC0EIdmoiDCAMQQBGDQAaQZwELQAAIQ1BnAQgDUH/AXEgDEH/AXFqIg5B/wFxOgAAIAxBCHYgDkEIdmoiDyAPQQBGDQAaQZsELQAAIRBBmwQgEEH/AXEgD0H/AXFqIhFB/wFxOgAAIA9BCHYgEUEIdmoiEiASQQBGDQAaQZoELQAAIRNBmgQgE0H/AXEgEkH/AXFqIhRB/wFxOgAAIBJBCHYgFEEIdmoiFSAVQQBGDQAaQZkELQAAIRZBmQQgFkH/AXEgFUH/AXFqIhdB/wFxOgAAIBVBCHYgF0EIdmoiGCAYQQBGDQAaQZgELQAAIRlBmAQgGUH/AXEgGEH/AXFqIhpB/wFxOgAAIBhBCHYgGkEIdmoiGyAbQQBGDQAaQZcELQAAIRxBlwQgHEH/AXEgG0H/AXFqIh1B/wFxOgAAIBtBCHYgHUEIdmoiHiAeQQBGDQAaQZYELQAAIR9BlgQgH0H/AXEgHkH/AXFqIiBB/wFxOgAAIB5BCHYgIEEIdmoiISAhQQBGDQAaQZUELQAAISJBlQQgIkH/AXEgIUH/AXFqIiNB/wFxOgAAICFBCHYgI0EIdmoiJCAkQQBGDQAaQZQELQAAISVBlAQgJUH/AXEgJEH/AXFqIiZB/wFxOgAAICRBCHYgJkEIdmoiJyAnQQBGDQAaQZMELQAAIShBkwQgKEH/AXEgJ0H/AXFqIilB/wFxOgAAICdBCHYgKUEIdmoiKiAqQQBGDQAaQZIELQAAIStBkgQgK0H/AXEgKkH/AXFqIixB/wFxOgAAICpBCHYgLEEIdmoiLSAtQQBGDQAaQZEELQAAIS5BkQQgLkH/AXEgLUH/AXFqIi9B/wFxOgAAIC1BCHYgL0EIdmoiMCAwQQBGDQAaQZAELQAAITEgMEEIdiAxQf8BcSAwQf8BcWoiMkEIdmohM0GQBCAyQf8BcToAACAzIDNBAEYNABogMwshAwudCQEpfxAKQQRBBkEIIABBGEYiAhsgAEEQRiIBGyEDQQBBCkEMQQ4gAhsgARsiBDYCgARBAEEANgIgQQBBADYCJEEAQQA2AihBAEEANgIsQQBBADYCMEEAQQA2AjRBAEEANgI4QQBBADYCPEEAQQA2AkBBAEEANgJEQQBBADYCSEEAQQA2AkxBAEEANgJQQQBBADYCVEEAQQA2AlhBAEEANgJcQQBBADYCYEEAQQA2AmRBAEEANgJoQQBBADYCbEEAQQA2AnBBAEEANgJ0QQBBADYCeEEAQQA2AnxBAEEANgKAAUEAQQA2AoQBQQBBADYCiAFBAEEANgKMAUEAQQA2ApABQQBBADYClAFBAEEANgKYAUEAQQA2ApwBQQBBADYCoAFBAEEANgKkAUEAQQA2AqgBQQBBADYCrAFBAEEANgKwAUEAQQA2ArQBQQBBADYCuAFBAEEANgK8AUEAQQA2AsABQQBBADYCxAFBAEEANgLIAUEAQQA2AswBQQBBADYC0AFBAEEANgLUAUEAQQA2AtgBQQBBADYC3AFBAEEANgLgAUEAQQA2AuQBQQBBADYC6AFBAEEANgLsAUEAQQA2AvABQQBBADYC9AFBAEEANgL4AUEAQQA2AvwBQQBBADYCgAJBAEEANgKEAkEAQQA2AogCQQBBADYCjAJBAAIGIQUgBSAFIANJRQ0AGiAFAgYhBiAGAwYhByAHAgYhCCAIQQJ0IglBAWotAAAhCiAJQQJqLQAAIQsgCUEDai0AACEMIAktAAAhDSAIQQJ0QZACaiANQf8BcSAKQf8BcUEIdCALQf8BcUEQdCAMQf8BcUEYdHJycjYCACAICyEIIAhBAWohDiAOIA4gA0kNABogDgshByAHCyEGIAYLIQUgBEEBakECdCEPIA8gA2shEEEAAgYhESARIBEgEElFDQAaIBECBiESIBIDBiETIBMCBiEUIBQgA2oiFUEBa0ECdEGQAmooAgAhFiAWQRh0IBZBCHZyIhhBCHZB/wFxQaAEai0AACEZIBhBEHZB/wFxQaAEai0AACEaIBhBGHZB/wFxQaAEai0AACEbIBhB/wFxQaAEai0AACEcIBUgA25BAWtBoMgAai0AACEdIBZBCHZB/wFxQaAEai0AACEeIBZBEHZB/wFxQaAEai0AACEfIBZBGHZB/wFxQaAEai0AACEgIBZB/wFxQaAEai0AACEhIBUgA2tBAnRBkAJqKAIAISIgFUECdEGQAmogIUH/AXEgHkH/AXFBCHRyIB9B/wFxQRB0ICBB/wFxQRh0cnIgHEH/AXEgGUH/AXFBCHRyIBpB/wFxQRB0IBtB/wFxQRh0cnIgHUH/AXFzIBYgFSADcCIXQQBGGyADQQhGIBdBBEZxGyAiczYCACAUCyEUIBRBAWohIyAjICMgEEkNABogIwshEyATCyESIBILIRFBAAIGISQgJCAkIA9JRQ0AGiAkAgYhJSAlAwYhJiAmAgYhJyAnQQJ0QZACaigCACEoICdBAnRBIGogKDYCACAnCyEnICdBAWohKSApICkgD0kNABogKQshJiAmCyElICULISQLigoBPX9BACgCsEghAAIFIABBAEZFDQBBAEEBAgkhAiEBIAEgAgMJIQQhAyADQQFqIQUgBCAEQQF0IARBB3ZBAXFBG2xzQf8BcXMhBiADQaAGaiAEQf8BcToAACAFIAYgBUGAAkkNABoaIAUgBgshBCEDIAMgBAshAiEBQQBB4wBB/wFxOgCgBEEAAgYhByAHIAdB/wFJRQ0AGiAHAgYhCCAIAwYhCSAJAgYhCkH/ASAKa0GgBmotAAAhCyAKQaAGai0AACEOIA5B/wFxQaAEaiALQf8BcSIMIAxBCHRyIg0gDUEEdnMgDUEFdnMgDUEGdnMgDUEHdnNB4wBzQf8BcUH/AXE6AAAgCgshCiAKQQFqIQ8gDyAPQf8BSQ0AGiAPCyEJIAkLIQggCAshB0EAAgYhECAQIBBBgAJJRQ0AGiAQAgYhESARAwYhEiASAgYhEyATQaAmakEAQf8BcToAACATCyETIBNBAWohFCAUIBRBgAJJDQAaIBQLIRIgEgshESARCyEQQQACBiEVIBUgFUGAAklFDQAaIBUCBiEWIBYDBiEXIBcCBiEYIBhBoARqLQAAIRkgGUH/AXFBoCZqIBhB/wFxOgAAIBgLIRggGEEBaiEaIBogGkGAAkkNABogGgshFyAXCyEWIBYLIRVBAEEBAgkhHCEbIBsgHAMJIR4hHSAdQQFqIR8gHkEBdCAeQQd2QQFxQRtsc0H/AXEhICAdQaDIAGogHkH/AXE6AAAgHyAgIB9BEEkNABoaIB8gIAshHiEdIB0gHgshHCEbQQACBiEhICEgIUGAAklFDQAaICECBiEiICIDBiEjICMCBiEkICRBoARqLQAAISUgJEGgJmotAAAhJyAkQQJ0QaAGaiAlQf8BcSImICZBAXQgJkEHdkEBcUEbbHNB/wFxc0EYdCAmQRB0ICZBCHQgJkEBdCAmQQd2QQFxQRtsc0H/AXFycnI2AgAgJEECdEGgKGogJ0H/AXEiKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIrcyArQQF0ICtBB3ZBAXFBG2xzQf8BcSIsQQF0ICxBB3ZBAXFBG2xzQf8BcXNBGHQgKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSItQQF0IC1BB3ZBAXFBG2xzQf8BcSIucyAuQQF0IC5BB3ZBAXFBG2xzQf8BcXNBEHQgKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIpQQF0IClBB3ZBAXFBG2xzQf8BcSIqQQF0ICpBB3ZBAXFBG2xzQf8BcXNBCHQgKEEBdCAoQQd2QQFxQRtsc0H/AXEiLyAvQQF0IC9BB3ZBAXFBG2xzQf8BcSIwcyAwQQF0IDBBB3ZBAXFBG2xzQf8BcXNycnI2AgAgJAshJCAkQQFqITEgMSAxQYACSQ0AGiAxCyEjICMLISIgIgshIUEAAgYhMiAyIDJBgAJJRQ0AGiAyAgYhMyAzAwYhNCA0AgYhNSA1QQJ0QaAGaigCACE2IDVBAnRBoA5qIDZBCHciNzYCACA1QQJ0QaAWaiA3QQh3Ijg2AgAgNUECdEGgHmogOEEIdzYCACA1QQJ0QaAoaigCACE5IDVBAnRBoDBqIDlBCHciOjYCACA1QQJ0QaA4aiA6QQh3Ijs2AgAgNUECdEGgwABqIDtBCHc2AgAgNQshNSA1QQFqITwgPCA8QYACSQ0AGiA8CyE0IDQLITMgMwshMkEAQQE2ArBICwvRAQEIfyAAQYAGbEGAzoAFaiEDIABBgAZsQYDPgAVqIQQgAEGABmxBgM2ABWpBAf4XAgACBQIFIAFFDQAMAQsCBQMFIARBAP5BAgAhBQIFIAVFIAJBAUdxRQ0AIARBAEJ//gECACEGDAELAgUgBUEBRkUNAEEAKAKAjYIFIQcgAEGABmxBgNCABWr+EAIAIQggAEGABmxBgNGABWr+EAIAIQkgAEGABmxBgNKABWr+EAIAIQogCCAJIAogBxADCyADQQH+FwIAIAINAUEBDQALCwsL6wYBO38CBQIFIAFBAUZFDQAgACABIAIgAxADDAELQQBBASABQQFBgAggAkEBa2ogAm4iBEEBIARPGyIFQQFraiAFbiIGIAEgAmxB/wdqQYAIbiIHIAYgB00bIghBASAITxsgAUUbIQkCBQIFIAlBAU1FDQAgACABIAIgAxADDAELQQAgAzYCgI2CBRABIQogAUEAIAEgCmkiCyABIAtNGyIMIAkgDCAJTRsiDUEgIA1BIE0bIg5BAWsgDkEARhsiD0EBaiIQQQFraiAQbiERIAAgAWohEiAPIAEgEUEBa2ogEW5BAWsiEyAPIBNNGyEUQQBBAEEAAgghFyEWIRUgFSAWIBcgFUEfSUUNABoaGiAVIBYgFwIIIRohGSEYIBggGSAaAwghHSEcIRsgGyAcIB0CCCEgIR8hHiAeIB8gICAgIBRPDQIaGhogHkEBaiEhIAAgIEEBaiARbGohIiAfICACCSElISQgJCAlIApBASAhdHFBAEcgIiASSXFFDQAaGiAhQYAGbEGA0IAFaiAi/hcCACAhQYAGbEGA0YAFaiARIBIgImsiIyARICNNG/4XAgAgIUGABmxBgNKABWogAv4XAgAgJEEBICF0ciEmICVBAWohJyAmICcLISUhJCAeICQgJQshICEfIR4gHkEBaiEoICggHyAgIChBH0kNABoaGiAoIB8gIAshHSEcIRsgGyAcIB0LIRohGSEYIBggGSAaCyEXIRYhFUEBIBYQACEpIAAgASARIAEgEU0bIAIgAxADIBYCBiEqICogKkEAR0UNABogKgIGISsgKwMGISwgLAIGIS1BACAtQQACCCEwIS8hLiAuIC8gMCAvQQBHRQ0AGhoaIC4gLyAwAgghMyEyITEgMSAyIDMDCCE2ITUhNCA0IDUgNgIIITkhOCE3IDcgOCA5IDhBAXFFDQAaGhogN0GABmxBgM6ABWpBAP5BAgAhOyAtQQEgN3QiOnMgO0EARw0EGiA5IDpyITwgNyA4IDwLITkhOCE3IDdBAWohPSA4QQF2IT4gPSA+IDkgPkEARw0AGhoaID0gPiA5CyE2ITUhNCA0IDUgNgshMyEyITEgMSAyIDMLITAhLyEuIC0LIS0gLSAtQQBHDQAaIC0LISwgLAshKyArCyEqQYCNggVBAEHAAPwLAAsLCxcAQQBBAEGgBPwLAEHAyABBACAA/AsACxQAIABBgAZsQYDNgAVqQQD+FwIACw=='), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 10520256);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 544)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*544, 544)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*4, 4)))
, "state.nonce": new Uint8Array(memoryExport.buffer, 528, 16)
, "state.nonce_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*16, 16)))
, constants: new Uint8Array(memoryExport.buffer, 544, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 800 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 1824 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2848 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 3872 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5152 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 6176 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 7200 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8224 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9248 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9264 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9280 + i*10485760, 10485760)))
, _worker: new Uint8Array(memoryExport.buffer, 10495104, 25152)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495104 + i*25152, 25152)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 10495104, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495104 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 10495232, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495232 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 10495360, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495360 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10495488, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495488 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 10495616, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495616 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 10520192, 64)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10520192 + i*64, 64)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}
let _cache;
export default function aes_ctr(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}