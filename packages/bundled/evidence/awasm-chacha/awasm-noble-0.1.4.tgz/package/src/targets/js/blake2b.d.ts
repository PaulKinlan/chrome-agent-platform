// WARNING: This file is auto-generated. Any changes will be lost.
export default function blake2(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly init: Uint8Array;
    readonly init_chunks: ReadonlyArray<Uint8Array>;
    readonly 'init.salt_chunks': ReadonlyArray<Uint8Array>;
    readonly 'init.personalization_chunks': ReadonlyArray<Uint8Array>;
    readonly state: Uint8Array;
    readonly state_chunks: ReadonlyArray<Uint8Array>;
    readonly 'state.counter_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.state_chunks': ReadonlyArray<Uint8Array>;
    readonly buffer: Uint8Array;
    readonly buffer_chunks: ReadonlyArray<Uint8Array>;
  };
  initBlake2(v0: number, v1: number, v2: number, v3: number, v4: number): void;
  padding(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): number;
  processBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number): void;
  processOutBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  reset(v0: number, v1: number, v2: number, v3: number, v4: number): void;
};