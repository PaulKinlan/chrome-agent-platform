// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 162, maximum: 162, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABXw5gAn9/AX9gAAF/YAF/AGAEf39/fwBgA39/fwBgAABgBn9/f39/fwBgAn9/AGABfwF/YAV/f39/fwV/f39/f2ADf39/A39/f2ACf38Cf39gA39+fgN/fn5gAn97An97AlsEA2VudgdfbWVtb3J5AgOiAaIBA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAxMSAwABBAUEBgQGBQIEBwQDAgIFB4oCEwZtZW1vcnkCABlfcHJvY2Vzc0Jsb2Nrc190aHJlYWRfaW50AAMOX3dvcmtlcl9ub3RpZnkABA5fd29ya2VyX29ubGluZQAFCWFhZEJsb2NrcwAGB2FhZEluaXQABw1kZWNyeXB0QmxvY2tzAAgLZGVjcnlwdEluaXQACQ1lbmNyeXB0QmxvY2tzAAoLZW5jcnlwdEluaXQACwlnY21Jbml0SjAADAtnaGFzaEJsb2NrcwANCmluaXRXb3JrZXIADgtub25jZUZpbmlzaAAPB3BhZExhc3QAEA1wcm9jZXNzQmxvY2tzABEFcmVzZXQAEgpzdG9wV29ya2VyABMJdGFnRmluaXNoABQKxGkS3xsBxgF/IAAgAWohBCAEIAFBAXBrIQUgAAIIIQYgBiAGIAVJRQ0AGiAGAgghByAHAwghCCAIAgghCSAJIAJsIQogAyAKayILIAIgCyACSRshDEEAKAKQBCENQQAoAoAEIQ5BACgChAQhD0EAKAKIBCEQQQAoAowEIRFBACAOIA8gECARQf8BcUEYdCARQYD+A3FBCHRyIBFBgID8B3FBCHYgEUEYdnJyIAkgAmxqIhJB/wFxQRh0IBJBgP4DcUEIdHIgEkGAgPwHcUEIdiASQRh2cnICCSEXIRYhFSEUIRMgEyAUIBUgFiAXAwkhHCEbIRohGSEYIBhBAWohHUEAKAIgIR9BACgCJCEgQQAoAighIUEAKAIsISIgDUEBayEjQQAgGSAfcyAaICBzIBsgIXMgHCAicwIJISghJyEmISUhJCAkICUgJiAnICgDCSEtISwhKyEqISkgKUEBaiEuIClBAWpBAnQiL0ECdEEgaigCACEwICpB/wFxQQJ0QYCIBGooAgAhMSArQQh2Qf8BcUECdEGAkARqKAIAITIgLEEQdkH/AXFBAnRBgJgEaigCACEzIC1BGHZB/wFxQQJ0QYCgBGooAgAhNCAwIDEgMnMgMyA0c3NzITUgL0EBakECdEEgaigCACE2ICtB/wFxQQJ0QYCIBGooAgAhNyAsQQh2Qf8BcUECdEGAkARqKAIAITggLUEQdkH/AXFBAnRBgJgEaigCACE5ICpBGHZB/wFxQQJ0QYCgBGooAgAhOiA2IDcgOHMgOSA6c3NzITsgL0ECakECdEEgaigCACE8ICxB/wFxQQJ0QYCIBGooAgAhPSAtQQh2Qf8BcUECdEGAkARqKAIAIT4gKkEQdkH/AXFBAnRBgJgEaigCACE/ICtBGHZB/wFxQQJ0QYCgBGooAgAhQCA8ID0gPnMgPyBAc3NzIUEgL0EDakECdEEgaigCACFCIC1B/wFxQQJ0QYCIBGooAgAhQyAqQQh2Qf8BcUECdEGAkARqKAIAIUQgK0EQdkH/AXFBAnRBgJgEaigCACFFICxBGHZB/wFxQQJ0QYCgBGooAgAhRiBCIEMgRHMgRSBGc3NzIUcgLiA1IDsgQSBHIC4gI0kNABoaGhoaIC4gNSA7IEEgRwshLSEsISshKiEpICkgKiArICwgLQshKCEnISYhJSEkIA1BAnQiSEECdEEgaigCACFJICZBCHZB/wFxQYCGBGotAAAhSiAnQRB2Qf8BcUGAhgRqLQAAIUsgKEEYdkH/AXFBgIYEai0AACFMICVB/wFxQYCGBGotAAAhTSBIQQFqQQJ0QSBqKAIAIU4gJ0EIdkH/AXFBgIYEai0AACFPIChBEHZB/wFxQYCGBGotAAAhUCAlQRh2Qf8BcUGAhgRqLQAAIVEgJkH/AXFBgIYEai0AACFSIEhBAmpBAnRBIGooAgAhUyAoQQh2Qf8BcUGAhgRqLQAAIVQgJUEQdkH/AXFBgIYEai0AACFVICZBGHZB/wFxQYCGBGotAAAhViAnQf8BcUGAhgRqLQAAIVcgSEEDakECdEEgaigCACFYICVBCHZB/wFxQYCGBGotAAAhWSAmQRB2Qf8BcUGAhgRqLQAAIVogJ0EYdkH/AXFBgIYEai0AACFbIChB/wFxQYCGBGotAAAhXCAKIBhqQQR0QaDKBGoiHigCACFdIB5BBGoiXigCACFfIF5BBGoiYCgCACFhIGBBBGooAgAhYiAeIF0gSSBNQf8BcSBKQf8BcUEIdHIgS0H/AXFBEHQgTEH/AXFBGHRycnNzNgIAIB5BBGoiYyBfIE4gUkH/AXEgT0H/AXFBCHRyIFBB/wFxQRB0IFFB/wFxQRh0cnJzczYCACBjQQRqImQgYSBTIFdB/wFxIFRB/wFxQQh0ciBVQf8BcUEQdCBWQf8BcUEYdHJyc3M2AgAgZEEEaiBiIFggXEH/AXEgWUH/AXFBCHRyIFpB/wFxQRB0IFtB/wFxQRh0cnJzczYCACAcQf8BcUEYdCAcQYD+A3FBCHRyIBxBgID8B3FBCHYgHEEYdnJyQQFqImVB/wFxQRh0IGVBgP4DcUEIdHIgZUGAgPwHcUEIdiBlQRh2cnIhZiAdIBkgGiAbIGYgHSAMSQ0AGhoaGhogHSAZIBogGyBmCyEcIRshGiEZIRggGCAZIBogGyAcCyEXIRYhFSEUIRMgCQshCSAJQQFqIWcgZyBnIAVJDQAaIGcLIQggCAshByAHCyEGIAUCCCFoIGggaCAESUUNABogaAIIIWkgaQMIIWogagIIIWsgayACbCFsIAMgbGsibSACIG0gAkkbIW5BACgCkAQhb0EAKAKABCFwQQAoAoQEIXFBACgCiAQhckEAKAKMBCFzQQAgcCBxIHIgc0H/AXFBGHQgc0GA/gNxQQh0ciBzQYCA/AdxQQh2IHNBGHZyciBrIAJsaiJ0Qf8BcUEYdCB0QYD+A3FBCHRyIHRBgID8B3FBCHYgdEEYdnJyAgkheSF4IXchdiF1IHUgdiB3IHggeQMJIX4hfSF8IXsheiB6QQFqIX9BACgCICGBAUEAKAIkIYIBQQAoAighgwFBACgCLCGEASBvQQFrIYUBQQAgeyCBAXMgfCCCAXMgfSCDAXMgfiCEAXMCCSGKASGJASGIASGHASGGASCGASCHASCIASCJASCKAQMJIY8BIY4BIY0BIYwBIYsBIIsBQQFqIZABIIsBQQFqQQJ0IpEBQQJ0QSBqKAIAIZIBIIwBQf8BcUECdEGAiARqKAIAIZMBII0BQQh2Qf8BcUECdEGAkARqKAIAIZQBII4BQRB2Qf8BcUECdEGAmARqKAIAIZUBII8BQRh2Qf8BcUECdEGAoARqKAIAIZYBIJIBIJMBIJQBcyCVASCWAXNzcyGXASCRAUEBakECdEEgaigCACGYASCNAUH/AXFBAnRBgIgEaigCACGZASCOAUEIdkH/AXFBAnRBgJAEaigCACGaASCPAUEQdkH/AXFBAnRBgJgEaigCACGbASCMAUEYdkH/AXFBAnRBgKAEaigCACGcASCYASCZASCaAXMgmwEgnAFzc3MhnQEgkQFBAmpBAnRBIGooAgAhngEgjgFB/wFxQQJ0QYCIBGooAgAhnwEgjwFBCHZB/wFxQQJ0QYCQBGooAgAhoAEgjAFBEHZB/wFxQQJ0QYCYBGooAgAhoQEgjQFBGHZB/wFxQQJ0QYCgBGooAgAhogEgngEgnwEgoAFzIKEBIKIBc3NzIaMBIJEBQQNqQQJ0QSBqKAIAIaQBII8BQf8BcUECdEGAiARqKAIAIaUBIIwBQQh2Qf8BcUECdEGAkARqKAIAIaYBII0BQRB2Qf8BcUECdEGAmARqKAIAIacBII4BQRh2Qf8BcUECdEGAoARqKAIAIagBIKQBIKUBIKYBcyCnASCoAXNzcyGpASCQASCXASCdASCjASCpASCQASCFAUkNABoaGhoaIJABIJcBIJ0BIKMBIKkBCyGPASGOASGNASGMASGLASCLASCMASCNASCOASCPAQshigEhiQEhiAEhhwEhhgEgb0ECdCKqAUECdEEgaigCACGrASCIAUEIdkH/AXFBgIYEai0AACGsASCJAUEQdkH/AXFBgIYEai0AACGtASCKAUEYdkH/AXFBgIYEai0AACGuASCHAUH/AXFBgIYEai0AACGvASCqAUEBakECdEEgaigCACGwASCJAUEIdkH/AXFBgIYEai0AACGxASCKAUEQdkH/AXFBgIYEai0AACGyASCHAUEYdkH/AXFBgIYEai0AACGzASCIAUH/AXFBgIYEai0AACG0ASCqAUECakECdEEgaigCACG1ASCKAUEIdkH/AXFBgIYEai0AACG2ASCHAUEQdkH/AXFBgIYEai0AACG3ASCIAUEYdkH/AXFBgIYEai0AACG4ASCJAUH/AXFBgIYEai0AACG5ASCqAUEDakECdEEgaigCACG6ASCHAUEIdkH/AXFBgIYEai0AACG7ASCIAUEQdkH/AXFBgIYEai0AACG8ASCJAUEYdkH/AXFBgIYEai0AACG9ASCKAUH/AXFBgIYEai0AACG+ASBsIHpqQQR0QaDKBGoigAEoAgAhvwEggAFBBGoiwAEoAgAhwQEgwAFBBGoiwgEoAgAhwwEgwgFBBGooAgAhxAEggAEgvwEgqwEgrwFB/wFxIKwBQf8BcUEIdHIgrQFB/wFxQRB0IK4BQf8BcUEYdHJyc3M2AgAggAFBBGoixQEgwQEgsAEgtAFB/wFxILEBQf8BcUEIdHIgsgFB/wFxQRB0ILMBQf8BcUEYdHJyc3M2AgAgxQFBBGoixgEgwwEgtQEguQFB/wFxILYBQf8BcUEIdHIgtwFB/wFxQRB0ILgBQf8BcUEYdHJyc3M2AgAgxgFBBGogxAEgugEgvgFB/wFxILsBQf8BcUEIdHIgvAFB/wFxQRB0IL0BQf8BcUEYdHJyc3M2AgAgfkH/AXFBGHQgfkGA/gNxQQh0ciB+QYCA/AdxQQh2IH5BGHZyckEBaiLHAUH/AXFBGHQgxwFBgP4DcUEIdHIgxwFBgID8B3FBCHYgxwFBGHZyciHIASB/IHsgfCB9IMgBIH8gbkkNABoaGhoaIH8geyB8IH0gyAELIX4hfSF8IXsheiB6IHsgfCB9IH4LIXkheCF3IXYhdSBrCyFrIGtBAWohyQEgyQEgyQEgBEkNABogyQELIWogagshaSBpCyFoC+IBARB/QQAgAUEAAgohBCEDIQIgAiADIAQgA0EAR0UNABoaGiACIAMgBAIKIQchBiEFIAUgBiAHAwohCiEJIQggCCAJIAoCCiENIQwhCyALIAwgDSAMQQFxRQ0AGhoaIAtBgAZsQYDRhAVqIAD+FwIAIAtBgAZsQYDRhAVqQQH+AAIAIQ4gDUEBIAt0ciEPIAsgDCAPCyENIQwhCyALQQFqIRAgDEEBdiERIBAgESANIBFBAEcNABoaGiAQIBEgDQshCiEJIQggCCAJIAoLIQchBiEFIAUgBiAHCyEEIQMhAiAEC5oBAQx/QQBBAAILIQEhACAAIAEgAEEfSUUNABoaIAAgAQILIQMhAiACIAMDCyEFIQQgBCAFAgshByEGIAZBAWoiCEGABmxBgM+EBWr+EAIAIQkgB0EBIAh0QQAgCRtyIQogBiAKCyEHIQYgBkEBaiELIAsgByALQR9JDQAaGiALIAcLIQUhBCAEIAULIQMhAiACIAMLIQEhACABCwYAIAAQDQs7AEEAQQA2AtAEQQBBADYC1ARBAEEANgLYBEEAQQA2AtwEQQD9DAAAAAAAAAAAAAAAAAAAAAD9CwTgBAuvAgIBfg1/QQApA6AEIQNBACADIABBBHQgAmutfDcDoAQgACABIAIQECAAEA0CBSAAQQBHRQ0AQQAgAEH/B2pBgAhuQYAIIAAQEQsgAAIIIQRBjwQtAAAhBUGPBCAFQf8BcSAEQf8BcWoiBkH/AXE6AAAgBEEIdiAGQQh2aiIHIAdBAEYNABpBjgQtAAAhCEGOBCAIQf8BcSAHQf8BcWoiCUH/AXE6AAAgB0EIdiAJQQh2aiIKIApBAEYNABpBjQQtAAAhC0GNBCALQf8BcSAKQf8BcWoiDEH/AXE6AAAgCkEIdiAMQQh2aiINIA1BAEYNABpBjAQtAAAhDiANQQh2IA5B/wFxIA1B/wFxaiIPQQh2aiEQQYwEIA9B/wFxOgAAIBAgEEEARg0AGiAQCyEECxAAIAAgASACIAMgBCAFEAsLrwICAX4Nf0EAKQOgBCEDQQAgAyAAQQR0IAJrrXw3A6AEAgUgAEEAR0UNAEEAIABB/wdqQYAIbkGACCAAEBELIAACCCEEQY8ELQAAIQVBjwQgBUH/AXEgBEH/AXFqIgZB/wFxOgAAIARBCHYgBkEIdmoiByAHQQBGDQAaQY4ELQAAIQhBjgQgCEH/AXEgB0H/AXFqIglB/wFxOgAAIAdBCHYgCUEIdmoiCiAKQQBGDQAaQY0ELQAAIQtBjQQgC0H/AXEgCkH/AXFqIgxB/wFxOgAAIApBCHYgDEEIdmoiDSANQQBGDQAaQYwELQAAIQ4gDUEIdiAOQf8BcSANQf8BcWoiD0EIdmohEEGMBCAPQf8BcToAACAQIBBBAEYNABogEAshBCAAIAEgAhAQIAAQDQvYJxupAX8GfgF/An4BfwJ+AX8CfgF/An4BfwJ+AX8CfgF/An4Bfwh+Bn8BewF/AXsBfwF7AX8DewN/QQAoApDKBCEGAgUgBkEARkUNAEEAQQECCyEIIQcgByAIAwshCiEJIAlBAWohCyAKIApBAXQgCkEHdkEBcUEbbHNB/wFxcyEMIAlBgIgEaiAKQf8BcToAACALIAwgC0GAAkkNABoaIAsgDAshCiEJIAkgCgshCCEHQQBB4wBB/wFxOgCAhgRBAAIIIQ0gDSANQf8BSUUNABogDQIIIQ4gDgMIIQ8gDwIIIRBB/wEgEGtBgIgEai0AACERIBBBgIgEai0AACEUIBRB/wFxQYCGBGogEUH/AXEiEiASQQh0ciITIBNBBHZzIBNBBXZzIBNBBnZzIBNBB3ZzQeMAc0H/AXFB/wFxOgAAIBALIRAgEEEBaiEVIBUgFUH/AUkNABogFQshDyAPCyEOIA4LIQ1BAAIIIRYgFiAWQYACSUUNABogFgIIIRcgFwMIIRggGAIIIRkgGUGAqARqQQBB/wFxOgAAIBkLIRkgGUEBaiEaIBogGkGAAkkNABogGgshGCAYCyEXIBcLIRZBAAIIIRsgGyAbQYACSUUNABogGwIIIRwgHAMIIR0gHQIIIR4gHkGAhgRqLQAAIR8gH0H/AXFBgKgEaiAeQf8BcToAACAeCyEeIB5BAWohICAgICBBgAJJDQAaICALIR0gHQshHCAcCyEbQQBBAQILISIhISAhICIDCyEkISMgI0EBaiElICRBAXQgJEEHdkEBcUEbbHNB/wFxISYgI0GAygRqICRB/wFxOgAAICUgJiAlQRBJDQAaGiAlICYLISQhIyAjICQLISIhIUEAAgghJyAnICdBgAJJRQ0AGiAnAgghKCAoAwghKSApAgghKiAqQYCGBGotAAAhKyAqQYCoBGotAAAhLSAqQQJ0QYCIBGogK0H/AXEiLCAsQQF0ICxBB3ZBAXFBG2xzQf8BcXNBGHQgLEEQdCAsQQh0ICxBAXQgLEEHdkEBcUEbbHNB/wFxcnJyNgIAICpBAnRBgKoEaiAtQf8BcSIuIC5BAXQgLkEHdkEBcUEbbHNB/wFxIjFzIDFBAXQgMUEHdkEBcUEbbHNB/wFxIjJBAXQgMkEHdkEBcUEbbHNB/wFxc0EYdCAuIC5BAXQgLkEHdkEBcUEbbHNB/wFxIjNBAXQgM0EHdkEBcUEbbHNB/wFxIjRzIDRBAXQgNEEHdkEBcUEbbHNB/wFxc0EQdCAuIC5BAXQgLkEHdkEBcUEbbHNB/wFxIi9BAXQgL0EHdkEBcUEbbHNB/wFxIjBBAXQgMEEHdkEBcUEbbHNB/wFxc0EIdCAuQQF0IC5BB3ZBAXFBG2xzQf8BcSI1IDVBAXQgNUEHdkEBcUEbbHNB/wFxIjZzIDZBAXQgNkEHdkEBcUEbbHNB/wFxc3JycjYCACAqCyEqICpBAWohNyA3IDdBgAJJDQAaIDcLISkgKQshKCAoCyEnQQACCCE4IDggOEGAAklFDQAaIDgCCCE5IDkDCCE6IDoCCCE7IDtBAnRBgIgEaigCACE8IDtBAnRBgJAEaiA8QQh3Ij02AgAgO0ECdEGAmARqID1BCHciPjYCACA7QQJ0QYCgBGogPkEIdzYCACA7QQJ0QYCqBGooAgAhPyA7QQJ0QYCyBGogP0EIdyJANgIAIDtBAnRBgLoEaiBAQQh3IkE2AgAgO0ECdEGAwgRqIEFBCHc2AgAgOwshOyA7QQFqIUIgQiBCQYACSQ0AGiBCCyE6IDoLITkgOQshOEEAQQE2ApDKBAtBBEEGQQggAEEYRiJEGyAAQRBGIkMbIUVBAEEKQQxBDiBEGyBDGyJGNgKQBEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgghRyBHIEcgRUlFDQAaIEcCCCFIIEgDCCFJIEkCCCFKIEpBAnQiS0EBai0AACFMIEtBAmotAAAhTSBLQQNqLQAAIU4gSy0AACFPIEpBAnRBkAJqIE9B/wFxIExB/wFxQQh0IE1B/wFxQRB0IE5B/wFxQRh0cnJyNgIAIEoLIUogSkEBaiFQIFAgUCBFSQ0AGiBQCyFJIEkLIUggSAshRyBGQQFqQQJ0IVEgUSBFayFSQQACCCFTIFMgUyBSSUUNABogUwIIIVQgVAMIIVUgVQIIIVYgViBFaiJXQQFrQQJ0QZACaigCACFYIFhBGHQgWEEIdnIiWkEIdkH/AXFBgIYEai0AACFbIFpBEHZB/wFxQYCGBGotAAAhXCBaQRh2Qf8BcUGAhgRqLQAAIV0gWkH/AXFBgIYEai0AACFeIFcgRW5BAWtBgMoEai0AACFfIFhBCHZB/wFxQYCGBGotAAAhYCBYQRB2Qf8BcUGAhgRqLQAAIWEgWEEYdkH/AXFBgIYEai0AACFiIFhB/wFxQYCGBGotAAAhYyBXIEVrQQJ0QZACaigCACFkIFdBAnRBkAJqIGNB/wFxIGBB/wFxQQh0ciBhQf8BcUEQdCBiQf8BcUEYdHJyIF5B/wFxIFtB/wFxQQh0ciBcQf8BcUEQdCBdQf8BcUEYdHJyIF9B/wFxcyBYIFcgRXAiWUEARhsgRUEIRiBZQQRGcRsgZHM2AgAgVgshViBWQQFqIWUgZSBlIFJJDQAaIGULIVUgVQshVCBUCyFTQQACCCFmIGYgZiBRSUUNABogZgIIIWcgZwMIIWggaAIIIWkgaUECdEGQAmooAgAhaiBpQQJ0QSBqIGo2AgAgaQshaSBpQQFqIWsgayBrIFFJDQAaIGsLIWggaAshZyBnCyFmQQAoApAEIWxBACgCICFtQQAoAiQhbkEAKAIoIW9BACgCLCFwIGxBAWshcUEAIG0gbiBvIHACCSF2IXUhdCFzIXIgciBzIHQgdSB2AwkheyF6IXkheCF3IHdBAWohfCB3QQFqQQJ0In1BAnRBIGooAgAhfiB4Qf8BcUECdEGAiARqKAIAIX8geUEIdkH/AXFBAnRBgJAEaigCACGAASB6QRB2Qf8BcUECdEGAmARqKAIAIYEBIHtBGHZB/wFxQQJ0QYCgBGooAgAhggEgfiB/IIABcyCBASCCAXNzcyGDASB9QQFqQQJ0QSBqKAIAIYQBIHlB/wFxQQJ0QYCIBGooAgAhhQEgekEIdkH/AXFBAnRBgJAEaigCACGGASB7QRB2Qf8BcUECdEGAmARqKAIAIYcBIHhBGHZB/wFxQQJ0QYCgBGooAgAhiAEghAEghQEghgFzIIcBIIgBc3NzIYkBIH1BAmpBAnRBIGooAgAhigEgekH/AXFBAnRBgIgEaigCACGLASB7QQh2Qf8BcUECdEGAkARqKAIAIYwBIHhBEHZB/wFxQQJ0QYCYBGooAgAhjQEgeUEYdkH/AXFBAnRBgKAEaigCACGOASCKASCLASCMAXMgjQEgjgFzc3MhjwEgfUEDakECdEEgaigCACGQASB7Qf8BcUECdEGAiARqKAIAIZEBIHhBCHZB/wFxQQJ0QYCQBGooAgAhkgEgeUEQdkH/AXFBAnRBgJgEaigCACGTASB6QRh2Qf8BcUECdEGAoARqKAIAIZQBIJABIJEBIJIBcyCTASCUAXNzcyGVASB8IIMBIIkBII8BIJUBIHwgcUkNABoaGhoaIHwggwEgiQEgjwEglQELIXsheiF5IXghdyB3IHggeSB6IHsLIXYhdSF0IXMhciBsQQJ0IpYBQQJ0QSBqKAIAIZcBIHRBCHZB/wFxQYCGBGotAAAhmAEgdUEQdkH/AXFBgIYEai0AACGZASB2QRh2Qf8BcUGAhgRqLQAAIZoBIHNB/wFxQYCGBGotAAAhmwEglgFBAWpBAnRBIGooAgAhnAEgdUEIdkH/AXFBgIYEai0AACGdASB2QRB2Qf8BcUGAhgRqLQAAIZ4BIHNBGHZB/wFxQYCGBGotAAAhnwEgdEH/AXFBgIYEai0AACGgASCWAUECakECdEEgaigCACGhASB2QQh2Qf8BcUGAhgRqLQAAIaIBIHNBEHZB/wFxQYCGBGotAAAhowEgdEEYdkH/AXFBgIYEai0AACGkASB1Qf8BcUGAhgRqLQAAIaUBIJYBQQNqQQJ0QSBqKAIAIaYBIHNBCHZB/wFxQYCGBGotAAAhpwEgdEEQdkH/AXFBgIYEai0AACGoASB1QRh2Qf8BcUGAhgRqLQAAIakBIHZB/wFxQYCGBGotAAAhqgFBACCXASCbAUH/AXEgmAFB/wFxQQh0ciCZAUH/AXFBEHQgmgFB/wFxQRh0cnJzNgLwBEEAIJwBIKABQf8BcSCdAUH/AXFBCHRyIJ4BQf8BcUEQdCCfAUH/AXFBGHRycnM2AvQEQQAgoQEgpQFB/wFxIKIBQf8BcUEIdHIgowFB/wFxQRB0IKQBQf8BcUEYdHJyczYC+ARBACCmASCqAUH/AXEgpwFB/wFxQQh0ciCoAUH/AXFBEHQgqQFB/wFxQRh0cnJzNgL8BEEAKALwBCGrAUEAKAL0BCGsAUEAKAL4BCGtAUEAKAL8BCGuAUEAIKwBrUIghiCrAa2EIq8BQv+B/Ifwn8D/AINBCKyGIK8BQQisiEL/gfyH8J/A/wCDhCKxAUL//4OA8P8/g0EQrIYgsQFBEKyIQv//g4Dw/z+DhCKyAUEgrIYgsgFBIKyIhCCuAa1CIIYgrQGthCKwAUL/gfyH8J/A/wCDQQishiCwAUEIrIhC/4H8h/CfwP8Ag4QiswFC//+DgPD/P4NBEKyGILMBQRCsiEL//4OA8P8/g4QitAFBIKyGILQBQSCsiIQCDCG3ASG2ASG1ASC1ASC2ASC3ASC1AUEQSUUNABoaGiC1ASC2ASC3AQIMIboBIbkBIbgBILgBILkBILoBAwwhvQEhvAEhuwEguwEgvAEgvQECDCHAASG/ASG+AUEAIL8BIMABAgwhwwEhwgEhwQEgwQEgwgEgwwEgwQFBCElFDQAaGhogwQEgwgEgwwECDCHGASHFASHEASDEASDFASDGAQMMIckBIcgBIccBIMcBIMgBIMkBAgwhzAEhywEhygEgygFBBHRBgIUEaiDLAUL/gfyH8J/A/wCDQQishiDLAUEIrIhC/4H8h/CfwP8Ag4QizQFC//+DgPD/P4NBEKyGIM0BQRCsiEL//4OA8P8/g4QizgFBIKyGIM4BQSCsiIT9EiDMAUL/gfyH8J/A/wCDQQishiDMAUEIrIhC/4H8h/CfwP8Ag4QizwFC//+DgPD/P4NBEKyGIM8BQRCsiEL//4OA8P8/g4Qi0AFBIKyGINABQSCsiIT9HgH9CwQAIMsBQj+GIMwBQgGIhCHRASDLAUIBiEKAgICAgICAgGFCACDMAUIBg32DhSHSASDKASDSASDRAQshzAEhywEhygEgygFBAWoh0wEg0wEgywEgzAEg0wFBCEkNABoaGiDTASDLASDMAQshyQEhyAEhxwEgxwEgyAEgyQELIcYBIcUBIcQBIMQBIMUBIMYBCyHDASHCASHBAUEAAggh1AEg1AEg1AFBgAJJRQ0AGiDUAQIIIdUBINUBAwgh1gEg1gECCCHXAUEA/QwAAAAAAAAAAAAAAAAAAAAAAg0h2QEh2AEg2AEg2QEg2AFBCElFDQAaGiDYASDZAQINIdsBIdoBINoBINsBAw0h3QEh3AEg3AEg3QECDSHfASHeASDeAUEEdEGAhQRq/QAEACHgASDfASDgAUIAINcBQQcg3gFrdkEBca19/RL9Tv1RIeEBIN4BIOEBCyHfASHeASDeAUEBaiHiASDiASDfASDiAUEISQ0AGhog4gEg3wELId0BIdwBINwBIN0BCyHbASHaASDaASDbAQsh2QEh2AEgvgFBCHQg1wFqQQR0QYAFaiDZAf0LBAAg1wELIdcBINcBQQFqIeMBIOMBIOMBQYACSQ0AGiDjAQsh1gEg1gELIdUBINUBCyHUASC+ASDCASDDAQshwAEhvwEhvgEgvgFBAWoh5AEg5AEgvwEgwAEg5AFBEEkNABoaGiDkASC/ASDAAQshvQEhvAEhuwEguwEgvAEgvQELIboBIbkBIbgBILgBILkBILoBCyG3ASG2ASG1AUEAIAWtQiCGIASthDcDmARBAEIANwOgBEGwBEEAQRD8CwBBwARBAEEQ/AsAAgUgAUEMRkUNAEEAQQFB/wFxOgCPBBAMCwumCwFQf0EAKAKQBCEAQQAoAoAEIQFBACgChAQhAkEAKAKIBCEDQQAoAowEIQRBACgCICEFQQAoAiQhBkEAKAIoIQdBACgCLCEIIABBAWshCUEAIAEgBXMgAiAGcyADIAdzIAQgCHMCCSEOIQ0hDCELIQogCiALIAwgDSAOAwkhEyESIREhECEPIA9BAWohFCAPQQFqQQJ0IhVBAnRBIGooAgAhFiAQQf8BcUECdEGAiARqKAIAIRcgEUEIdkH/AXFBAnRBgJAEaigCACEYIBJBEHZB/wFxQQJ0QYCYBGooAgAhGSATQRh2Qf8BcUECdEGAoARqKAIAIRogFiAXIBhzIBkgGnNzcyEbIBVBAWpBAnRBIGooAgAhHCARQf8BcUECdEGAiARqKAIAIR0gEkEIdkH/AXFBAnRBgJAEaigCACEeIBNBEHZB/wFxQQJ0QYCYBGooAgAhHyAQQRh2Qf8BcUECdEGAoARqKAIAISAgHCAdIB5zIB8gIHNzcyEhIBVBAmpBAnRBIGooAgAhIiASQf8BcUECdEGAiARqKAIAISMgE0EIdkH/AXFBAnRBgJAEaigCACEkIBBBEHZB/wFxQQJ0QYCYBGooAgAhJSARQRh2Qf8BcUECdEGAoARqKAIAISYgIiAjICRzICUgJnNzcyEnIBVBA2pBAnRBIGooAgAhKCATQf8BcUECdEGAiARqKAIAISkgEEEIdkH/AXFBAnRBgJAEaigCACEqIBFBEHZB/wFxQQJ0QYCYBGooAgAhKyASQRh2Qf8BcUECdEGAoARqKAIAISwgKCApICpzICsgLHNzcyEtIBQgGyAhICcgLSAUIAlJDQAaGhoaGiAUIBsgISAnIC0LIRMhEiERIRAhDyAPIBAgESASIBMLIQ4hDSEMIQshCiAAQQJ0Ii5BAnRBIGooAgAhLyAMQQh2Qf8BcUGAhgRqLQAAITAgDUEQdkH/AXFBgIYEai0AACExIA5BGHZB/wFxQYCGBGotAAAhMiALQf8BcUGAhgRqLQAAITMgLkEBakECdEEgaigCACE0IA1BCHZB/wFxQYCGBGotAAAhNSAOQRB2Qf8BcUGAhgRqLQAAITYgC0EYdkH/AXFBgIYEai0AACE3IAxB/wFxQYCGBGotAAAhOCAuQQJqQQJ0QSBqKAIAITkgDkEIdkH/AXFBgIYEai0AACE6IAtBEHZB/wFxQYCGBGotAAAhOyAMQRh2Qf8BcUGAhgRqLQAAITwgDUH/AXFBgIYEai0AACE9IC5BA2pBAnRBIGooAgAhPiALQQh2Qf8BcUGAhgRqLQAAIT8gDEEQdkH/AXFBgIYEai0AACFAIA1BGHZB/wFxQYCGBGotAAAhQSAOQf8BcUGAhgRqLQAAIUJBACAvIDNB/wFxIDBB/wFxQQh0ciAxQf8BcUEQdCAyQf8BcUEYdHJyczYCsARBACA0IDhB/wFxIDVB/wFxQQh0ciA2Qf8BcUEQdCA3Qf8BcUEYdHJyczYCtARBACA5ID1B/wFxIDpB/wFxQQh0ciA7Qf8BcUEQdCA8Qf8BcUEYdHJyczYCuARBACA+IEJB/wFxID9B/wFxQQh0ciBAQf8BcUEQdCBBQf8BcUEYdHJyczYCvARBAQIIIUNBjwQtAAAhREGPBCBEQf8BcSBDQf8BcWoiRUH/AXE6AAAgQ0EIdiBFQQh2aiJGIEZBAEYNABpBjgQtAAAhR0GOBCBHQf8BcSBGQf8BcWoiSEH/AXE6AAAgRkEIdiBIQQh2aiJJIElBAEYNABpBjQQtAAAhSkGNBCBKQf8BcSBJQf8BcWoiS0H/AXE6AAAgSUEIdiBLQQh2aiJMIExBAEYNABpBjAQtAAAhTSBMQQh2IE1B/wFxIExB/wFxaiJOQQh2aiFPQYwEIE5B/wFxOgAAIE8gT0EARg0AGiBPCyFDC5gGDAF7AX8BewF/AXsBfwF7AX8DewJ+EXsBf0EA/QAE4AQhAUEAIAECDSEDIQIgAiADIAIgAElFDQAaGiACIAMCDSEFIQQgBCAFAw0hByEGIAYgBwINIQkhCCAIQQR0QaDKBGr9AAQAIQogCSAK/VEhCyAL/R0AIgxCAIhC/wGDp0EAdkH/AXFBBHRBgAVq/QAEACEOQYACIAxCCIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhD0GABCAMQhCIQv8Bg6dBAHZB/wFxakEEdEGABWr9AAQAIRBBgAYgDEIYiEL/AYOnQQB2Qf8BcWpBBHRBgAVq/QAEACERQYAIIAxCIIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhEkGACiAMQiiIQv8Bg6dBAHZB/wFxakEEdEGABWr9AAQAIRNBgAwgDEIwiEL/AYOnQQB2Qf8BcWpBBHRBgAVq/QAEACEUQYAOIAxCOIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhFUGAECAL/R0BIg1CAIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhFkGAEiANQgiIQv8Bg6dBAHZB/wFxakEEdEGABWr9AAQAIRdBgBQgDUIQiEL/AYOnQQB2Qf8BcWpBBHRBgAVq/QAEACEYQYAWIA1CGIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhGUGAGCANQiCIQv8Bg6dBAHZB/wFxakEEdEGABWr9AAQAIRpBgBogDUIoiEL/AYOnQQB2Qf8BcWpBBHRBgAVq/QAEACEbQYAcIA1CMIhC/wGDp0EAdkH/AXFqQQR0QYAFav0ABAAhHEGAHiANQjiIQv8Bg6dBAHZB/wFxakEEdEGABWr9AAQAIR0gDiAP/VEgEP1RIBH9USAS/VEgE/1RIBT9USAV/VEgFv1RIBf9USAY/VEgGf1RIBr9USAb/VEgHP1RIB39USEeIAggHgshCSEIIAhBAWohHyAfIAkgHyAASQ0AGhogHyAJCyEHIQYgBiAHCyEFIQQgBCAFCyEDIQJBACAD/QsE4AQL0QEBCH8gAEGABmxBgNCEBWohAyAAQYAGbEGA0YQFaiEEIABBgAZsQYDPhAVqQQH+FwIAAgUCBSABRQ0ADAELAgUDBSAEQQD+QQIAIQUCBSAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCwIFIAVBAUZFDQBBACgCgI+GBSEHIABBgAZsQYDShAVq/hACACEIIABBgAZsQYDThAVq/hACACEJIABBgAZsQYDUhAVq/hACACEKIAggCSAKIAcQAwsgA0EB/hcCACACDQFBAQ0ACwsLC5kBAgJ7An5BAEIANwOgygQgAa1CIIYgAK2E/RIhAkEAIAIgAv0NBwYFBAMCAQAPDg0MCwoJCP0dADcDqMoEQQEQDUEA/QAE4AQhA0EAIAP9HQAiBKc2AoAEQQAgBEIgiKc2AoQEQQAgA/0dASIFpzYCiARBACAFQiCIpzYCjARBAP0MAAAAAAAAAAAAAAAAAAAAAP0LBOAEEAwLKwEBfwIFIAEgAkEAR3FFDQAgAEEEdCACayIDQaDKBGpBACADIAJq/AsACwvrBgE7fwIFAgUgAUEBRkUNACAAIAEgAiADEAMMAQtBAEEBIAFBAUGACCACQQFraiACbiIEQQEgBE8bIgVBAWtqIAVuIgYgASACbEH/B2pBgAhuIgcgBiAHTRsiCEEBIAhPGyABRRshCQIFAgUgCUEBTUUNACAAIAEgAiADEAMMAQtBACADNgKAj4YFEAEhCiABQQAgASAKaSILIAEgC00bIgwgCSAMIAlNGyINQSAgDUEgTRsiDkEBayAOQQBGGyIPQQFqIhBBAWtqIBBuIREgACABaiESIA8gASARQQFraiARbkEBayITIA8gE00bIRRBAEEAQQACCiEXIRYhFSAVIBYgFyAVQR9JRQ0AGhoaIBUgFiAXAgohGiEZIRggGCAZIBoDCiEdIRwhGyAbIBwgHQIKISAhHyEeIB4gHyAgICAgFE8NAhoaGiAeQQFqISEgACAgQQFqIBFsaiEiIB8gIAILISUhJCAkICUgCkEBICF0cUEARyAiIBJJcUUNABoaICFBgAZsQYDShAVqICL+FwIAICFBgAZsQYDThAVqIBEgEiAiayIjIBEgI00b/hcCACAhQYAGbEGA1IQFaiAC/hcCACAkQQEgIXRyISYgJUEBaiEnICYgJwshJSEkIB4gJCAlCyEgIR8hHiAeQQFqISggKCAfICAgKEEfSQ0AGhoaICggHyAgCyEdIRwhGyAbIBwgHQshGiEZIRggGCAZIBoLIRchFiEVQQEgFhAAISkgACABIBEgASARTRsgAiADEAMgFgIIISogKiAqQQBHRQ0AGiAqAgghKyArAwghLCAsAgghLUEAIC1BAAIKITAhLyEuIC4gLyAwIC9BAEdFDQAaGhogLiAvIDACCiEzITIhMSAxIDIgMwMKITYhNSE0IDQgNSA2AgohOSE4ITcgNyA4IDkgOEEBcUUNABoaGiA3QYAGbEGA0IQFakEA/kECACE7IC1BASA3dCI6cyA7QQBHDQQaIDkgOnIhPCA3IDggPAshOSE4ITcgN0EBaiE9IDhBAXYhPiA9ID4gOSA+QQBHDQAaGhogPSA+IDkLITYhNSE0IDQgNSA2CyEzITIhMSAxIDIgMwshMCEvIS4gLQshLSAtIC1BAEcNABogLQshLCAsCyErICsLISpBgI+GBUEAQcAA/AsACwsLGABBAEEAQYCGBPwLAEGgygRBACAA/AsACxQAIABBgAZsQYDPhAVqQQD+FwIAC9kBBAJ+A3sCfgR/QQApA5gEIQBBACkDoAQhASAAQgOG/RIhAkEAIAIgAv0NBwYFBAMCAQAPDg0MCwoJCP0dADcDoMoEIAFCA4b9EiEDQQAgAyAD/Q0HBgUEAwIBAA8ODQwLCgkI/R0ANwOoygRBARANQQD9AATgBCEEQQAoArAEIQdBACgCtAQhCEEAKAK4BCEJQQAoArwEIQpBACAE/R0AIgWnIAdzNgLABEEAIAVCIIinIAhzNgLEBEEAIAT9HQEiBqcgCXM2AsgEQQAgBkIgiKcgCnM2AswECw=='), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 10586048);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 66304)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*66304, 66304)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.nonce": new Uint8Array(memoryExport.buffer, 512, 16)
, "state.nonce_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*16, 16)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 528, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*4, 4)))
, "state.aadLen": new Uint8Array(memoryExport.buffer, 536, 8)
, "state.aadLen_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 536 + i*8, 8)))
, "state.dataLen": new Uint8Array(memoryExport.buffer, 544, 8)
, "state.dataLen_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*8, 8)))
, "state.tagMask": new Uint8Array(memoryExport.buffer, 560, 16)
, "state.tagMask_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 560 + i*16, 16)))
, "state.tag": new Uint8Array(memoryExport.buffer, 576, 16)
, "state.tag_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 576 + i*16, 16)))
, "state.ghash": new Uint8Array(memoryExport.buffer, 592, 48)
, "state.ghash_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 592 + i*48, 48)))
, "state.ghash.y": new Uint8Array(memoryExport.buffer, 592, 16)
, "state.ghash.y_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 592 + i*16, 16)))
, "state.ghash.y64": new Uint8Array(memoryExport.buffer, 608, 16)
, "state.ghash.y64_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 608 + i*16, 16)))
, "state.ghash.h": new Uint8Array(memoryExport.buffer, 624, 16)
, "state.ghash.h_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 624 + i*16, 16)))
, "state.table64v": new Uint8Array(memoryExport.buffer, 640, 65536)
, "state.table64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 640 + i*65536, 65536)))
, "state.tmp64v": new Uint8Array(memoryExport.buffer, 66176, 128)
, "state.tmp64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 66176 + i*128, 128)))
, constants: new Uint8Array(memoryExport.buffer, 66304, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 66304 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 66304, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 66304 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 66304, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 66304 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 66560, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 66560 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 67584, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 67584 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 68608, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 68608 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 69632, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 69632 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 70656, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 70656 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 70656, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 70656 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 70912, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 70912 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 71936, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 71936 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 72960, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 72960 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 73984, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 73984 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 75008, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 75008 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 75024, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 75024 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 75040, 10485760)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 75040 + i*10485760, 10485760)))
, _worker: new Uint8Array(memoryExport.buffer, 10560896, 25152)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10560896 + i*25152, 25152)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 10560896, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10560896 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 10561024, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10561024 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 10561152, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10561152 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10561280, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10561280 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 10561408, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10561408 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 10585984, 64)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10585984 + i*64, 64)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}
let _cache;
export default function aes_gcm(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}