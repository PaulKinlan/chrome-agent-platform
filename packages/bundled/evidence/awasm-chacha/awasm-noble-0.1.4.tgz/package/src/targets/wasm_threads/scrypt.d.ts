// WARNING: This file is auto-generated. Any changes will be lost.
export default function scrypt(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly xorInput: Uint8Array;
    readonly xorInput_chunks: ReadonlyArray<Uint8Array>;
    readonly output: Uint8Array;
    readonly output_chunks: ReadonlyArray<Uint8Array>;
    readonly _worker: Uint8Array;
    readonly _worker_chunks: ReadonlyArray<Uint8Array>;
    readonly '_worker.online': Uint8Array;
    readonly '_worker.online_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.next': Uint8Array;
    readonly '_worker.next_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.total': Uint8Array;
    readonly '_worker.total_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.perBatch': Uint8Array;
    readonly '_worker.perBatch_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.workers': Uint8Array;
    readonly '_worker.workers_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.stack': Uint8Array;
    readonly '_worker.stack_chunks': ReadonlyArray<Uint8Array>;
  };
  _blockMix_thread_int(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number): void;
  _worker_notify(v0: number, v1: number): number;
  _worker_online(): number;
  blockMix(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number): void;
  initWorker(v0: number, v1: number, v2: number): void;
  stopWorker(v0: number): void;
};