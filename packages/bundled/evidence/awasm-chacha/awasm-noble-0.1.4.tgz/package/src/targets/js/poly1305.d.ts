// WARNING: This file is auto-generated. Any changes will be lost.
export default function poly1305(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly state: Uint8Array;
    readonly state_chunks: ReadonlyArray<Uint8Array>;
    readonly 'state.state_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.key_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.r_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.r5_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.h_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.pad_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.poly.tag_chunks': ReadonlyArray<Uint8Array>;
    readonly buffer: Uint8Array;
    readonly buffer_chunks: ReadonlyArray<Uint8Array>;
  };
  macBlocksAt(v0: number, v1: number, v2: number, v3: number, v4: number): void;
  macFinish(v0: number): void;
  macInit(v0: number): void;
  macPadAt(v0: number, v1: number, v2: number): void;
  padding(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): number;
  processBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number): void;
  processOutBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  reset(v0: number, v1: number, v2: number, v3: number, v4: number): void;
};