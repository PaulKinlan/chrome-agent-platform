// WARNING: This file is auto-generated. Any changes will be lost.
export default function argon(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly refBlocks: Uint8Array;
    readonly refBlocks_chunks: ReadonlyArray<Uint8Array>;
    readonly inputBlocks: Uint8Array;
    readonly inputBlocks_chunks: ReadonlyArray<Uint8Array>;
    readonly indices: Uint8Array;
    readonly indices_chunks: ReadonlyArray<Uint8Array>;
    readonly refIndices: Uint8Array;
    readonly refIndices_chunks: ReadonlyArray<Uint8Array>;
  };
  compress(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  getAddresses(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number, v8: number, v9: number): void;
};