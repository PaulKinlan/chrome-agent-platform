// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};


const __buf = new ArrayBuffer(10495040);
if (!(__buf instanceof ArrayBuffer)) throw new Error('wrong buffer');

const memory = new Uint8Array(__buf);
const memory_i32 = new Int32Array(__buf);



function decryptBlocks(v0, v1, v2) {
    
    encryptBlocks(v0, v1, v2);
return ;
}



function decryptInit(v0) {
    
    initTables();
const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
memory_i32[128] = v4;
memory_i32[8] = 0;
memory_i32[9] = 0;
memory_i32[10] = 0;
memory_i32[11] = 0;
memory_i32[12] = 0;
memory_i32[13] = 0;
memory_i32[14] = 0;
memory_i32[15] = 0;
memory_i32[16] = 0;
memory_i32[17] = 0;
memory_i32[18] = 0;
memory_i32[19] = 0;
memory_i32[20] = 0;
memory_i32[21] = 0;
memory_i32[22] = 0;
memory_i32[23] = 0;
memory_i32[24] = 0;
memory_i32[25] = 0;
memory_i32[26] = 0;
memory_i32[27] = 0;
memory_i32[28] = 0;
memory_i32[29] = 0;
memory_i32[30] = 0;
memory_i32[31] = 0;
memory_i32[32] = 0;
memory_i32[33] = 0;
memory_i32[34] = 0;
memory_i32[35] = 0;
memory_i32[36] = 0;
memory_i32[37] = 0;
memory_i32[38] = 0;
memory_i32[39] = 0;
memory_i32[40] = 0;
memory_i32[41] = 0;
memory_i32[42] = 0;
memory_i32[43] = 0;
memory_i32[44] = 0;
memory_i32[45] = 0;
memory_i32[46] = 0;
memory_i32[47] = 0;
memory_i32[48] = 0;
memory_i32[49] = 0;
memory_i32[50] = 0;
memory_i32[51] = 0;
memory_i32[52] = 0;
memory_i32[53] = 0;
memory_i32[54] = 0;
memory_i32[55] = 0;
memory_i32[56] = 0;
memory_i32[57] = 0;
memory_i32[58] = 0;
memory_i32[59] = 0;
memory_i32[60] = 0;
memory_i32[61] = 0;
memory_i32[62] = 0;
memory_i32[63] = 0;
memory_i32[64] = 0;
memory_i32[65] = 0;
memory_i32[66] = 0;
memory_i32[67] = 0;
let s0 = 0;
L0:  {const v5 = s0;

if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v5;break L0;
}
let s1 = v5;
L1:  {const v6 = s1;

let s2 = v6;
L2: for (;;) {const v7 = s2;

let s3 = v7;
L3:  {const v8 = s3;

const v9 = (v8 << 2);
const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
const v13 = memory[((v9) >>> 0) + 0];
memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
s3 = v8;}
const v8 = s3;

const v14 = ((1 + v8) | 0);
if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v14;continue L2;
}
s2 = v14;break L2;}
const v7 = s2;

s1 = v7;}
const v6 = s1;

s0 = v6;}

const v15 = (((1 + v4) | 0) << 2);
const v16 = ((v15 - v3) | 0);
let s4 = 0;
L4:  {const v17 = s4;

if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v17;break L4;
}
let s5 = v17;
L5:  {const v18 = s5;

let s6 = v18;
L6: for (;;) {const v19 = s6;

let s7 = v19;
L7:  {const v20 = s7;

const v21 = ((v3 + v20) | 0);
const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v23 = ((((((v21)>>>0)%(((v3)>>>0))))>>>0));
const v24 = ((v22 >>> 8) | (v22 << 24));
const v25 = memory[((((544 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
const v26 = memory[((((544 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
const v27 = memory[((((544 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
const v28 = memory[((((544 + (255 & v24)) | 0)) >>> 0) + 0];
const v29 = memory[((((9248 + ((((((((v21)>>>0)/(((v3)>>>0))))>>>0)) - 1) | 0)) | 0)) >>> 0) + 0];
const v30 = memory[((((544 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
const v31 = memory[((((544 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
const v32 = memory[((((544 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
const v33 = memory[((((544 + (255 & v22)) | 0)) >>> 0) + 0];
const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
s7 = v20;}
const v20 = s7;

const v35 = ((1 + v20) | 0);
if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
s6 = v35;continue L6;
}
s6 = v35;break L6;}
const v19 = s6;

s5 = v19;}
const v18 = s5;

s4 = v18;}

let s8 = 0;
L8:  {const v36 = s8;

if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v36;break L8;
}
let s9 = v36;
L9:  {const v37 = s9;

let s10 = v37;
L10: for (;;) {const v38 = s10;

let s11 = v38;
L11:  {const v39 = s11;

const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
s11 = v39;}
const v39 = s11;

const v41 = ((1 + v39) | 0);
if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
s10 = v41;continue L10;
}
s10 = v41;break L10;}
const v38 = s10;

s9 = v38;}
const v37 = s9;

s8 = v37;}

return ;
}



function encryptBlocks(v0, v1, v2) {
    
    L0:  {
if (((((((((v0) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L0;
}
processBlocks(0, 1, v0, v0);
}

let s0 = v0;
L1:  {const v3 = s0;

const v4 = memory[543];
const v5 = (((255 & v3) + (255 & v4)) | 0);
const v6 = (((v5 >>> 8) + (v3 >>> 8)) | 0);
memory[543] = (255 & v5);
if (((((v6) | 0) === ((0) | 0)) | 0)) {
s0 = v6;break L1;
}
const v7 = memory[542];
const v8 = (((255 & v6) + (255 & v7)) | 0);
const v9 = (((v8 >>> 8) + (v6 >>> 8)) | 0);
memory[542] = (255 & v8);
if (((((v9) | 0) === ((0) | 0)) | 0)) {
s0 = v9;break L1;
}
const v10 = memory[541];
const v11 = (((255 & v9) + (255 & v10)) | 0);
const v12 = (((v11 >>> 8) + (v9 >>> 8)) | 0);
memory[541] = (255 & v11);
if (((((v12) | 0) === ((0) | 0)) | 0)) {
s0 = v12;break L1;
}
const v13 = memory[540];
const v14 = (((255 & v12) + (255 & v13)) | 0);
const v15 = (((v14 >>> 8) + (v12 >>> 8)) | 0);
memory[540] = (255 & v14);
if (((((v15) | 0) === ((0) | 0)) | 0)) {
s0 = v15;break L1;
}
const v16 = memory[539];
const v17 = (((255 & v15) + (255 & v16)) | 0);
const v18 = (((v17 >>> 8) + (v15 >>> 8)) | 0);
memory[539] = (255 & v17);
if (((((v18) | 0) === ((0) | 0)) | 0)) {
s0 = v18;break L1;
}
const v19 = memory[538];
const v20 = (((255 & v18) + (255 & v19)) | 0);
const v21 = (((v20 >>> 8) + (v18 >>> 8)) | 0);
memory[538] = (255 & v20);
if (((((v21) | 0) === ((0) | 0)) | 0)) {
s0 = v21;break L1;
}
const v22 = memory[537];
const v23 = (((255 & v21) + (255 & v22)) | 0);
const v24 = (((v23 >>> 8) + (v21 >>> 8)) | 0);
memory[537] = (255 & v23);
if (((((v24) | 0) === ((0) | 0)) | 0)) {
s0 = v24;break L1;
}
const v25 = memory[536];
const v26 = (((255 & v24) + (255 & v25)) | 0);
const v27 = (((v26 >>> 8) + (v24 >>> 8)) | 0);
memory[536] = (255 & v26);
if (((((v27) | 0) === ((0) | 0)) | 0)) {
s0 = v27;break L1;
}
const v28 = memory[535];
const v29 = (((255 & v27) + (255 & v28)) | 0);
const v30 = (((v29 >>> 8) + (v27 >>> 8)) | 0);
memory[535] = (255 & v29);
if (((((v30) | 0) === ((0) | 0)) | 0)) {
s0 = v30;break L1;
}
const v31 = memory[534];
const v32 = (((255 & v30) + (255 & v31)) | 0);
const v33 = (((v32 >>> 8) + (v30 >>> 8)) | 0);
memory[534] = (255 & v32);
if (((((v33) | 0) === ((0) | 0)) | 0)) {
s0 = v33;break L1;
}
const v34 = memory[533];
const v35 = (((255 & v33) + (255 & v34)) | 0);
const v36 = (((v35 >>> 8) + (v33 >>> 8)) | 0);
memory[533] = (255 & v35);
if (((((v36) | 0) === ((0) | 0)) | 0)) {
s0 = v36;break L1;
}
const v37 = memory[532];
const v38 = (((255 & v36) + (255 & v37)) | 0);
const v39 = (((v38 >>> 8) + (v36 >>> 8)) | 0);
memory[532] = (255 & v38);
if (((((v39) | 0) === ((0) | 0)) | 0)) {
s0 = v39;break L1;
}
const v40 = memory[531];
const v41 = (((255 & v39) + (255 & v40)) | 0);
const v42 = (((v41 >>> 8) + (v39 >>> 8)) | 0);
memory[531] = (255 & v41);
if (((((v42) | 0) === ((0) | 0)) | 0)) {
s0 = v42;break L1;
}
const v43 = memory[530];
const v44 = (((255 & v42) + (255 & v43)) | 0);
const v45 = (((v44 >>> 8) + (v42 >>> 8)) | 0);
memory[530] = (255 & v44);
if (((((v45) | 0) === ((0) | 0)) | 0)) {
s0 = v45;break L1;
}
const v46 = memory[529];
const v47 = (((255 & v45) + (255 & v46)) | 0);
const v48 = (((v47 >>> 8) + (v45 >>> 8)) | 0);
memory[529] = (255 & v47);
if (((((v48) | 0) === ((0) | 0)) | 0)) {
s0 = v48;break L1;
}
const v49 = memory[528];
const v50 = (((255 & v48) + (255 & v49)) | 0);
const v51 = (((v50 >>> 8) + (v48 >>> 8)) | 0);
memory[528] = (255 & v50);
if (((((v51) | 0) === ((0) | 0)) | 0)) {
s0 = v51;break L1;
}
s0 = v51;}

return ;
}



function encryptInit(v0) {
    
    initTables();
const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
memory_i32[128] = v4;
memory_i32[8] = 0;
memory_i32[9] = 0;
memory_i32[10] = 0;
memory_i32[11] = 0;
memory_i32[12] = 0;
memory_i32[13] = 0;
memory_i32[14] = 0;
memory_i32[15] = 0;
memory_i32[16] = 0;
memory_i32[17] = 0;
memory_i32[18] = 0;
memory_i32[19] = 0;
memory_i32[20] = 0;
memory_i32[21] = 0;
memory_i32[22] = 0;
memory_i32[23] = 0;
memory_i32[24] = 0;
memory_i32[25] = 0;
memory_i32[26] = 0;
memory_i32[27] = 0;
memory_i32[28] = 0;
memory_i32[29] = 0;
memory_i32[30] = 0;
memory_i32[31] = 0;
memory_i32[32] = 0;
memory_i32[33] = 0;
memory_i32[34] = 0;
memory_i32[35] = 0;
memory_i32[36] = 0;
memory_i32[37] = 0;
memory_i32[38] = 0;
memory_i32[39] = 0;
memory_i32[40] = 0;
memory_i32[41] = 0;
memory_i32[42] = 0;
memory_i32[43] = 0;
memory_i32[44] = 0;
memory_i32[45] = 0;
memory_i32[46] = 0;
memory_i32[47] = 0;
memory_i32[48] = 0;
memory_i32[49] = 0;
memory_i32[50] = 0;
memory_i32[51] = 0;
memory_i32[52] = 0;
memory_i32[53] = 0;
memory_i32[54] = 0;
memory_i32[55] = 0;
memory_i32[56] = 0;
memory_i32[57] = 0;
memory_i32[58] = 0;
memory_i32[59] = 0;
memory_i32[60] = 0;
memory_i32[61] = 0;
memory_i32[62] = 0;
memory_i32[63] = 0;
memory_i32[64] = 0;
memory_i32[65] = 0;
memory_i32[66] = 0;
memory_i32[67] = 0;
let s0 = 0;
L0:  {const v5 = s0;

if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v5;break L0;
}
let s1 = v5;
L1:  {const v6 = s1;

let s2 = v6;
L2: for (;;) {const v7 = s2;

let s3 = v7;
L3:  {const v8 = s3;

const v9 = (v8 << 2);
const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
const v13 = memory[((v9) >>> 0) + 0];
memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
s3 = v8;}
const v8 = s3;

const v14 = ((1 + v8) | 0);
if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v14;continue L2;
}
s2 = v14;break L2;}
const v7 = s2;

s1 = v7;}
const v6 = s1;

s0 = v6;}

const v15 = (((1 + v4) | 0) << 2);
const v16 = ((v15 - v3) | 0);
let s4 = 0;
L4:  {const v17 = s4;

if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v17;break L4;
}
let s5 = v17;
L5:  {const v18 = s5;

let s6 = v18;
L6: for (;;) {const v19 = s6;

let s7 = v19;
L7:  {const v20 = s7;

const v21 = ((v3 + v20) | 0);
const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v23 = ((((((v21)>>>0)%(((v3)>>>0))))>>>0));
const v24 = ((v22 >>> 8) | (v22 << 24));
const v25 = memory[((((544 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
const v26 = memory[((((544 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
const v27 = memory[((((544 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
const v28 = memory[((((544 + (255 & v24)) | 0)) >>> 0) + 0];
const v29 = memory[((((9248 + ((((((((v21)>>>0)/(((v3)>>>0))))>>>0)) - 1) | 0)) | 0)) >>> 0) + 0];
const v30 = memory[((((544 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
const v31 = memory[((((544 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
const v32 = memory[((((544 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
const v33 = memory[((((544 + (255 & v22)) | 0)) >>> 0) + 0];
const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
s7 = v20;}
const v20 = s7;

const v35 = ((1 + v20) | 0);
if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
s6 = v35;continue L6;
}
s6 = v35;break L6;}
const v19 = s6;

s5 = v19;}
const v18 = s5;

s4 = v18;}

let s8 = 0;
L8:  {const v36 = s8;

if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v36;break L8;
}
let s9 = v36;
L9:  {const v37 = s9;

let s10 = v37;
L10: for (;;) {const v38 = s10;

let s11 = v38;
L11:  {const v39 = s11;

const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
s11 = v39;}
const v39 = s11;

const v41 = ((1 + v39) | 0);
if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
s10 = v41;continue L10;
}
s10 = v41;break L10;}
const v38 = s10;

s9 = v38;}
const v37 = s9;

s8 = v37;}

return ;
}



function initTables() {
    
    const v0 = memory_i32[2316];
L0:  {
if (((((((((v0) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L0;
}
let s0 = 0, s1 = 1;
L1:  {const v1 = s0;
const v2 = s1;

let s2 = v1, s3 = v2;
L2: for (;;) {const v3 = s2;
const v4 = s3;

const v5 = ((1 + v3) | 0);
const v6 = ((255 & (Math.imul(27, (1 & (v4 >>> 7))) ^ (v4 << 1))) ^ v4);
memory[((((800 + v3) | 0)) >>> 0) + 0] = (255 & v4);
if (((((v5) >>> 0) < ((256) >>> 0)) | 0)) {
s2 = v5;
s3 = v6;continue L2;
}
s2 = v5;
s3 = v6;break L2;}
const v3 = s2;
const v4 = s3;

s0 = v3;
s1 = v4;}

memory[544] = (255 & 99);
let s4 = 0;
L3:  {const v7 = s4;

if (((((((((v7) >>> 0) < ((255) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v7;break L3;
}
let s5 = v7;
L4:  {const v8 = s5;

let s6 = v8;
L5: for (;;) {const v9 = s6;

let s7 = v9;
L6:  {const v10 = s7;

const v11 = memory[((((800 + ((255 - v10) | 0)) | 0)) >>> 0) + 0];
const v12 = (255 & v11);
const v13 = ((v12 << 8) | v12);
const v14 = memory[((((800 + v10) | 0)) >>> 0) + 0];
memory[((((544 + (255 & v14)) | 0)) >>> 0) + 0] = (255 & (255 & (99 ^ ((v13 >>> 7) ^ ((v13 >>> 6) ^ ((v13 >>> 5) ^ ((v13 >>> 4) ^ v13)))))));
s7 = v10;}
const v10 = s7;

const v15 = ((1 + v10) | 0);
if (((((v15) >>> 0) < ((255) >>> 0)) | 0)) {
s6 = v15;continue L5;
}
s6 = v15;break L5;}
const v9 = s6;

s5 = v9;}
const v8 = s5;

s4 = v8;}

let s8 = 0;
L7:  {const v16 = s8;

if (((((((((v16) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v16;break L7;
}
let s9 = v16;
L8:  {const v17 = s9;

let s10 = v17;
L9: for (;;) {const v18 = s10;

let s11 = v18;
L10:  {const v19 = s11;

memory[((((4896 + v19) | 0)) >>> 0) + 0] = (255 & 0);
s11 = v19;}
const v19 = s11;

const v20 = ((1 + v19) | 0);
if (((((v20) >>> 0) < ((256) >>> 0)) | 0)) {
s10 = v20;continue L9;
}
s10 = v20;break L9;}
const v18 = s10;

s9 = v18;}
const v17 = s9;

s8 = v17;}

let s12 = 0;
L11:  {const v21 = s12;

if (((((((((v21) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s12 = v21;break L11;
}
let s13 = v21;
L12:  {const v22 = s13;

let s14 = v22;
L13: for (;;) {const v23 = s14;

let s15 = v23;
L14:  {const v24 = s15;

const v25 = memory[((((544 + v24) | 0)) >>> 0) + 0];
memory[((((4896 + (255 & v25)) | 0)) >>> 0) + 0] = (255 & v24);
s15 = v24;}
const v24 = s15;

const v26 = ((1 + v24) | 0);
if (((((v26) >>> 0) < ((256) >>> 0)) | 0)) {
s14 = v26;continue L13;
}
s14 = v26;break L13;}
const v23 = s14;

s13 = v23;}
const v22 = s13;

s12 = v22;}

let s16 = 0, s17 = 1;
L15:  {const v27 = s16;
const v28 = s17;

let s18 = v27, s19 = v28;
L16: for (;;) {const v29 = s18;
const v30 = s19;

const v31 = ((1 + v29) | 0);
const v32 = (255 & (Math.imul(27, (1 & (v30 >>> 7))) ^ (v30 << 1)));
memory[((((9248 + v29) | 0)) >>> 0) + 0] = (255 & v30);
if (((((v31) >>> 0) < ((16) >>> 0)) | 0)) {
s18 = v31;
s19 = v32;continue L16;
}
s18 = v31;
s19 = v32;break L16;}
const v29 = s18;
const v30 = s19;

s16 = v29;
s17 = v30;}

let s20 = 0;
L17:  {const v33 = s20;

if (((((((((v33) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s20 = v33;break L17;
}
let s21 = v33;
L18:  {const v34 = s21;

let s22 = v34;
L19: for (;;) {const v35 = s22;

let s23 = v35;
L20:  {const v36 = s23;

const v37 = memory[((((544 + v36) | 0)) >>> 0) + 0];
const v38 = (255 & v37);
const v39 = memory[((((4896 + v36) | 0)) >>> 0) + 0];
const v40 = (255 & v39);
const v41 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v42 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
const v43 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v44 = (255 & (Math.imul(27, (1 & (v43 >>> 7))) ^ (v43 << 1)));
const v45 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v46 = (255 & (Math.imul(27, (1 & (v45 >>> 7))) ^ (v45 << 1)));
const v47 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v48 = (255 & (Math.imul(27, (1 & (v47 >>> 7))) ^ (v47 << 1)));
memory_i32[(((((800 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) | (v38 << 8)) | (v38 << 16)) | (((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) ^ v38) << 24));
memory_i32[(((((5152 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & (Math.imul(27, (1 & (v48 >>> 7))) ^ (v48 << 1))) ^ (v48 ^ v47)) | (((255 & (Math.imul(27, (1 & (v42 >>> 7))) ^ (v42 << 1))) ^ v40) << 8)) | (((255 & (Math.imul(27, (1 & (v46 >>> 7))) ^ (v46 << 1))) ^ (v46 ^ v40)) << 16)) | (((255 & (Math.imul(27, (1 & (v44 >>> 7))) ^ (v44 << 1))) ^ (v43 ^ v40)) << 24));
s23 = v36;}
const v36 = s23;

const v49 = ((1 + v36) | 0);
if (((((v49) >>> 0) < ((256) >>> 0)) | 0)) {
s22 = v49;continue L19;
}
s22 = v49;break L19;}
const v35 = s22;

s21 = v35;}
const v34 = s21;

s20 = v34;}

let s24 = 0;
L21:  {const v50 = s24;

if (((((((((v50) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s24 = v50;break L21;
}
let s25 = v50;
L22:  {const v51 = s25;

let s26 = v51;
L23: for (;;) {const v52 = s26;

let s27 = v52;
L24:  {const v53 = s27;

const v54 = memory_i32[(((((800 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v55 = ((v54 << 8) | ((v54 >>> (32 - 8)) >>> 0));
const v56 = ((v55 << 8) | ((v55 >>> (32 - 8)) >>> 0));
memory_i32[(((((1824 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v55;
memory_i32[(((((2848 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v56;
memory_i32[(((((3872 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v56 << 8) | ((v56 >>> (32 - 8)) >>> 0));
const v57 = memory_i32[(((((5152 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v58 = ((v57 << 8) | ((v57 >>> (32 - 8)) >>> 0));
const v59 = ((v58 << 8) | ((v58 >>> (32 - 8)) >>> 0));
memory_i32[(((((6176 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v58;
memory_i32[(((((7200 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v59;
memory_i32[(((((8224 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v59 << 8) | ((v59 >>> (32 - 8)) >>> 0));
s27 = v53;}
const v53 = s27;

const v60 = ((1 + v53) | 0);
if (((((v60) >>> 0) < ((256) >>> 0)) | 0)) {
s26 = v60;continue L23;
}
s26 = v60;break L23;}
const v52 = s26;

s25 = v52;}
const v51 = s25;

s24 = v51;}

memory_i32[2316] = 1;
}

return ;
}



function processBlocks(v0, v1, v2, v3) {
    
    let s0 = 0;
L0:  {const v4 = s0;

if (((((((((v4) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v4;break L0;
}
let s1 = v4;
L1:  {const v5 = s1;

let s2 = v5;
L2: for (;;) {const v6 = s2;

let s3 = v6;
L3:  {const v7 = s3;

const v8 = ((v7 + v0) | 0);
const v9 = Math.imul(v2, v8);
const v10 = ((v3 - v9) | 0);
const v11 = ((((((v10) >>> 0) < ((v2) >>> 0)) | 0)) ? (v10) : (v2));
const v12 = memory_i32[128];
const v13 = memory_i32[132];
const v14 = memory_i32[133];
const v15 = memory_i32[134];
const v16 = memory_i32[135];
let s4 = Math.imul(v2, v8), s5 = v13, s6 = v14, s7 = v15, s8 = v16;
L4:  {const v17 = s4;
const v18 = s5;
const v19 = s6;
const v20 = s7;
const v21 = s8;

const v22 = (((v21 >>> 24) | ((16711680 & v21) >>> 8)) | (((65280 & v21) << 8) | ((255 & v21) << 24)));
const v23 = ((v17 + v22) | 0);
const v24 = (((v23 >>> 24) | ((16711680 & v23) >>> 8)) | (((65280 & v23) << 8) | ((255 & v23) << 24)));
const v25 = (1 & ((((v23) >>> 0) < ((v22) >>> 0)) | 0));
if (((((v25) | 0) === ((0) | 0)) | 0)) {
s4 = v25;
s5 = v18;
s6 = v19;
s7 = v20;
s8 = v24;break L4;
}
const v26 = (((v20 >>> 24) | ((16711680 & v20) >>> 8)) | (((65280 & v20) << 8) | ((255 & v20) << 24)));
const v27 = ((v25 + v26) | 0);
const v28 = (((v27 >>> 24) | ((16711680 & v27) >>> 8)) | (((65280 & v27) << 8) | ((255 & v27) << 24)));
const v29 = (1 & ((((v27) >>> 0) < ((v26) >>> 0)) | 0));
if (((((v29) | 0) === ((0) | 0)) | 0)) {
s4 = v29;
s5 = v18;
s6 = v19;
s7 = v28;
s8 = v24;break L4;
}
const v30 = (((v19 >>> 24) | ((16711680 & v19) >>> 8)) | (((65280 & v19) << 8) | ((255 & v19) << 24)));
const v31 = ((v29 + v30) | 0);
const v32 = (((v31 >>> 24) | ((16711680 & v31) >>> 8)) | (((65280 & v31) << 8) | ((255 & v31) << 24)));
const v33 = (1 & ((((v31) >>> 0) < ((v30) >>> 0)) | 0));
if (((((v33) | 0) === ((0) | 0)) | 0)) {
s4 = v33;
s5 = v18;
s6 = v32;
s7 = v28;
s8 = v24;break L4;
}
const v34 = (((v18 >>> 24) | ((16711680 & v18) >>> 8)) | (((65280 & v18) << 8) | ((255 & v18) << 24)));
const v35 = ((v33 + v34) | 0);
const v36 = (((v35 >>> 24) | ((16711680 & v35) >>> 8)) | (((65280 & v35) << 8) | ((255 & v35) << 24)));
const v37 = (1 & ((((v35) >>> 0) < ((v34) >>> 0)) | 0));
if (((((v37) | 0) === ((0) | 0)) | 0)) {
s4 = v37;
s5 = v36;
s6 = v32;
s7 = v28;
s8 = v24;break L4;
}
s4 = v37;
s5 = v36;
s6 = v32;
s7 = v28;
s8 = v24;}
const v18 = s5;
const v19 = s6;
const v20 = s7;
const v21 = s8;

let s9 = 0, s10 = v18, s11 = v19, s12 = v20, s13 = v21;
L5:  {const v38 = s9;
const v39 = s10;
const v40 = s11;
const v41 = s12;
const v42 = s13;

let s14 = v38, s15 = v39, s16 = v40, s17 = v41, s18 = v42;
L6: for (;;) {const v43 = s14;
const v44 = s15;
const v45 = s16;
const v46 = s17;
const v47 = s18;

const v48 = ((1 + v43) | 0);
const v49 = memory_i32[8];
const v50 = memory_i32[9];
const v51 = memory_i32[10];
const v52 = memory_i32[11];
const v53 = ((v12 - 1) | 0);
let s19 = 0, s20 = (v49 ^ v44), s21 = (v50 ^ v45), s22 = (v51 ^ v46), s23 = (v52 ^ v47);
L7:  {const v54 = s19;
const v55 = s20;
const v56 = s21;
const v57 = s22;
const v58 = s23;

let s24 = v54, s25 = v55, s26 = v56, s27 = v57, s28 = v58;
L8: for (;;) {const v59 = s24;
const v60 = s25;
const v61 = s26;
const v62 = s27;
const v63 = s28;

const v64 = ((1 + v59) | 0);
const v65 = (((1 + v59) | 0) << 2);
const v66 = memory_i32[(((((32 + (v65 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v67 = memory_i32[(((((800 + ((255 & v60) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v68 = memory_i32[(((((1824 + ((255 & (v61 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v69 = memory_i32[(((((2848 + ((255 & (v62 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v70 = memory_i32[(((((3872 + ((255 & (v63 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v71 = (((v70 ^ v69) ^ (v68 ^ v67)) ^ v66);
const v72 = memory_i32[(((((32 + (((1 + v65) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v73 = memory_i32[(((((800 + ((255 & v61) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v74 = memory_i32[(((((1824 + ((255 & (v62 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v75 = memory_i32[(((((2848 + ((255 & (v63 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v76 = memory_i32[(((((3872 + ((255 & (v60 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v77 = (((v76 ^ v75) ^ (v74 ^ v73)) ^ v72);
const v78 = memory_i32[(((((32 + (((2 + v65) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v79 = memory_i32[(((((800 + ((255 & v62) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v80 = memory_i32[(((((1824 + ((255 & (v63 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v81 = memory_i32[(((((2848 + ((255 & (v60 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v82 = memory_i32[(((((3872 + ((255 & (v61 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v83 = (((v82 ^ v81) ^ (v80 ^ v79)) ^ v78);
const v84 = memory_i32[(((((32 + (((3 + v65) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v85 = memory_i32[(((((800 + ((255 & v63) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v86 = memory_i32[(((((1824 + ((255 & (v60 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v87 = memory_i32[(((((2848 + ((255 & (v61 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v88 = memory_i32[(((((3872 + ((255 & (v62 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v89 = (((v88 ^ v87) ^ (v86 ^ v85)) ^ v84);
if (((((v64) >>> 0) < ((v53) >>> 0)) | 0)) {
s24 = v64;
s25 = v71;
s26 = v77;
s27 = v83;
s28 = v89;continue L8;
}
s24 = v64;
s25 = v71;
s26 = v77;
s27 = v83;
s28 = v89;break L8;}
const v59 = s24;
const v60 = s25;
const v61 = s26;
const v62 = s27;
const v63 = s28;

s19 = v59;
s20 = v60;
s21 = v61;
s22 = v62;
s23 = v63;}
const v55 = s20;
const v56 = s21;
const v57 = s22;
const v58 = s23;

const v90 = (v12 << 2);
const v91 = memory_i32[(((((32 + (v90 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v92 = memory[((((544 + (255 & (v56 >>> 8))) | 0)) >>> 0) + 0];
const v93 = memory[((((544 + (255 & (v57 >>> 16))) | 0)) >>> 0) + 0];
const v94 = memory[((((544 + (255 & (v58 >>> 24))) | 0)) >>> 0) + 0];
const v95 = memory[((((544 + (255 & v55)) | 0)) >>> 0) + 0];
const v96 = memory_i32[(((((32 + (((1 + v90) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v97 = memory[((((544 + (255 & (v57 >>> 8))) | 0)) >>> 0) + 0];
const v98 = memory[((((544 + (255 & (v58 >>> 16))) | 0)) >>> 0) + 0];
const v99 = memory[((((544 + (255 & (v55 >>> 24))) | 0)) >>> 0) + 0];
const v100 = memory[((((544 + (255 & v56)) | 0)) >>> 0) + 0];
const v101 = memory_i32[(((((32 + (((2 + v90) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v102 = memory[((((544 + (255 & (v58 >>> 8))) | 0)) >>> 0) + 0];
const v103 = memory[((((544 + (255 & (v55 >>> 16))) | 0)) >>> 0) + 0];
const v104 = memory[((((544 + (255 & (v56 >>> 24))) | 0)) >>> 0) + 0];
const v105 = memory[((((544 + (255 & v57)) | 0)) >>> 0) + 0];
const v106 = memory_i32[(((((32 + (((3 + v90) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v107 = memory[((((544 + (255 & (v55 >>> 8))) | 0)) >>> 0) + 0];
const v108 = memory[((((544 + (255 & (v56 >>> 16))) | 0)) >>> 0) + 0];
const v109 = memory[((((544 + (255 & (v57 >>> 24))) | 0)) >>> 0) + 0];
const v110 = memory[((((544 + (255 & v58)) | 0)) >>> 0) + 0];
const v111 = ((9280 + (((v43 + v9) | 0) << 4)) | 0);
const v112 = memory_i32[(((v111) >>> 0) + 0) >>> 2];
const v113 = ((4 + v111) | 0);
const v114 = memory_i32[(((v113) >>> 0) + 0) >>> 2];
const v115 = ((4 + v113) | 0);
const v116 = memory_i32[(((v115) >>> 0) + 0) >>> 2];
const v117 = memory_i32[(((((4 + v115) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((v111) >>> 0) + 0) >>> 2] = ((((((255 & v94) << 24) | ((255 & v93) << 16)) | (((255 & v92) << 8) | (255 & v95))) ^ v91) ^ v112);
const v118 = ((4 + v111) | 0);
memory_i32[(((v118) >>> 0) + 0) >>> 2] = ((((((255 & v99) << 24) | ((255 & v98) << 16)) | (((255 & v97) << 8) | (255 & v100))) ^ v96) ^ v114);
const v119 = ((4 + v118) | 0);
memory_i32[(((v119) >>> 0) + 0) >>> 2] = ((((((255 & v104) << 24) | ((255 & v103) << 16)) | (((255 & v102) << 8) | (255 & v105))) ^ v101) ^ v116);
memory_i32[(((((4 + v119) | 0)) >>> 0) + 0) >>> 2] = ((((((255 & v109) << 24) | ((255 & v108) << 16)) | (((255 & v107) << 8) | (255 & v110))) ^ v106) ^ v117);
let s29 = 1, s30 = v44, s31 = v45, s32 = v46, s33 = v47;
L9:  {const v120 = s29;
const v121 = s30;
const v122 = s31;
const v123 = s32;
const v124 = s33;

const v125 = (((v124 >>> 24) | ((16711680 & v124) >>> 8)) | (((65280 & v124) << 8) | ((255 & v124) << 24)));
const v126 = ((v120 + v125) | 0);
const v127 = (((v126 >>> 24) | ((16711680 & v126) >>> 8)) | (((65280 & v126) << 8) | ((255 & v126) << 24)));
const v128 = (1 & ((((v126) >>> 0) < ((v125) >>> 0)) | 0));
if (((((v128) | 0) === ((0) | 0)) | 0)) {
s29 = v128;
s30 = v121;
s31 = v122;
s32 = v123;
s33 = v127;break L9;
}
const v129 = (((v123 >>> 24) | ((16711680 & v123) >>> 8)) | (((65280 & v123) << 8) | ((255 & v123) << 24)));
const v130 = ((v128 + v129) | 0);
const v131 = (((v130 >>> 24) | ((16711680 & v130) >>> 8)) | (((65280 & v130) << 8) | ((255 & v130) << 24)));
const v132 = (1 & ((((v130) >>> 0) < ((v129) >>> 0)) | 0));
if (((((v132) | 0) === ((0) | 0)) | 0)) {
s29 = v132;
s30 = v121;
s31 = v122;
s32 = v131;
s33 = v127;break L9;
}
const v133 = (((v122 >>> 24) | ((16711680 & v122) >>> 8)) | (((65280 & v122) << 8) | ((255 & v122) << 24)));
const v134 = ((v132 + v133) | 0);
const v135 = (((v134 >>> 24) | ((16711680 & v134) >>> 8)) | (((65280 & v134) << 8) | ((255 & v134) << 24)));
const v136 = (1 & ((((v134) >>> 0) < ((v133) >>> 0)) | 0));
if (((((v136) | 0) === ((0) | 0)) | 0)) {
s29 = v136;
s30 = v121;
s31 = v135;
s32 = v131;
s33 = v127;break L9;
}
const v137 = (((v121 >>> 24) | ((16711680 & v121) >>> 8)) | (((65280 & v121) << 8) | ((255 & v121) << 24)));
const v138 = ((v136 + v137) | 0);
const v139 = (((v138 >>> 24) | ((16711680 & v138) >>> 8)) | (((65280 & v138) << 8) | ((255 & v138) << 24)));
const v140 = (1 & ((((v138) >>> 0) < ((v137) >>> 0)) | 0));
if (((((v140) | 0) === ((0) | 0)) | 0)) {
s29 = v140;
s30 = v139;
s31 = v135;
s32 = v131;
s33 = v127;break L9;
}
s29 = v140;
s30 = v139;
s31 = v135;
s32 = v131;
s33 = v127;}
const v121 = s30;
const v122 = s31;
const v123 = s32;
const v124 = s33;

if (((((v48) >>> 0) < ((v11) >>> 0)) | 0)) {
s14 = v48;
s15 = v121;
s16 = v122;
s17 = v123;
s18 = v124;continue L6;
}
s14 = v48;
s15 = v121;
s16 = v122;
s17 = v123;
s18 = v124;break L6;}
const v43 = s14;
const v44 = s15;
const v45 = s16;
const v46 = s17;
const v47 = s18;

s9 = v43;
s10 = v44;
s11 = v45;
s12 = v46;
s13 = v47;}

s3 = v7;}
const v7 = s3;

const v141 = ((1 + v7) | 0);
if (((((v141) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v141;continue L2;
}
s2 = v141;break L2;}
const v6 = s2;

s1 = v6;}
const v5 = s1;

s0 = v5;}

return ;
}



function reset(v0) {
    
    memory.fill(0, 0, 0 + 544)
memory.fill(0, 9280, 9280 + ((v0) >>> 0))
return ;
}
const instance = { exports: {decryptBlocks: decryptBlocks, decryptInit: decryptInit, encryptBlocks: encryptBlocks, encryptInit: encryptInit, initTables: initTables, processBlocks: processBlocks, reset: reset, memory: { buffer: __buf }}};

;
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 10495040);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 544)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*544, 544)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*4, 4)))
, "state.nonce": new Uint8Array(memoryExport.buffer, 528, 16)
, "state.nonce_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*16, 16)))
, constants: new Uint8Array(memoryExport.buffer, 544, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 800 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 1824 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2848 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 3872 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5152 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 6176 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 7200 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8224 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9248 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9264 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9280 + i*10485760, 10485760)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments  });}
let _cache;
export default function aes_ctr(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}