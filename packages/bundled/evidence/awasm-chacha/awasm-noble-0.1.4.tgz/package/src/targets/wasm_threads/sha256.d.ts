// WARNING: This file is auto-generated. Any changes will be lost.
export default function sha2(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly state: Uint8Array;
    readonly state_chunks: ReadonlyArray<Uint8Array>;
    readonly 'state.counter_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.state_chunks': ReadonlyArray<Uint8Array>;
    readonly buffer: Uint8Array;
    readonly buffer_chunks: ReadonlyArray<Uint8Array>;
    readonly _worker: Uint8Array;
    readonly _worker_chunks: ReadonlyArray<Uint8Array>;
    readonly '_worker.online': Uint8Array;
    readonly '_worker.online_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.next': Uint8Array;
    readonly '_worker.next_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.total': Uint8Array;
    readonly '_worker.total_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.perBatch': Uint8Array;
    readonly '_worker.perBatch_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.workers': Uint8Array;
    readonly '_worker.workers_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.stack': Uint8Array;
    readonly '_worker.stack_chunks': ReadonlyArray<Uint8Array>;
  };
  _processBlocks_thread_int(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number): void;
  _processOutBlocks_thread_int(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  _worker_notify(v0: number, v1: number): number;
  _worker_online(): number;
  initWorker(v0: number, v1: number, v2: number): void;
  padding(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): number;
  processBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number): void;
  processOutBlocks(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  reset(v0: number, v1: number, v2: number, v3: number, v4: number): void;
  resetBuffer(v0: number, v1: number, v2: number, v3: number, v4: number): void;
  stopWorker(v0: number): void;
};