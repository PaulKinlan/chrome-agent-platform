// WARNING: This file is auto-generated. Any changes will be lost.
export default function salsa(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly state: Uint8Array;
    readonly state_chunks: ReadonlyArray<Uint8Array>;
    readonly 'state.counter': Uint8Array;
    readonly 'state.counter_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.sigma': Uint8Array;
    readonly 'state.sigma_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.key': Uint8Array;
    readonly 'state.key_chunks': ReadonlyArray<Uint8Array>;
    readonly 'state.nonce': Uint8Array;
    readonly 'state.nonce_chunks': ReadonlyArray<Uint8Array>;
    readonly buffer: Uint8Array;
    readonly buffer_chunks: ReadonlyArray<Uint8Array>;
    readonly derive: Uint8Array;
    readonly derive_chunks: ReadonlyArray<Uint8Array>;
    readonly 'derive.nonce': Uint8Array;
    readonly 'derive.nonce_chunks': ReadonlyArray<Uint8Array>;
    readonly 'derive.out': Uint8Array;
    readonly 'derive.out_chunks': ReadonlyArray<Uint8Array>;
  };
  decryptBlocks(v0: number, v1: number, v2: number): void;
  derive(): void;
  encryptBlocks(v0: number, v1: number, v2: number): void;
  processBlocks(v0: number, v1: number, v2: number, v3: number, v4: number): void;
  reset(v0: number): void;
};