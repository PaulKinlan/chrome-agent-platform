// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};


const __buf = new ArrayBuffer(10495040);
if (!(__buf instanceof ArrayBuffer)) throw new Error('wrong buffer');

const memory = new Uint8Array(__buf);
const memory_i32 = new Int32Array(__buf);



function decryptBlocks(v0, v1, v2) {
    
    encryptBlocks(v0, v1, v2);
return ;
}



function decryptInit(v0) {
    
    initTables();
const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
memory_i32[128] = v4;
memory_i32[8] = 0;
memory_i32[9] = 0;
memory_i32[10] = 0;
memory_i32[11] = 0;
memory_i32[12] = 0;
memory_i32[13] = 0;
memory_i32[14] = 0;
memory_i32[15] = 0;
memory_i32[16] = 0;
memory_i32[17] = 0;
memory_i32[18] = 0;
memory_i32[19] = 0;
memory_i32[20] = 0;
memory_i32[21] = 0;
memory_i32[22] = 0;
memory_i32[23] = 0;
memory_i32[24] = 0;
memory_i32[25] = 0;
memory_i32[26] = 0;
memory_i32[27] = 0;
memory_i32[28] = 0;
memory_i32[29] = 0;
memory_i32[30] = 0;
memory_i32[31] = 0;
memory_i32[32] = 0;
memory_i32[33] = 0;
memory_i32[34] = 0;
memory_i32[35] = 0;
memory_i32[36] = 0;
memory_i32[37] = 0;
memory_i32[38] = 0;
memory_i32[39] = 0;
memory_i32[40] = 0;
memory_i32[41] = 0;
memory_i32[42] = 0;
memory_i32[43] = 0;
memory_i32[44] = 0;
memory_i32[45] = 0;
memory_i32[46] = 0;
memory_i32[47] = 0;
memory_i32[48] = 0;
memory_i32[49] = 0;
memory_i32[50] = 0;
memory_i32[51] = 0;
memory_i32[52] = 0;
memory_i32[53] = 0;
memory_i32[54] = 0;
memory_i32[55] = 0;
memory_i32[56] = 0;
memory_i32[57] = 0;
memory_i32[58] = 0;
memory_i32[59] = 0;
memory_i32[60] = 0;
memory_i32[61] = 0;
memory_i32[62] = 0;
memory_i32[63] = 0;
memory_i32[64] = 0;
memory_i32[65] = 0;
memory_i32[66] = 0;
memory_i32[67] = 0;
let s0 = 0;
L0:  {const v5 = s0;

if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v5;break L0;
}
let s1 = v5;
L1:  {const v6 = s1;

let s2 = v6;
L2: for (;;) {const v7 = s2;

let s3 = v7;
L3:  {const v8 = s3;

const v9 = (v8 << 2);
const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
const v13 = memory[((v9) >>> 0) + 0];
memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
s3 = v8;}
const v8 = s3;

const v14 = ((1 + v8) | 0);
if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v14;continue L2;
}
s2 = v14;break L2;}
const v7 = s2;

s1 = v7;}
const v6 = s1;

s0 = v6;}

const v15 = (((1 + v4) | 0) << 2);
const v16 = ((v15 - v3) | 0);
let s4 = 0;
L4:  {const v17 = s4;

if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v17;break L4;
}
let s5 = v17;
L5:  {const v18 = s5;

let s6 = v18;
L6: for (;;) {const v19 = s6;

let s7 = v19;
L7:  {const v20 = s7;

const v21 = ((v3 + v20) | 0);
const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v23 = ((((((v21)>>>0)%(((v3)>>>0))))>>>0));
const v24 = ((v22 >>> 8) | (v22 << 24));
const v25 = memory[((((544 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
const v26 = memory[((((544 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
const v27 = memory[((((544 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
const v28 = memory[((((544 + (255 & v24)) | 0)) >>> 0) + 0];
const v29 = memory[((((9248 + ((((((((v21)>>>0)/(((v3)>>>0))))>>>0)) - 1) | 0)) | 0)) >>> 0) + 0];
const v30 = memory[((((544 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
const v31 = memory[((((544 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
const v32 = memory[((((544 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
const v33 = memory[((((544 + (255 & v22)) | 0)) >>> 0) + 0];
const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
s7 = v20;}
const v20 = s7;

const v35 = ((1 + v20) | 0);
if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
s6 = v35;continue L6;
}
s6 = v35;break L6;}
const v19 = s6;

s5 = v19;}
const v18 = s5;

s4 = v18;}

let s8 = 0;
L8:  {const v36 = s8;

if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v36;break L8;
}
let s9 = v36;
L9:  {const v37 = s9;

let s10 = v37;
L10: for (;;) {const v38 = s10;

let s11 = v38;
L11:  {const v39 = s11;

const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
s11 = v39;}
const v39 = s11;

const v41 = ((1 + v39) | 0);
if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
s10 = v41;continue L10;
}
s10 = v41;break L10;}
const v38 = s10;

s9 = v38;}
const v37 = s9;

s8 = v37;}

return ;
}



function encryptBlocks(v0, v1, v2) {
    
    const v3 = memory_i32[128];
let s0 = 0;
L0:  {const v4 = s0;

if (((((((((v4) >>> 0) < ((v0) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v4;break L0;
}
let s1 = v4;
L1:  {const v5 = s1;

let s2 = v5;
L2: for (;;) {const v6 = s2;

let s3 = v6;
L3:  {const v7 = s3;

const v8 = ((9280 + (v7 << 4)) | 0);
const v9 = memory_i32[(((v8) >>> 0) + 0) >>> 2];
const v10 = ((4 + v8) | 0);
const v11 = memory_i32[(((v10) >>> 0) + 0) >>> 2];
const v12 = ((4 + v10) | 0);
const v13 = memory_i32[(((v12) >>> 0) + 0) >>> 2];
const v14 = memory_i32[(((((4 + v12) | 0)) >>> 0) + 0) >>> 2];
const v15 = memory_i32[132];
const v16 = memory_i32[133];
const v17 = memory_i32[134];
const v18 = memory_i32[135];
const v19 = memory_i32[8];
const v20 = memory_i32[9];
const v21 = memory_i32[10];
const v22 = memory_i32[11];
const v23 = ((v3 - 1) | 0);
let s4 = 0, s5 = (v19 ^ v15), s6 = (v20 ^ v16), s7 = (v21 ^ v17), s8 = (v22 ^ v18);
L4:  {const v24 = s4;
const v25 = s5;
const v26 = s6;
const v27 = s7;
const v28 = s8;

let s9 = v24, s10 = v25, s11 = v26, s12 = v27, s13 = v28;
L5: for (;;) {const v29 = s9;
const v30 = s10;
const v31 = s11;
const v32 = s12;
const v33 = s13;

const v34 = ((1 + v29) | 0);
const v35 = (((1 + v29) | 0) << 2);
const v36 = memory_i32[(((((32 + (v35 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v37 = memory_i32[(((((800 + ((255 & v30) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v38 = memory_i32[(((((1824 + ((255 & (v31 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v39 = memory_i32[(((((2848 + ((255 & (v32 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v40 = memory_i32[(((((3872 + ((255 & (v33 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v41 = (((v40 ^ v39) ^ (v38 ^ v37)) ^ v36);
const v42 = memory_i32[(((((32 + (((1 + v35) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v43 = memory_i32[(((((800 + ((255 & v31) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v44 = memory_i32[(((((1824 + ((255 & (v32 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v45 = memory_i32[(((((2848 + ((255 & (v33 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v46 = memory_i32[(((((3872 + ((255 & (v30 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v47 = (((v46 ^ v45) ^ (v44 ^ v43)) ^ v42);
const v48 = memory_i32[(((((32 + (((2 + v35) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v49 = memory_i32[(((((800 + ((255 & v32) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v50 = memory_i32[(((((1824 + ((255 & (v33 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v51 = memory_i32[(((((2848 + ((255 & (v30 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v52 = memory_i32[(((((3872 + ((255 & (v31 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v53 = (((v52 ^ v51) ^ (v50 ^ v49)) ^ v48);
const v54 = memory_i32[(((((32 + (((3 + v35) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v55 = memory_i32[(((((800 + ((255 & v33) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v56 = memory_i32[(((((1824 + ((255 & (v30 >>> 8)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v57 = memory_i32[(((((2848 + ((255 & (v31 >>> 16)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v58 = memory_i32[(((((3872 + ((255 & (v32 >>> 24)) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v59 = (((v58 ^ v57) ^ (v56 ^ v55)) ^ v54);
if (((((v34) >>> 0) < ((v23) >>> 0)) | 0)) {
s9 = v34;
s10 = v41;
s11 = v47;
s12 = v53;
s13 = v59;continue L5;
}
s9 = v34;
s10 = v41;
s11 = v47;
s12 = v53;
s13 = v59;break L5;}
const v29 = s9;
const v30 = s10;
const v31 = s11;
const v32 = s12;
const v33 = s13;

s4 = v29;
s5 = v30;
s6 = v31;
s7 = v32;
s8 = v33;}
const v25 = s5;
const v26 = s6;
const v27 = s7;
const v28 = s8;

const v60 = (v3 << 2);
const v61 = memory_i32[(((((32 + (v60 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v62 = memory[((((544 + (255 & (v26 >>> 8))) | 0)) >>> 0) + 0];
const v63 = memory[((((544 + (255 & (v27 >>> 16))) | 0)) >>> 0) + 0];
const v64 = memory[((((544 + (255 & (v28 >>> 24))) | 0)) >>> 0) + 0];
const v65 = memory[((((544 + (255 & v25)) | 0)) >>> 0) + 0];
const v66 = (((((255 & v64) << 24) | ((255 & v63) << 16)) | (((255 & v62) << 8) | (255 & v65))) ^ v61);
const v67 = memory_i32[(((((32 + (((1 + v60) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v68 = memory[((((544 + (255 & (v27 >>> 8))) | 0)) >>> 0) + 0];
const v69 = memory[((((544 + (255 & (v28 >>> 16))) | 0)) >>> 0) + 0];
const v70 = memory[((((544 + (255 & (v25 >>> 24))) | 0)) >>> 0) + 0];
const v71 = memory[((((544 + (255 & v26)) | 0)) >>> 0) + 0];
const v72 = (((((255 & v70) << 24) | ((255 & v69) << 16)) | (((255 & v68) << 8) | (255 & v71))) ^ v67);
const v73 = memory_i32[(((((32 + (((2 + v60) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v74 = memory[((((544 + (255 & (v28 >>> 8))) | 0)) >>> 0) + 0];
const v75 = memory[((((544 + (255 & (v25 >>> 16))) | 0)) >>> 0) + 0];
const v76 = memory[((((544 + (255 & (v26 >>> 24))) | 0)) >>> 0) + 0];
const v77 = memory[((((544 + (255 & v27)) | 0)) >>> 0) + 0];
const v78 = (((((255 & v76) << 24) | ((255 & v75) << 16)) | (((255 & v74) << 8) | (255 & v77))) ^ v73);
const v79 = memory_i32[(((((32 + (((3 + v60) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v80 = memory[((((544 + (255 & (v25 >>> 8))) | 0)) >>> 0) + 0];
const v81 = memory[((((544 + (255 & (v26 >>> 16))) | 0)) >>> 0) + 0];
const v82 = memory[((((544 + (255 & (v27 >>> 24))) | 0)) >>> 0) + 0];
const v83 = memory[((((544 + (255 & v28)) | 0)) >>> 0) + 0];
const v84 = (((((255 & v82) << 24) | ((255 & v81) << 16)) | (((255 & v80) << 8) | (255 & v83))) ^ v79);
memory_i32[(((v8) >>> 0) + 0) >>> 2] = (v66 ^ v9);
const v85 = ((4 + v8) | 0);
memory_i32[(((v85) >>> 0) + 0) >>> 2] = (v72 ^ v11);
const v86 = ((4 + v85) | 0);
memory_i32[(((v86) >>> 0) + 0) >>> 2] = (v78 ^ v13);
memory_i32[(((((4 + v86) | 0)) >>> 0) + 0) >>> 2] = (v84 ^ v14);
memory_i32[132] = v66;
memory_i32[133] = v72;
memory_i32[134] = v78;
memory_i32[135] = v84;
s3 = v7;}
const v7 = s3;

const v87 = ((1 + v7) | 0);
if (((((v87) >>> 0) < ((v0) >>> 0)) | 0)) {
s2 = v87;continue L2;
}
s2 = v87;break L2;}
const v6 = s2;

s1 = v6;}
const v5 = s1;

s0 = v5;}

return ;
}



function encryptInit(v0) {
    
    initTables();
const v1 = ((((v0) | 0) === ((16) | 0)) | 0);
const v2 = ((((v0) | 0) === ((24) | 0)) | 0);
const v3 = ((v1) ? (4) : (((v2) ? (6) : (8))));
const v4 = ((v1) ? (10) : (((v2) ? (12) : (14))));
memory_i32[128] = v4;
memory_i32[8] = 0;
memory_i32[9] = 0;
memory_i32[10] = 0;
memory_i32[11] = 0;
memory_i32[12] = 0;
memory_i32[13] = 0;
memory_i32[14] = 0;
memory_i32[15] = 0;
memory_i32[16] = 0;
memory_i32[17] = 0;
memory_i32[18] = 0;
memory_i32[19] = 0;
memory_i32[20] = 0;
memory_i32[21] = 0;
memory_i32[22] = 0;
memory_i32[23] = 0;
memory_i32[24] = 0;
memory_i32[25] = 0;
memory_i32[26] = 0;
memory_i32[27] = 0;
memory_i32[28] = 0;
memory_i32[29] = 0;
memory_i32[30] = 0;
memory_i32[31] = 0;
memory_i32[32] = 0;
memory_i32[33] = 0;
memory_i32[34] = 0;
memory_i32[35] = 0;
memory_i32[36] = 0;
memory_i32[37] = 0;
memory_i32[38] = 0;
memory_i32[39] = 0;
memory_i32[40] = 0;
memory_i32[41] = 0;
memory_i32[42] = 0;
memory_i32[43] = 0;
memory_i32[44] = 0;
memory_i32[45] = 0;
memory_i32[46] = 0;
memory_i32[47] = 0;
memory_i32[48] = 0;
memory_i32[49] = 0;
memory_i32[50] = 0;
memory_i32[51] = 0;
memory_i32[52] = 0;
memory_i32[53] = 0;
memory_i32[54] = 0;
memory_i32[55] = 0;
memory_i32[56] = 0;
memory_i32[57] = 0;
memory_i32[58] = 0;
memory_i32[59] = 0;
memory_i32[60] = 0;
memory_i32[61] = 0;
memory_i32[62] = 0;
memory_i32[63] = 0;
memory_i32[64] = 0;
memory_i32[65] = 0;
memory_i32[66] = 0;
memory_i32[67] = 0;
let s0 = 0;
L0:  {const v5 = s0;

if (((((((((v5) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v5;break L0;
}
let s1 = v5;
L1:  {const v6 = s1;

let s2 = v6;
L2: for (;;) {const v7 = s2;

let s3 = v7;
L3:  {const v8 = s3;

const v9 = (v8 << 2);
const v10 = memory[((((1 + v9) | 0)) >>> 0) + 0];
const v11 = memory[((((2 + v9) | 0)) >>> 0) + 0];
const v12 = memory[((((3 + v9) | 0)) >>> 0) + 0];
const v13 = memory[((v9) >>> 0) + 0];
memory_i32[(((((272 + (v8 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & v12) << 24) | ((255 & v11) << 16)) | ((255 & v10) << 8)) | (255 & v13));
s3 = v8;}
const v8 = s3;

const v14 = ((1 + v8) | 0);
if (((((v14) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v14;continue L2;
}
s2 = v14;break L2;}
const v7 = s2;

s1 = v7;}
const v6 = s1;

s0 = v6;}

const v15 = (((1 + v4) | 0) << 2);
const v16 = ((v15 - v3) | 0);
let s4 = 0;
L4:  {const v17 = s4;

if (((((((((v17) >>> 0) < ((v16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v17;break L4;
}
let s5 = v17;
L5:  {const v18 = s5;

let s6 = v18;
L6: for (;;) {const v19 = s6;

let s7 = v19;
L7:  {const v20 = s7;

const v21 = ((v3 + v20) | 0);
const v22 = memory_i32[(((((272 + (((v21 - 1) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
const v23 = ((((((v21)>>>0)%(((v3)>>>0))))>>>0));
const v24 = ((v22 >>> 8) | (v22 << 24));
const v25 = memory[((((544 + (255 & (v24 >>> 8))) | 0)) >>> 0) + 0];
const v26 = memory[((((544 + (255 & (v24 >>> 16))) | 0)) >>> 0) + 0];
const v27 = memory[((((544 + (255 & (v24 >>> 24))) | 0)) >>> 0) + 0];
const v28 = memory[((((544 + (255 & v24)) | 0)) >>> 0) + 0];
const v29 = memory[((((9248 + ((((((((v21)>>>0)/(((v3)>>>0))))>>>0)) - 1) | 0)) | 0)) >>> 0) + 0];
const v30 = memory[((((544 + (255 & (v22 >>> 8))) | 0)) >>> 0) + 0];
const v31 = memory[((((544 + (255 & (v22 >>> 16))) | 0)) >>> 0) + 0];
const v32 = memory[((((544 + (255 & (v22 >>> 24))) | 0)) >>> 0) + 0];
const v33 = memory[((((544 + (255 & v22)) | 0)) >>> 0) + 0];
const v34 = memory_i32[(((((272 + (((v21 - v3) | 0) << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((272 + (v21 << 2)) | 0)) >>> 0) + 0) >>> 2] = (v34 ^ (((((((v23) | 0) === ((4) | 0)) | 0) & ((((v3) | 0) === ((8) | 0)) | 0))) ? (((((255 & v32) << 24) | ((255 & v31) << 16)) | (((255 & v30) << 8) | (255 & v33)))) : (((((((v23) | 0) === ((0) | 0)) | 0)) ? (((255 & v29) ^ ((((255 & v27) << 24) | ((255 & v26) << 16)) | (((255 & v25) << 8) | (255 & v28))))) : (v22)))));
s7 = v20;}
const v20 = s7;

const v35 = ((1 + v20) | 0);
if (((((v35) >>> 0) < ((v16) >>> 0)) | 0)) {
s6 = v35;continue L6;
}
s6 = v35;break L6;}
const v19 = s6;

s5 = v19;}
const v18 = s5;

s4 = v18;}

let s8 = 0;
L8:  {const v36 = s8;

if (((((((((v36) >>> 0) < ((v15) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v36;break L8;
}
let s9 = v36;
L9:  {const v37 = s9;

let s10 = v37;
L10: for (;;) {const v38 = s10;

let s11 = v38;
L11:  {const v39 = s11;

const v40 = memory_i32[(((((272 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2];
memory_i32[(((((32 + (v39 << 2)) | 0)) >>> 0) + 0) >>> 2] = v40;
s11 = v39;}
const v39 = s11;

const v41 = ((1 + v39) | 0);
if (((((v41) >>> 0) < ((v15) >>> 0)) | 0)) {
s10 = v41;continue L10;
}
s10 = v41;break L10;}
const v38 = s10;

s9 = v38;}
const v37 = s9;

s8 = v37;}

return ;
}



function initTables() {
    
    const v0 = memory_i32[2316];
L0:  {
if (((((((((v0) | 0) === ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L0;
}
let s0 = 0, s1 = 1;
L1:  {const v1 = s0;
const v2 = s1;

let s2 = v1, s3 = v2;
L2: for (;;) {const v3 = s2;
const v4 = s3;

const v5 = ((1 + v3) | 0);
const v6 = ((255 & (Math.imul(27, (1 & (v4 >>> 7))) ^ (v4 << 1))) ^ v4);
memory[((((800 + v3) | 0)) >>> 0) + 0] = (255 & v4);
if (((((v5) >>> 0) < ((256) >>> 0)) | 0)) {
s2 = v5;
s3 = v6;continue L2;
}
s2 = v5;
s3 = v6;break L2;}
const v3 = s2;
const v4 = s3;

s0 = v3;
s1 = v4;}

memory[544] = (255 & 99);
let s4 = 0;
L3:  {const v7 = s4;

if (((((((((v7) >>> 0) < ((255) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v7;break L3;
}
let s5 = v7;
L4:  {const v8 = s5;

let s6 = v8;
L5: for (;;) {const v9 = s6;

let s7 = v9;
L6:  {const v10 = s7;

const v11 = memory[((((800 + ((255 - v10) | 0)) | 0)) >>> 0) + 0];
const v12 = (255 & v11);
const v13 = ((v12 << 8) | v12);
const v14 = memory[((((800 + v10) | 0)) >>> 0) + 0];
memory[((((544 + (255 & v14)) | 0)) >>> 0) + 0] = (255 & (255 & (99 ^ ((v13 >>> 7) ^ ((v13 >>> 6) ^ ((v13 >>> 5) ^ ((v13 >>> 4) ^ v13)))))));
s7 = v10;}
const v10 = s7;

const v15 = ((1 + v10) | 0);
if (((((v15) >>> 0) < ((255) >>> 0)) | 0)) {
s6 = v15;continue L5;
}
s6 = v15;break L5;}
const v9 = s6;

s5 = v9;}
const v8 = s5;

s4 = v8;}

let s8 = 0;
L7:  {const v16 = s8;

if (((((((((v16) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v16;break L7;
}
let s9 = v16;
L8:  {const v17 = s9;

let s10 = v17;
L9: for (;;) {const v18 = s10;

let s11 = v18;
L10:  {const v19 = s11;

memory[((((4896 + v19) | 0)) >>> 0) + 0] = (255 & 0);
s11 = v19;}
const v19 = s11;

const v20 = ((1 + v19) | 0);
if (((((v20) >>> 0) < ((256) >>> 0)) | 0)) {
s10 = v20;continue L9;
}
s10 = v20;break L9;}
const v18 = s10;

s9 = v18;}
const v17 = s9;

s8 = v17;}

let s12 = 0;
L11:  {const v21 = s12;

if (((((((((v21) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s12 = v21;break L11;
}
let s13 = v21;
L12:  {const v22 = s13;

let s14 = v22;
L13: for (;;) {const v23 = s14;

let s15 = v23;
L14:  {const v24 = s15;

const v25 = memory[((((544 + v24) | 0)) >>> 0) + 0];
memory[((((4896 + (255 & v25)) | 0)) >>> 0) + 0] = (255 & v24);
s15 = v24;}
const v24 = s15;

const v26 = ((1 + v24) | 0);
if (((((v26) >>> 0) < ((256) >>> 0)) | 0)) {
s14 = v26;continue L13;
}
s14 = v26;break L13;}
const v23 = s14;

s13 = v23;}
const v22 = s13;

s12 = v22;}

let s16 = 0, s17 = 1;
L15:  {const v27 = s16;
const v28 = s17;

let s18 = v27, s19 = v28;
L16: for (;;) {const v29 = s18;
const v30 = s19;

const v31 = ((1 + v29) | 0);
const v32 = (255 & (Math.imul(27, (1 & (v30 >>> 7))) ^ (v30 << 1)));
memory[((((9248 + v29) | 0)) >>> 0) + 0] = (255 & v30);
if (((((v31) >>> 0) < ((16) >>> 0)) | 0)) {
s18 = v31;
s19 = v32;continue L16;
}
s18 = v31;
s19 = v32;break L16;}
const v29 = s18;
const v30 = s19;

s16 = v29;
s17 = v30;}

let s20 = 0;
L17:  {const v33 = s20;

if (((((((((v33) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s20 = v33;break L17;
}
let s21 = v33;
L18:  {const v34 = s21;

let s22 = v34;
L19: for (;;) {const v35 = s22;

let s23 = v35;
L20:  {const v36 = s23;

const v37 = memory[((((544 + v36) | 0)) >>> 0) + 0];
const v38 = (255 & v37);
const v39 = memory[((((4896 + v36) | 0)) >>> 0) + 0];
const v40 = (255 & v39);
const v41 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v42 = (255 & (Math.imul(27, (1 & (v41 >>> 7))) ^ (v41 << 1)));
const v43 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v44 = (255 & (Math.imul(27, (1 & (v43 >>> 7))) ^ (v43 << 1)));
const v45 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v46 = (255 & (Math.imul(27, (1 & (v45 >>> 7))) ^ (v45 << 1)));
const v47 = (255 & (Math.imul(27, (1 & (v40 >>> 7))) ^ (v40 << 1)));
const v48 = (255 & (Math.imul(27, (1 & (v47 >>> 7))) ^ (v47 << 1)));
memory_i32[(((((800 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) | (v38 << 8)) | (v38 << 16)) | (((255 & (Math.imul(27, (1 & (v38 >>> 7))) ^ (v38 << 1))) ^ v38) << 24));
memory_i32[(((((5152 + (v36 << 2)) | 0)) >>> 0) + 0) >>> 2] = (((((255 & (Math.imul(27, (1 & (v48 >>> 7))) ^ (v48 << 1))) ^ (v48 ^ v47)) | (((255 & (Math.imul(27, (1 & (v42 >>> 7))) ^ (v42 << 1))) ^ v40) << 8)) | (((255 & (Math.imul(27, (1 & (v46 >>> 7))) ^ (v46 << 1))) ^ (v46 ^ v40)) << 16)) | (((255 & (Math.imul(27, (1 & (v44 >>> 7))) ^ (v44 << 1))) ^ (v43 ^ v40)) << 24));
s23 = v36;}
const v36 = s23;

const v49 = ((1 + v36) | 0);
if (((((v49) >>> 0) < ((256) >>> 0)) | 0)) {
s22 = v49;continue L19;
}
s22 = v49;break L19;}
const v35 = s22;

s21 = v35;}
const v34 = s21;

s20 = v34;}

let s24 = 0;
L21:  {const v50 = s24;

if (((((((((v50) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s24 = v50;break L21;
}
let s25 = v50;
L22:  {const v51 = s25;

let s26 = v51;
L23: for (;;) {const v52 = s26;

let s27 = v52;
L24:  {const v53 = s27;

const v54 = memory_i32[(((((800 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v55 = ((v54 << 8) | ((v54 >>> (32 - 8)) >>> 0));
const v56 = ((v55 << 8) | ((v55 >>> (32 - 8)) >>> 0));
memory_i32[(((((1824 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v55;
memory_i32[(((((2848 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v56;
memory_i32[(((((3872 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v56 << 8) | ((v56 >>> (32 - 8)) >>> 0));
const v57 = memory_i32[(((((5152 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2];
const v58 = ((v57 << 8) | ((v57 >>> (32 - 8)) >>> 0));
const v59 = ((v58 << 8) | ((v58 >>> (32 - 8)) >>> 0));
memory_i32[(((((6176 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v58;
memory_i32[(((((7200 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = v59;
memory_i32[(((((8224 + (v53 << 2)) | 0)) >>> 0) + 0) >>> 2] = ((v59 << 8) | ((v59 >>> (32 - 8)) >>> 0));
s27 = v53;}
const v53 = s27;

const v60 = ((1 + v53) | 0);
if (((((v60) >>> 0) < ((256) >>> 0)) | 0)) {
s26 = v60;continue L23;
}
s26 = v60;break L23;}
const v52 = s26;

s25 = v52;}
const v51 = s25;

s24 = v51;}

memory_i32[2316] = 1;
}

return ;
}



function reset(v0) {
    
    memory.fill(0, 0, 0 + 544)
memory.fill(0, 9280, 9280 + ((v0) >>> 0))
return ;
}
const instance = { exports: {decryptBlocks: decryptBlocks, decryptInit: decryptInit, encryptBlocks: encryptBlocks, encryptInit: encryptInit, initTables: initTables, reset: reset, memory: { buffer: __buf }}};

;
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 10495040);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 544)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*544, 544)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*4, 4)))
, "state.iv": new Uint8Array(memoryExport.buffer, 528, 16)
, "state.iv_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*16, 16)))
, constants: new Uint8Array(memoryExport.buffer, 544, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 800 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 1824 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2848 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 3872 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5152 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 6176 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 7200 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8224 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9248 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9264 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9280 + i*10485760, 10485760)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments  });}
let _cache;
export default function aes_ofb(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}