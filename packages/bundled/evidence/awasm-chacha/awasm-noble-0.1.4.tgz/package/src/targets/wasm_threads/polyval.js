// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 41121, maximum: 41121, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABYw5gAn9/AX9gAAF/YAF/AGAIf39/f39/f38AYAZ/f39/f38AYAN/f38AYAZ/f39/f38Bf2AFf39/f38AYAF/AX9gAn97An97YAN/f38Df39/YAJ/fwJ/f2AAAGADf35+A39+fgJdBANlbnYHX21lbW9yeQIDocECocECA2VudhRfd29ya2VyX25vdGlmeUJyaWRnZQAAA2VudhRfd29ya2VyX29ubGluZUJyaWRnZQABA2Vudgtpbml0V29ya2VycwACAwwLAwQAAQUCBgMEBwIHwAEMBm1lbW9yeQIAGV9wcm9jZXNzQmxvY2tzX3RocmVhZF9pbnQAAxxfcHJvY2Vzc091dEJsb2Nrc190aHJlYWRfaW50AAQOX3dvcmtlcl9ub3RpZnkABQ5fd29ya2VyX29ubGluZQAGCmluaXRXb3JrZXIABwdtYWNJbml0AAgHcGFkZGluZwAJDXByb2Nlc3NCbG9ja3MAChBwcm9jZXNzT3V0QmxvY2tzAAsFcmVzZXQADApzdG9wV29ya2VyAA0K3zoLhRIZDH8BewF/AXsBfwF7AX8BewF/A3sCfhF7DX8BewF/AXsBfwF7AX8BewF/A3sCfhF7A38gACABaiEIIAggAUEEcGshCSAAAgghCiAKIAogCUlFDQAaIAoCCCELIAsDCCEMIAwCCCENIAIgB2shDkEAAgghDyAPIA9BBElFDQAaIA8CCCEQIBADCCERIBECCCESIA0gEmohEyATQcCBBGxBIGr9AAQAIRRBACAUAgkhFiEVIBUgFiAVIA5JRQ0AGhogFSAWAgkhGCEXIBcgGAMJIRohGSAZIBoCCSEcIRsgEyADbEEEdCAbQQR0QYCA4IN6amr9AAQAIR0gEyADbEEEdCAbQQR0QYCA4IN6amr9DAAAAAAAAAAAAAAAAAAAAAD9CwQAIBwgHf1RIR4gE0HAgQRsIB79HQEiIEI4iEL/AYOnQQB2Qf8BcUEEdEHAAGpq/QAEACEhIBNBwIEEbEGAAiAgQjCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEiIBNBwIEEbEGABCAgQiiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEjIBNBwIEEbEGABiAgQiCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEkIBNBwIEEbEGACCAgQhiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACElIBNBwIEEbEGACiAgQhCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEmIBNBwIEEbEGADCAgQgiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEnIBNBwIEEbEGADiAgQgCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACEoIBNBwIEEbEGAECAe/R0AIh9COIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISkgE0HAgQRsQYASIB9CMIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISogE0HAgQRsQYAUIB9CKIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISsgE0HAgQRsQYAWIB9CIIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAISwgE0HAgQRsQYAYIB9CGIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS0gE0HAgQRsQYAaIB9CEIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS4gE0HAgQRsQYAcIB9CCIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAIS8gE0HAgQRsQYAeIB9CAIhC/wGDp0EAdkH/AXFqQQR0QcAAamr9AAQAITAgISAi/VEgI/1RICT9USAl/VEgJv1RICf9USAo/VEgKf1RICr9USAr/VEgLP1RIC39USAu/VEgL/1RIDD9USExIBsgMQshHCEbIBtBAWohMiAyIBwgMiAOSQ0AGhogMiAcCyEaIRkgGSAaCyEYIRcgFyAYCyEWIRUgE0HAgQRsQSBqIBb9CwQAIBILIRIgEkEBaiEzIDMgM0EESQ0AGiAzCyERIBELIRAgEAshDyANCyENIA1BBGohNCA0IDQgCUkNABogNAshDCAMCyELIAsLIQogCQIIITUgNSA1IAhJRQ0AGiA1AgghNiA2AwghNyA3AgghOCACIAdrITlBAAIIITogOiA6QQFJRQ0AGiA6AgghOyA7AwghPCA8AgghPSA4ID1qIT4gPkHAgQRsQSBq/QAEACE/QQAgPwIJIUEhQCBAIEEgQCA5SUUNABoaIEAgQQIJIUMhQiBCIEMDCSFFIUQgRCBFAgkhRyFGID4gA2xBBHQgRkEEdEGAgOCDempq/QAEACFIID4gA2xBBHQgRkEEdEGAgOCDempq/QwAAAAAAAAAAAAAAAAAAAAA/QsEACBHIEj9USFJID5BwIEEbCBJ/R0BIktCOIhC/wGDp0EAdkH/AXFBBHRBwABqav0ABAAhTCA+QcCBBGxBgAIgS0IwiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTSA+QcCBBGxBgAQgS0IoiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTiA+QcCBBGxBgAYgS0IgiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhTyA+QcCBBGxBgAggS0IYiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUCA+QcCBBGxBgAogS0IQiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUSA+QcCBBGxBgAwgS0IIiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUiA+QcCBBGxBgA4gS0IAiEL/AYOnQQB2Qf8BcWpBBHRBwABqav0ABAAhUyA+QcCBBGxBgBAgSf0dACJKQjiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFUID5BwIEEbEGAEiBKQjCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFVID5BwIEEbEGAFCBKQiiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFWID5BwIEEbEGAFiBKQiCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFXID5BwIEEbEGAGCBKQhiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFYID5BwIEEbEGAGiBKQhCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFZID5BwIEEbEGAHCBKQgiIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFaID5BwIEEbEGAHiBKQgCIQv8Bg6dBAHZB/wFxakEEdEHAAGpq/QAEACFbIEwgTf1RIE79USBP/VEgUP1RIFH9USBS/VEgU/1RIFT9USBV/VEgVv1RIFf9USBY/VEgWf1RIFr9USBb/VEhXCBGIFwLIUchRiBGQQFqIV0gXSBHIF0gOUkNABoaIF0gRwshRSFEIEQgRQshQyFCIEIgQwshQSFAID5BwIEEbEEgaiBB/QsEACA9CyE9ID1BAWohXiBeIF5BAUkNABogXgshPCA8CyE7IDsLITogOAshOCA4QQFqIV8gXyBfIAhJDQAaIF8LITcgNwshNiA2CyE1C7EEBQt/AXsQfwF7B38gACABaiEGIAYgAUEEcGshByAAAgghCCAIIAggB0lFDQAaIAgCCCEJIAkDCCEKIAoCCCELQQACCCEMIAwgDEEESUUNABogDAIIIQ0gDQMIIQ4gDgIIIQ8gCyAPaiEQIBBBwIEEbEEgav0ABAAhEUEAAgghEiASIBIgAklFDQAaIBICCCETIBMDCCEUIBQCCCEVIBAgA2xBBHQgFUEEdEGAgOCDempqIBH9CwQAIBULIRUgFUEBaiEWIBYgFiACSQ0AGiAWCyEUIBQLIRMgEwshEiAPCyEPIA9BAWohFyAXIBdBBEkNABogFwshDiAOCyENIA0LIQwgCwshCyALQQRqIRggGCAYIAdJDQAaIBgLIQogCgshCSAJCyEIIAcCCCEZIBkgGSAGSUUNABogGQIIIRogGgMIIRsgGwIIIRxBAAIIIR0gHSAdQQFJRQ0AGiAdAgghHiAeAwghHyAfAgghICAcICBqISEgIUHAgQRsQSBq/QAEACEiQQACCCEjICMgIyACSUUNABogIwIIISQgJAMIISUgJQIIISYgISADbEEEdCAmQQR0QYCA4IN6amogIv0LBAAgJgshJiAmQQFqIScgJyAnIAJJDQAaICcLISUgJQshJCAkCyEjICALISAgIEEBaiEoICggKEEBSQ0AGiAoCyEfIB8LIR4gHgshHSAcCyEcIBxBAWohKSApICkgBkkNABogKQshGyAbCyEaIBoLIRkL5AEBEH9BACABQQACCiEEIQMhAiACIAMgBCADQQBHRQ0AGhoaIAIgAyAEAgohByEGIQUgBSAGIAcDCiEKIQkhCCAIIAkgCgIKIQ0hDCELIAsgDCANIAxBAXFFDQAaGhogC0GABmxBgIaAhXpqIAD+FwIAIAtBgAZsQYCGgIV6akEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAubAQEMf0EAQQACCyEBIQAgACABIABBH0lFDQAaGiAAIAECCyEDIQIgAiADAwshBSEEIAQgBQILIQchBiAGQQFqIghBgAZsQYCEgIV6av4QAgAhCSAHQQEgCHRBACAJG3IhCiAGIAoLIQchBiAGQQFqIQsgCyAHIAtBH0kNABoaIAsgBwshBSEEIAQgBQshAyECIAIgAwshASEAIAEL/wIBEn8gAEGABmxBgIWAhXpqIQMgAEGABmxBgIaAhXpqIQQgAEGABmxBgISAhXpqQQH+FwIAAgwCDCABRQ0ADAELAgwDDCAEQQD+QQIAIQUCDCAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCwIMIAVBAUZFDQBBACgCgMSBhQohB0EAKAKExIGFCiEIQQAoAojEgYUKIQlBACgCjMSBhQohCkEAKAKQxIGFCiELIABBgAZsQYCHgIV6av4QAgAhDCAAQYAGbEGAiICFemr+EAIAIQ0gAEGABmxBgImAhXpq/hACACEOIAwgDSAOIAcgCCAJIAogCxADCwIMIAVBAkZFDQBBACgCgMSBhQohD0EAKAKExIGFCiEQQQAoAojEgYUKIREgAEGABmxBgIeAhXpq/hACACESIABBgAZsQYCIgIV6av4QAgAhEyAAQYAGbEGAiYCFemr+EAIAIRQgEiATIBQgDyAQIBEQBAsgA0EB/hcCACACDQFBAQ0ACwsLC60NHR5/Bn4BfwJ+AX8CfgF/An4BfwJ+AX8CfgF/An4BfwJ+AX8IfgZ/AXsBfwF7AX8BewF/A3sBfwZ+An9BAAIIIQEgASABQQhJRQ0AGiABAgghAiACAwghAyADAgghBCAAQcCBBGwgBEEwamotAAAhBiAAQcCBBGxBDyAEayIFQTBqai0AACEHIABBwIEEbCAEQTBqaiAHOgAAIABBwIEEbCAFQTBqaiAGOgAAIAQLIQQgBEEBaiEIIAggCEEISQ0AGiAICyEDIAMLIQIgAgshASAAQcCBBGxBP2otAAAhCUEAQQACCyELIQogCiALAwshDSEMIAxBAWohDiAAQcCBBGwgDEEwamotAAAhDyAAQcCBBGwgDEEwamogD0EBdiANckH/AXE6AAAgD0EBcUEHdCEQIA4gECAOQRBJDQAaGiAOIBALIQ0hDCAMIA0LIQshCiAAQcCBBGxBMGotAAAhESAAQcCBBGxBMGogEUEAIAlBAXFrQeEBcXM6AAAgAEHAgQRsQRBqIhJBADYCACASQQRqIhNBADYCACATQQRqIhRBADYCACAUQQRqQQA2AgAgAEHAgQRsQSBq/QwAAAAAAAAAAAAAAAAAAAAA/QsEACAAQcCBBGwiFUEANgIAIBVBBGoiFkEANgIAIBZBBGoiF0EANgIAIBdBBGpBADYCACAAQcCBBGxBMGoiGCgCACEZIBhBBGoiGigCACEbIBpBBGoiHCgCACEdIBxBBGooAgAhHkEAIButQiCGIBmthCIfQv+B/Ifwn8D/AINBCKyGIB9BCKyIQv+B/Ifwn8D/AIOEIiFC//+DgPD/P4NBEKyGICFBEKyIQv//g4Dw/z+DhCIiQSCshiAiQSCsiIQgHq1CIIYgHa2EIiBC/4H8h/CfwP8Ag0EIrIYgIEEIrIhC/4H8h/CfwP8Ag4QiI0L//4OA8P8/g0EQrIYgI0EQrIhC//+DgPD/P4OEIiRBIKyGICRBIKyIhAINISchJiElICUgJiAnICVBEElFDQAaGhogJSAmICcCDSEqISkhKCAoICkgKgMNIS0hLCErICsgLCAtAg0hMCEvIS5BACAvIDACDSEzITIhMSAxIDIgMyAxQQhJRQ0AGhoaIDEgMiAzAg0hNiE1ITQgNCA1IDYDDSE5ITghNyA3IDggOQINITwhOyE6IABBwIEEbCA6QQR0QcCABGpqIDtC/4H8h/CfwP8Ag0EIrIYgO0EIrIhC/4H8h/CfwP8Ag4QiPUL//4OA8P8/g0EQrIYgPUEQrIhC//+DgPD/P4OEIj5BIKyGID5BIKyIhP0SIDxC/4H8h/CfwP8Ag0EIrIYgPEEIrIhC/4H8h/CfwP8Ag4QiP0L//4OA8P8/g0EQrIYgP0EQrIhC//+DgPD/P4OEIkBBIKyGIEBBIKyIhP0eAf0LBAAgO0I/hiA8QgGIhCFBIDtCAYhCgICAgICAgIBhQgAgPEIBg32DhSFCIDogQiBBCyE8ITshOiA6QQFqIUMgQyA7IDwgQ0EISQ0AGhoaIEMgOyA8CyE5ITghNyA3IDggOQshNiE1ITQgNCA1IDYLITMhMiExQQACCCFEIEQgREGAAklFDQAaIEQCCCFFIEUDCCFGIEYCCCFHQQD9DAAAAAAAAAAAAAAAAAAAAAACCSFJIUggSCBJIEhBCElFDQAaGiBIIEkCCSFLIUogSiBLAwkhTSFMIEwgTQIJIU8hTiAAQcCBBGwgTkEEdEHAgARqav0ABAAhUCBPIFBCACBHQQcgTmt2QQFxrX39Ev1O/VEhUSBOIFELIU8hTiBOQQFqIVIgUiBPIFJBCEkNABoaIFIgTwshTSFMIEwgTQshSyFKIEogSwshSSFIIABBwIEEbCAuQQh0IEdqQQR0QcAAamogSf0dASJUQv+B/Ifwn8D/AINBCKyGIFRBCKyIQv+B/Ifwn8D/AIOEIlVC//+DgPD/P4NBEKyGIFVBEKyIQv//g4Dw/z+DhCJWQSCshiBWQSCsiIT9EiBJ/R0AIlNC/4H8h/CfwP8Ag0EIrIYgU0EIrIhC/4H8h/CfwP8Ag4QiV0L//4OA8P8/g0EQrIYgV0EQrIhC//+DgPD/P4OEIlhBIKyGIFhBIKyIhP0eAf0LBAAgRwshRyBHQQFqIVkgWSBZQYACSQ0AGiBZCyFGIEYLIUUgRQshRCAuIDIgMwshMCEvIS4gLkEBaiFaIFogLyAwIFpBEEkNABoaGiBaIC8gMAshLSEsISsgKyAsIC0LISohKSEoICggKSAqCyEnISYhJQuJAQEHfyAEQQRuIQYCDCADQQBHRQ0AQQACCCEHIAcgByADSUUNABogBwIIIQggCAMIIQkgCQIIIQogACACIAZsbEECdCABIApqQYCA4IN6ampBADoAACAKCyEKIApBAWohCyALIAsgA0kNABogCwshCSAJCyEIIAgLIQcLQQFBACABQQBGGyEMIAwLtQcBO38CDAIMIAFBAUZFDQAgACABIAIgAyAEIAUgBiAHEAMMAQtBAEEBIAFBAUGACCACQQFraiACbiIIQQEgCE8bIglBAWtqIAluIgogASACbEH/B2pBgAhuIgsgCiALTRsiDEEBIAxPGyABRRshDQIMAgwgDUEBTUUNACAAIAEgAiADIAQgBSAGIAcQAwwBC0EAIAM2AoDEgYUKQQAgBDYChMSBhQpBACAFNgKIxIGFCkEAIAY2AozEgYUKQQAgBzYCkMSBhQoQASEOIAFBACABIA5pIg8gASAPTRsiECANIBAgDU0bIhFBICARQSBNGyISQQFrIBJBAEYbIhNBAWoiFEEBa2ogFG4hFSAAIAFqIRYgEyABIBVBAWtqIBVuQQFrIhcgEyAXTRshGEEAQQBBAAIKIRshGiEZIBkgGiAbIBlBH0lFDQAaGhogGSAaIBsCCiEeIR0hHCAcIB0gHgMKISEhICEfIB8gICAhAgohJCEjISIgIiAjICQgJCAYTw0CGhoaICJBAWohJSAAICRBAWogFWxqISYgIyAkAgshKSEoICggKSAOQQEgJXRxQQBHICYgFklxRQ0AGhogJUGABmxBgIeAhXpqICb+FwIAICVBgAZsQYCIgIV6aiAVIBYgJmsiJyAVICdNG/4XAgAgJUGABmxBgImAhXpqIAL+FwIAIChBASAldHIhKiApQQFqISsgKiArCyEpISggIiAoICkLISQhIyEiICJBAWohLCAsICMgJCAsQR9JDQAaGhogLCAjICQLISEhICEfIB8gICAhCyEeIR0hHCAcIB0gHgshGyEaIRlBASAaEAAhLSAAIAEgFSABIBVNGyACIAMgBCAFIAYgBxADIBoCCCEuIC4gLkEAR0UNABogLgIIIS8gLwMIITAgMAIIITFBACAxQQACCiE0ITMhMiAyIDMgNCAzQQBHRQ0AGhoaIDIgMyA0AgohNyE2ITUgNSA2IDcDCiE6ITkhOCA4IDkgOgIKIT0hPCE7IDsgPCA9IDxBAXFFDQAaGhogO0GABmxBgIWAhXpqQQD+QQIAIT8gMUEBIDt0Ij5zID9BAEcNBBogPSA+ciFAIDsgPCBACyE9ITwhOyA7QQFqIUEgPEEBdiFCIEEgQiA9IEJBAEcNABoaGiBBIEIgPQshOiE5ITggOCA5IDoLITchNiE1IDUgNiA3CyE0ITMhMiAxCyExIDEgMUEARw0AGiAxCyEwIDALIS8gLwshLkGAxIGFekEAQYAB/AsACwsLkwcBO38CDAIMIAFBAUZFDQAgACABIAIgAyAEIAUQBAwBC0EAQQEgAUEBQYAIIAJBAWtqIAJuIgZBASAGTxsiB0EBa2ogB24iCCABIAJsQf8HakGACG4iCSAIIAlNGyIKQQEgCk8bIAFFGyELAgwCDCALQQFNRQ0AIAAgASACIAMgBCAFEAQMAQtBACADNgKAxIGFCkEAIAQ2AoTEgYUKQQAgBTYCiMSBhQoQASEMIAFBACABIAxpIg0gASANTRsiDiALIA4gC00bIg9BICAPQSBNGyIQQQFrIBBBAEYbIhFBAWoiEkEBa2ogEm4hEyAAIAFqIRQgESABIBNBAWtqIBNuQQFrIhUgESAVTRshFkEAQQBBAAIKIRkhGCEXIBcgGCAZIBdBH0lFDQAaGhogFyAYIBkCCiEcIRshGiAaIBsgHAMKIR8hHiEdIB0gHiAfAgohIiEhISAgICAhICIgIiAWTw0CGhoaICBBAWohIyAAICJBAWogE2xqISQgISAiAgshJyEmICYgJyAMQQEgI3RxQQBHICQgFElxRQ0AGhogI0GABmxBgIeAhXpqICT+FwIAICNBgAZsQYCIgIV6aiATIBQgJGsiJSATICVNG/4XAgAgI0GABmxBgImAhXpqIAL+FwIAICZBASAjdHIhKCAnQQFqISkgKCApCyEnISYgICAmICcLISIhISEgICBBAWohKiAqICEgIiAqQR9JDQAaGhogKiAhICILIR8hHiEdIB0gHiAfCyEcIRshGiAaIBsgHAshGSEYIRdBAiAYEAAhKyAAIAEgEyABIBNNGyACIAMgBCAFEAQgGAIIISwgLCAsQQBHRQ0AGiAsAgghLSAtAwghLiAuAgghL0EAIC9BAAIKITIhMSEwIDAgMSAyIDFBAEdFDQAaGhogMCAxIDICCiE1ITQhMyAzIDQgNQMKITghNyE2IDYgNyA4AgohOyE6ITkgOSA6IDsgOkEBcUUNABoaGiA5QYAGbEGAhYCFempBAP5BAgAhPSAvQQEgOXQiPHMgPUEARw0EGiA7IDxyIT4gOSA6ID4LITshOiE5IDlBAWohPyA6QQF2IUAgPyBAIDsgQEEARw0AGhoaID8gQCA7CyE4ITchNiA2IDcgOAshNSE0ITMgMyA0IDULITIhMSEwIC8LIS8gLyAvQQBHDQAaIC8LIS4gLgshLSAtCyEsQYDEgYV6QQBBgAH8CwALCwuCAQEGfyADQQRuIQUgAEHAgQRsQQBBwIEEIAFs/AsAQQACCCEGIAYgBiABSUUNABogBgIIIQcgBwMIIQggCAIIIQkgACAJaiAEIAVsbEECdEGAgOCDempBACAC/AsAIAkLIQkgCUEBaiEKIAogCiABSQ0AGiAKCyEIIAgLIQcgBwshBgsVACAAQYAGbEGAhICFempBAP4XAgAL'), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 2694865536);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 2692218880)
, state_chunks: Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 65728)))
, "state.state_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 16)))
, "state.ghash_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 48)))
, "state.ghash.y_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 16)))
, "state.ghash.y64_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*65728, 16)))
, "state.ghash.h_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 48 + i*65728, 16)))
, "state.table64v_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 64 + i*65728, 65536)))
, "state.tmp64v_chunks": Object.freeze(Array.from({length: 40960},(_,i)=>new Uint8Array(memoryExport.buffer, 65600 + i*65728, 128)))
, buffer: new Uint8Array(memoryExport.buffer, 2692218880, 2621440)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2692218880 + i*2621440, 2621440)))
, _worker: new Uint8Array(memoryExport.buffer, 2694840320, 25216)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840320 + i*25216, 25216)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 2694840320, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840320 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 2694840448, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840448 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 2694840576, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840576 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 2694840704, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840704 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 2694840832, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694840832 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 2694865408, 128)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2694865408 + i*128, 128)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}
let _cache;
export default function polyval(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}