// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};


const __buf = new ArrayBuffer(2687168);
if (!(__buf instanceof ArrayBuffer)) throw new Error('wrong buffer');

const memory = new Uint8Array(__buf);
const memory_i32 = new Int32Array(__buf);



function macInit(v0) {
    
    const v1 = ((16 + Math.imul(65728, v0)) | 0);
memory_i32[(((v1) >>> 0) + 0) >>> 2] = 0;
const v2 = ((4 + v1) | 0);
memory_i32[(((v2) >>> 0) + 0) >>> 2] = 0;
const v3 = ((4 + v2) | 0);
memory_i32[(((v3) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((((4 + v3) | 0)) >>> 0) + 0) >>> 2] = 0;
const v4 = ((32 + Math.imul(65728, v0)) | 0);
const v5 = Math.imul(65728, v0);
memory_i32[(((v4) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((v4) >>> 0) + 4) >>> 2] = 0;
memory_i32[(((v4) >>> 0) + 8) >>> 2] = 0;
memory_i32[(((v4) >>> 0) + 12) >>> 2] = 0;
memory_i32[(((v5) >>> 0) + 0) >>> 2] = 0;
const v6 = ((4 + v5) | 0);
memory_i32[(((v6) >>> 0) + 0) >>> 2] = 0;
const v7 = ((4 + v6) | 0);
memory_i32[(((v7) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((((4 + v7) | 0)) >>> 0) + 0) >>> 2] = 0;
const v8 = ((48 + Math.imul(65728, v0)) | 0);
const v9 = memory_i32[(((v8) >>> 0) + 0) >>> 2];
const v10 = ((4 + v8) | 0);
const v11 = memory_i32[(((v10) >>> 0) + 0) >>> 2];
const v12 = ((4 + v10) | 0);
const v13 = memory_i32[(((v12) >>> 0) + 0) >>> 2];
const v14 = memory_i32[(((((4 + v12) | 0)) >>> 0) + 0) >>> 2];
const v15 = (16711935 & v9);
const v16 = (63 & 8);
const v17 = ((((v16) | 0) === 0) | 0);
const v18 = (v16 >>> 5);
const v19 = (31 & v16);
const v20 = (63 & 8);
const v21 = ((((v20) | 0) === 0) | 0);
const v22 = (v20 >>> 5);
const v23 = (31 & v20);
const v24 = ((16711935 & ((v21) ? (v9) : (((v22) ? ((v11 >>> v23)) : (((v11 << ((32 - v23) | 0)) | (v9 >>> v23))))))) | ((v17) ? (v15) : (((v18) ? (0) : ((v15 << v19))))));
const v25 = (65535 & v24);
const v26 = (63 & 16);
const v27 = ((((v26) | 0) === 0) | 0);
const v28 = (v26 >>> 5);
const v29 = (31 & v26);
const v30 = (63 & 16);
const v31 = ((((v30) | 0) === 0) | 0);
const v32 = (v30 >>> 5);
const v33 = (31 & v30);
const v34 = (16711935 & v11);
const v35 = ((16711935 & ((v21) ? (v11) : (((v22) ? (0) : ((v11 >>> v23)))))) | ((v17) ? (v34) : (((v18) ? ((v15 << v19)) : (((v15 >>> ((32 - v19) | 0)) | (v34 << v19)))))));
const v36 = ((65535 & ((v31) ? (v24) : (((v32) ? ((v35 >>> v33)) : (((v35 << ((32 - v33) | 0)) | (v24 >>> v33))))))) | ((v27) ? (v25) : (((v28) ? (0) : ((v25 << v29))))));
const v37 = (63 & 32);
const v38 = ((((v37) | 0) === 0) | 0);
const v39 = (v37 >>> 5);
const v40 = (31 & v37);
const v41 = (63 & 32);
const v42 = ((((v41) | 0) === 0) | 0);
const v43 = (v41 >>> 5);
const v44 = (31 & v41);
const v45 = (65535 & v35);
const v46 = ((65535 & ((v31) ? (v35) : (((v32) ? (0) : ((v35 >>> v33)))))) | ((v27) ? (v45) : (((v28) ? ((v25 << v29)) : (((v25 >>> ((32 - v29) | 0)) | (v45 << v29)))))));
const v47 = (16711935 & v13);
const v48 = (63 & 8);
const v49 = ((((v48) | 0) === 0) | 0);
const v50 = (v48 >>> 5);
const v51 = (31 & v48);
const v52 = (63 & 8);
const v53 = ((((v52) | 0) === 0) | 0);
const v54 = (v52 >>> 5);
const v55 = (31 & v52);
const v56 = ((16711935 & ((v53) ? (v13) : (((v54) ? ((v14 >>> v55)) : (((v14 << ((32 - v55) | 0)) | (v13 >>> v55))))))) | ((v49) ? (v47) : (((v50) ? (0) : ((v47 << v51))))));
const v57 = (65535 & v56);
const v58 = (63 & 16);
const v59 = ((((v58) | 0) === 0) | 0);
const v60 = (v58 >>> 5);
const v61 = (31 & v58);
const v62 = (63 & 16);
const v63 = ((((v62) | 0) === 0) | 0);
const v64 = (v62 >>> 5);
const v65 = (31 & v62);
const v66 = (16711935 & v14);
const v67 = ((16711935 & ((v53) ? (v14) : (((v54) ? (0) : ((v14 >>> v55)))))) | ((v49) ? (v66) : (((v50) ? ((v47 << v51)) : (((v47 >>> ((32 - v51) | 0)) | (v66 << v51)))))));
const v68 = ((65535 & ((v63) ? (v56) : (((v64) ? ((v67 >>> v65)) : (((v67 << ((32 - v65) | 0)) | (v56 >>> v65))))))) | ((v59) ? (v57) : (((v60) ? (0) : ((v57 << v61))))));
const v69 = (63 & 32);
const v70 = ((((v69) | 0) === 0) | 0);
const v71 = (v69 >>> 5);
const v72 = (31 & v69);
const v73 = (63 & 32);
const v74 = ((((v73) | 0) === 0) | 0);
const v75 = (v73 >>> 5);
const v76 = (31 & v73);
const v77 = (65535 & v67);
const v78 = ((65535 & ((v63) ? (v67) : (((v64) ? (0) : ((v67 >>> v65)))))) | ((v59) ? (v77) : (((v60) ? ((v57 << v61)) : (((v57 >>> ((32 - v61) | 0)) | (v77 << v61)))))));
let s0 = 0, s1 = (((v42) ? (v36) : (((v43) ? ((v46 >>> v44)) : (((v46 << ((32 - v44) | 0)) | (v36 >>> v44)))))) | ((v38) ? (v36) : (((v39) ? (0) : ((v36 << v40)))))), s2 = (((v42) ? (v46) : (((v43) ? (0) : ((v46 >>> v44))))) | ((v38) ? (v46) : (((v39) ? ((v36 << v40)) : (((v36 >>> ((32 - v40) | 0)) | (v46 << v40))))))), s3 = (((v74) ? (v68) : (((v75) ? ((v78 >>> v76)) : (((v78 << ((32 - v76) | 0)) | (v68 >>> v76)))))) | ((v70) ? (v68) : (((v71) ? (0) : ((v68 << v72)))))), s4 = (((v74) ? (v78) : (((v75) ? (0) : ((v78 >>> v76))))) | ((v70) ? (v78) : (((v71) ? ((v68 << v72)) : (((v68 >>> ((32 - v72) | 0)) | (v78 << v72)))))));
L0:  {const v79 = s0;
const v80 = s1;
const v81 = s2;
const v82 = s3;
const v83 = s4;

if (((((((((v79) >>> 0) < ((16) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v79;
s1 = v80;
s2 = v81;
s3 = v82;
s4 = v83;break L0;
}
let s5 = v79, s6 = v80, s7 = v81, s8 = v82, s9 = v83;
L1:  {const v84 = s5;
const v85 = s6;
const v86 = s7;
const v87 = s8;
const v88 = s9;

let s10 = v84, s11 = v85, s12 = v86, s13 = v87, s14 = v88;
L2: for (;;) {const v89 = s10;
const v90 = s11;
const v91 = s12;
const v92 = s13;
const v93 = s14;

let s15 = v89, s16 = v90, s17 = v91, s18 = v92, s19 = v93;
L3:  {const v94 = s15;
const v95 = s16;
const v96 = s17;
const v97 = s18;
const v98 = s19;

let s20 = 0, s21 = v95, s22 = v96, s23 = v97, s24 = v98;
L4:  {const v99 = s20;
const v100 = s21;
const v101 = s22;
const v102 = s23;
const v103 = s24;

if (((((((((v99) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
s20 = v99;
s21 = v100;
s22 = v101;
s23 = v102;
s24 = v103;break L4;
}
let s25 = v99, s26 = v100, s27 = v101, s28 = v102, s29 = v103;
L5:  {const v104 = s25;
const v105 = s26;
const v106 = s27;
const v107 = s28;
const v108 = s29;

let s30 = v104, s31 = v105, s32 = v106, s33 = v107, s34 = v108;
L6: for (;;) {const v109 = s30;
const v110 = s31;
const v111 = s32;
const v112 = s33;
const v113 = s34;

let s35 = v109, s36 = v110, s37 = v111, s38 = v112, s39 = v113;
L7:  {const v114 = s35;
const v115 = s36;
const v116 = s37;
const v117 = s38;
const v118 = s39;

const v119 = ((((65600 + (v114 << 4)) | 0) + Math.imul(65728, v0)) | 0);
const v120 = (16711935 & v115);
const v121 = (16711935 & v116);
const v122 = (63 & 8);
const v123 = (31 & v122);
const v124 = (v122 >>> 5);
const v125 = ((((v122) | 0) === 0) | 0);
const v126 = (63 & 8);
const v127 = (31 & v126);
const v128 = (v126 >>> 5);
const v129 = ((((v126) | 0) === 0) | 0);
const v130 = ((16711935 & ((v129) ? (v115) : (((v128) ? ((v116 >>> v127)) : (((v116 << ((32 - v127) | 0)) | (v115 >>> v127))))))) | ((v125) ? (v120) : (((v124) ? (0) : ((v120 << v123))))));
const v131 = ((16711935 & ((v129) ? (v116) : (((v128) ? (0) : ((v116 >>> v127)))))) | ((v125) ? (v121) : (((v124) ? ((v120 << v123)) : (((v120 >>> ((32 - v123) | 0)) | (v121 << v123)))))));
const v132 = (65535 & v130);
const v133 = (65535 & v131);
const v134 = (63 & 16);
const v135 = (31 & v134);
const v136 = (v134 >>> 5);
const v137 = ((((v134) | 0) === 0) | 0);
const v138 = (63 & 16);
const v139 = (31 & v138);
const v140 = (v138 >>> 5);
const v141 = ((((v138) | 0) === 0) | 0);
const v142 = ((65535 & ((v141) ? (v130) : (((v140) ? ((v131 >>> v139)) : (((v131 << ((32 - v139) | 0)) | (v130 >>> v139))))))) | ((v137) ? (v132) : (((v136) ? (0) : ((v132 << v135))))));
const v143 = ((65535 & ((v141) ? (v131) : (((v140) ? (0) : ((v131 >>> v139)))))) | ((v137) ? (v133) : (((v136) ? ((v132 << v135)) : (((v132 >>> ((32 - v135) | 0)) | (v133 << v135)))))));
const v144 = (63 & 32);
const v145 = (31 & v144);
const v146 = (v144 >>> 5);
const v147 = ((((v144) | 0) === 0) | 0);
const v148 = (63 & 32);
const v149 = (31 & v148);
const v150 = (v148 >>> 5);
const v151 = ((((v148) | 0) === 0) | 0);
const v152 = (16711935 & v117);
const v153 = (16711935 & v118);
const v154 = (63 & 8);
const v155 = (31 & v154);
const v156 = (v154 >>> 5);
const v157 = ((((v154) | 0) === 0) | 0);
const v158 = (63 & 8);
const v159 = (31 & v158);
const v160 = (v158 >>> 5);
const v161 = ((((v158) | 0) === 0) | 0);
const v162 = ((16711935 & ((v161) ? (v117) : (((v160) ? ((v118 >>> v159)) : (((v118 << ((32 - v159) | 0)) | (v117 >>> v159))))))) | ((v157) ? (v152) : (((v156) ? (0) : ((v152 << v155))))));
const v163 = ((16711935 & ((v161) ? (v118) : (((v160) ? (0) : ((v118 >>> v159)))))) | ((v157) ? (v153) : (((v156) ? ((v152 << v155)) : (((v152 >>> ((32 - v155) | 0)) | (v153 << v155)))))));
const v164 = (65535 & v162);
const v165 = (65535 & v163);
const v166 = (63 & 16);
const v167 = (31 & v166);
const v168 = (v166 >>> 5);
const v169 = ((((v166) | 0) === 0) | 0);
const v170 = (63 & 16);
const v171 = (31 & v170);
const v172 = (v170 >>> 5);
const v173 = ((((v170) | 0) === 0) | 0);
const v174 = ((65535 & ((v173) ? (v162) : (((v172) ? ((v163 >>> v171)) : (((v163 << ((32 - v171) | 0)) | (v162 >>> v171))))))) | ((v169) ? (v164) : (((v168) ? (0) : ((v164 << v167))))));
const v175 = ((65535 & ((v173) ? (v163) : (((v172) ? (0) : ((v163 >>> v171)))))) | ((v169) ? (v165) : (((v168) ? ((v164 << v167)) : (((v164 >>> ((32 - v167) | 0)) | (v165 << v167)))))));
const v176 = (63 & 32);
const v177 = (31 & v176);
const v178 = (v176 >>> 5);
const v179 = ((((v176) | 0) === 0) | 0);
const v180 = (63 & 32);
const v181 = (31 & v180);
const v182 = (v180 >>> 5);
const v183 = ((((v180) | 0) === 0) | 0);
const v184 = (1 & v117);
const v185 = ((v118 << 31) | (v117 >>> 1));
const v186 = ((v118 >>> 1) | (v115 << 31));
const v187 = ((v116 << 31) | (v115 >>> 1));
const v188 = ((((0 - (((((0 - v184) | 0) & (-1 ^ v184)) | v184) >>> 31)) | 0) & -520093696) ^ (v116 >>> 1));
memory_i32[(((v119) >>> 0) + 0) >>> 2] = (((v151) ? (v142) : (((v150) ? ((v143 >>> v149)) : (((v143 << ((32 - v149) | 0)) | (v142 >>> v149)))))) | ((v147) ? (v142) : (((v146) ? (0) : ((v142 << v145))))));
memory_i32[(((v119) >>> 0) + 4) >>> 2] = (((v151) ? (v143) : (((v150) ? (0) : ((v143 >>> v149))))) | ((v147) ? (v143) : (((v146) ? ((v142 << v145)) : (((v142 >>> ((32 - v145) | 0)) | (v143 << v145)))))));
memory_i32[(((v119) >>> 0) + 8) >>> 2] = (((v183) ? (v174) : (((v182) ? ((v175 >>> v181)) : (((v175 << ((32 - v181) | 0)) | (v174 >>> v181)))))) | ((v179) ? (v174) : (((v178) ? (0) : ((v174 << v177))))));
memory_i32[(((v119) >>> 0) + 12) >>> 2] = (((v183) ? (v175) : (((v182) ? (0) : ((v175 >>> v181))))) | ((v179) ? (v175) : (((v178) ? ((v174 << v177)) : (((v174 >>> ((32 - v177) | 0)) | (v175 << v177)))))));
s35 = v114;
s36 = v187;
s37 = v188;
s38 = v185;
s39 = v186;}
const v114 = s35;
const v115 = s36;
const v116 = s37;
const v117 = s38;
const v118 = s39;

const v189 = ((1 + v114) | 0);
if (((((v189) >>> 0) < ((8) >>> 0)) | 0)) {
s30 = v189;
s31 = v115;
s32 = v116;
s33 = v117;
s34 = v118;continue L6;
}
s30 = v189;
s31 = v115;
s32 = v116;
s33 = v117;
s34 = v118;break L6;}
const v109 = s30;
const v110 = s31;
const v111 = s32;
const v112 = s33;
const v113 = s34;

s25 = v109;
s26 = v110;
s27 = v111;
s28 = v112;
s29 = v113;}
const v104 = s25;
const v105 = s26;
const v106 = s27;
const v107 = s28;
const v108 = s29;

s20 = v104;
s21 = v105;
s22 = v106;
s23 = v107;
s24 = v108;}
const v100 = s21;
const v101 = s22;
const v102 = s23;
const v103 = s24;

let s40 = 0;
L8:  {const v190 = s40;

if (((((((((v190) >>> 0) < ((256) >>> 0)) | 0)) | 0) === 0) | 0)) {
s40 = v190;break L8;
}
let s41 = v190;
L9:  {const v191 = s41;

let s42 = v191;
L10: for (;;) {const v192 = s42;

let s43 = v192;
L11:  {const v193 = s43;

let s44 = 0, s45 = 0, s46 = 0, s47 = 0, s48 = 0;
L12:  {const v194 = s44;
const v195 = s45;
const v196 = s46;
const v197 = s47;
const v198 = s48;

if (((((((((v194) >>> 0) < ((8) >>> 0)) | 0)) | 0) === 0) | 0)) {
s44 = v194;
s45 = v195;
s46 = v196;
s47 = v197;
s48 = v198;break L12;
}
let s49 = v194, s50 = v195, s51 = v196, s52 = v197, s53 = v198;
L13:  {const v199 = s49;
const v200 = s50;
const v201 = s51;
const v202 = s52;
const v203 = s53;

let s54 = v199, s55 = v200, s56 = v201, s57 = v202, s58 = v203;
L14: for (;;) {const v204 = s54;
const v205 = s55;
const v206 = s56;
const v207 = s57;
const v208 = s58;

let s59 = v204, s60 = v205, s61 = v206, s62 = v207, s63 = v208;
L15:  {const v209 = s59;
const v210 = s60;
const v211 = s61;
const v212 = s62;
const v213 = s63;

const v214 = (1 & (v193 >>> ((7 - v209) | 0)));
const v215 = ((((65600 + (v209 << 4)) | 0) + Math.imul(65728, v0)) | 0);
const v216 = ((0 - v214) | 0);
const v217 = ((0 - (((v216 & (-1 ^ v214)) | v214) >>> 31)) | 0);
const v218 = memory_i32[(((v215) >>> 0) + 0) >>> 2];
const v219 = memory_i32[(((v215) >>> 0) + 4) >>> 2];
const v220 = memory_i32[(((v215) >>> 0) + 8) >>> 2];
const v221 = memory_i32[(((v215) >>> 0) + 12) >>> 2];
const v222 = ((v216 & v218) ^ v210);
const v223 = ((v217 & v219) ^ v211);
const v224 = ((v216 & v220) ^ v212);
const v225 = ((v217 & v221) ^ v213);
s59 = v209;
s60 = v222;
s61 = v223;
s62 = v224;
s63 = v225;}
const v209 = s59;
const v210 = s60;
const v211 = s61;
const v212 = s62;
const v213 = s63;

const v226 = ((1 + v209) | 0);
if (((((v226) >>> 0) < ((8) >>> 0)) | 0)) {
s54 = v226;
s55 = v210;
s56 = v211;
s57 = v212;
s58 = v213;continue L14;
}
s54 = v226;
s55 = v210;
s56 = v211;
s57 = v212;
s58 = v213;break L14;}
const v204 = s54;
const v205 = s55;
const v206 = s56;
const v207 = s57;
const v208 = s58;

s49 = v204;
s50 = v205;
s51 = v206;
s52 = v207;
s53 = v208;}
const v199 = s49;
const v200 = s50;
const v201 = s51;
const v202 = s52;
const v203 = s53;

s44 = v199;
s45 = v200;
s46 = v201;
s47 = v202;
s48 = v203;}
const v195 = s45;
const v196 = s46;
const v197 = s47;
const v198 = s48;

const v227 = ((((64 + (((v193 + (v94 << 8)) | 0) << 4)) | 0) + Math.imul(65728, v0)) | 0);
memory_i32[(((v227) >>> 0) + 0) >>> 2] = v195;
memory_i32[(((v227) >>> 0) + 4) >>> 2] = v196;
memory_i32[(((v227) >>> 0) + 8) >>> 2] = v197;
memory_i32[(((v227) >>> 0) + 12) >>> 2] = v198;
s43 = v193;}
const v193 = s43;

const v228 = ((1 + v193) | 0);
if (((((v228) >>> 0) < ((256) >>> 0)) | 0)) {
s42 = v228;continue L10;
}
s42 = v228;break L10;}
const v192 = s42;

s41 = v192;}
const v191 = s41;

s40 = v191;}

s15 = v94;
s16 = v100;
s17 = v101;
s18 = v102;
s19 = v103;}
const v94 = s15;
const v95 = s16;
const v96 = s17;
const v97 = s18;
const v98 = s19;

const v229 = ((1 + v94) | 0);
if (((((v229) >>> 0) < ((16) >>> 0)) | 0)) {
s10 = v229;
s11 = v95;
s12 = v96;
s13 = v97;
s14 = v98;continue L2;
}
s10 = v229;
s11 = v95;
s12 = v96;
s13 = v97;
s14 = v98;break L2;}
const v89 = s10;
const v90 = s11;
const v91 = s12;
const v92 = s13;
const v93 = s14;

s5 = v89;
s6 = v90;
s7 = v91;
s8 = v92;
s9 = v93;}
const v84 = s5;
const v85 = s6;
const v86 = s7;
const v87 = s8;
const v88 = s9;

s0 = v84;
s1 = v85;
s2 = v86;
s3 = v87;
s4 = v88;}

return ;
}



function padding(v0, v1, v2, v3, v4, v5) {
    
    const v6 = ((((((v4)>>>0)/(((4)>>>0))))>>>0));
L0:  {
if (((((((((v3) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L0;
}
let s0 = 0;
L1:  {const v7 = s0;

if (((((((((v7) >>> 0) < ((v3) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v7;break L1;
}
let s1 = v7;
L2:  {const v8 = s1;

let s2 = v8;
L3: for (;;) {const v9 = s2;

let s3 = v9;
L4:  {const v10 = s3;

memory[((((((65728 + ((v10 + v1) | 0)) | 0) + (Math.imul(Math.imul(v6, v2), v0) << 2)) | 0)) >>> 0) + 0] = 0;
s3 = v10;}
const v10 = s3;

const v11 = ((1 + v10) | 0);
if (((((v11) >>> 0) < ((v3) >>> 0)) | 0)) {
s2 = v11;continue L3;
}
s2 = v11;break L3;}
const v9 = s2;

s1 = v9;}
const v8 = s1;

s0 = v8;}

}

const v12 = ((((((v1) | 0) === ((0) | 0)) | 0)) ? (1) : (0));
return v12;
}



function processBlocks(v0, v1, v2, v3, v4, v5, v6, v7) {
    
    let s0 = 0;
L0:  {const v8 = s0;

if (((((((((v8) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v8;break L0;
}
let s1 = v8;
L1:  {const v9 = s1;

let s2 = v9;
L2: for (;;) {const v10 = s2;

let s3 = v10;
L3:  {const v11 = s3;

const v12 = ((v11 + v0) | 0);
const v13 = ((v2 - v7) | 0);
let s4 = 0;
L4:  {const v14 = s4;

if (((((((((v14) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v14;break L4;
}
let s5 = v14;
L5:  {const v15 = s5;

let s6 = v15;
L6: for (;;) {const v16 = s6;

let s7 = v16;
L7:  {const v17 = s7;

const v18 = ((v17 + v12) | 0);
const v19 = ((32 + Math.imul(65728, v18)) | 0);
const v20 = memory_i32[(((v19) >>> 0) + 0) >>> 2];
const v21 = memory_i32[(((v19) >>> 0) + 4) >>> 2];
const v22 = memory_i32[(((v19) >>> 0) + 8) >>> 2];
const v23 = memory_i32[(((v19) >>> 0) + 12) >>> 2];
let s8 = 0, s9 = v20, s10 = v21, s11 = v22, s12 = v23;
L8:  {const v24 = s8;
const v25 = s9;
const v26 = s10;
const v27 = s11;
const v28 = s12;

if (((((((((v24) >>> 0) < ((v13) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v24;
s9 = v25;
s10 = v26;
s11 = v27;
s12 = v28;break L8;
}
let s13 = v24, s14 = v25, s15 = v26, s16 = v27, s17 = v28;
L9:  {const v29 = s13;
const v30 = s14;
const v31 = s15;
const v32 = s16;
const v33 = s17;

let s18 = v29, s19 = v30, s20 = v31, s21 = v32, s22 = v33;
L10: for (;;) {const v34 = s18;
const v35 = s19;
const v36 = s20;
const v37 = s21;
const v38 = s22;

let s23 = v34, s24 = v35, s25 = v36, s26 = v37, s27 = v38;
L11:  {const v39 = s23;
const v40 = s24;
const v41 = s25;
const v42 = s26;
const v43 = s27;

const v44 = ((((65728 + (v39 << 4)) | 0) + (Math.imul(v3, v18) << 4)) | 0);
const v45 = ((((65728 + (v39 << 4)) | 0) + (Math.imul(v3, v18) << 4)) | 0);
const v46 = memory_i32[(((v44) >>> 0) + 0) >>> 2];
const v47 = (v46 ^ v40);
const v48 = ((((64 + ((255 & ((255 & v47) >>> 0)) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v49 = memory_i32[(((v44) >>> 0) + 4) >>> 2];
const v50 = (v49 ^ v41);
const v51 = ((((64 + ((((255 & ((255 & ((v50 << 24) | (v47 >>> 8))) >>> 0)) + 256) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v52 = ((((64 + ((((255 & ((255 & ((v50 << 16) | (v47 >>> 16))) >>> 0)) + 512) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v53 = ((((64 + ((((255 & ((255 & ((v50 << 8) | (v47 >>> 24))) >>> 0)) + 768) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v54 = ((((64 + ((((255 & ((255 & v50) >>> 0)) + 1024) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v55 = ((((64 + ((((255 & ((255 & (v50 >>> 8)) >>> 0)) + 1280) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v56 = ((((64 + ((((255 & ((255 & (v50 >>> 16)) >>> 0)) + 1536) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v57 = ((((64 + ((((255 & ((255 & (v50 >>> 24)) >>> 0)) + 1792) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v58 = memory_i32[(((v44) >>> 0) + 8) >>> 2];
const v59 = (v58 ^ v42);
const v60 = ((((64 + ((((255 & ((255 & v59) >>> 0)) + 2048) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v61 = memory_i32[(((v44) >>> 0) + 12) >>> 2];
const v62 = (v61 ^ v43);
const v63 = ((((64 + ((((255 & ((255 & ((v62 << 24) | (v59 >>> 8))) >>> 0)) + 2304) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v64 = ((((64 + ((((255 & ((255 & ((v62 << 16) | (v59 >>> 16))) >>> 0)) + 2560) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v65 = ((((64 + ((((255 & ((255 & ((v62 << 8) | (v59 >>> 24))) >>> 0)) + 2816) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v66 = ((((64 + ((((255 & ((255 & v62) >>> 0)) + 3072) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v67 = ((((64 + ((((255 & ((255 & (v62 >>> 8)) >>> 0)) + 3328) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v68 = ((((64 + ((((255 & ((255 & (v62 >>> 16)) >>> 0)) + 3584) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v69 = ((((64 + ((((255 & ((255 & (v62 >>> 24)) >>> 0)) + 3840) | 0) << 4)) | 0) + Math.imul(65728, v18)) | 0);
const v70 = memory_i32[(((v48) >>> 0) + 0) >>> 2];
const v71 = memory_i32[(((v48) >>> 0) + 4) >>> 2];
const v72 = memory_i32[(((v48) >>> 0) + 8) >>> 2];
const v73 = memory_i32[(((v48) >>> 0) + 12) >>> 2];
const v74 = memory_i32[(((v51) >>> 0) + 0) >>> 2];
const v75 = memory_i32[(((v51) >>> 0) + 4) >>> 2];
const v76 = memory_i32[(((v51) >>> 0) + 8) >>> 2];
const v77 = memory_i32[(((v51) >>> 0) + 12) >>> 2];
const v78 = memory_i32[(((v52) >>> 0) + 0) >>> 2];
const v79 = memory_i32[(((v52) >>> 0) + 4) >>> 2];
const v80 = memory_i32[(((v52) >>> 0) + 8) >>> 2];
const v81 = memory_i32[(((v52) >>> 0) + 12) >>> 2];
const v82 = memory_i32[(((v53) >>> 0) + 0) >>> 2];
const v83 = memory_i32[(((v53) >>> 0) + 4) >>> 2];
const v84 = memory_i32[(((v53) >>> 0) + 8) >>> 2];
const v85 = memory_i32[(((v53) >>> 0) + 12) >>> 2];
const v86 = memory_i32[(((v54) >>> 0) + 0) >>> 2];
const v87 = memory_i32[(((v54) >>> 0) + 4) >>> 2];
const v88 = memory_i32[(((v54) >>> 0) + 8) >>> 2];
const v89 = memory_i32[(((v54) >>> 0) + 12) >>> 2];
const v90 = memory_i32[(((v55) >>> 0) + 0) >>> 2];
const v91 = memory_i32[(((v55) >>> 0) + 4) >>> 2];
const v92 = memory_i32[(((v55) >>> 0) + 8) >>> 2];
const v93 = memory_i32[(((v55) >>> 0) + 12) >>> 2];
const v94 = memory_i32[(((v56) >>> 0) + 0) >>> 2];
const v95 = memory_i32[(((v56) >>> 0) + 4) >>> 2];
const v96 = memory_i32[(((v56) >>> 0) + 8) >>> 2];
const v97 = memory_i32[(((v56) >>> 0) + 12) >>> 2];
const v98 = memory_i32[(((v57) >>> 0) + 0) >>> 2];
const v99 = memory_i32[(((v57) >>> 0) + 4) >>> 2];
const v100 = memory_i32[(((v57) >>> 0) + 8) >>> 2];
const v101 = memory_i32[(((v57) >>> 0) + 12) >>> 2];
const v102 = memory_i32[(((v60) >>> 0) + 0) >>> 2];
const v103 = memory_i32[(((v60) >>> 0) + 4) >>> 2];
const v104 = memory_i32[(((v60) >>> 0) + 8) >>> 2];
const v105 = memory_i32[(((v60) >>> 0) + 12) >>> 2];
const v106 = memory_i32[(((v63) >>> 0) + 0) >>> 2];
const v107 = memory_i32[(((v63) >>> 0) + 4) >>> 2];
const v108 = memory_i32[(((v63) >>> 0) + 8) >>> 2];
const v109 = memory_i32[(((v63) >>> 0) + 12) >>> 2];
const v110 = memory_i32[(((v64) >>> 0) + 0) >>> 2];
const v111 = memory_i32[(((v64) >>> 0) + 4) >>> 2];
const v112 = memory_i32[(((v64) >>> 0) + 8) >>> 2];
const v113 = memory_i32[(((v64) >>> 0) + 12) >>> 2];
const v114 = memory_i32[(((v65) >>> 0) + 0) >>> 2];
const v115 = memory_i32[(((v65) >>> 0) + 4) >>> 2];
const v116 = memory_i32[(((v65) >>> 0) + 8) >>> 2];
const v117 = memory_i32[(((v65) >>> 0) + 12) >>> 2];
const v118 = memory_i32[(((v66) >>> 0) + 0) >>> 2];
const v119 = memory_i32[(((v66) >>> 0) + 4) >>> 2];
const v120 = memory_i32[(((v66) >>> 0) + 8) >>> 2];
const v121 = memory_i32[(((v66) >>> 0) + 12) >>> 2];
const v122 = memory_i32[(((v67) >>> 0) + 0) >>> 2];
const v123 = memory_i32[(((v67) >>> 0) + 4) >>> 2];
const v124 = memory_i32[(((v67) >>> 0) + 8) >>> 2];
const v125 = memory_i32[(((v67) >>> 0) + 12) >>> 2];
const v126 = memory_i32[(((v68) >>> 0) + 0) >>> 2];
const v127 = memory_i32[(((v68) >>> 0) + 4) >>> 2];
const v128 = memory_i32[(((v68) >>> 0) + 8) >>> 2];
const v129 = memory_i32[(((v68) >>> 0) + 12) >>> 2];
const v130 = memory_i32[(((v69) >>> 0) + 0) >>> 2];
const v131 = memory_i32[(((v69) >>> 0) + 4) >>> 2];
const v132 = memory_i32[(((v69) >>> 0) + 8) >>> 2];
const v133 = memory_i32[(((v69) >>> 0) + 12) >>> 2];
const v134 = (v130 ^ (v126 ^ (v122 ^ (v118 ^ (v114 ^ (v110 ^ (v106 ^ (v102 ^ (v98 ^ (v94 ^ (v90 ^ (v86 ^ (v82 ^ (v78 ^ (v74 ^ v70)))))))))))))));
const v135 = (v131 ^ (v127 ^ (v123 ^ (v119 ^ (v115 ^ (v111 ^ (v107 ^ (v103 ^ (v99 ^ (v95 ^ (v91 ^ (v87 ^ (v83 ^ (v79 ^ (v75 ^ v71)))))))))))))));
const v136 = (v132 ^ (v128 ^ (v124 ^ (v120 ^ (v116 ^ (v112 ^ (v108 ^ (v104 ^ (v100 ^ (v96 ^ (v92 ^ (v88 ^ (v84 ^ (v80 ^ (v76 ^ v72)))))))))))))));
const v137 = (v133 ^ (v129 ^ (v125 ^ (v121 ^ (v117 ^ (v113 ^ (v109 ^ (v105 ^ (v101 ^ (v97 ^ (v93 ^ (v89 ^ (v85 ^ (v81 ^ (v77 ^ v73)))))))))))))));
memory_i32[(((v45) >>> 0) + 0) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 4) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 8) >>> 2] = 0;
memory_i32[(((v45) >>> 0) + 12) >>> 2] = 0;
s23 = v39;
s24 = v134;
s25 = v135;
s26 = v136;
s27 = v137;}
const v39 = s23;
const v40 = s24;
const v41 = s25;
const v42 = s26;
const v43 = s27;

const v138 = ((1 + v39) | 0);
if (((((v138) >>> 0) < ((v13) >>> 0)) | 0)) {
s18 = v138;
s19 = v40;
s20 = v41;
s21 = v42;
s22 = v43;continue L10;
}
s18 = v138;
s19 = v40;
s20 = v41;
s21 = v42;
s22 = v43;break L10;}
const v34 = s18;
const v35 = s19;
const v36 = s20;
const v37 = s21;
const v38 = s22;

s13 = v34;
s14 = v35;
s15 = v36;
s16 = v37;
s17 = v38;}
const v29 = s13;
const v30 = s14;
const v31 = s15;
const v32 = s16;
const v33 = s17;

s8 = v29;
s9 = v30;
s10 = v31;
s11 = v32;
s12 = v33;}
const v25 = s9;
const v26 = s10;
const v27 = s11;
const v28 = s12;

const v139 = ((32 + Math.imul(65728, v18)) | 0);
memory_i32[(((v139) >>> 0) + 0) >>> 2] = v25;
memory_i32[(((v139) >>> 0) + 4) >>> 2] = v26;
memory_i32[(((v139) >>> 0) + 8) >>> 2] = v27;
memory_i32[(((v139) >>> 0) + 12) >>> 2] = v28;
s7 = v17;}
const v17 = s7;

const v140 = ((1 + v17) | 0);
if (((((v140) >>> 0) < ((1) >>> 0)) | 0)) {
s6 = v140;continue L6;
}
s6 = v140;break L6;}
const v16 = s6;

s5 = v16;}
const v15 = s5;

s4 = v15;}

s3 = v11;}
const v11 = s3;

const v141 = ((1 + v11) | 0);
if (((((v141) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v141;continue L2;
}
s2 = v141;break L2;}
const v10 = s2;

s1 = v10;}
const v9 = s1;

s0 = v9;}

return ;
}



function processOutBlocks(v0, v1, v2, v3, v4, v5) {
    
    let s0 = 0;
L0:  {const v6 = s0;

if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v6;break L0;
}
let s1 = v6;
L1:  {const v7 = s1;

let s2 = v7;
L2: for (;;) {const v8 = s2;

let s3 = v8;
L3:  {const v9 = s3;

const v10 = ((v9 + v0) | 0);
let s4 = 0;
L4:  {const v11 = s4;

if (((((((((v11) >>> 0) < ((1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s4 = v11;break L4;
}
let s5 = v11;
L5:  {const v12 = s5;

let s6 = v12;
L6: for (;;) {const v13 = s6;

let s7 = v13;
L7:  {const v14 = s7;

const v15 = ((v14 + v10) | 0);
const v16 = ((32 + Math.imul(65728, v15)) | 0);
const v17 = memory_i32[(((v16) >>> 0) + 0) >>> 2];
const v18 = memory_i32[(((v16) >>> 0) + 4) >>> 2];
const v19 = memory_i32[(((v16) >>> 0) + 8) >>> 2];
const v20 = memory_i32[(((v16) >>> 0) + 12) >>> 2];
let s8 = 0;
L8:  {const v21 = s8;

if (((((((((v21) >>> 0) < ((v2) >>> 0)) | 0)) | 0) === 0) | 0)) {
s8 = v21;break L8;
}
let s9 = v21;
L9:  {const v22 = s9;

let s10 = v22;
L10: for (;;) {const v23 = s10;

let s11 = v23;
L11:  {const v24 = s11;

const v25 = ((((65728 + (v24 << 4)) | 0) + (Math.imul(v3, v15) << 4)) | 0);
memory_i32[(((v25) >>> 0) + 0) >>> 2] = v17;
memory_i32[(((v25) >>> 0) + 4) >>> 2] = v18;
memory_i32[(((v25) >>> 0) + 8) >>> 2] = v19;
memory_i32[(((v25) >>> 0) + 12) >>> 2] = v20;
s11 = v24;}
const v24 = s11;

const v26 = ((1 + v24) | 0);
if (((((v26) >>> 0) < ((v2) >>> 0)) | 0)) {
s10 = v26;continue L10;
}
s10 = v26;break L10;}
const v23 = s10;

s9 = v23;}
const v22 = s9;

s8 = v22;}

s7 = v14;}
const v14 = s7;

const v27 = ((1 + v14) | 0);
if (((((v27) >>> 0) < ((1) >>> 0)) | 0)) {
s6 = v27;continue L6;
}
s6 = v27;break L6;}
const v13 = s6;

s5 = v13;}
const v12 = s5;

s4 = v12;}

s3 = v9;}
const v9 = s3;

const v28 = ((1 + v9) | 0);
if (((((v28) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v28;continue L2;
}
s2 = v28;break L2;}
const v8 = s2;

s1 = v8;}
const v7 = s1;

s0 = v7;}

return ;
}



function reset(v0, v1, v2, v3, v4) {
    
    const v5 = ((((((v3)>>>0)/(((4)>>>0))))>>>0));
memory.fill(0, ((Math.imul(65728, v0)) >>> 0), ((Math.imul(65728, v0)) >>> 0) + ((Math.imul(v1, 65728)) >>> 0))
let s0 = 0;
L0:  {const v6 = s0;

if (((((((((v6) >>> 0) < ((v1) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v6;break L0;
}
let s1 = v6;
L1:  {const v7 = s1;

let s2 = v7;
L2: for (;;) {const v8 = s2;

let s3 = v8;
L3:  {const v9 = s3;

memory.fill(0, ((((65728 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0), ((((65728 + (Math.imul(Math.imul(v5, v4), ((v9 + v0) | 0)) << 2)) | 0)) >>> 0) + ((v2) >>> 0))
s3 = v9;}
const v9 = s3;

const v10 = ((1 + v9) | 0);
if (((((v10) >>> 0) < ((v1) >>> 0)) | 0)) {
s2 = v10;continue L2;
}
s2 = v10;break L2;}
const v8 = s2;

s1 = v8;}
const v7 = s1;

s0 = v7;}

return ;
}
const instance = { exports: {macInit: macInit, padding: padding, processBlocks: processBlocks, processOutBlocks: processOutBlocks, reset: reset, memory: { buffer: __buf }}};

;
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 2687168);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 65728)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 65728)))
, "state.state_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*65728, 16)))
, "state.ghash_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 48)))
, "state.ghash.y_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 16 + i*65728, 16)))
, "state.ghash.y64_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*65728, 16)))
, "state.ghash.h_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 48 + i*65728, 16)))
, "state.table64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 64 + i*65728, 65536)))
, "state.tmp64v_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 65600 + i*65728, 128)))
, buffer: new Uint8Array(memoryExport.buffer, 65728, 2621440)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 65728 + i*2621440, 2621440)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments  });}
let _cache;
export default function ghash(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}