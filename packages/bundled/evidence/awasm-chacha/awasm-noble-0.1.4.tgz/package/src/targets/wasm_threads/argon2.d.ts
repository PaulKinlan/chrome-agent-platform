// WARNING: This file is auto-generated. Any changes will be lost.
export default function argon(_imports?: any, pool?: any): {
  readonly memory: Uint8Array;
  readonly segments: {
    readonly refBlocks: Uint8Array;
    readonly refBlocks_chunks: ReadonlyArray<Uint8Array>;
    readonly inputBlocks: Uint8Array;
    readonly inputBlocks_chunks: ReadonlyArray<Uint8Array>;
    readonly indices: Uint8Array;
    readonly indices_chunks: ReadonlyArray<Uint8Array>;
    readonly refIndices: Uint8Array;
    readonly refIndices_chunks: ReadonlyArray<Uint8Array>;
    readonly _worker: Uint8Array;
    readonly _worker_chunks: ReadonlyArray<Uint8Array>;
    readonly '_worker.online': Uint8Array;
    readonly '_worker.online_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.next': Uint8Array;
    readonly '_worker.next_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.total': Uint8Array;
    readonly '_worker.total_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.perBatch': Uint8Array;
    readonly '_worker.perBatch_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.workers': Uint8Array;
    readonly '_worker.workers_chunks': ReadonlyArray<Uint8Array>;
    readonly '_worker.stack': Uint8Array;
    readonly '_worker.stack_chunks': ReadonlyArray<Uint8Array>;
  };
  _compress_thread_int(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  _worker_notify(v0: number, v1: number): number;
  _worker_online(): number;
  compress(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number): void;
  getAddresses(v0: number, v1: number, v2: number, v3: number, v4: number, v5: number, v6: number, v7: number, v8: number, v9: number): void;
  initWorker(v0: number, v1: number, v2: number): void;
  stopWorker(v0: number): void;
};