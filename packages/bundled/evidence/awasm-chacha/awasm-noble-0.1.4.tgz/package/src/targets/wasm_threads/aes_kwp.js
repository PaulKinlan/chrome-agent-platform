// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 81, maximum: 81, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABUwxgAn9/AX9gAAF/YAF/AGADf39/AX9gBH9/f38Ef39/f2AEf39/fwBgAABgA39/fwBgA39/fwN/f39gAn9/An9/YAV/f39/fwV/f39/f2ABfwF/AlkEA2VudgdfbWVtb3J5AgNRUQNlbnYUX3dvcmtlcl9ub3RpZnlCcmlkZ2UAAANlbnYUX3dvcmtlcl9vbmxpbmVCcmlkZ2UAAQNlbnYLaW5pdFdvcmtlcnMAAgMPDgABAwQEBQIFAgYHAgIAB9ABDwZtZW1vcnkCAA5fd29ya2VyX25vdGlmeQADDl93b3JrZXJfb25saW5lAAQKYWRkUGFkZGluZwAFC2Flc0Jsb2NrRGVjAAYLYWVzQmxvY2tFbmMABw1kZWNyeXB0QmxvY2tzAAgLZGVjcnlwdEluaXQACQ1lbmNyeXB0QmxvY2tzAAoLZW5jcnlwdEluaXQACwppbml0VGFibGVzAAwKaW5pdFdvcmtlcgANBXJlc2V0AA4Kc3RvcFdvcmtlcgAPDXZlcmlmeVBhZGRpbmcAEArEQQ7iAQEQf0EAIAFBAAIIIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCCCEHIQYhBSAFIAYgBwMIIQohCSEIIAggCSAKAgghDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAz8ACaiAA/hcCACALQYAGbEGAz8ACakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACCSEBIQAgACABIABBH0lFDQAaGiAAIAECCSEDIQIgAiADAwkhBSEEIAQgBQIJIQchBiAGQQFqIghBgAZsQYDNwAJq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQs8AEEAQaaz5bJ6NgKwSEEAIABB/wFxQRh0IABBgP4DcUEIdHIgAEGAgPwHcUEIdiAAQRh2cnI2ArRIQQALrQkBQ39BACgCgAQhBEEAKAIgIQVBACgCJCEGQQAoAighB0EAKAIsIQggBEEBayEJQQAgACAFcyABIAZzIAIgB3MgAyAIcwIKIQ4hDSEMIQshCiAKIAsgDCANIA4DCiETIRIhESEQIQ8gD0EBaiEUIA9BAWpBAnQiFUECdEEgaigCACEWIBBB/wFxQQJ0QZAoaigCACEXIBNBCHZB/wFxQQJ0QZAwaigCACEYIBJBEHZB/wFxQQJ0QZA4aigCACEZIBFBGHZB/wFxQQJ0QZDAAGooAgAhGiAWIBcgGHMgGSAac3NzIRsgFUEBakECdEEgaigCACEcIBFB/wFxQQJ0QZAoaigCACEdIBBBCHZB/wFxQQJ0QZAwaigCACEeIBNBEHZB/wFxQQJ0QZA4aigCACEfIBJBGHZB/wFxQQJ0QZDAAGooAgAhICAcIB0gHnMgHyAgc3NzISEgFUECakECdEEgaigCACEiIBJB/wFxQQJ0QZAoaigCACEjIBFBCHZB/wFxQQJ0QZAwaigCACEkIBBBEHZB/wFxQQJ0QZA4aigCACElIBNBGHZB/wFxQQJ0QZDAAGooAgAhJiAiICMgJHMgJSAmc3NzIScgFUEDakECdEEgaigCACEoIBNB/wFxQQJ0QZAoaigCACEpIBJBCHZB/wFxQQJ0QZAwaigCACEqIBFBEHZB/wFxQQJ0QZA4aigCACErIBBBGHZB/wFxQQJ0QZDAAGooAgAhLCAoICkgKnMgKyAsc3NzIS0gFCAbICEgJyAtIBQgCUkNABoaGhoaIBQgGyAhICcgLQshEyESIREhECEPIA8gECARIBIgEwshDiENIQwhCyEKIARBAnQiLkECdEEgaigCACEvIA5BCHZB/wFxQZAmai0AACEwIA1BEHZB/wFxQZAmai0AACExIAxBGHZB/wFxQZAmai0AACEyIAtB/wFxQZAmai0AACEzIC5BAWpBAnRBIGooAgAhNCALQQh2Qf8BcUGQJmotAAAhNSAOQRB2Qf8BcUGQJmotAAAhNiANQRh2Qf8BcUGQJmotAAAhNyAMQf8BcUGQJmotAAAhOCAuQQJqQQJ0QSBqKAIAITkgDEEIdkH/AXFBkCZqLQAAITogC0EQdkH/AXFBkCZqLQAAITsgDkEYdkH/AXFBkCZqLQAAITwgDUH/AXFBkCZqLQAAIT0gLkEDakECdEEgaigCACE+IA1BCHZB/wFxQZAmai0AACE/IAxBEHZB/wFxQZAmai0AACFAIAtBGHZB/wFxQZAmai0AACFBIA5B/wFxQZAmai0AACFCQQAgLyAzQf8BcSAwQf8BcUEIdHIgMUH/AXFBEHQgMkH/AXFBGHRycnM2ApACQQAgNCA4Qf8BcSA1Qf8BcUEIdHIgNkH/AXFBEHQgN0H/AXFBGHRycnM2ApQCQQAgOSA9Qf8BcSA6Qf8BcUEIdHIgO0H/AXFBEHQgPEH/AXFBGHRycnM2ApgCQQAgPiBCQf8BcSA/Qf8BcUEIdHIgQEH/AXFBEHQgQUH/AXFBGHRycnM2ApwCQQAoApACIUNBACgClAIhREEAKAKYAiFFQQAoApwCIUYgQyBEIEUgRgupCQFDf0EAKAKABCEEQQAoAiAhBUEAKAIkIQZBACgCKCEHQQAoAiwhCCAEQQFrIQlBACAAIAVzIAEgBnMgAiAHcyADIAhzAgohDiENIQwhCyEKIAogCyAMIA0gDgMKIRMhEiERIRAhDyAPQQFqIRQgD0EBakECdCIVQQJ0QSBqKAIAIRYgEEH/AXFBAnRBkAZqKAIAIRcgEUEIdkH/AXFBAnRBkA5qKAIAIRggEkEQdkH/AXFBAnRBkBZqKAIAIRkgE0EYdkH/AXFBAnRBkB5qKAIAIRogFiAXIBhzIBkgGnNzcyEbIBVBAWpBAnRBIGooAgAhHCARQf8BcUECdEGQBmooAgAhHSASQQh2Qf8BcUECdEGQDmooAgAhHiATQRB2Qf8BcUECdEGQFmooAgAhHyAQQRh2Qf8BcUECdEGQHmooAgAhICAcIB0gHnMgHyAgc3NzISEgFUECakECdEEgaigCACEiIBJB/wFxQQJ0QZAGaigCACEjIBNBCHZB/wFxQQJ0QZAOaigCACEkIBBBEHZB/wFxQQJ0QZAWaigCACElIBFBGHZB/wFxQQJ0QZAeaigCACEmICIgIyAkcyAlICZzc3MhJyAVQQNqQQJ0QSBqKAIAISggE0H/AXFBAnRBkAZqKAIAISkgEEEIdkH/AXFBAnRBkA5qKAIAISogEUEQdkH/AXFBAnRBkBZqKAIAISsgEkEYdkH/AXFBAnRBkB5qKAIAISwgKCApICpzICsgLHNzcyEtIBQgGyAhICcgLSAUIAlJDQAaGhoaGiAUIBsgISAnIC0LIRMhEiERIRAhDyAPIBAgESASIBMLIQ4hDSEMIQshCiAEQQJ0Ii5BAnRBIGooAgAhLyAMQQh2Qf8BcUGQBGotAAAhMCANQRB2Qf8BcUGQBGotAAAhMSAOQRh2Qf8BcUGQBGotAAAhMiALQf8BcUGQBGotAAAhMyAuQQFqQQJ0QSBqKAIAITQgDUEIdkH/AXFBkARqLQAAITUgDkEQdkH/AXFBkARqLQAAITYgC0EYdkH/AXFBkARqLQAAITcgDEH/AXFBkARqLQAAITggLkECakECdEEgaigCACE5IA5BCHZB/wFxQZAEai0AACE6IAtBEHZB/wFxQZAEai0AACE7IAxBGHZB/wFxQZAEai0AACE8IA1B/wFxQZAEai0AACE9IC5BA2pBAnRBIGooAgAhPiALQQh2Qf8BcUGQBGotAAAhPyAMQRB2Qf8BcUGQBGotAAAhQCANQRh2Qf8BcUGQBGotAAAhQSAOQf8BcUGQBGotAAAhQkEAIC8gM0H/AXEgMEH/AXFBCHRyIDFB/wFxQRB0IDJB/wFxQRh0cnJzNgKQAkEAIDQgOEH/AXEgNUH/AXFBCHRyIDZB/wFxQRB0IDdB/wFxQRh0cnJzNgKUAkEAIDkgPUH/AXEgOkH/AXFBCHRyIDtB/wFxQRB0IDxB/wFxQRh0cnJzNgKYAkEAID4gQkH/AXEgP0H/AXFBCHRyIEBB/wFxQRB0IEFB/wFxQRh0cnJzNgKcAkEAKAKQAiFDQQAoApQCIURBACgCmAIhRUEAKAKcAiFGIEMgRCBFIEYL1QIBHH8gA0F/RiIEIABBAkZxIQZBAUEGIABBAWsiBWwgBSAEGyAGGyEHIABBAWshCEEAKAKwSCEJQQAoArRIIQpBACAJIAogBUEGbCADIAQbQQACCiEPIQ4hDSEMIQsgCyAMIA0gDiAPAwohFCETIRIhESEQIBBBAWohFSAIIBRrQQN0QbDIAGoiFigCACEXIBZBBGooAgAhGCARIBIgEiATQf8BcUEYdCATQYD+A3FBCHRyIBNBgID8B3FBCHYgE0EYdnJycyAGGyAXIBgQBiEZIRohGyEcIBYgGjYCACAWQQRqIBk2AgAgEyATQQFrIAYbIR1BACAUQQFqIh4gHiAIRhshHyAVIBwgGyAdIB8gFSAHSQ0AGhoaGhogFSAcIBsgHSAfCyEUIRMhEiERIRAgECARIBIgEyAUCyEPIQ4hDSEMIQtBACAMNgKwSEEAIA02ArRIC5oOAU1/EAxBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgshBSAFIAUgA0lFDQAaIAUCCyEGIAYDCyEHIAcCCyEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACCyERIBEgESAQSUUNABogEQILIRIgEgMLIRMgEwILIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBkARqLQAAIRkgGEEQdkH/AXFBkARqLQAAIRogGEEYdkH/AXFBkARqLQAAIRsgGEH/AXFBkARqLQAAIRwgFSADbkEBa0GQyABqLQAAIR0gFkEIdkH/AXFBkARqLQAAIR4gFkEQdkH/AXFBkARqLQAAIR8gFkEYdkH/AXFBkARqLQAAISAgFkH/AXFBkARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgshJCAkICQgD0lFDQAaICQCCyElICUDCyEmICYCCyEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJEEAAgshKiAqICogD0lFDQAaICoCCyErICsDCyEsICwCCyEtIC1BAnRBIGooAgAhLiAtQQJ0QZACaiAuNgIAIC0LIS0gLUEBaiEvIC8gLyAPSQ0AGiAvCyEsICwLISsgKwshKkEAKAKABCEwIDBBAWohMUEAAgshMiAyIDIgMUlFDQAaIDICCyEzIDMDCyE0IDQCCyE1IDFBAWsgNWtBAnQiNkECdEGQAmooAgAhNyA1QQJ0IjhBAnRBIGogNzYCACA2QQFqQQJ0QZACaigCACE5IDhBAWpBAnRBIGogOTYCACA2QQJqQQJ0QZACaigCACE6IDhBAmpBAnRBIGogOjYCACA2QQNqQQJ0QZACaigCACE7IDhBA2pBAnRBIGogOzYCACA1CyE1IDVBAWohPCA8IDwgMUkNABogPAshNCA0CyEzIDMLITIgD0EIayE9QQACCyE+ID4gPiA9SUUNABogPgILIT8gPwMLIUAgQAILIUEgQUEEaiJCQQJ0QSBqKAIAIUMgQ0EIdkH/AXFBkARqLQAAIUQgQ0EQdkH/AXFBkARqLQAAIUUgQ0EYdkH/AXFBkARqLQAAIUYgQ0H/AXFBkARqLQAAIUcgR0H/AXEgREH/AXFBCHRyIEVB/wFxQRB0IEZB/wFxQRh0cnIiSEEAdkH/AXFBAnRBkChqKAIAIUkgSEEIdkH/AXFBAnRBkDBqKAIAIUogSEEQdkH/AXFBAnRBkDhqKAIAIUsgSEEYdkH/AXFBAnRBkMAAaigCACFMIEJBAnRBIGogSSBKcyBLIExzczYCACBBCyFBIEFBAWohTSBNIE0gPUkNABogTQshQCBACyE/ID8LIT4L1gIBHX8gA0F/RiIEIABBAkZxIQZBAUEGIABBAWsiBWwgBSAEGyAGGyEHIABBAWshCEEAKAKwSCEJQQAoArRIIQpBACAJIApBASADIAQbQQACCiEPIQ4hDSEMIQsgCyAMIA0gDiAPAwohFCETIRIhESEQIBBBAWohFSAUQQFqQQN0QbDIAGoiFigCACEXIBZBBGooAgAhGCARIBIgFyAYEAchGSEaIRshHCAWIBo2AgAgFkEEaiAZNgIAIBMgE0EBaiAGGyEdIBtBACATQf8BcUEYdCATQYD+A3FBCHRyIBNBgID8B3FBCHYgE0EYdnJyIAYbcyEeQQAgFEEBaiIfIB8gCEYbISAgFSAcIB4gHSAgIBUgB0kNABoaGhoaIBUgHCAeIB0gIAshFCETIRIhESEQIBAgESASIBMgFAshDyEOIQ0hDCELQQAgDDYCsEhBACANNgK0SAudCQEpfxAMQQRBBkEIIABBGEYiAhsgAEEQRiIBGyEDQQBBCkEMQQ4gAhsgARsiBDYCgARBAEEANgIgQQBBADYCJEEAQQA2AihBAEEANgIsQQBBADYCMEEAQQA2AjRBAEEANgI4QQBBADYCPEEAQQA2AkBBAEEANgJEQQBBADYCSEEAQQA2AkxBAEEANgJQQQBBADYCVEEAQQA2AlhBAEEANgJcQQBBADYCYEEAQQA2AmRBAEEANgJoQQBBADYCbEEAQQA2AnBBAEEANgJ0QQBBADYCeEEAQQA2AnxBAEEANgKAAUEAQQA2AoQBQQBBADYCiAFBAEEANgKMAUEAQQA2ApABQQBBADYClAFBAEEANgKYAUEAQQA2ApwBQQBBADYCoAFBAEEANgKkAUEAQQA2AqgBQQBBADYCrAFBAEEANgKwAUEAQQA2ArQBQQBBADYCuAFBAEEANgK8AUEAQQA2AsABQQBBADYCxAFBAEEANgLIAUEAQQA2AswBQQBBADYC0AFBAEEANgLUAUEAQQA2AtgBQQBBADYC3AFBAEEANgLgAUEAQQA2AuQBQQBBADYC6AFBAEEANgLsAUEAQQA2AvABQQBBADYC9AFBAEEANgL4AUEAQQA2AvwBQQBBADYCgAJBAEEANgKEAkEAQQA2AogCQQBBADYCjAJBAAILIQUgBSAFIANJRQ0AGiAFAgshBiAGAwshByAHAgshCCAIQQJ0IglBAWotAAAhCiAJQQJqLQAAIQsgCUEDai0AACEMIAktAAAhDSAIQQJ0QZACaiANQf8BcSAKQf8BcUEIdCALQf8BcUEQdCAMQf8BcUEYdHJycjYCACAICyEIIAhBAWohDiAOIA4gA0kNABogDgshByAHCyEGIAYLIQUgBEEBakECdCEPIA8gA2shEEEAAgshESARIBEgEElFDQAaIBECCyESIBIDCyETIBMCCyEUIBQgA2oiFUEBa0ECdEGQAmooAgAhFiAWQRh0IBZBCHZyIhhBCHZB/wFxQZAEai0AACEZIBhBEHZB/wFxQZAEai0AACEaIBhBGHZB/wFxQZAEai0AACEbIBhB/wFxQZAEai0AACEcIBUgA25BAWtBkMgAai0AACEdIBZBCHZB/wFxQZAEai0AACEeIBZBEHZB/wFxQZAEai0AACEfIBZBGHZB/wFxQZAEai0AACEgIBZB/wFxQZAEai0AACEhIBUgA2tBAnRBkAJqKAIAISIgFUECdEGQAmogIUH/AXEgHkH/AXFBCHRyIB9B/wFxQRB0ICBB/wFxQRh0cnIgHEH/AXEgGUH/AXFBCHRyIBpB/wFxQRB0IBtB/wFxQRh0cnIgHUH/AXFzIBYgFSADcCIXQQBGGyADQQhGIBdBBEZxGyAiczYCACAUCyEUIBRBAWohIyAjICMgEEkNABogIwshEyATCyESIBILIRFBAAILISQgJCAkIA9JRQ0AGiAkAgshJSAlAwshJiAmAgshJyAnQQJ0QZACaigCACEoICdBAnRBIGogKDYCACAnCyEnICdBAWohKSApICkgD0kNABogKQshJiAmCyElICULISQLigoBPX9BACgCoEghAAIGIABBAEZFDQBBAEEBAgkhAiEBIAEgAgMJIQQhAyADQQFqIQUgBCAEQQF0IARBB3ZBAXFBG2xzQf8BcXMhBiADQZAGaiAEQf8BcToAACAFIAYgBUGAAkkNABoaIAUgBgshBCEDIAMgBAshAiEBQQBB4wBB/wFxOgCQBEEAAgshByAHIAdB/wFJRQ0AGiAHAgshCCAIAwshCSAJAgshCkH/ASAKa0GQBmotAAAhCyAKQZAGai0AACEOIA5B/wFxQZAEaiALQf8BcSIMIAxBCHRyIg0gDUEEdnMgDUEFdnMgDUEGdnMgDUEHdnNB4wBzQf8BcUH/AXE6AAAgCgshCiAKQQFqIQ8gDyAPQf8BSQ0AGiAPCyEJIAkLIQggCAshB0EAAgshECAQIBBBgAJJRQ0AGiAQAgshESARAwshEiASAgshEyATQZAmakEAQf8BcToAACATCyETIBNBAWohFCAUIBRBgAJJDQAaIBQLIRIgEgshESARCyEQQQACCyEVIBUgFUGAAklFDQAaIBUCCyEWIBYDCyEXIBcCCyEYIBhBkARqLQAAIRkgGUH/AXFBkCZqIBhB/wFxOgAAIBgLIRggGEEBaiEaIBogGkGAAkkNABogGgshFyAXCyEWIBYLIRVBAEEBAgkhHCEbIBsgHAMJIR4hHSAdQQFqIR8gHkEBdCAeQQd2QQFxQRtsc0H/AXEhICAdQZDIAGogHkH/AXE6AAAgHyAgIB9BEEkNABoaIB8gIAshHiEdIB0gHgshHCEbQQACCyEhICEgIUGAAklFDQAaICECCyEiICIDCyEjICMCCyEkICRBkARqLQAAISUgJEGQJmotAAAhJyAkQQJ0QZAGaiAlQf8BcSImICZBAXQgJkEHdkEBcUEbbHNB/wFxc0EYdCAmQRB0ICZBCHQgJkEBdCAmQQd2QQFxQRtsc0H/AXFycnI2AgAgJEECdEGQKGogJ0H/AXEiKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIrcyArQQF0ICtBB3ZBAXFBG2xzQf8BcSIsQQF0ICxBB3ZBAXFBG2xzQf8BcXNBGHQgKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSItQQF0IC1BB3ZBAXFBG2xzQf8BcSIucyAuQQF0IC5BB3ZBAXFBG2xzQf8BcXNBEHQgKCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIpQQF0IClBB3ZBAXFBG2xzQf8BcSIqQQF0ICpBB3ZBAXFBG2xzQf8BcXNBCHQgKEEBdCAoQQd2QQFxQRtsc0H/AXEiLyAvQQF0IC9BB3ZBAXFBG2xzQf8BcSIwcyAwQQF0IDBBB3ZBAXFBG2xzQf8BcXNycnI2AgAgJAshJCAkQQFqITEgMSAxQYACSQ0AGiAxCyEjICMLISIgIgshIUEAAgshMiAyIDJBgAJJRQ0AGiAyAgshMyAzAwshNCA0AgshNSA1QQJ0QZAGaigCACE2IDVBAnRBkA5qIDZBCHciNzYCACA1QQJ0QZAWaiA3QQh3Ijg2AgAgNUECdEGQHmogOEEIdzYCACA1QQJ0QZAoaigCACE5IDVBAnRBkDBqIDlBCHciOjYCACA1QQJ0QZA4aiA6QQh3Ijs2AgAgNUECdEGQwABqIDtBCHc2AgAgNQshNSA1QQFqITwgPCA8QYACSQ0AGiA8CyE0IDQLITMgMwshMkEAQQE2AqBICwt8AQR/IABBgAZsQYDOwAJqIQMgAEGABmxBgM/AAmohBCAAQYAGbEGAzcACakEB/hcCAAIGAgYgAUUNAAwBCwIGAwYgBEEA/kECACEFAgYgBUUgAkEBR3FFDQAgBEEAQn/+AQIAIQYMAQsgA0EB/hcCACACDQFBAQ0ACwsLCxcAQQBBAEGEBPwLAEGwyABBACAA/AsACxQAIABBgAZsQYDNwAJqQQD+FwIAC4oDARZ/QQAoArBIIQJBACgCtEghA0EIIANB/wFxQRh0IANBgP4DcUEIdHIgA0GAgPwHcUEIdiADQRh2cnIiBGpBAEEAQQAgAEEIayIFIARrIgYgAkGms+WyekcgBCAFS3IgBkEHS3IiBxsiCEkiCRtBsMgAai0AACEKQQggBGpBAWpBAEEBIAhJIgsbQbDIAGotAAAhDEEIIARqQQJqQQBBAiAISSING0GwyABqLQAAIQ5BCCAEakEDakEAQQMgCEkiDxtBsMgAai0AACEQQQggBGpBBGpBAEEEIAhJIhEbQbDIAGotAAAhEkEIIARqQQVqQQBBBSAISSITG0GwyABqLQAAIRRBCCAEakEGakEAQQYgCEkiFRtBsMgAai0AACEWIAFBAWogCCAHIAkgCkH/AXFBAEdxIAsgDEH/AXFBAEdxciANIA5B/wFxQQBHcXIgDyAQQf8BcUEAR3FyIBEgEkH/AXFBAEdxciATIBRB/wFxQQBHcXIgFSAWQf8BcUEAR3FychshFyAXCw=='), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 5277328);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 516)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*516, 516)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*4, 4)))
, constants: new Uint8Array(memoryExport.buffer, 528, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 528, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 528, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 784, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 784 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1808, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 1808 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2832, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2832 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3856, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 3856 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 4880, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4880 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4880, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4880 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5136, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5136 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6160, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 6160 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7184, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 7184 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8208, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8208 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 9232, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9232 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 9248, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9248 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 9264, 5242880)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9264 + i*5242880, 5242880)))
, _worker: new Uint8Array(memoryExport.buffer, 5252224, 25104)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252224 + i*25104, 25104)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 5252224, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252224 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 5252352, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252352 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 5252480, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252480 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 5252608, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252608 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 5252736, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5252736 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 5277312, 4)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5277312 + i*4, 4)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}
let _cache;
export default function aes_kwp(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}