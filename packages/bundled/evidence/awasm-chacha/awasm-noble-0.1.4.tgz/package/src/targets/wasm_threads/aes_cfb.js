// WARNING: This file is auto-generated. Any changes will be lost.

function init_module(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};



let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  ;\n  const getInstance = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);;\n  const _imports = {env: {}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;
;
if (!_imports.env._memory) _imports.env._memory = new WebAssembly.Memory({initial: 161, maximum: 161, shared: true});
const code = Uint8Array.from(atob('AGFzbQEAAAABOglgAn9/AX9gAAF/YAF/AGADf39/AGAAAGADf39/A39/f2ACf38Cf39gAX8Bf2AFf39/f38Ff39/f38CWwQDZW52B19tZW1vcnkCA6EBoQEDZW52FF93b3JrZXJfbm90aWZ5QnJpZGdlAAADZW52FF93b3JrZXJfb25saW5lQnJpZGdlAAEDZW52C2luaXRXb3JrZXJzAAIDCwoAAQMCAwIEAwICB5cBCwZtZW1vcnkCAA5fd29ya2VyX25vdGlmeQADDl93b3JrZXJfb25saW5lAAQNZGVjcnlwdEJsb2NrcwAFC2RlY3J5cHRJbml0AAYNZW5jcnlwdEJsb2NrcwAHC2VuY3J5cHRJbml0AAgKaW5pdFRhYmxlcwAJCmluaXRXb3JrZXIACgVyZXNldAALCnN0b3BXb3JrZXIADAqjNgriAQEQf0EAIAFBAAIFIQQhAyECIAIgAyAEIANBAEdFDQAaGhogAiADIAQCBSEHIQYhBSAFIAYgBwMFIQohCSEIIAggCSAKAgUhDSEMIQsgCyAMIA0gDEEBcUUNABoaGiALQYAGbEGAz4AFaiAA/hcCACALQYAGbEGAz4AFakEB/gACACEOIA1BASALdHIhDyALIAwgDwshDSEMIQsgC0EBaiEQIAxBAXYhESAQIBEgDSARQQBHDQAaGhogECARIA0LIQohCSEIIAggCSAKCyEHIQYhBSAFIAYgBwshBCEDIQIgBAuaAQEMf0EAQQACBiEBIQAgACABIABBH0lFDQAaGiAAIAECBiEDIQIgAiADAwYhBSEEIAQgBQIGIQchBiAGQQFqIghBgAZsQYDNgAVq/hACACEJIAdBASAIdEEAIAkbciEKIAYgCgshByEGIAZBAWohCyALIAcgC0EfSQ0AGhogCyAHCyEFIQQgBCAFCyEDIQIgAiADCyEBIQAgAQvRCgFRf0EAKAKABCEDQQACByEEIAQgBCAASUUNABogBAIHIQUgBQMHIQYgBgIHIQcgB0EEdEHAyABqIggoAgAhCSAIQQRqIgooAgAhCyAKQQRqIgwoAgAhDSAMQQRqKAIAIQ5BACgCkAQhD0EAKAKUBCEQQQAoApgEIRFBACgCnAQhEkEAKAIgIRNBACgCJCEUQQAoAighFUEAKAIsIRYgA0EBayEXQQAgDyATcyAQIBRzIBEgFXMgEiAWcwIIIRwhGyEaIRkhGCAYIBkgGiAbIBwDCCEhISAhHyEeIR0gHUEBaiEiIB1BAWpBAnQiI0ECdEEgaigCACEkIB5B/wFxQQJ0QaAGaigCACElIB9BCHZB/wFxQQJ0QaAOaigCACEmICBBEHZB/wFxQQJ0QaAWaigCACEnICFBGHZB/wFxQQJ0QaAeaigCACEoICQgJSAmcyAnIChzc3MhKSAjQQFqQQJ0QSBqKAIAISogH0H/AXFBAnRBoAZqKAIAISsgIEEIdkH/AXFBAnRBoA5qKAIAISwgIUEQdkH/AXFBAnRBoBZqKAIAIS0gHkEYdkH/AXFBAnRBoB5qKAIAIS4gKiArICxzIC0gLnNzcyEvICNBAmpBAnRBIGooAgAhMCAgQf8BcUECdEGgBmooAgAhMSAhQQh2Qf8BcUECdEGgDmooAgAhMiAeQRB2Qf8BcUECdEGgFmooAgAhMyAfQRh2Qf8BcUECdEGgHmooAgAhNCAwIDEgMnMgMyA0c3NzITUgI0EDakECdEEgaigCACE2ICFB/wFxQQJ0QaAGaigCACE3IB5BCHZB/wFxQQJ0QaAOaigCACE4IB9BEHZB/wFxQQJ0QaAWaigCACE5ICBBGHZB/wFxQQJ0QaAeaigCACE6IDYgNyA4cyA5IDpzc3MhOyAiICkgLyA1IDsgIiAXSQ0AGhoaGhogIiApIC8gNSA7CyEhISAhHyEeIR0gHSAeIB8gICAhCyEcIRshGiEZIRggA0ECdCI8QQJ0QSBqKAIAIT0gGkEIdkH/AXFBoARqLQAAIT4gG0EQdkH/AXFBoARqLQAAIT8gHEEYdkH/AXFBoARqLQAAIUAgGUH/AXFBoARqLQAAIUEgPEEBakECdEEgaigCACFCIBtBCHZB/wFxQaAEai0AACFDIBxBEHZB/wFxQaAEai0AACFEIBlBGHZB/wFxQaAEai0AACFFIBpB/wFxQaAEai0AACFGIDxBAmpBAnRBIGooAgAhRyAcQQh2Qf8BcUGgBGotAAAhSCAZQRB2Qf8BcUGgBGotAAAhSSAaQRh2Qf8BcUGgBGotAAAhSiAbQf8BcUGgBGotAAAhSyA8QQNqQQJ0QSBqKAIAIUwgGUEIdkH/AXFBoARqLQAAIU0gGkEQdkH/AXFBoARqLQAAIU4gG0EYdkH/AXFBoARqLQAAIU8gHEH/AXFBoARqLQAAIVAgCCAJID0gQUH/AXEgPkH/AXFBCHRyID9B/wFxQRB0IEBB/wFxQRh0cnJzczYCACAIQQRqIlEgCyBCIEZB/wFxIENB/wFxQQh0ciBEQf8BcUEQdCBFQf8BcUEYdHJyc3M2AgAgUUEEaiJSIA0gRyBLQf8BcSBIQf8BcUEIdHIgSUH/AXFBEHQgSkH/AXFBGHRycnNzNgIAIFJBBGogDiBMIFBB/wFxIE1B/wFxQQh0ciBOQf8BcUEQdCBPQf8BcUEYdHJyc3M2AgBBACAJNgKQBEEAIAs2ApQEQQAgDTYCmARBACAONgKcBCAHCyEHIAdBAWohUyBTIFMgAEkNABogUwshBiAGCyEFIAULIQQLnQkBKX8QCUEEQQZBCCAAQRhGIgIbIABBEEYiARshA0EAQQpBDEEOIAIbIAEbIgQ2AoAEQQBBADYCIEEAQQA2AiRBAEEANgIoQQBBADYCLEEAQQA2AjBBAEEANgI0QQBBADYCOEEAQQA2AjxBAEEANgJAQQBBADYCREEAQQA2AkhBAEEANgJMQQBBADYCUEEAQQA2AlRBAEEANgJYQQBBADYCXEEAQQA2AmBBAEEANgJkQQBBADYCaEEAQQA2AmxBAEEANgJwQQBBADYCdEEAQQA2AnhBAEEANgJ8QQBBADYCgAFBAEEANgKEAUEAQQA2AogBQQBBADYCjAFBAEEANgKQAUEAQQA2ApQBQQBBADYCmAFBAEEANgKcAUEAQQA2AqABQQBBADYCpAFBAEEANgKoAUEAQQA2AqwBQQBBADYCsAFBAEEANgK0AUEAQQA2ArgBQQBBADYCvAFBAEEANgLAAUEAQQA2AsQBQQBBADYCyAFBAEEANgLMAUEAQQA2AtABQQBBADYC1AFBAEEANgLYAUEAQQA2AtwBQQBBADYC4AFBAEEANgLkAUEAQQA2AugBQQBBADYC7AFBAEEANgLwAUEAQQA2AvQBQQBBADYC+AFBAEEANgL8AUEAQQA2AoACQQBBADYChAJBAEEANgKIAkEAQQA2AowCQQACByEFIAUgBSADSUUNABogBQIHIQYgBgMHIQcgBwIHIQggCEECdCIJQQFqLQAAIQogCUECai0AACELIAlBA2otAAAhDCAJLQAAIQ0gCEECdEGQAmogDUH/AXEgCkH/AXFBCHQgC0H/AXFBEHQgDEH/AXFBGHRycnI2AgAgCAshCCAIQQFqIQ4gDiAOIANJDQAaIA4LIQcgBwshBiAGCyEFIARBAWpBAnQhDyAPIANrIRBBAAIHIREgESARIBBJRQ0AGiARAgchEiASAwchEyATAgchFCAUIANqIhVBAWtBAnRBkAJqKAIAIRYgFkEYdCAWQQh2ciIYQQh2Qf8BcUGgBGotAAAhGSAYQRB2Qf8BcUGgBGotAAAhGiAYQRh2Qf8BcUGgBGotAAAhGyAYQf8BcUGgBGotAAAhHCAVIANuQQFrQaDIAGotAAAhHSAWQQh2Qf8BcUGgBGotAAAhHiAWQRB2Qf8BcUGgBGotAAAhHyAWQRh2Qf8BcUGgBGotAAAhICAWQf8BcUGgBGotAAAhISAVIANrQQJ0QZACaigCACEiIBVBAnRBkAJqICFB/wFxIB5B/wFxQQh0ciAfQf8BcUEQdCAgQf8BcUEYdHJyIBxB/wFxIBlB/wFxQQh0ciAaQf8BcUEQdCAbQf8BcUEYdHJyIB1B/wFxcyAWIBUgA3AiF0EARhsgA0EIRiAXQQRGcRsgInM2AgAgFAshFCAUQQFqISMgIyAjIBBJDQAaICMLIRMgEwshEiASCyERQQACByEkICQgJCAPSUUNABogJAIHISUgJQMHISYgJgIHIScgJ0ECdEGQAmooAgAhKCAnQQJ0QSBqICg2AgAgJwshJyAnQQFqISkgKSApIA9JDQAaICkLISYgJgshJSAlCyEkC9kKAVV/QQAoAoAEIQNBAAIHIQQgBCAEIABJRQ0AGiAEAgchBSAFAwchBiAGAgchByAHQQR0QcDIAGoiCCgCACEJIAhBBGoiCigCACELIApBBGoiDCgCACENIAxBBGooAgAhDkEAKAKQBCEPQQAoApQEIRBBACgCmAQhEUEAKAKcBCESQQAoAiAhE0EAKAIkIRRBACgCKCEVQQAoAiwhFiADQQFrIRdBACAPIBNzIBAgFHMgESAVcyASIBZzAgghHCEbIRohGSEYIBggGSAaIBsgHAMIISEhICEfIR4hHSAdQQFqISIgHUEBakECdCIjQQJ0QSBqKAIAISQgHkH/AXFBAnRBoAZqKAIAISUgH0EIdkH/AXFBAnRBoA5qKAIAISYgIEEQdkH/AXFBAnRBoBZqKAIAIScgIUEYdkH/AXFBAnRBoB5qKAIAISggJCAlICZzICcgKHNzcyEpICNBAWpBAnRBIGooAgAhKiAfQf8BcUECdEGgBmooAgAhKyAgQQh2Qf8BcUECdEGgDmooAgAhLCAhQRB2Qf8BcUECdEGgFmooAgAhLSAeQRh2Qf8BcUECdEGgHmooAgAhLiAqICsgLHMgLSAuc3NzIS8gI0ECakECdEEgaigCACEwICBB/wFxQQJ0QaAGaigCACExICFBCHZB/wFxQQJ0QaAOaigCACEyIB5BEHZB/wFxQQJ0QaAWaigCACEzIB9BGHZB/wFxQQJ0QaAeaigCACE0IDAgMSAycyAzIDRzc3MhNSAjQQNqQQJ0QSBqKAIAITYgIUH/AXFBAnRBoAZqKAIAITcgHkEIdkH/AXFBAnRBoA5qKAIAITggH0EQdkH/AXFBAnRBoBZqKAIAITkgIEEYdkH/AXFBAnRBoB5qKAIAITogNiA3IDhzIDkgOnNzcyE7ICIgKSAvIDUgOyAiIBdJDQAaGhoaGiAiICkgLyA1IDsLISEhICEfIR4hHSAdIB4gHyAgICELIRwhGyEaIRkhGCADQQJ0IjxBAnRBIGooAgAhPSAaQQh2Qf8BcUGgBGotAAAhPiAbQRB2Qf8BcUGgBGotAAAhPyAcQRh2Qf8BcUGgBGotAAAhQCAZQf8BcUGgBGotAAAhQSA8QQFqQQJ0QSBqKAIAIUIgG0EIdkH/AXFBoARqLQAAIUMgHEEQdkH/AXFBoARqLQAAIUQgGUEYdkH/AXFBoARqLQAAIUUgGkH/AXFBoARqLQAAIUYgPEECakECdEEgaigCACFHIBxBCHZB/wFxQaAEai0AACFIIBlBEHZB/wFxQaAEai0AACFJIBpBGHZB/wFxQaAEai0AACFKIBtB/wFxQaAEai0AACFLIDxBA2pBAnRBIGooAgAhTCAZQQh2Qf8BcUGgBGotAAAhTSAaQRB2Qf8BcUGgBGotAAAhTiAbQRh2Qf8BcUGgBGotAAAhTyAcQf8BcUGgBGotAAAhUCAIIAkgPSBBQf8BcSA+Qf8BcUEIdHIgP0H/AXFBEHQgQEH/AXFBGHRycnNzIlE2AgAgCEEEaiJVIAsgQiBGQf8BcSBDQf8BcUEIdHIgREH/AXFBEHQgRUH/AXFBGHRycnNzIlI2AgAgVUEEaiJWIA0gRyBLQf8BcSBIQf8BcUEIdHIgSUH/AXFBEHQgSkH/AXFBGHRycnNzIlM2AgAgVkEEaiAOIEwgUEH/AXEgTUH/AXFBCHRyIE5B/wFxQRB0IE9B/wFxQRh0cnJzcyJUNgIAQQAgUTYCkARBACBSNgKUBEEAIFM2ApgEQQAgVDYCnAQgBwshByAHQQFqIVcgVyBXIABJDQAaIFcLIQYgBgshBSAFCyEEC50JASl/EAlBBEEGQQggAEEYRiICGyAAQRBGIgEbIQNBAEEKQQxBDiACGyABGyIENgKABEEAQQA2AiBBAEEANgIkQQBBADYCKEEAQQA2AixBAEEANgIwQQBBADYCNEEAQQA2AjhBAEEANgI8QQBBADYCQEEAQQA2AkRBAEEANgJIQQBBADYCTEEAQQA2AlBBAEEANgJUQQBBADYCWEEAQQA2AlxBAEEANgJgQQBBADYCZEEAQQA2AmhBAEEANgJsQQBBADYCcEEAQQA2AnRBAEEANgJ4QQBBADYCfEEAQQA2AoABQQBBADYChAFBAEEANgKIAUEAQQA2AowBQQBBADYCkAFBAEEANgKUAUEAQQA2ApgBQQBBADYCnAFBAEEANgKgAUEAQQA2AqQBQQBBADYCqAFBAEEANgKsAUEAQQA2ArABQQBBADYCtAFBAEEANgK4AUEAQQA2ArwBQQBBADYCwAFBAEEANgLEAUEAQQA2AsgBQQBBADYCzAFBAEEANgLQAUEAQQA2AtQBQQBBADYC2AFBAEEANgLcAUEAQQA2AuABQQBBADYC5AFBAEEANgLoAUEAQQA2AuwBQQBBADYC8AFBAEEANgL0AUEAQQA2AvgBQQBBADYC/AFBAEEANgKAAkEAQQA2AoQCQQBBADYCiAJBAEEANgKMAkEAAgchBSAFIAUgA0lFDQAaIAUCByEGIAYDByEHIAcCByEIIAhBAnQiCUEBai0AACEKIAlBAmotAAAhCyAJQQNqLQAAIQwgCS0AACENIAhBAnRBkAJqIA1B/wFxIApB/wFxQQh0IAtB/wFxQRB0IAxB/wFxQRh0cnJyNgIAIAgLIQggCEEBaiEOIA4gDiADSQ0AGiAOCyEHIAcLIQYgBgshBSAEQQFqQQJ0IQ8gDyADayEQQQACByERIBEgESAQSUUNABogEQIHIRIgEgMHIRMgEwIHIRQgFCADaiIVQQFrQQJ0QZACaigCACEWIBZBGHQgFkEIdnIiGEEIdkH/AXFBoARqLQAAIRkgGEEQdkH/AXFBoARqLQAAIRogGEEYdkH/AXFBoARqLQAAIRsgGEH/AXFBoARqLQAAIRwgFSADbkEBa0GgyABqLQAAIR0gFkEIdkH/AXFBoARqLQAAIR4gFkEQdkH/AXFBoARqLQAAIR8gFkEYdkH/AXFBoARqLQAAISAgFkH/AXFBoARqLQAAISEgFSADa0ECdEGQAmooAgAhIiAVQQJ0QZACaiAhQf8BcSAeQf8BcUEIdHIgH0H/AXFBEHQgIEH/AXFBGHRyciAcQf8BcSAZQf8BcUEIdHIgGkH/AXFBEHQgG0H/AXFBGHRyciAdQf8BcXMgFiAVIANwIhdBAEYbIANBCEYgF0EERnEbICJzNgIAIBQLIRQgFEEBaiEjICMgIyAQSQ0AGiAjCyETIBMLIRIgEgshEUEAAgchJCAkICQgD0lFDQAaICQCByElICUDByEmICYCByEnICdBAnRBkAJqKAIAISggJ0ECdEEgaiAoNgIAICcLIScgJ0EBaiEpICkgKSAPSQ0AGiApCyEmICYLISUgJQshJAuKCgE9f0EAKAKwSCEAAgQgAEEARkUNAEEAQQECBiECIQEgASACAwYhBCEDIANBAWohBSAEIARBAXQgBEEHdkEBcUEbbHNB/wFxcyEGIANBoAZqIARB/wFxOgAAIAUgBiAFQYACSQ0AGhogBSAGCyEEIQMgAyAECyECIQFBAEHjAEH/AXE6AKAEQQACByEHIAcgB0H/AUlFDQAaIAcCByEIIAgDByEJIAkCByEKQf8BIAprQaAGai0AACELIApBoAZqLQAAIQ4gDkH/AXFBoARqIAtB/wFxIgwgDEEIdHIiDSANQQR2cyANQQV2cyANQQZ2cyANQQd2c0HjAHNB/wFxQf8BcToAACAKCyEKIApBAWohDyAPIA9B/wFJDQAaIA8LIQkgCQshCCAICyEHQQACByEQIBAgEEGAAklFDQAaIBACByERIBEDByESIBICByETIBNBoCZqQQBB/wFxOgAAIBMLIRMgE0EBaiEUIBQgFEGAAkkNABogFAshEiASCyERIBELIRBBAAIHIRUgFSAVQYACSUUNABogFQIHIRYgFgMHIRcgFwIHIRggGEGgBGotAAAhGSAZQf8BcUGgJmogGEH/AXE6AAAgGAshGCAYQQFqIRogGiAaQYACSQ0AGiAaCyEXIBcLIRYgFgshFUEAQQECBiEcIRsgGyAcAwYhHiEdIB1BAWohHyAeQQF0IB5BB3ZBAXFBG2xzQf8BcSEgIB1BoMgAaiAeQf8BcToAACAfICAgH0EQSQ0AGhogHyAgCyEeIR0gHSAeCyEcIRtBAAIHISEgISAhQYACSUUNABogIQIHISIgIgMHISMgIwIHISQgJEGgBGotAAAhJSAkQaAmai0AACEnICRBAnRBoAZqICVB/wFxIiYgJkEBdCAmQQd2QQFxQRtsc0H/AXFzQRh0ICZBEHQgJkEIdCAmQQF0ICZBB3ZBAXFBG2xzQf8BcXJycjYCACAkQQJ0QaAoaiAnQf8BcSIoIChBAXQgKEEHdkEBcUEbbHNB/wFxIitzICtBAXQgK0EHdkEBcUEbbHNB/wFxIixBAXQgLEEHdkEBcUEbbHNB/wFxc0EYdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIi1BAXQgLUEHdkEBcUEbbHNB/wFxIi5zIC5BAXQgLkEHdkEBcUEbbHNB/wFxc0EQdCAoIChBAXQgKEEHdkEBcUEbbHNB/wFxIilBAXQgKUEHdkEBcUEbbHNB/wFxIipBAXQgKkEHdkEBcUEbbHNB/wFxc0EIdCAoQQF0IChBB3ZBAXFBG2xzQf8BcSIvIC9BAXQgL0EHdkEBcUEbbHNB/wFxIjBzIDBBAXQgMEEHdkEBcUEbbHNB/wFxc3JycjYCACAkCyEkICRBAWohMSAxIDFBgAJJDQAaIDELISMgIwshIiAiCyEhQQACByEyIDIgMkGAAklFDQAaIDICByEzIDMDByE0IDQCByE1IDVBAnRBoAZqKAIAITYgNUECdEGgDmogNkEIdyI3NgIAIDVBAnRBoBZqIDdBCHciODYCACA1QQJ0QaAeaiA4QQh3NgIAIDVBAnRBoChqKAIAITkgNUECdEGgMGogOUEIdyI6NgIAIDVBAnRBoDhqIDpBCHciOzYCACA1QQJ0QaDAAGogO0EIdzYCACA1CyE1IDVBAWohPCA8IDxBgAJJDQAaIDwLITQgNAshMyAzCyEyQQBBATYCsEgLC3wBBH8gAEGABmxBgM6ABWohAyAAQYAGbEGAz4AFaiEEIABBgAZsQYDNgAVqQQH+FwIAAgQCBCABRQ0ADAELAgQDBCAEQQD+QQIAIQUCBCAFRSACQQFHcUUNACAEQQBCf/4BAgAhBgwBCyADQQH+FwIAIAINAUEBDQALCwsLFwBBAEEAQaAE/AsAQcDIAEEAIAD8CwALFAAgAEGABmxBgM2ABWpBAP4XAgAL'), char => char.charCodeAt(0));
const module = new WebAssembly.Module(code);
const instance = new WebAssembly.Instance(module, _imports);

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 10520208);
const segments = Object.freeze({state: new Uint8Array(memoryExport.buffer, 0, 544)
, state_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*544, 544)))
, "state.key": new Uint8Array(memoryExport.buffer, 0, 32)
, "state.key_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*32, 32)))
, "state.expandedKey": new Uint8Array(memoryExport.buffer, 32, 240)
, "state.expandedKey_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 32 + i*240, 240)))
, "state.tmp": new Uint8Array(memoryExport.buffer, 272, 240)
, "state.tmp_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 272 + i*240, 240)))
, "state.rounds": new Uint8Array(memoryExport.buffer, 512, 4)
, "state.rounds_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 512 + i*4, 4)))
, "state.iv": new Uint8Array(memoryExport.buffer, 528, 16)
, "state.iv_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 528 + i*16, 16)))
, constants: new Uint8Array(memoryExport.buffer, 544, 8724)
, constants_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*8724, 8724)))
, "constants.encrypt": new Uint8Array(memoryExport.buffer, 544, 4352)
, "constants.encrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*4352, 4352)))
, "constants.encrypt.sbox": new Uint8Array(memoryExport.buffer, 544, 256)
, "constants.encrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 544 + i*256, 256)))
, "constants.encrypt.T0": new Uint8Array(memoryExport.buffer, 800, 1024)
, "constants.encrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 800 + i*1024, 1024)))
, "constants.encrypt.T1": new Uint8Array(memoryExport.buffer, 1824, 1024)
, "constants.encrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 1824 + i*1024, 1024)))
, "constants.encrypt.T2": new Uint8Array(memoryExport.buffer, 2848, 1024)
, "constants.encrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 2848 + i*1024, 1024)))
, "constants.encrypt.T3": new Uint8Array(memoryExport.buffer, 3872, 1024)
, "constants.encrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 3872 + i*1024, 1024)))
, "constants.decrypt": new Uint8Array(memoryExport.buffer, 4896, 4352)
, "constants.decrypt_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*4352, 4352)))
, "constants.decrypt.sbox": new Uint8Array(memoryExport.buffer, 4896, 256)
, "constants.decrypt.sbox_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 4896 + i*256, 256)))
, "constants.decrypt.T0": new Uint8Array(memoryExport.buffer, 5152, 1024)
, "constants.decrypt.T0_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 5152 + i*1024, 1024)))
, "constants.decrypt.T1": new Uint8Array(memoryExport.buffer, 6176, 1024)
, "constants.decrypt.T1_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 6176 + i*1024, 1024)))
, "constants.decrypt.T2": new Uint8Array(memoryExport.buffer, 7200, 1024)
, "constants.decrypt.T2_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 7200 + i*1024, 1024)))
, "constants.decrypt.T3": new Uint8Array(memoryExport.buffer, 8224, 1024)
, "constants.decrypt.T3_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8224 + i*1024, 1024)))
, "constants.xPowers": new Uint8Array(memoryExport.buffer, 9248, 16)
, "constants.xPowers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9248 + i*16, 16)))
, "constants.inited": new Uint8Array(memoryExport.buffer, 9264, 4)
, "constants.inited_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9264 + i*4, 4)))
, buffer: new Uint8Array(memoryExport.buffer, 9280, 10485760)
, buffer_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 9280 + i*10485760, 10485760)))
, _worker: new Uint8Array(memoryExport.buffer, 10495104, 25104)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495104 + i*25104, 25104)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 10495104, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495104 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 10495232, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495232 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 10495360, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495360 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 10495488, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495488 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 10495616, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10495616 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 10520192, 4)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 10520192 + i*4, 4)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}
let _cache;
export default function aes_cfb(_imports = {}, pool){
  if (_cache) return _cache;
  return (_cache = init_module(_imports, pool));
}