// WARNING: This file is auto-generated. Any changes will be lost.
export default function workerPool(_imports = {}, pool){
const workers = [];

const _importsEmbed = {env: {workerProcess: (id, modId) => {
        if (!registry[modId])
            throw new Error('unknown modId');
        registry[modId].exports.initWorker(id, 0, 1);
    }, workerNotify: (id, modId) => {
        if (!registry[modId])
            throw new Error('unknown cmd');
        registry[modId].exports.initWorker(id, 1, 0);
    }}};
_imports = {..._importsEmbed,..._imports, env: {..._importsEmbed.env, ..._imports.env}};

const codeFn = ()=>{
    
const env = _imports.env;
const __buf = env && env._memory ? env._memory.buffer : new SharedArrayBuffer(33296);
if (!(__buf instanceof SharedArrayBuffer)) throw new Error('wrong buffer');

const memory_i32 = new Int32Array(__buf);
const {_worker_notifyBridge, _worker_onlineBridge, initWorkers, workerNotify, workerProcess} = env;



function _worker_notify(v0, v1) {
    
    let s0 = 0, s1 = v1, s2 = 0;
L0:  {const v2 = s0;
const v3 = s1;
const v4 = s2;

if (((((((((v3) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
s0 = v2;
s1 = v3;
s2 = v4;break L0;
}
let s3 = v2, s4 = v3, s5 = v4;
L1:  {const v5 = s3;
const v6 = s4;
const v7 = s5;

let s6 = v5, s7 = v6, s8 = v7;
L2: for (;;) {const v8 = s6;
const v9 = s7;
const v10 = s8;

let s9 = v8, s10 = v9, s11 = v10;
L3:  {const v11 = s9;
const v12 = s10;
const v13 = s11;

if ((((((1 & v12)) | 0) === 0) | 0)) {
s9 = v11;
s10 = v12;
s11 = v13;break L3;
}
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.store(memory_i32, __addr >>> 2, (v0|0)))))(((((8960 + Math.imul(768, v11)) | 0)) >>> 0) + 0);
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.notify(memory_i32, __addr >>> 2, 1|0))))(((((8960 + Math.imul(768, v11)) | 0)) >>> 0) + 0);
const v15 = ((1 << v11) | v13);
s9 = v11;
s10 = v12;
s11 = v15;}
const v11 = s9;
const v12 = s10;
const v13 = s11;

const v16 = ((1 + v11) | 0);
const v17 = (v12 >>> 1);
if (((((v17) | 0) !== ((0) | 0)) | 0)) {
s6 = v16;
s7 = v17;
s8 = v13;continue L2;
}
s6 = v16;
s7 = v17;
s8 = v13;break L2;}
const v8 = s6;
const v9 = s7;
const v10 = s8;

s3 = v8;
s4 = v9;
s5 = v10;}
const v5 = s3;
const v6 = s4;
const v7 = s5;

s0 = v5;
s1 = v6;
s2 = v7;}
const v4 = s2;

return v4;
}



function _worker_online() {
    
    let s0 = 0, s1 = 0;
L0:  {const v0 = s0;
const v1 = s1;

if (((((((((v0) >>> 0) < ((31) >>> 0)) | 0)) | 0) === 0) | 0)) {
s0 = v0;
s1 = v1;break L0;
}
let s2 = v0, s3 = v1;
L1:  {const v2 = s2;
const v3 = s3;

let s4 = v2, s5 = v3;
L2: for (;;) {const v4 = s4;
const v5 = s5;

let s6 = v4, s7 = v5;
L3:  {const v6 = s6;
const v7 = s7;

const v8 = ((1 + v6) | 0);
const v9 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))(((((8704 + Math.imul(768, v8)) | 0)) >>> 0) + 0);
const v10 = (((v9) ? ((1 << v8)) : (0)) | v7);
s6 = v6;
s7 = v10;}
const v6 = s6;
const v7 = s7;

const v11 = ((1 + v6) | 0);
if (((((v11) >>> 0) < ((31) >>> 0)) | 0)) {
s4 = v11;
s5 = v7;continue L2;
}
s4 = v11;
s5 = v7;break L2;}
const v4 = s4;
const v5 = s5;

s2 = v4;
s3 = v5;}
const v2 = s2;
const v3 = s3;

s0 = v2;
s1 = v3;}
const v1 = s1;

return v1;
}



function initWorker(v0) {
    
    const v1 = ((8704 + Math.imul(768, v0)) | 0);
const v2 = ((8832 + Math.imul(768, v0)) | 0);
const v3 = ((8960 + Math.imul(768, v0)) | 0);
const v4 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))((((v0 << 8)) >>> 0) + 0);
L0:  {
L1:  {
if (((((((((v4) | 0) !== ((0) | 0)) | 0)) | 0) === 0) | 0)) {
break L1;
}
break L0;
}

((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.store(memory_i32, __addr >>> 2, (1|0)))))(((v1) >>> 0) + 0);
L2:  {
L3: for (;;) {
const v5 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.exchange(memory_i32, __addr >>> 2, (0|0))|0)))(((v3) >>> 0) + 0);
L4:  {
if (((((((((v5) | 0) === 0) | 0)) | 0) === 0) | 0)) {
break L4;
}
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (({ok:0,'not-equal':1,'timed-out':2}[(((-1|0) < 0) ? Atomics.wait(memory_i32, __addr >>> 2, (0|0)) : (m=>Atomics.wait(memory_i32, __addr >>> 2, (0|0), (m<=0?0:m)))(Math.ceil((-1 * 4294967296 + (-1>>>0)) / 1_000_000)))]))))(((v3) >>> 0) + 0);
continue L3;
}

L5:  {
if (((((((((v5) | 0) === ((1) | 0)) | 0)) | 0) === 0) | 0)) {
break L5;
}
const v7 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))((((v0 << 8)) >>> 0) + 0);
if (((((v7) | 0) === 0) | 0)) {
continue L3;
}
break L2;
}

workerProcess(v0, v5);
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.store(memory_i32, __addr >>> 2, (1|0)))))(((v2) >>> 0) + 0);
if (1) {
continue L3;
}
break L3;}

}

((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.store(memory_i32, __addr >>> 2, (0|0)))))(((v1) >>> 0) + 0);
}

return ;
}



function mainInstalled(v0) {
    
    Atomics.add(memory_i32, 0, (1|0))|0;
Atomics.add(memory_i32, 64, (1|0))|0;
Atomics.add(memory_i32, 128, (1|0))|0;
Atomics.add(memory_i32, 192, (1|0))|0;
Atomics.add(memory_i32, 256, (1|0))|0;
Atomics.add(memory_i32, 320, (1|0))|0;
Atomics.add(memory_i32, 384, (1|0))|0;
Atomics.add(memory_i32, 448, (1|0))|0;
Atomics.add(memory_i32, 512, (1|0))|0;
Atomics.add(memory_i32, 576, (1|0))|0;
Atomics.add(memory_i32, 640, (1|0))|0;
Atomics.add(memory_i32, 704, (1|0))|0;
Atomics.add(memory_i32, 768, (1|0))|0;
Atomics.add(memory_i32, 832, (1|0))|0;
Atomics.add(memory_i32, 896, (1|0))|0;
Atomics.add(memory_i32, 960, (1|0))|0;
Atomics.add(memory_i32, 1024, (1|0))|0;
Atomics.add(memory_i32, 1088, (1|0))|0;
Atomics.add(memory_i32, 1152, (1|0))|0;
Atomics.add(memory_i32, 1216, (1|0))|0;
Atomics.add(memory_i32, 1280, (1|0))|0;
Atomics.add(memory_i32, 1344, (1|0))|0;
Atomics.add(memory_i32, 1408, (1|0))|0;
Atomics.add(memory_i32, 1472, (1|0))|0;
Atomics.add(memory_i32, 1536, (1|0))|0;
Atomics.add(memory_i32, 1600, (1|0))|0;
Atomics.add(memory_i32, 1664, (1|0))|0;
Atomics.add(memory_i32, 1728, (1|0))|0;
Atomics.add(memory_i32, 1792, (1|0))|0;
Atomics.add(memory_i32, 1856, (1|0))|0;
Atomics.add(memory_i32, 1920, (1|0))|0;
Atomics.add(memory_i32, 1984, (1|0))|0;
const r0 = _worker_notify(1, -1);

return ;
}



function mainReset() {
    
    Atomics.store(memory_i32, 0, (0|0));
Atomics.store(memory_i32, 32, (0|0));
Atomics.store(memory_i32, 64, (0|0));
Atomics.store(memory_i32, 96, (0|0));
Atomics.store(memory_i32, 128, (0|0));
Atomics.store(memory_i32, 160, (0|0));
Atomics.store(memory_i32, 192, (0|0));
Atomics.store(memory_i32, 224, (0|0));
Atomics.store(memory_i32, 256, (0|0));
Atomics.store(memory_i32, 288, (0|0));
Atomics.store(memory_i32, 320, (0|0));
Atomics.store(memory_i32, 352, (0|0));
Atomics.store(memory_i32, 384, (0|0));
Atomics.store(memory_i32, 416, (0|0));
Atomics.store(memory_i32, 448, (0|0));
Atomics.store(memory_i32, 480, (0|0));
Atomics.store(memory_i32, 512, (0|0));
Atomics.store(memory_i32, 544, (0|0));
Atomics.store(memory_i32, 576, (0|0));
Atomics.store(memory_i32, 608, (0|0));
Atomics.store(memory_i32, 640, (0|0));
Atomics.store(memory_i32, 672, (0|0));
Atomics.store(memory_i32, 704, (0|0));
Atomics.store(memory_i32, 736, (0|0));
Atomics.store(memory_i32, 768, (0|0));
Atomics.store(memory_i32, 800, (0|0));
Atomics.store(memory_i32, 832, (0|0));
Atomics.store(memory_i32, 864, (0|0));
Atomics.store(memory_i32, 896, (0|0));
Atomics.store(memory_i32, 928, (0|0));
Atomics.store(memory_i32, 960, (0|0));
Atomics.store(memory_i32, 992, (0|0));
Atomics.store(memory_i32, 1024, (0|0));
Atomics.store(memory_i32, 1056, (0|0));
Atomics.store(memory_i32, 1088, (0|0));
Atomics.store(memory_i32, 1120, (0|0));
Atomics.store(memory_i32, 1152, (0|0));
Atomics.store(memory_i32, 1184, (0|0));
Atomics.store(memory_i32, 1216, (0|0));
Atomics.store(memory_i32, 1248, (0|0));
Atomics.store(memory_i32, 1280, (0|0));
Atomics.store(memory_i32, 1312, (0|0));
Atomics.store(memory_i32, 1344, (0|0));
Atomics.store(memory_i32, 1376, (0|0));
Atomics.store(memory_i32, 1408, (0|0));
Atomics.store(memory_i32, 1440, (0|0));
Atomics.store(memory_i32, 1472, (0|0));
Atomics.store(memory_i32, 1504, (0|0));
Atomics.store(memory_i32, 1536, (0|0));
Atomics.store(memory_i32, 1568, (0|0));
Atomics.store(memory_i32, 1600, (0|0));
Atomics.store(memory_i32, 1632, (0|0));
Atomics.store(memory_i32, 1664, (0|0));
Atomics.store(memory_i32, 1696, (0|0));
Atomics.store(memory_i32, 1728, (0|0));
Atomics.store(memory_i32, 1760, (0|0));
Atomics.store(memory_i32, 1792, (0|0));
Atomics.store(memory_i32, 1824, (0|0));
Atomics.store(memory_i32, 1856, (0|0));
Atomics.store(memory_i32, 1888, (0|0));
Atomics.store(memory_i32, 1920, (0|0));
Atomics.store(memory_i32, 1952, (0|0));
Atomics.store(memory_i32, 1984, (0|0));
Atomics.store(memory_i32, 2016, (0|0));
return ;
}



function registryInfo(v0) {
    
    const v1 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))((((v0 << 8)) >>> 0) + 0);
const v2 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))(((((128 + (v0 << 8)) | 0)) >>> 0) + 0);
return [v1, v2];
}



function stopWorker(v0) {
    
    ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.store(memory_i32, __addr >>> 2, (0|0)))))(((((8704 + Math.imul(768, v0)) | 0)) >>> 0) + 0);
return ;
}



function workerInstalled(v0, v1) {
    
    workerNotify(v0, v1);
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.sub(memory_i32, __addr >>> 2, (1|0))|0)))((((v0 << 8)) >>> 0) + 0);
((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.add(memory_i32, __addr >>> 2, (1|0))|0)))(((((128 + (v0 << 8)) | 0)) >>> 0) + 0);
const v4 = ((__addr)=>((__addr & 3) ? (()=>{throw new Error('unaligned atomic access')})() : (Atomics.load(memory_i32, __addr >>> 2)|0)))((((v0 << 8)) >>> 0) + 0);
return v4;
}
const instance = { exports: {_worker_notify: _worker_notify, _worker_online: _worker_online, initWorker: initWorker, mainInstalled: mainInstalled, mainReset: mainReset, registryInfo: registryInfo, stopWorker: stopWorker, workerInstalled: workerInstalled, memory: { buffer: __buf }}};

    return instance;
}

let _poolId;
_imports.env._worker_notifyBridge = (cmd, mask)=>{
  instance.exports._worker_notify(cmd, mask);
  if (pool) {
    if (typeof _poolId!=='number') throw new Error('not installed');
    return pool.notify(_poolId, mask);
  }
};
_imports.env._worker_onlineBridge = ()=>{
    let res = instance.exports._worker_online();
    if (pool) res &= pool.online();
    return res;
};

function initWorkers(limit = 32) {
  if (pool) {
    _poolId = pool.install(code, instance.exports.memory);
    return _poolId;
  }
  (async ()=>{
    try {
      let W = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency)
        ? navigator.hardwareConcurrency
        : 4;
      W = Math.min(W, 32, limit);
      let workerSrc = "(self)=>{\n  const registry = {};;\n  const getInstance = (code, _imports)=>(new Function('_imports', \"return (\"+code+\")(_imports)\"))(_imports);;\n  const _imports = {env: {workerProcess: (id, modId) => {\n        if (!registry[modId])\n            throw new Error('unknown modId');\n        registry[modId].exports.initWorker(id, 0, 1);\n    }, workerNotify: (id, modId) => {\n        if (!registry[modId])\n            throw new Error('unknown cmd');\n        registry[modId].exports.initWorker(id, 1, 0);\n    }}};\n  _imports.env.initWorkers = ()=>{\n    throw new Error('initWorkers inside worker');\n  };\n  _imports.env._worker_notifyBridge = (cmd, mask)=>{\n    throw new Error('_worker_callBridge inside worker');\n  };\n  _imports.env._worker_onlineBridge = ()=>{\n    throw new Error('_worker_onlineBridge inside worker');\n  };\n  let instance;\n  let workerId;\n  self.onmessage = (msg)=>{\n      if (msg.data.type==='init') {\n        if (instance) throw new Error('worker already initialized');\n        let {id, memory, code} = msg.data;\n        instance = getInstance(code, {..._imports, env: {..._imports.env, _memory: memory}});\n        workerId = id;\n        instance.exports.initWorker(id, 0, 0);\n        instance.exports.stopWorker(id);\n        return false;\n      }\n      \nif (msg.data.type==='install') {\n  if (!instance) throw new Error('instance not started yet');\n  for (const k in msg.data.registry) {\n    if (registry[k]) throw new Error('worker('+workerId+') module '+k+' already installed');\n    const {code, memory} = msg.data.registry[k];\n    const getInstanceJS = (code, _imports)=>(new Function('_imports', \"return (\"+code+\")(_imports)\"))(_imports);\n    const getInstanceWASM = (code, _imports)=>new WebAssembly.Instance(new WebAssembly.Module(code), _imports);\n    registry[k] = (typeof code==='string' ? getInstanceJS : getInstanceWASM)(code, {env: {..._imports.env, _memory: memory}});\n    const r1 = instance.exports.workerInstalled(workerId, +k);\n  }\n  instance.exports.initWorker(workerId, 0, 0);\n  instance.exports.stopWorker(workerId);\n  return false;\n}\n  ;\n      return false;\n  }\n}";
      let initWorker;
      if (typeof Worker !== 'undefined') {
        const urlSrc = "("+workerSrc+")(self);"
        let url;
        try { url = URL.createObjectURL(new Blob([urlSrc], { type: 'text/javascript' })); } 
        catch { url = 'data:text/javascript;base64,' + btoa(urlSrc); }
        initWorker = () => {
          if (!url) return;
          try { return new Worker(url); }
          catch {}
          try { return new Worker(url, { type: 'module' }); }
          catch {}
        };
      } else {
        let NodeWorker;
        try {
          // Avoid bundlers stuff
          NodeWorker = new Function('return req'+'uire("node:worker_threads").Worker')()
        } catch {}
        if (!NodeWorker) {
          try { NodeWorker = (await import('node:worker_threads')).Worker; }
          catch {}
        }
        if (NodeWorker) {
          // Node ESM eval workers lack require(); parentPort comes from import fallback.
          initWorker = ()=>new NodeWorker("(typeof require==='function' ? Promise.resolve(require('node:worker_threads')) : import('node:worker_threads')).then(({ parentPort }) => ("+workerSrc+")(parentPort));", { eval: true });
        }
      }
      while (workers.length < W-1) {
        const w = initWorker && initWorker();
        if (!w) break;
        const id = workers.push(w);
        w.postMessage({ type: 'init', id, memory: instance.exports.memory, code });
        if (_imports.env && _imports.env.onWorkerInstall) _imports.env.onWorkerInstall(w, id);
        if (typeof w.unref === 'function') w.unref();
      }
    } catch(e) {
     console.log('initWorkers', e);
    }
  })();
}
_imports.env.initWorkers = initWorkers;

const instance = codeFn();
const code = codeFn.toString();

_imports.env.initWorkers();
const _exports = instance.exports;
const buffer = _exports.memory ? _exports.memory.buffer : new ArrayBuffer(0);
const memoryExport = new Uint8Array(buffer, 0, 33296);
const segments = Object.freeze({registry: new Uint8Array(memoryExport.buffer, 0, 8192)
, registry_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 0 + i*8192, 8192)))
, _worker: new Uint8Array(memoryExport.buffer, 8192, 25104)
, _worker_chunks: Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8192 + i*25104, 25104)))
, "_worker.online": new Uint8Array(memoryExport.buffer, 8192, 4)
, "_worker.online_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8192 + i*4, 4)))
, "_worker.next": new Uint8Array(memoryExport.buffer, 8320, 4)
, "_worker.next_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8320 + i*4, 4)))
, "_worker.total": new Uint8Array(memoryExport.buffer, 8448, 4)
, "_worker.total_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8448 + i*4, 4)))
, "_worker.perBatch": new Uint8Array(memoryExport.buffer, 8576, 4)
, "_worker.perBatch_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8576 + i*4, 4)))
, "_worker.workers": new Uint8Array(memoryExport.buffer, 8704, 24576)
, "_worker.workers_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 8704 + i*24576, 24576)))
, "_worker.stack": new Uint8Array(memoryExport.buffer, 33280, 4)
, "_worker.stack_chunks": Object.freeze(Array.from({length: 1},(_,i)=>new Uint8Array(memoryExport.buffer, 33280 + i*4, 4)))
});

return Object.freeze({ ..._exports, memory: memoryExport, segments , workers, initWorkers });}