/**
 * Abstract logic for hashes.
 * @module
 */
import { abool, abytes, anumber, clean, concatBytes, copyBytes, copyFast, isBytes, mkAsync, } from "./utils.js";
const checkParallelOutput = (opts, count, outputLen, canXOF) => {
    const raw = (isBytes(opts) ? {} : opts || {});
    if (raw.dkLen !== undefined)
        anumber(raw.dkLen, 'opts.dkLen');
    if (raw.outPos !== undefined)
        anumber(raw.outPos, 'opts.outPos');
    const dkLen = (raw.dkLen === undefined ? outputLen : raw.dkLen) | 0;
    if (!canXOF && dkLen > outputLen)
        throw new RangeError(`"opts.dkLen" expected <= ${outputLen}, got ${dkLen}`);
    if (Array.isArray(raw.out)) {
        if (raw.outPos !== undefined && raw.outPos !== 0)
            throw new Error('outPos is not supported with output view arrays');
        if (raw.out.length !== count)
            throw new RangeError('output array length must match messages length');
        for (let i = 0; i < count; i++)
            abytes(raw.out[i], dkLen, 'output');
        return { dkLen, out: raw.out };
    }
    if (raw.out !== undefined)
        abytes(raw.out, undefined, 'output');
    const out = raw.out || new Uint8Array(dkLen * count);
    const outPos = (raw.outPos === undefined ? 0 : raw.outPos) | 0;
    if (outPos < 0 || outPos + dkLen * count > out.length)
        throw new RangeError('out/outPos too small');
    const slices = [];
    for (let i = 0; i < count; i++) {
        const pos = outPos + i * dkLen;
        slices.push(out.subarray(pos, pos + dkLen));
    }
    return { dkLen, out: slices };
};
const BRAND = /* @__PURE__ */ Symbol('hash_impl_brand');
const brandSet = /* @__PURE__ */ new WeakSet();
function isBranded(x) {
    return typeof x === 'function' || (typeof x === 'object' && x !== null)
        ? brandSet.has(x)
        : false;
}
// Universal generic wrapper
export function mkHash(modFn, def_, platform) {
    const def = def_;
    const { outputLen, blockLen, suffix = 0, init, canXOF, oid } = def;
    const outBlockLen = def.outputBlockLen ? def.outputBlockLen : def.outputLen;
    let hashImpl;
    let hashAsyncImpl;
    let chunksImpl;
    let chunksAsyncImpl;
    let parallelImpl;
    let parallelAsyncImpl;
    let createImpl;
    let cleanStateImpl;
    let inited = false;
    function lazyInit() {
        if (inited)
            throw new Error('second lazyInit call');
        const mod = modFn();
        inited = true;
        const { processBlocks, processOutBlocks, padding, reset } = mod;
        const BUFFER = mod.segments.buffer;
        const STATE = mod.segments.state_chunks[0];
        const STATE_CHUNKS = mod.segments.state_chunks;
        const parallelChunks = mod.segments.state_chunks.length;
        const maxBlocks = Math.floor(BUFFER.length / blockLen);
        const chunks = maxBlocks - 2; // 2 for padding
        if (chunks < 1)
            throw new Error('wrong chunks');
        const maxOutBlocks = Math.floor(BUFFER.length / outBlockLen);
        const prefixStates = new WeakSet();
        function initHash(opts, batchPos = 0) {
            const rawOpts = opts;
            reset(batchPos, 1, 0, outBlockLen, maxOutBlocks);
            let blocks = 0;
            let streamOutputLen = outputLen;
            if (rawOpts.dkLen !== undefined) {
                anumber(rawOpts.dkLen, 'opts.dkLen');
                streamOutputLen = rawOpts.dkLen | 0;
                if (!canXOF && streamOutputLen > outputLen)
                    throw new RangeError(`"opts.dkLen" expected <= ${outputLen}, got ${streamOutputLen}`);
            }
            if (init) {
                const i = init(batchPos, maxBlocks, mod, hash, rawOpts);
                if (i && i.blocks !== undefined)
                    blocks = i.blocks;
                if (i && i.outputLen !== undefined)
                    streamOutputLen = i.outputLen;
            }
            return { blocks, outputLen: streamOutputLen };
        }
        //  reset(0, 1);
        function processMessage(msg, blocks) {
            // Preloaded blocks from init(): e.g., keyed BLAKE2 writes key||zeros into BUFFER
            // Invariant: these are full blocks, already in BUFFER, and must *not* be treated as 'last'.
            if (blocks > 0) {
                if (msg.length === 0) {
                    const padBlocks = padding(0, blocks * blockLen, maxBlocks, 0, blockLen, suffix);
                    processBlocks(0, 1, blocks + padBlocks, maxBlocks, blockLen, 1, 0, padBlocks);
                    return;
                }
                processBlocks(0, 1, blocks, maxBlocks, blockLen, 0, 0, 0);
            }
            let pos = 0;
            do {
                const take = Math.min(msg.length - pos, chunks * blockLen);
                copyFast(BUFFER, 0, msg, pos, take);
                const isLast = pos + take == msg.length;
                // How many full/partial blocks do we have here? Can be zero.
                let blocks = Math.ceil(take / blockLen);
                // now, we need position where we add padding? take?
                // How much space remains? blockLen-rem, except rem=0.
                const left = blocks * blockLen - take;
                let padBlocks = 0;
                if (isLast) {
                    // suffix for sha3 and length for blake1, nothing for others
                    padBlocks = padding(0, take, maxBlocks, left, blockLen, suffix);
                    blocks += padBlocks;
                }
                processBlocks(0, 1, blocks, maxBlocks, blockLen, isLast ? 1 : 0, left, padBlocks);
                pos += take;
            } while (pos < msg.length); // no extra final take=0 pass
        }
        function processMessages(parts, blocks, prefix) {
            // TODO: cleanup, garbage.
            const cap = (chunks * blockLen) | 0; // max bytes per batch
            // total length to keep isLast identical to single-buffer path
            const prefixLen = prefix ? prefix.buf.length : 0;
            let totalLen = prefixLen;
            for (let k = 0; k < parts.length; k++)
                totalLen += parts[k].length;
            // Preloaded blocks from init():
            // those are full blocks, already in BUFFER, and must NOT be treated as 'last'.
            if (blocks > 0) {
                if (totalLen === 0) {
                    const padBlocks = padding(0, blocks * blockLen, maxBlocks, 0, blockLen, suffix);
                    processBlocks(0, 1, blocks + padBlocks, maxBlocks, blockLen, 1, 0, padBlocks);
                    return;
                }
                processBlocks(0, 1, blocks, maxBlocks, blockLen, 0, 0, 0);
            }
            let pos = 0; // global position in virtual concatenation
            let idx = 0; // which part
            let off = 0; // offset within current part
            while (pos < totalLen) {
                const take = Math.min(totalLen - pos, cap) | 0;
                // fill BUFFER[0..take) from parts[idx..] without concat
                let written = 0;
                if (prefix && pos < prefixLen) {
                    const n = Math.min(take, prefixLen - pos) | 0;
                    copyFast(BUFFER, written, prefix.buf, pos, n);
                    written += n;
                }
                while (written < take) {
                    const cur = parts[idx];
                    const rem = (cur.length - off) | 0;
                    const n = (take - written < rem ? take - written : rem) | 0;
                    copyFast(BUFFER, written, cur, off, n);
                    written += n;
                    off += n;
                    if (off === cur.length) {
                        idx++;
                        off = 0;
                    }
                }
                const isLast = pos + take === totalLen;
                let blocks = Math.ceil(take / blockLen) | 0;
                const left = (blocks * blockLen - take) | 0;
                let padBlocks = 0;
                if (isLast) {
                    padBlocks = padding(0, take, maxBlocks, left, blockLen, suffix) | 0;
                    blocks = (blocks + padBlocks) | 0;
                }
                processBlocks(0, 1, blocks, maxBlocks, blockLen, isLast ? 1 : 0, left, padBlocks);
                pos += take;
            }
            return;
        }
        // same as processMessage but with chunkPos.
        function processMessageParallel(msg, chunkPos, chunkLen, blocks, maxBlocks, prefix) {
            const chunks = maxBlocks - 2;
            if (chunks < 1)
                throw new Error('wrong chunks');
            const prefixLen = prefix ? prefix.buf.length : 0;
            const msgLen = msg[chunkPos].length;
            const totalLen = prefixLen + msgLen;
            const copyLane = (dst, lane, pos, take) => {
                let written = 0;
                if (prefix && pos < prefixLen) {
                    const n = Math.min(take, prefixLen - pos);
                    copyFast(BUFFER, dst, prefix.buf, pos, n);
                    written += n;
                }
                if (written < take)
                    copyFast(BUFFER, dst + written, lane, pos + written - prefixLen, take - written);
            };
            // Caller validates per-group size equality before touching module state.
            if (blocks > 0) {
                if (totalLen === 0) {
                    // No more message input: do a normal finalization over an empty tail.
                    // Keep 'left' consistent with the wrapper contract for take=0: left=0.
                    const padBlocks = padding(0, blocks * blockLen, maxBlocks, 0, blockLen, suffix);
                    for (let j = 0; j < chunkLen; j++) {
                        const pb2 = padding(j, blocks * blockLen, maxBlocks, 0, blockLen, suffix);
                        if (pb2 !== padBlocks)
                            throw new Error('different padding across batch');
                    }
                    processBlocks(0, chunkLen, blocks + padBlocks, maxBlocks, blockLen, 1, 0, padBlocks);
                    return;
                }
                processBlocks(0, chunkLen, blocks, maxBlocks, blockLen, 0, 0, 0);
            }
            let pos = 0;
            do {
                const take = Math.min(totalLen - pos, chunks * blockLen);
                for (let i = 0; i < chunkLen; i++) {
                    copyLane(i * maxBlocks * blockLen, msg[chunkPos + i], pos, take);
                }
                const isLast = pos + take == totalLen;
                // How many full/partial blocks do we have here? Can be zero.
                let blocks = Math.ceil(take / blockLen);
                // How much space remains? blockLen-rem, except rem=0.
                const left = blocks * blockLen - take;
                let padBlocks = 0;
                if (isLast) {
                    // suffix for sha3 and length for blake1, nothing for others
                    padBlocks = padding(0, take, maxBlocks, left, blockLen, suffix);
                    for (let j = 1; j < chunkLen; j++) {
                        const pb2 = padding(j, take, maxBlocks, left, blockLen, suffix);
                        if (pb2 !== padBlocks)
                            throw new Error('parallel batch: different padding');
                    }
                    blocks += padBlocks;
                }
                processBlocks(0, chunkLen, blocks, maxBlocks, blockLen, isLast ? 1 : 0, left, padBlocks);
                pos += take;
            } while (pos < totalLen); // no extra final take=0 pass
            return;
        }
        function checkOutputOpts(o = {}, bytes, defaultLen = outputLen) {
            const raw = o;
            if (raw.dkLen !== undefined)
                anumber(raw.dkLen, 'opts.dkLen');
            if (raw.outPos !== undefined)
                anumber(raw.outPos, 'opts.outPos');
            if (raw.out !== undefined)
                abytes(raw.out, undefined, 'output');
            if (bytes !== undefined)
                anumber(bytes, 'xof.bytes');
            let dkLen = bytes !== undefined ? bytes : (raw.dkLen === undefined ? defaultLen : raw.dkLen) | 0;
            // Old awasm hash output opts intentionally allow requesting a shorter fixed digest, but
            // must reject oversize lengths instead of silently clamping or zero-extending the tail.
            if (!canXOF && dkLen > outputLen)
                throw new RangeError(`"opts.dkLen" expected <= ${outputLen}, got ${dkLen}`);
            const out = raw.out || new Uint8Array(dkLen);
            const outPos = (raw.outPos === undefined ? 0 : raw.outPos) | 0;
            if (outPos < 0 || outPos + dkLen > out.length)
                throw new RangeError('out/outPos too small');
            return { dkLen, out: out, outPos };
        }
        function processOutput(o = {}, checked = checkOutputOpts(o)) {
            const { dkLen, out, outPos } = checked;
            const batch = chunks | 0;
            const blocksTotal = ((dkLen + outBlockLen - 1) / outBlockLen) | 0; // ceil div
            let produced = 0, blocksLeft = blocksTotal;
            let maxWritten = 0;
            while (blocksLeft > 0) {
                const takeBlocks = blocksLeft > batch ? batch : blocksLeft;
                const isLast = blocksLeft === takeBlocks ? 1 : 0;
                processOutBlocks(0, 1, takeBlocks, maxOutBlocks, outBlockLen, isLast);
                const emitted = takeBlocks * outBlockLen;
                const need = dkLen - produced;
                const takeBytes = need < emitted ? need : emitted;
                copyFast(out, outPos + produced, BUFFER, 0, takeBytes);
                maxWritten = Math.max(maxWritten, takeBytes, takeBlocks * outBlockLen);
                produced += takeBytes;
                blocksLeft -= takeBlocks;
            }
            // NOTE: it would be nice to return slices subarray here, but it is not free!
            return { maxWritten, out };
        }
        function processOutputParallel(chunkLen, maxOutBlocks, checked, outOffset) {
            const chunks = maxOutBlocks;
            const { dkLen, out } = checked;
            let maxWritten = 0;
            const batch = chunks | 0;
            const blocksTotal = ((dkLen + outBlockLen - 1) / outBlockLen) | 0; // ceil div
            let produced = 0, blocksLeft = blocksTotal;
            while (blocksLeft > 0) {
                const takeBlocks = blocksLeft > batch ? batch : blocksLeft;
                const isLast = blocksLeft === takeBlocks ? 1 : 0;
                processOutBlocks(0, chunkLen, takeBlocks, maxOutBlocks, outBlockLen, isLast);
                const emitted = takeBlocks * outBlockLen;
                const need = dkLen - produced;
                const takeBytes = need < emitted ? need : emitted;
                for (let i = 0; i < chunkLen; i++) {
                    copyFast(out[outOffset + i], produced, BUFFER, i * outBlockLen * maxOutBlocks, takeBytes);
                    // Some modules (e.g. blake3) may write full output blocks even when only part is copied out.
                    // Track emitted block span for reset() so unread bytes are also zeroized.
                    maxWritten = Math.max(maxWritten, takeBytes, emitted);
                }
                produced += takeBytes;
                blocksLeft -= takeBlocks;
            }
            // NOTE: it would be nice to return slices subarray here, but it is not free!
            return { out, maxWritten };
        }
        const stateBytes = (state) => {
            if (!isBytes(state))
                throw new Error('prefixState is not from this hash');
            if (state.length < STATE.length)
                throw new Error('prefixState is too short');
            // Byte-state backends serialize only `state || partialBlock`; a full block must be flushed.
            if (state.length >= STATE.length + blockLen)
                throw new Error('prefixState is too long');
            if (!prefixStates.has(state))
                throw new Error('prefixState is not from this hash');
            return state;
        };
        const prefixState = (opts = {}) => {
            const raw = opts;
            if (raw.prefixState === undefined)
                return;
            const state = stateBytes(raw.prefixState);
            return { state: state.subarray(0, STATE.length), buf: state.subarray(STATE.length) };
        };
        class StreamHash {
            canXOF;
            blockLen;
            outputLen;
            buf;
            pos;
            state;
            finished;
            destroyed;
            constructor(opts) {
                if (opts.streamBufLen % blockLen || opts.streamBufLen < blockLen)
                    throw new Error('wrong streamBufLen');
                this.finished = false;
                this.destroyed = false;
                //   this.reserve = blockLen; // TODO: change when sha2
                this.buf = new Uint8Array(opts.streamBufLen);
                this.pos = 0;
                if (opts.blocks !== undefined) {
                    if (opts.blocks * blockLen > this.buf.length)
                        throw new Error('too much blocks');
                    copyFast(this.buf, 0, BUFFER, 0, opts.blocks * blockLen);
                    this.pos = opts.blocks * blockLen;
                }
                this.canXOF = !!canXOF;
                this.blockLen = blockLen;
                this.outputLen = opts.outputLen;
                this.state = copyBytes(STATE);
                reset(0, 1, 0, outBlockLen, maxOutBlocks); // cleanup
            }
            restoreState() {
                copyFast(STATE, 0, this.state, 0, STATE.length);
            }
            saveState() {
                this.state = copyBytes(STATE);
            }
            update(msg) {
                abytes(msg);
                if (this.destroyed)
                    throw new Error('Hash instance has been destroyed');
                if (this.finished)
                    throw new Error('Hash#digest() has already been called');
                let msgPos = 0;
                let blocks = Math.ceil((this.pos + msg.length) / blockLen) - 1; // never process last block here!
                if (blocks > 0) {
                    this.restoreState();
                    let takeBlocks = Math.min(chunks, blocks);
                    // first can be unaligned!
                    const msgFirstLen = takeBlocks * blockLen - this.pos;
                    copyFast(BUFFER, 0, this.buf, 0, this.pos);
                    copyFast(BUFFER, this.pos, msg, msgPos, msgFirstLen);
                    this.pos = 0;
                    msgPos += msgFirstLen;
                    processBlocks(0, 1, takeBlocks, maxBlocks, blockLen, 0, 0, 0);
                    blocks -= takeBlocks;
                    for (; msgPos < msg.length && blocks;) {
                        const takeBlocks = Math.min(chunks, blocks);
                        copyFast(BUFFER, 0, msg, msgPos, takeBlocks * blockLen);
                        processBlocks(0, 1, takeBlocks, maxBlocks, blockLen, 0, 0, 0);
                        blocks -= takeBlocks;
                        msgPos += takeBlocks * blockLen;
                    }
                    this.saveState();
                    reset(0, 1, 0, outBlockLen, maxOutBlocks);
                }
                // save leftovers
                const leftover = msg.length - msgPos;
                if (leftover) {
                    copyFast(this.buf, this.pos, msg, msgPos, leftover);
                    this.pos += leftover;
                }
                return this;
            }
            finish() {
                if (this.finished)
                    throw new Error('Hash#digest() has already been called');
                this.restoreState();
                this.finished = true;
                const isLast = true;
                let take = this.pos;
                let blocks = Math.ceil(take / blockLen);
                copyFast(BUFFER, 0, this.buf, 0, this.pos);
                const left = blocks * blockLen - take; // how much space we have. blockLen-rem except when rem=0
                let padBlocks = 0;
                if (isLast) {
                    padBlocks = padding(0, take, maxBlocks, left, blockLen, suffix); // suffix for sha3 and length for blake1, nothing for others
                    blocks += padBlocks;
                }
                processBlocks(0, 1, blocks, maxBlocks, blockLen, 1, left, padBlocks);
                this.pos = outBlockLen;
                return blocks * blockLen;
            }
            digest(opts = {}) {
                if (this.destroyed)
                    throw new Error('Hash instance has been destroyed');
                const outChecked = checkOutputOpts(opts, undefined, this.outputLen);
                this.finish();
                const { out: res, maxWritten } = processOutput(opts, outChecked);
                this.destroy();
                reset(0, 1, maxWritten, outBlockLen, maxOutBlocks);
                return res;
            }
            /**
             * Resets internal state. Makes Hash instance unusable.
             * Reset is impossible for keyed hashes if key is consumed into state. If digest is not consumed
             * by user, they will need to manually call `destroy()` when zeroing is necessary.
             */
            destroy() {
                this.destroyed = true;
                this.state.fill(0);
                this.buf.fill(0);
            }
            xof(bytes, opts = {}) {
                if (!canXOF)
                    throw new Error('XOF is not possible for this instance');
                if (this.destroyed)
                    throw new Error('Hash instance has been destroyed');
                const outChecked = checkOutputOpts(opts, bytes);
                if (!this.finished) {
                    this.finish();
                    this.saveState();
                }
                // XOF mutates module state via processOutBlocks(). Snapshot/restore around calls so
                // stream instances don't leak squeeze state into global hash wrappers.
                this.restoreState();
                const { out, outPos } = outChecked;
                for (let pos = 0; pos < bytes;) {
                    if (this.pos >= outBlockLen) {
                        // get next squeeze block
                        processOutBlocks(0, 1, 1, maxOutBlocks, outBlockLen, 0); // never 'last' in XOF
                        copyFast(this.buf, 0, BUFFER, 0, outBlockLen);
                        this.pos = 0;
                    }
                    const take = (outBlockLen - this.pos < bytes - pos ? outBlockLen - this.pos : bytes - pos) | 0;
                    copyFast(out, (outPos + pos) | 0, this.buf, this.pos, take);
                    this.pos = (this.pos + take) | 0;
                    pos = (pos + take) | 0;
                }
                this.saveState();
                reset(0, 1, 0, outBlockLen, maxOutBlocks);
                return out;
            }
            // old api
            digestInto(buf) {
                // digestInto is the fixed-size surface even for XOF hashes, but callers may provide a
                // larger workspace buffer and expect the tail to stay untouched.
                abytes(buf, undefined, 'output');
                if (buf.length < this.outputLen)
                    // Keep short digest destinations aligned with the shared noble-hashes contract:
                    // wrong output type -> TypeError, too-short output -> RangeError.
                    throw new RangeError('digestInto() expects output buffer of length at least ' + this.outputLen);
                this.digest({ out: buf.subarray(0, this.outputLen), dkLen: this.outputLen });
            }
            xofInto(buf) {
                return this.xof(buf.length, { out: buf });
            }
            /**
             * Clones hash instance. Unsafe: doesn't check whether `to` is valid. Can be used as `clone()`
             * when no options are passed.
             * Reasons to use `_cloneInto` instead of clone: 1) performance 2) reuse instance => all internal
             * buffers are overwritten => causes buffer overwrite which is used for digest in some cases.
             * There are no guarantees for clean-up because it's impossible in JS.
             */
            _cloneInto(to) {
                if (this.destroyed)
                    throw new Error('Hash instance has been destroyed');
                // Allocate target if needed (ensure same stream buffer capacity).
                const dst = to || new this.constructor({ streamBufLen: this.buf.length });
                if (!(dst instanceof StreamHash))
                    throw new Error('wrong instance');
                if (dst.buf.length !== this.buf.length)
                    throw new Error('wrong buffer length');
                // Clones must preserve the public stream metadata too. digest()/digestInto() allocate and
                // validate against outputLen, xof()/xofInto() gate on canXOF, and callers may read blockLen.
                dst.blockLen = this.blockLen;
                dst.outputLen = this.outputLen;
                dst.canXOF = this.canXOF;
                // Copy tail / XOF cache content up to bufPos.
                if (this.pos)
                    copyFast(dst.buf, 0, this.buf, 0, this.pos);
                dst.pos = this.pos | 0;
                // Snapshot of full engine state used by restoreState().
                dst.state = copyBytes(this.state);
                // Flags
                dst.finished = !!this.finished;
                dst.destroyed = !!this.destroyed;
                return dst;
            }
            // Safe version that clones internal state
            clone() {
                return this._cloneInto();
            }
            exportState() {
                if (this.destroyed)
                    throw new Error('Hash instance has been destroyed');
                if (this.finished)
                    throw new Error('Hash#digest() has already been called');
                // update() keeps one full tail block unprocessed for finalization; export must absorb it
                // so a full-block prefix is represented only by the engine state plus a short leftover.
                if (this.pos === blockLen) {
                    this.restoreState();
                    copyFast(BUFFER, 0, this.buf, 0, blockLen);
                    processBlocks(0, 1, 1, maxBlocks, blockLen, 0, 0, 0);
                    this.saveState();
                    this.pos = 0;
                    this.buf.fill(0);
                    reset(0, 1, 0, outBlockLen, maxOutBlocks);
                }
                // Returned bytes are exactly `state || partialBlock`, with no outputLen, pos, or header.
                const out = new Uint8Array(this.state.length + this.pos);
                out.set(this.state);
                if (this.pos)
                    out.set(this.buf.subarray(0, this.pos), this.state.length);
                prefixStates.add(out);
                return out;
            }
        }
        const hashSync = (msg, opts = {}) => {
            abytes(msg);
            const outChecked = checkOutputOpts(opts);
            const { blocks } = initHash(opts);
            processMessage(msg, blocks);
            const { out: res, maxWritten } = processOutput(opts, outChecked);
            reset(0, 1, maxWritten, outBlockLen, maxOutBlocks);
            return res;
        };
        const chunksSync = (parts, opts = {}) => {
            if (!Array.isArray(parts))
                throw new Error('expected array of messages');
            let total = 0;
            for (const p of parts) {
                abytes(p);
                total += p.length;
            }
            const prefix = prefixState(opts);
            if (prefix && total === 0)
                throw new Error('prefixState requires a non-empty message');
            const outChecked = checkOutputOpts(opts);
            if (prefix) {
                reset(0, 1, 0, outBlockLen, maxOutBlocks);
                copyFast(STATE, 0, prefix.state, 0, prefix.state.length);
                processMessages(parts, 0, prefix);
            }
            else {
                const { blocks } = initHash(opts);
                processMessages(parts, blocks);
            }
            const { out: res, maxWritten } = processOutput(opts, outChecked);
            reset(0, 1, maxWritten, outBlockLen, maxOutBlocks);
            return res;
        };
        const parallelSync = (chunks, opts = {}) => {
            if (!Array.isArray(chunks))
                throw new Error('expected array of messages');
            const prefix = prefixState(opts);
            if (prefix && chunks.length === 0)
                throw new Error('prefixState requires a non-empty message');
            // At least 3 blocks (for padding).
            const maxGroups = Math.floor(BUFFER.length / (blockLen * 3));
            const maxOutGroups = Math.floor(BUFFER.length / outBlockLen);
            // Validate user input first. Wrong input must throw before touching module state/memory.
            for (let i = 0; i < chunks.length; i += parallelChunks) {
                const groupLen = Math.min(parallelChunks, chunks.length - i, maxGroups, maxOutGroups);
                for (let j = 0; j < groupLen; j++)
                    if (!isBytes(chunks[i + j]))
                        throw new Error(`expected Uint8Array, got type=${typeof chunks[i + j]}`);
                if (prefix && chunks[i].length === 0)
                    throw new Error('prefixState requires a non-empty message');
                for (let j = 1; j < groupLen; j++) {
                    if (chunks[i + j].length !== chunks[i].length)
                        throw new Error('different sizes inside chunk');
                }
            }
            const outChecked = checkParallelOutput(opts, chunks.length, outputLen, canXOF);
            for (let i = 0; i < chunks.length; i += parallelChunks) {
                const groupLen = Math.min(parallelChunks, chunks.length - i, maxGroups, maxOutGroups);
                const maxBlocks = Math.floor(BUFFER.length / (blockLen * groupLen));
                const maxOutBlocks = Math.floor(BUFFER.length / (outBlockLen * groupLen));
                let blocks = 0;
                if (prefix) {
                    reset(0, groupLen, 0, outBlockLen, maxOutBlocks);
                    for (let j = 0; j < groupLen; j++)
                        copyFast(STATE_CHUNKS[j], 0, prefix.state, 0, prefix.state.length);
                }
                else if (init) {
                    const i = init(0, maxBlocks, mod, hash, opts);
                    if (i && i.blocks !== undefined)
                        blocks = i.blocks;
                    for (let j = 0; j < groupLen; j++) {
                        const t = init(j, maxBlocks, mod, hash, opts);
                        if ((t && t.blocks) !== (i && i.blocks))
                            throw new Error('inconsistent init blocks inside parallel group');
                    }
                }
                processMessageParallel(chunks, i, groupLen, blocks, maxBlocks, prefix);
                const { maxWritten } = processOutputParallel(groupLen, maxOutBlocks, outChecked, i);
                reset(0, groupLen, maxWritten, outBlockLen, maxOutBlocks);
            }
            return outChecked.out;
        };
        const setupTick = (setup, total, opts) => {
            const rawSetup = setup;
            const rawOpts = opts;
            return !rawSetup.isAsync
                ? !rawOpts?.onProgress
                    ? (rawSetup({ total: 0 }), (_inc) => false)
                    : rawSetup({ total, onProgress: rawOpts.onProgress })
                : rawSetup({
                    total,
                    asyncTick: rawOpts?.asyncTick,
                    onProgress: rawOpts?.onProgress,
                    nextTick: rawOpts?.nextTick,
                });
        };
        const hashRun = mkAsync(function* (setup, msg, opts = {}) {
            const setupMode = setup;
            if (!setupMode.isAsync && !opts?.onProgress)
                return hashSync(msg, opts);
            const tick = setupTick(setupMode, msg.length, opts);
            const out = hashSync(msg, opts);
            if ((setupMode.isAsync || !!opts?.onProgress) && tick(msg.length))
                yield;
            return out;
        });
        const chunksRun = mkAsync(function* (setup, parts, opts = {}) {
            const setupMode = setup;
            if (!setupMode.isAsync && !opts?.onProgress)
                return chunksSync(parts, opts);
            let total = 0;
            for (const p of parts)
                total += p.length;
            const tick = setupTick(setupMode, total, opts);
            const out = chunksSync(parts, opts);
            if ((setupMode.isAsync || !!opts?.onProgress) && tick(total))
                yield;
            return out;
        });
        const parallelRun = mkAsync(function* (setup, parts, opts = {}) {
            const setupMode = setup;
            if (!setupMode.isAsync && !opts?.onProgress)
                return parallelSync(parts, opts);
            let total = 0;
            for (const p of parts)
                total += p.length;
            const tick = setupTick(setupMode, total, opts);
            const out = parallelSync(parts, opts);
            if ((setupMode.isAsync || !!opts?.onProgress) && tick(total))
                yield;
            return out;
        });
        hashImpl = (msg, opts = {}) => hashSync(msg, opts);
        hashAsyncImpl = async (msg, opts) => {
            const rawOpts = opts;
            if (!rawOpts)
                return hashSync(msg, {});
            return rawOpts.asyncTick !== undefined ||
                rawOpts.onProgress !== undefined ||
                rawOpts.nextTick !== undefined
                ? hashRun.async(msg, rawOpts)
                : hashSync(msg, rawOpts);
        };
        chunksImpl = (parts, opts = {}) => chunksSync(parts, opts);
        chunksAsyncImpl = async (parts, opts) => {
            const rawOpts = opts;
            if (!rawOpts)
                return chunksSync(parts, {});
            return rawOpts.asyncTick !== undefined ||
                rawOpts.onProgress !== undefined ||
                rawOpts.nextTick !== undefined
                ? chunksRun.async(parts, rawOpts)
                : chunksSync(parts, rawOpts);
        };
        parallelImpl = (parts, opts = {}) => parallelSync(parts, opts);
        parallelAsyncImpl = async (parts, opts) => {
            const rawOpts = opts;
            if (!rawOpts)
                return parallelSync(parts, {});
            return rawOpts.asyncTick !== undefined ||
                rawOpts.onProgress !== undefined ||
                rawOpts.nextTick !== undefined
                ? parallelRun.async(parts, rawOpts)
                : parallelSync(parts, rawOpts);
        };
        createImpl = (opts = {}) => {
            const rawOpts = opts;
            reset(0, 1, 0, outBlockLen, maxOutBlocks);
            const { blocks, outputLen } = initHash(rawOpts);
            return new StreamHash({ ...rawOpts, streamBufLen: blockLen, blocks, outputLen });
        };
        cleanStateImpl = (state) => {
            const bytes = stateBytes(state);
            clean(bytes);
            prefixStates.delete(bytes);
        };
    }
    // Trampoline: init only on first usage
    hashImpl = (msg, opts) => {
        lazyInit();
        return hashImpl(msg, opts);
    };
    hashAsyncImpl = (msg, opts) => {
        lazyInit();
        return hashAsyncImpl(msg, opts);
    };
    chunksImpl = (parts, opts) => {
        lazyInit();
        return chunksImpl(parts, opts);
    };
    chunksAsyncImpl = (parts, opts) => {
        lazyInit();
        return chunksAsyncImpl(parts, opts);
    };
    parallelImpl = (chunks, opts) => {
        lazyInit();
        return parallelImpl(chunks, opts);
    };
    parallelAsyncImpl = (chunks, opts) => {
        lazyInit();
        return parallelAsyncImpl(chunks, opts);
    };
    createImpl = (opts) => {
        lazyInit();
        return createImpl(opts);
    };
    cleanStateImpl = (state) => {
        lazyInit();
        return cleanStateImpl(state);
    };
    const hash = ((msg, opts = {}) => hashImpl(msg, opts));
    const chunksFn = (parts, opts = {}) => chunksImpl(parts, opts);
    Object.assign(chunksFn, {
        async: (parts, opts) => chunksAsyncImpl(parts, opts),
    });
    const parallel = (chunks, opts = {}) => parallelImpl(chunks, opts);
    Object.assign(parallel, {
        async: (chunks, opts) => parallelAsyncImpl(chunks, opts),
    });
    Object.assign(hash, {
        async: (msg, opts) => hashAsyncImpl(msg, opts),
        chunks: chunksFn,
        parallel,
        create: (opts = {}) => createImpl(opts),
        cleanState: (state) => cleanStateImpl(state),
        getPlatform: () => platform,
        getDefinition: () => def,
        canXOF: !!canXOF,
        outputLen,
        blockLen,
        oid,
    });
    Object.defineProperty(hash, BRAND, { value: true, enumerable: false });
    brandSet.add(hash);
    return Object.freeze(hash);
}
export function mkHashNoble(def_, impl_, platform = 'noble') {
    const def = def_;
    const impl = impl_;
    const { outputLen, blockLen, canXOF, oid } = def;
    const rawOutputOpts = (opts) => (isBytes(opts) ? {} : opts || {});
    const hasOutputOpts = (opts) => {
        const raw = rawOutputOpts(opts);
        return raw.dkLen !== undefined || raw.out !== undefined || raw.outPos !== undefined;
    };
    const prefixStates = new WeakSet();
    const stateStream = (state) => {
        if ((typeof state !== 'object' && typeof state !== 'function') || state === null)
            throw new Error('prefixState is not from this hash');
        const stream = state;
        if (!prefixStates.has(stream))
            throw new Error('prefixState is not from this hash');
        return stream;
    };
    const prefixState = (opts) => {
        const raw = rawOutputOpts(opts);
        if (raw.prefixState === undefined)
            return;
        return stateStream(raw.prefixState);
    };
    const checkOutput = (opts, bytes, defaultLen = outputLen) => {
        const raw = rawOutputOpts(opts);
        if (raw.dkLen !== undefined)
            anumber(raw.dkLen, 'opts.dkLen');
        if (raw.outPos !== undefined)
            anumber(raw.outPos, 'opts.outPos');
        if (raw.out !== undefined)
            abytes(raw.out, undefined, 'output');
        if (bytes !== undefined)
            anumber(bytes, 'xof.bytes');
        const dkLen = (bytes !== undefined ? bytes : raw.dkLen === undefined ? defaultLen : raw.dkLen) | 0;
        if (!canXOF && dkLen > outputLen)
            throw new RangeError(`"opts.dkLen" expected <= ${outputLen}, got ${dkLen}`);
        const hasOut = raw.out !== undefined;
        const out = raw.out || new Uint8Array(dkLen);
        const outPos = (raw.outPos === undefined ? 0 : raw.outPos) | 0;
        if (outPos < 0 || outPos + dkLen > out.length)
            throw new RangeError('out/outPos too small');
        return { dkLen, out: out, outPos, hasOut };
    };
    const writeInto = (inner, out, dkLen, tmp) => {
        const rawInner = inner;
        const rawOut = out;
        let rawTmp = tmp;
        if (canXOF) {
            rawInner.xofInto(rawOut.subarray(0, dkLen));
            return rawTmp;
        }
        // noble BLAKE2 streams require aligned digestInto() views, but awasm outPos is byte-granular.
        if (dkLen === outputLen && (rawOut.byteOffset & 3) === 0)
            rawInner.digestInto(rawOut);
        else {
            if (!rawTmp || rawTmp.length < outputLen)
                rawTmp = new Uint8Array(outputLen);
            rawInner.digestInto(rawTmp);
            if (dkLen)
                copyFast(rawOut, 0, rawTmp, 0, dkLen);
        }
        return rawTmp;
    };
    class Stream {
        canXOF = !!canXOF;
        blockLen = blockLen;
        outputLen;
        inner;
        constructor(inner, outputLen) {
            this.inner = inner;
            this.outputLen = outputLen;
        }
        update(msg) {
            abytes(msg);
            this.inner.update(msg);
            return this;
        }
        digest(opts) {
            if (!hasOutputOpts(opts) && !canXOF && this.outputLen === outputLen)
                return this.inner.digest();
            const checked = checkOutput(opts, undefined, this.outputLen);
            const tmp = writeInto(this.inner, checked.out.subarray(checked.outPos, checked.outPos + checked.dkLen), checked.dkLen);
            if (tmp)
                clean(tmp);
            return checked.out;
        }
        destroy() {
            this.inner.destroy();
        }
        xof(bytes, opts) {
            if (!canXOF)
                throw new Error('XOF is not possible for this instance');
            if (!hasOutputOpts(opts)) {
                anumber(bytes, 'xof.bytes');
                if (this.inner.xof)
                    return this.inner.xof(bytes);
                const out = new Uint8Array(bytes);
                this.inner.xofInto(out);
                return out;
            }
            const checked = checkOutput(opts, bytes);
            this.inner.xofInto(checked.out.subarray(checked.outPos, checked.outPos + checked.dkLen));
            return checked.out;
        }
        digestInto(buf) {
            abytes(buf, undefined, 'output');
            if (buf.length < this.outputLen)
                throw new RangeError('digestInto() expects output buffer of length at least ' + this.outputLen);
            const tmp = writeInto(this.inner, buf.subarray(0, this.outputLen), this.outputLen);
            if (tmp)
                clean(tmp);
        }
        xofInto(buf) {
            abytes(buf, undefined, 'output');
            if (!canXOF)
                throw new Error('XOF is not possible for this instance');
            this.inner.xofInto(buf);
            return buf;
        }
        _cloneInto(to) {
            if (to !== undefined && !(to instanceof Stream))
                throw new Error('wrong instance');
            const inner = this.inner._cloneInto(to?.inner);
            if (to) {
                to.inner = inner;
                to.outputLen = this.outputLen;
                return to;
            }
            return new Stream(inner, this.outputLen);
        }
        clone() {
            return this._cloneInto();
        }
        exportState() {
            // Native noble streams may carry structured state, e.g. BLAKE3. The clone itself is the state.
            const state = this.inner._cloneInto();
            prefixStates.add(state);
            return state;
        }
    }
    const createSync = (opts = {}) => {
        if (!impl.create)
            throw new Error('streaming is not supported');
        const inner = impl.create(opts);
        const raw = rawOutputOpts(opts);
        if (raw.dkLen !== undefined)
            anumber(raw.dkLen, 'opts.dkLen');
        const fallback = inner.outputLen || outputLen;
        const len = raw.dkLen === undefined ? fallback : raw.dkLen;
        if (!canXOF && len > outputLen)
            throw new RangeError(`"opts.dkLen" expected <= ${outputLen}, got ${len}`);
        return new Stream(inner, len);
    };
    const hashSync = (msg, opts = {}) => {
        abytes(msg);
        const raw = rawOutputOpts(opts);
        if (raw.out === undefined &&
            raw.outPos === undefined &&
            (raw.dkLen === undefined || (canXOF && raw.dkLen !== undefined)))
            return impl.hash(msg, opts);
        const checked = checkOutput(opts);
        const res = impl.hash(msg, opts);
        const { dkLen, out, outPos, hasOut } = checked;
        if (res.length < dkLen)
            throw new RangeError('output is too small');
        if (!hasOut && res.length === dkLen)
            return res;
        if (dkLen)
            copyFast(out, outPos, res, 0, dkLen);
        if (out !== res)
            clean(res);
        return out;
    };
    const chunksSync = (parts, opts = {}) => {
        if (!Array.isArray(parts))
            throw new Error('expected array of messages');
        let total = 0;
        for (const p of parts) {
            abytes(p);
            total += p.length;
        }
        const prefix = prefixState(opts);
        if (prefix && total === 0)
            throw new Error('prefixState requires a non-empty message');
        if (prefix) {
            const h = new Stream(prefix._cloneInto(), outputLen);
            for (const p of parts)
                h.update(p);
            return h.digest(rawOutputOpts(opts));
        }
        if (impl.create) {
            const h = createSync(opts);
            for (const p of parts)
                h.update(p);
            return h.digest(rawOutputOpts(opts));
        }
        const joined = concatBytes(...parts);
        try {
            return hashSync(joined, opts);
        }
        finally {
            clean(joined);
        }
    };
    const parallelSync = (parts, opts = {}) => {
        if (!Array.isArray(parts))
            throw new Error('expected array of messages');
        for (const p of parts)
            abytes(p);
        const prefix = prefixState(opts);
        if (prefix && parts.length === 0)
            throw new Error('prefixState requires a non-empty message');
        if (prefix)
            for (const p of parts)
                if (p.length === 0)
                    throw new Error('prefixState requires a non-empty message');
        const checked = checkParallelOutput(opts, parts.length, outputLen, canXOF);
        let tmp;
        const base = prefix || (impl.create ? impl.create(opts) : undefined);
        let work;
        for (let i = 0; i < parts.length; i++) {
            const lane = checked.out[i];
            if (base) {
                work = base._cloneInto(work);
                work.update(parts[i]);
                tmp = writeInto(work, lane, checked.dkLen, tmp);
            }
            else {
                const outOpts = (isBytes(opts)
                    ? { key: opts, out: lane, outPos: 0, dkLen: checked.dkLen }
                    : { ...(opts || {}), out: lane, outPos: 0, dkLen: checked.dkLen });
                hashSync(parts[i], outOpts);
            }
        }
        if (tmp)
            clean(tmp);
        if (work)
            work.destroy();
        if (base && base !== prefix)
            base.destroy();
        return checked.out;
    };
    const setupTick = (setup, total, opts) => {
        const rawSetup = setup;
        const rawOpts = opts;
        return !rawSetup.isAsync
            ? !rawOpts?.onProgress
                ? (rawSetup({ total: 0 }), (_inc) => false)
                : rawSetup({ total, onProgress: rawOpts.onProgress })
            : rawSetup({
                total,
                asyncTick: rawOpts?.asyncTick,
                onProgress: rawOpts?.onProgress,
                nextTick: rawOpts?.nextTick,
            });
    };
    const hash = ((msg, opts = {}) => hashSync(msg, opts));
    const chunks = (parts, opts = {}) => chunksSync(parts, opts);
    Object.assign(chunks, {
        async: mkAsync(function* (setup, parts, opts = {}) {
            const setupMode = setup;
            const rawOpts = opts;
            if (!setupMode.isAsync && !rawOpts?.onProgress)
                return chunksSync(parts, rawOpts);
            let total = 0;
            for (const p of parts)
                total += p.length;
            const tick = setupTick(setupMode, total, rawOpts);
            const out = chunksSync(parts, rawOpts);
            if ((setupMode.isAsync || !!rawOpts?.onProgress) && tick(total))
                yield;
            return out;
        }).async,
    });
    const parallel = (parts, opts = {}) => parallelSync(parts, opts);
    Object.assign(parallel, {
        async: mkAsync(function* (setup, parts, opts = {}) {
            const setupMode = setup;
            const rawOpts = opts;
            if (!setupMode.isAsync && !rawOpts?.onProgress)
                return parallelSync(parts, rawOpts);
            let total = 0;
            for (const p of parts)
                total += p.length;
            const tick = setupTick(setupMode, total, rawOpts);
            const out = parallelSync(parts, rawOpts);
            if ((setupMode.isAsync || !!rawOpts?.onProgress) && tick(total))
                yield;
            return out;
        }).async,
    });
    Object.assign(hash, {
        async: mkAsync(function* (setup, msg, opts = {}) {
            const setupMode = setup;
            // TArg expands byte-like option unions here; keep the cast local to the async shim.
            const rawOpts = opts;
            if (!setupMode.isAsync && !rawOpts?.onProgress)
                return hashSync(msg, rawOpts);
            const tick = setupTick(setupMode, msg.length, rawOpts);
            const out = hashSync(msg, rawOpts);
            if ((setupMode.isAsync || !!rawOpts?.onProgress) && tick(msg.length))
                yield;
            return out;
        }).async,
        chunks,
        parallel,
        create: (opts = {}) => createSync(opts),
        cleanState(state) {
            const stream = stateStream(state);
            stream.destroy();
            prefixStates.delete(stream);
        },
        getPlatform: () => platform,
        getDefinition: () => def,
        canXOF: !!canXOF,
        outputLen,
        blockLen,
        oid,
    });
    Object.defineProperty(hash, BRAND, { value: true, enumerable: false });
    brandSet.add(hash);
    return Object.freeze(hash);
}
const copyOutput = (out, opts, outputLen, canXOF) => {
    const rawLen = opts?.dkLen;
    if (rawLen !== undefined)
        anumber(rawLen, 'dkLen');
    const dkLen = rawLen === undefined ? outputLen : rawLen;
    anumber(dkLen, 'dkLen');
    // Old awasm hash output opts intentionally allow requesting a shorter fixed digest, but
    // must reject oversize lengths instead of silently clamping or zero-extending the tail.
    if (!canXOF && dkLen > outputLen)
        throw new RangeError(`"dkLen" expected <= ${outputLen}, got ${dkLen}`);
    if (out.length < dkLen)
        throw new RangeError(`expected output length >= dkLen, got ${out.length}`);
    const msg = out.subarray(0, dkLen);
    if (!opts?.out) {
        const res = copyBytes(msg);
        clean(out);
        return res;
    }
    const outPos = opts?.outPos || 0;
    anumber(outPos, 'outPos');
    if (opts.out.length < outPos + dkLen)
        throw new RangeError('output is too small');
    opts.out.set(msg, outPos);
    clean(out);
    return opts.out;
};
const copyParallelOutput = (outs, views, dkLen, outputLen, canXOF) => {
    if (views.length !== outs.length)
        throw new RangeError('output array length must match messages length');
    for (let i = 0; i < outs.length; i++)
        copyOutput(outs[i], { out: views[i], dkLen }, outputLen, canXOF);
    return views;
};
const hashSyncError = () => {
    throw new Error('sync is not supported');
};
export function mkHashAsync(def_, impl_, platform = 'webcrypto', isSupported, meta) {
    const def = def_;
    const impl = impl_;
    const { outputLen, blockLen, canXOF, oid } = def;
    const hash = ((_msg) => hashSyncError());
    const hashAsync = async (msg, opts = {}) => {
        abytes(msg);
        const out = await impl.hash(msg, opts);
        return copyOutput(out, opts, outputLen, canXOF);
    };
    const chunks = ((_parts) => hashSyncError());
    const chunksAsync = async (parts, opts = {}) => {
        if (opts.prefixState !== undefined)
            throw new Error('prefixState is not supported');
        for (let i = 0; i < parts.length; i++)
            abytes(parts[i]);
        if (impl.chunks) {
            const out = await impl.chunks(parts, opts);
            return copyOutput(out, opts, outputLen, canXOF);
        }
        const joined = concatBytes(...parts);
        try {
            const out = await impl.hash(joined, opts);
            return copyOutput(out, opts, outputLen, canXOF);
        }
        finally {
            clean(joined);
        }
    };
    Object.assign(chunks, { async: chunksAsync });
    const parallel = ((_parts) => hashSyncError());
    const parallelAsync = async (parts, opts = {}) => {
        if (opts.prefixState !== undefined)
            throw new Error('prefixState is not supported');
        for (let i = 0; i < parts.length; i++)
            abytes(parts[i]);
        const checked = checkParallelOutput(opts, parts.length, outputLen, canXOF);
        const runOpts = { ...opts, out: undefined, outPos: undefined };
        const out = impl.parallel
            ? await impl.parallel(parts, runOpts)
            : await Promise.all(parts.map((i) => impl.hash(i, runOpts)));
        return copyParallelOutput(out, checked.out, checked.dkLen, outputLen, canXOF);
    };
    Object.assign(parallel, { async: parallelAsync });
    Object.assign(hash, {
        async: hashAsync,
        chunks,
        parallel,
        create: () => {
            throw new Error('streaming is not supported');
        },
        cleanState: () => {
            throw new Error('prefixState is not supported');
        },
        getPlatform: () => platform,
        getDefinition: () => def,
        canXOF: !!canXOF,
        outputLen,
        blockLen,
        oid,
    });
    if (meta)
        Object.assign(hash, meta);
    if (isSupported)
        hash.isSupported = isSupported;
    Object.defineProperty(hash, BRAND, { value: true, enumerable: false });
    brandSet.add(hash);
    return Object.freeze(hash);
}
export function mkHashStub(def_) {
    const def = def_;
    const { outputLen, blockLen, canXOF, oid } = def;
    let inner;
    function checkInner(inner) {
        if (inner === undefined)
            throw new Error('implementation not installed');
    }
    const hash = ((msg, opts = {}) => {
        checkInner(inner);
        return inner(msg, opts);
    });
    const chunks = (parts, opts = {}) => {
        checkInner(inner);
        return inner.chunks(parts, opts);
    };
    Object.assign(chunks, {
        async: async (parts, opts = {}) => {
            checkInner(inner);
            return inner.chunks.async(parts, opts);
        },
    });
    const parallel = (chunks, opts = {}) => {
        checkInner(inner);
        return inner.parallel(chunks, opts);
    };
    Object.assign(parallel, {
        async(chunks, opts = {}) {
            checkInner(inner);
            return inner.parallel.async(chunks, opts);
        },
    });
    Object.assign(hash, {
        async: async (msg, opts = {}) => {
            checkInner(inner);
            return inner.async(msg, opts);
        },
        chunks,
        parallel,
        create(opts = {}) {
            checkInner(inner);
            return inner.create(opts);
        },
        cleanState(state) {
            checkInner(inner);
            return inner.cleanState(state);
        },
        getPlatform: () => {
            checkInner(inner);
            return inner.getPlatform();
        },
        getDefinition: () => {
            checkInner(inner);
            return inner.getDefinition();
        },
        install: (impl, opts = {}) => {
            const { onlyMissing } = opts;
            if (onlyMissing !== undefined)
                abool(onlyMissing);
            if (onlyMissing && inner !== undefined)
                return;
            // install() accepts only constructor-created hashes: WeakSet branding rejects copied fields,
            // and exact definition identity rejects same-shaped but different hash families.
            if (!isBranded(impl))
                throw new Error('install: non-branded implementation');
            // NOTE: this strict check works because all implementations will use exact same frozen definition
            // which means it is impossible to use same blockLen/outputLen hash from different definition
            if (impl.getDefinition() !== def)
                throw new Error('wrong implementation definition');
            inner = impl;
        },
        canXOF,
        outputLen,
        blockLen,
        oid,
    });
    return Object.freeze(hash);
}
