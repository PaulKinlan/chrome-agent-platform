export * from './targets/wasm_threads/index.ts';
//# sourceMappingURL=wasm_threads.d.ts.map