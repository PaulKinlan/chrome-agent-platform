import { type Cipher, type CipherDef, type CipherFactory } from './ciphers-abstract.ts';
import { type HashDef, type HashInstance, type HashState, type HashStream, type OutputOpts, type HashBatchOpts } from './hashes-abstract.ts';
import { argon2d as def_argon2d, argon2i as def_argon2i, argon2id as def_argon2id, scrypt as def_scrypt, type Blake2Opts, type Blake3Opts, type BlakeOpts } from './hashes.ts';
import { type ArgonOpts, type KDF, type ScryptOpts } from './kdf.ts';
import { type Asyncify, type KDFInput, type TArg, type TRet } from './utils.ts';
export type { OutputOpts, HashBatchOpts, HashState, HashStream, HashDef, HashInstance, Cipher, CipherDef, CipherFactory, KDF, BlakeOpts, Blake2Opts, Blake3Opts, ScryptOpts, ArgonOpts, TArg, TRet, Asyncify, KDFInput, };
type MACOpts = {
    key: Uint8Array;
} | Uint8Array;
type SecretBox = (key: TArg<Uint8Array>, nonce: TArg<Uint8Array>) => {
    seal: Cipher['encrypt'];
    open: Cipher['decrypt'];
};
/**
 * Noble BLAKE-224 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake224 } from '@awasm/noble/noble.js';
 * blake224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake224: TRet<HashInstance<BlakeOpts>>;
/**
 * Noble BLAKE-256 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake256 } from '@awasm/noble/noble.js';
 * blake256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake256: TRet<HashInstance<BlakeOpts>>;
/**
 * Noble BLAKE-384 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake384 } from '@awasm/noble/noble.js';
 * blake384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake384: TRet<HashInstance<BlakeOpts>>;
/**
 * Noble BLAKE-512 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake512 } from '@awasm/noble/noble.js';
 * blake512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake512: TRet<HashInstance<BlakeOpts>>;
/**
 * Noble BLAKE2s hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2s } from '@awasm/noble/noble.js';
 * blake2s(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake2s: TRet<HashInstance<Blake2Opts>>;
/**
 * Noble BLAKE2b hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake2b } from '@awasm/noble/noble.js';
 * blake2b(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake2b: TRet<HashInstance<Blake2Opts>>;
/**
 * Noble BLAKE3 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { blake3 } from '@awasm/noble/noble.js';
 * blake3(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const blake3: TRet<HashInstance<Blake3Opts>>;
/**
 * Noble MD5 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { md5 } from '@awasm/noble/noble.js';
 * md5(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const md5: TRet<HashInstance<undefined>>;
/**
 * Noble RIPEMD-160 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { ripemd160 } from '@awasm/noble/noble.js';
 * ripemd160(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const ripemd160: TRet<HashInstance<undefined>>;
/**
 * Noble SHA1 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha1 } from '@awasm/noble/noble.js';
 * sha1(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha1: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-224 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha224 } from '@awasm/noble/noble.js';
 * sha224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha224: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-256 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble/noble.js';
 * sha256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha256: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-384 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha384 } from '@awasm/noble/noble.js';
 * sha384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha384: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-512/224 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_224 } from '@awasm/noble/noble.js';
 * sha512_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512_224: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-512/256 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512_256 } from '@awasm/noble/noble.js';
 * sha512_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512_256: TRet<HashInstance<undefined>>;
/**
 * Noble SHA2-512 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha512 } from '@awasm/noble/noble.js';
 * sha512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha512: TRet<HashInstance<undefined>>;
/**
 * Noble SHA3-224 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_224 } from '@awasm/noble/noble.js';
 * sha3_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_224: TRet<HashInstance<undefined>>;
/**
 * Noble SHA3-256 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_256 } from '@awasm/noble/noble.js';
 * sha3_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_256: TRet<HashInstance<undefined>>;
/**
 * Noble SHA3-384 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_384 } from '@awasm/noble/noble.js';
 * sha3_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_384: TRet<HashInstance<undefined>>;
/**
 * Noble SHA3-512 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { sha3_512 } from '@awasm/noble/noble.js';
 * sha3_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const sha3_512: TRet<HashInstance<undefined>>;
/**
 * Noble Keccak-224 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_224 } from '@awasm/noble/noble.js';
 * keccak_224(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_224: TRet<HashInstance<undefined>>;
/**
 * Noble Keccak-256 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_256 } from '@awasm/noble/noble.js';
 * keccak_256(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_256: TRet<HashInstance<undefined>>;
/**
 * Noble Keccak-384 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_384 } from '@awasm/noble/noble.js';
 * keccak_384(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_384: TRet<HashInstance<undefined>>;
/**
 * Noble Keccak-512 hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { keccak_512 } from '@awasm/noble/noble.js';
 * keccak_512(new Uint8Array([1, 2, 3]));
 * ```
 */
export declare const keccak_512: TRet<HashInstance<undefined>>;
/**
 * Noble SHAKE128 XOF hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128 } from '@awasm/noble/noble.js';
 * shake128(new Uint8Array([1, 2, 3]), { dkLen: 32 });
 * ```
 */
export declare const shake128: TRet<HashInstance<undefined>>;
/**
 * Noble SHAKE256 XOF hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256 } from '@awasm/noble/noble.js';
 * shake256(new Uint8Array([1, 2, 3]), { dkLen: 32 });
 * ```
 */
export declare const shake256: TRet<HashInstance<undefined>>;
/**
 * Noble SHAKE128/32 XOF hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake128_32 } from '@awasm/noble/noble.js';
 * shake128_32(new Uint8Array([1, 2, 3]), { dkLen: 32 });
 * ```
 */
export declare const shake128_32: TRet<HashInstance<undefined>>;
/**
 * Noble SHAKE256/64 XOF hash.
 * @param msg - message to hash.
 * @param opts - optional {@link OutputOpts} hash configuration.
 * @returns Hash output bytes.
 * @example
 * ```ts
 * import { shake256_64 } from '@awasm/noble/noble.js';
 * shake256_64(new Uint8Array([1, 2, 3]), { dkLen: 64 });
 * ```
 */
export declare const shake256_64: TRet<HashInstance<undefined>>;
/**
 * Noble Poly1305 MAC.
 * @param msg - message to authenticate.
 * @param opts - optional {@link OutputOpts} hash configuration and MAC key options.
 * @returns Authentication tag bytes.
 * @example
 * ```ts
 * import { poly1305 } from '@awasm/noble/noble.js';
 * poly1305(new Uint8Array([1, 2, 3]), { key: new Uint8Array(32) });
 * ```
 */
export declare const poly1305: TRet<HashInstance<MACOpts>>;
/**
 * Noble AES-CMAC.
 * @param msg - message to authenticate.
 * @param opts - optional {@link OutputOpts} hash configuration and MAC key options.
 * @returns Authentication tag bytes.
 * @example
 * ```ts
 * import { cmac } from '@awasm/noble/noble.js';
 * cmac(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const cmac: TRet<HashInstance<MACOpts>>;
/**
 * Noble GHASH MAC.
 * @param msg - message to authenticate.
 * @param opts - optional {@link OutputOpts} hash configuration and MAC key options.
 * @returns Authentication tag bytes.
 * @example
 * ```ts
 * import { ghash } from '@awasm/noble/noble.js';
 * ghash(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const ghash: TRet<HashInstance<MACOpts>>;
/**
 * Noble Polyval MAC.
 * @param msg - message to authenticate.
 * @param opts - optional {@link OutputOpts} hash configuration and MAC key options.
 * @returns Authentication tag bytes.
 * @example
 * ```ts
 * import { polyval } from '@awasm/noble/noble.js';
 * polyval(new Uint8Array([1, 2, 3]), { key: new Uint8Array(16) });
 * ```
 */
export declare const polyval: TRet<HashInstance<MACOpts>>;
/**
 * Noble AES-CTR cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ctr } from '@awasm/noble/noble.js';
 * ctr(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const ctr: TRet<CipherFactory>;
/**
 * Noble AES-CBC cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as IV bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cbc } from '@awasm/noble/noble.js';
 * cbc(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const cbc: TRet<CipherFactory>;
/**
 * Noble AES-OFB cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as IV bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ofb } from '@awasm/noble/noble.js';
 * ofb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const ofb: TRet<CipherFactory>;
/**
 * Noble AES-CFB cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as IV bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { cfb } from '@awasm/noble/noble.js';
 * cfb(new Uint8Array(16), new Uint8Array(16));
 * ```
 */
export declare const cfb: TRet<CipherFactory>;
/**
 * Noble AES-ECB cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { ecb } from '@awasm/noble/noble.js';
 * ecb(new Uint8Array(16));
 * ```
 */
export declare const ecb: TRet<CipherFactory>;
/**
 * Noble AES-GCM cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce and AAD bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcm } from '@awasm/noble/noble.js';
 * gcm(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export declare const gcm: TRet<CipherFactory>;
/**
 * Noble AES-GCM-SIV cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce and AAD bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { gcmsiv } from '@awasm/noble/noble.js';
 * gcmsiv(new Uint8Array(16), new Uint8Array(12));
 * ```
 */
export declare const gcmsiv: TRet<CipherFactory>;
/**
 * Noble AES-SIV cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as AAD components.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aessiv } from '@awasm/noble/noble.js';
 * aessiv(new Uint8Array(32));
 * ```
 */
export declare const aessiv: TRet<CipherFactory>;
/**
 * Noble AES-KW cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskw } from '@awasm/noble/noble.js';
 * aeskw(new Uint8Array(16));
 * ```
 */
export declare const aeskw: TRet<CipherFactory>;
/**
 * Noble AES-KWP cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { aeskwp } from '@awasm/noble/noble.js';
 * aeskwp(new Uint8Array(16));
 * ```
 */
export declare const aeskwp: TRet<CipherFactory>;
/**
 * Noble Salsa20 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { salsa20 } from '@awasm/noble/noble.js';
 * salsa20(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export declare const salsa20: TRet<CipherFactory>;
/**
 * Noble XSalsa20 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20 } from '@awasm/noble/noble.js';
 * xsalsa20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xsalsa20: TRet<CipherFactory>;
/**
 * Noble ChaCha8 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha8 } from '@awasm/noble/noble.js';
 * chacha8(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha8: TRet<CipherFactory>;
/**
 * Noble ChaCha12 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha12 } from '@awasm/noble/noble.js';
 * chacha12(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha12: TRet<CipherFactory>;
/**
 * Noble ChaCha20 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20 } from '@awasm/noble/noble.js';
 * chacha20(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha20: TRet<CipherFactory>;
/**
 * Noble original ChaCha20 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20orig } from '@awasm/noble/noble.js';
 * chacha20orig(new Uint8Array(32), new Uint8Array(8));
 * ```
 */
export declare const chacha20orig: TRet<CipherFactory>;
/**
 * Noble XChaCha20 stream cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20 } from '@awasm/noble/noble.js';
 * xchacha20(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xchacha20: TRet<CipherFactory>;
/**
 * Noble ChaCha20-Poly1305 AEAD cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce and AAD bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { chacha20poly1305 } from '@awasm/noble/noble.js';
 * chacha20poly1305(new Uint8Array(32), new Uint8Array(12));
 * ```
 */
export declare const chacha20poly1305: TRet<CipherFactory>;
/**
 * Noble XChaCha20-Poly1305 AEAD cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce and AAD bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xchacha20poly1305 } from '@awasm/noble/noble.js';
 * xchacha20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xchacha20poly1305: TRet<CipherFactory>;
/**
 * Noble XSalsa20-Poly1305 AEAD cipher factory.
 * @param key - secret key bytes.
 * @param args - algorithm-specific extra arguments such as nonce bytes.
 * @returns Configured cipher instance.
 * @example
 * ```ts
 * import { xsalsa20poly1305 } from '@awasm/noble/noble.js';
 * xsalsa20poly1305(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const xsalsa20poly1305: TRet<CipherFactory>;
/**
 * Noble XSalsa20-Poly1305 secretbox helper.
 * @param key - secret key bytes.
 * @param nonce - nonce bytes.
 * @returns Configured secretbox helper.
 * @example
 * ```ts
 * import { secretbox } from '@awasm/noble/noble.js';
 * secretbox(new Uint8Array(32), new Uint8Array(24));
 * ```
 */
export declare const secretbox: TRet<SecretBox>;
/**
 * Noble scrypt KDF.
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { scrypt } from '@awasm/noble/noble.js';
 * scrypt('password', 'salt', { N: 16, r: 1, p: 1, dkLen: 32 });
 * ```
 */
export declare const scrypt: ReturnType<typeof def_scrypt>;
/**
 * Noble Argon2d KDF.
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2d } from '@awasm/noble/noble.js';
 * argon2d('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2d: ReturnType<typeof def_argon2d>;
/**
 * Noble Argon2i KDF.
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2i } from '@awasm/noble/noble.js';
 * argon2i('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2i: ReturnType<typeof def_argon2i>;
/**
 * Noble Argon2id KDF.
 * @param password - password or key material bytes.
 * @param salt - salt bytes.
 * @param opts - algorithm configuration options.
 * @returns Derived output bytes.
 * @example
 * ```ts
 * import { argon2id } from '@awasm/noble/noble.js';
 * argon2id('password', 'saltsalt', { t: 1, m: 8, p: 1, dkLen: 32 });
 * ```
 */
export declare const argon2id: ReturnType<typeof def_argon2id>;
//# sourceMappingURL=noble.d.ts.map