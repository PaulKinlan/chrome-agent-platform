/**
 * Constants for hashes and ciphers. Mostly initial state.
 * @module
 */
import { type TRet } from './utils.ts';
/**
 * Round constants:
 * First 32 bits of fractional parts of the cube roots of the first 64 primes 2..311)
 */
export declare const SHA256_K: number[];
/** Initial SHA256 state. Bits 0..32 of frac part of sqrt of primes 2..19 */
export declare const SHA256_IV: Uint32Array<ArrayBuffer>;
export declare const SHA256_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
/** Initial SHA224 state. Bits 32..64 of frac part of sqrt of primes 23..53 */
export declare const SHA224_IV: TRet<Uint32Array>;
export declare const SHA224_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const SHA512_K: bigint[];
/** Initial SHA512 state. Bits 0..64 of frac part of sqrt of primes 2..19 */
export declare const SHA512_IV: TRet<Uint32Array>;
export declare const SHA512_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
/** Initial SHA384 state. Bits 0..64 of frac part of sqrt of primes 23..53 */
export declare const SHA384_IV: TRet<Uint32Array>;
export declare const SHA384_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const SHA512_224_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const SHA512_256_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const B2B_IV: Uint32Array<ArrayBuffer>;
export declare const B2B_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const B2B_IV_U64: bigint[];
export declare const B2S_IV: Uint32Array<ArrayBuffer>;
export declare const B2S_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const BSIGMA: TRet<Uint8Array>;
export declare const B32C: Uint32Array<ArrayBuffer>;
export declare const B64C: Uint32Array<ArrayBuffer>;
export declare const B64C_U64: bigint[];
export declare const B256_IV: Uint32Array<ArrayBuffer>;
export declare const B512_IV: Uint32Array<ArrayBuffer>;
export declare const TBL256: number[];
export declare const TBL512: bigint[];
/** Initial SHA-1 state from RFC 3174 §6.1. */
export declare const SHA1_IV: Uint32Array<ArrayBuffer>;
export declare const SHA1_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
/** RFC 1321 §3.4 / Appendix A.3 `T[1..64]` table. */
export declare const MD5_K: number[];
/**
 * RFC 1321 §3.3 / Appendix A.3 MD5 initial state.
 * It matches the first four SHA-1 words, so slice() copies them without
 * aliasing SHA1_IV.
 */
export declare const MD5_IV: Uint32Array<ArrayBuffer>;
export declare const MD5_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
/** RIPEMD-160 initial state; same five 32-bit words as SHA-1. */
export declare const RIPEMD160_IV: Uint32Array<ArrayBuffer>;
export declare const RIPEMD160_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const RIPEMD160_idxL: Uint8Array<ArrayBuffer>[];
export declare const RIPEMD160_idxR: Uint8Array<ArrayBuffer>[];
export declare const RIPEMD160_shiftsL160: Uint8Array<ArrayBuffer>[];
export declare const RIPEMD160_shiftsR160: Uint8Array<ArrayBuffer>[];
export declare const RIPEMD160_Kl160: Uint32Array<ArrayBuffer>;
export declare const RIPEMD160_Kr160: Uint32Array<ArrayBuffer>;
export declare const SHA3_PI2: number[];
export declare const SHA3_ROTL: number[];
export declare const SHA3_IOTA: bigint[];
export declare const B3_Flags: {
    readonly CHUNK_START: 1;
    readonly CHUNK_END: 2;
    readonly PARENT: 4;
    readonly ROOT: 8;
    readonly KEYED_HASH: 16;
    readonly DERIVE_KEY_CONTEXT: 32;
    readonly DERIVE_KEY_MATERIAL: 64;
};
export declare const B3_IV: Uint32Array<ArrayBuffer>;
export declare const B3_IV_U8: Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>;
export declare const B3_SIGMA: TRet<Uint8Array>;
export declare const ARX_SIGMA16: Uint8Array<ArrayBuffer>;
export declare const ARX_SIGMA32: Uint8Array<ArrayBuffer>;
//# sourceMappingURL=constants.d.ts.map