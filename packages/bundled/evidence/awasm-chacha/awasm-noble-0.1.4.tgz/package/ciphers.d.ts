/**
 * Cipher definitions. Common logic for all targets.
 * Doesn't contain WASM-specific/JS-specific code.
 * @module
 */
import type { CipherDef } from './ciphers-abstract.ts';
import type * as TYPES from './targets/types.ts';
import { type TArg, type TRet } from './utils.ts';
export declare const limit: (name: string, min: number, max: number) => (value: number) => void;
export type ArxOpts = {
    counter?: number;
};
export type ArxInit = {
    allowShortKeys: boolean;
    extendNonce?: boolean;
    counterLength: number;
    counterRight: boolean;
};
export declare const initArx: (mod: any, key: TArg<Uint8Array>, nonce: TArg<Uint8Array>, opts: TArg<ArxOpts | undefined>, cfg: TArg<ArxInit>) => void;
export declare const salsa20: TRet<CipherDef<TYPES.SALSA20>>;
export declare const xsalsa20: TRet<CipherDef<TYPES.SALSA20>>;
export declare const chacha20orig: TRet<CipherDef<TYPES.CHACHA20>>;
export declare const chacha20: TRet<CipherDef<TYPES.CHACHA20>>;
export declare const xchacha20: TRet<CipherDef<TYPES.CHACHA20>>;
export declare const chacha8: TRet<CipherDef<TYPES.CHACHA8>>;
export declare const chacha12: TRet<CipherDef<TYPES.CHACHA12>>;
export declare const chacha20poly1305: TRet<CipherDef<any>>;
export declare const xchacha20poly1305: TRet<CipherDef<any>>;
export declare const xsalsa20poly1305: TRet<CipherDef<any>>;
export declare const ecb: TRet<CipherDef<TYPES.AES_ECB>>;
export declare const cbc: TRet<CipherDef<TYPES.AES_CBC>>;
export declare const cfb: TRet<CipherDef<TYPES.AES_CFB>>;
export declare const ofb: TRet<CipherDef<TYPES.AES_OFB>>;
export declare const ctr: TRet<CipherDef<TYPES.AES_CTR>>;
export declare const gcm: TRet<CipherDef<TYPES.AES_GCM>>;
export declare const gcmsiv: TRet<CipherDef<TYPES.AES_GCMSIV>>;
export declare const aessiv: TRet<CipherDef<TYPES.AES_SIV>>;
export declare const aeskw: TRet<CipherDef<TYPES.AES_KW>>;
export declare const aeskwp: TRet<CipherDef<TYPES.AES_KWP>>;
export declare const Definitions: {
    readonly ctr: {
        mod: "aes_ctr";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_CTR, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_CTR) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_CTR, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_CTR>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_CTR) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_CTR>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly cbc: {
        mod: "aes_cbc";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_CBC, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_CBC) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_CBC, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_CBC>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_CBC) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_CBC>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly ofb: {
        mod: "aes_ofb";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_OFB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_OFB) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_OFB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_OFB>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_OFB) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_OFB>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly cfb: {
        mod: "aes_cfb";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_CFB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_CFB) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_CFB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_CFB>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_CFB) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_CFB>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly ecb: {
        mod: "aes_ecb";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_ECB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_ECB) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_ECB, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_ECB>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_ECB) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_ECB>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly gcm: {
        mod: "aes_gcm";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_GCM, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_GCM) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_GCM, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_GCM>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_GCM) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_GCM>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly gcmsiv: {
        mod: "aes_gcmsiv";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_GCMSIV, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_GCMSIV) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_GCMSIV, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_GCMSIV>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_GCMSIV) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_GCMSIV>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly aessiv: {
        mod: "aes_siv";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_SIV, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_SIV) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_SIV, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_SIV>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_SIV) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_SIV>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly aeskw: {
        mod: "aes_kw";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_KW, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_KW) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_KW, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_KW>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_KW) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_KW>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly aeskwp: {
        mod: "aes_kwp";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.AES_KWP, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.AES_KWP) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.AES_KWP, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.AES_KWP>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.AES_KWP) => TRet<Uint8Array>) & ((mod: TArg<TYPES.AES_KWP>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly salsa20: {
        mod: "salsa20";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.SALSA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.SALSA20) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.SALSA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.SALSA20>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.SALSA20) => TRet<Uint8Array>) & ((mod: TArg<TYPES.SALSA20>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly xsalsa20: {
        mod: "salsa20";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.SALSA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.SALSA20) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.SALSA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.SALSA20>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.SALSA20) => TRet<Uint8Array>) & ((mod: TArg<TYPES.SALSA20>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly chacha8: {
        mod: "chacha8";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.CHACHA8, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.CHACHA8) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.CHACHA8, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.CHACHA8>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.CHACHA8) => TRet<Uint8Array>) & ((mod: TArg<TYPES.CHACHA8>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly chacha12: {
        mod: "chacha12";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.CHACHA12, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.CHACHA12) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.CHACHA12, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.CHACHA12>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.CHACHA12) => TRet<Uint8Array>) & ((mod: TArg<TYPES.CHACHA12>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly chacha20: {
        mod: "chacha20";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.CHACHA20) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.CHACHA20>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.CHACHA20) => TRet<Uint8Array>) & ((mod: TArg<TYPES.CHACHA20>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly chacha20orig: {
        mod: "chacha20";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.CHACHA20) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.CHACHA20>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.CHACHA20) => TRet<Uint8Array>) & ((mod: TArg<TYPES.CHACHA20>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly xchacha20: {
        mod: "chacha20";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: TYPES.CHACHA20) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: TYPES.CHACHA20, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: TArg<TYPES.CHACHA20>, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: TYPES.CHACHA20) => TRet<Uint8Array>) & ((mod: TArg<TYPES.CHACHA20>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly chacha20poly1305: {
        mod: "chacha_poly1305";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: any) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: any, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: any) => TRet<Uint8Array>) & ((mod: any) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly xchacha20poly1305: {
        mod: "chacha_poly1305";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: any) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: any, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: any) => TRet<Uint8Array>) & ((mod: any) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
    readonly xsalsa20poly1305: {
        mod: "salsa_poly1305";
        def: import("./ciphers-abstract.ts").CipherParams & {
            tagLeft?: boolean;
            dataOffset?: number;
            exactOutput?: boolean;
            paddingLeft?: number;
            padding?: boolean;
            padFull?: boolean;
            multiPass?: number;
            multiPassResult?: boolean | {
                encrypt?: boolean;
                decrypt?: boolean;
            };
            multiPassOut?: {
                encrypt?: number;
                decrypt?: number;
            };
            tagError?: string;
            lengthError?: string;
            lengthErrorEnc?: string;
            lengthErrorDec?: string;
            lengthLimitEnc?: (len: number, args?: unknown[], pending?: number) => void;
            lengthLimitDec?: (len: number, args?: unknown[], pending?: number) => void;
            padError?: string;
            emptyError?: string;
            noOverlap?: boolean;
            noOutput?: boolean;
            noStream?: boolean;
            twoPass?: boolean;
            validate?: (key: TArg<Uint8Array>, ...args: unknown[]) => void;
            init: (mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            };
            getTag?: ((mod: any) => TRet<Uint8Array>) | undefined;
        } & {
            blockSize?: number | undefined;
            blockLen: number;
            nonceLength?: number | undefined;
            tagLength?: number | undefined;
            withAAD?: true | undefined;
            varSizeNonce?: boolean | undefined;
            tagLeft?: boolean | undefined;
            dataOffset?: number | undefined;
            exactOutput?: boolean | undefined;
            paddingLeft?: number | undefined;
            padding?: boolean | undefined;
            padFull?: boolean | undefined;
            multiPass?: number | undefined;
            multiPassResult?: boolean | ({
                encrypt?: boolean;
                decrypt?: boolean;
            } & {
                encrypt?: boolean | undefined;
                decrypt?: boolean | undefined;
            }) | undefined;
            multiPassOut?: ({
                encrypt?: number;
                decrypt?: number;
            } & {
                encrypt?: number | undefined;
                decrypt?: number | undefined;
            }) | undefined;
            tagError?: string | undefined;
            lengthError?: string | undefined;
            lengthErrorEnc?: string | undefined;
            lengthErrorDec?: string | undefined;
            lengthLimitEnc?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            lengthLimitDec?: (((len: number, args?: unknown[], pending?: number) => void) & ((len: number, args?: TArg<unknown[] | undefined>, pending?: TArg<number | undefined>) => void) & {}) | undefined;
            padError?: string | undefined;
            emptyError?: string | undefined;
            noOverlap?: boolean | undefined;
            noOutput?: boolean | undefined;
            noStream?: boolean | undefined;
            twoPass?: boolean | undefined;
            validate?: (((key: TArg<Uint8Array>, ...args: unknown[]) => void) & ((key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void) & {}) | undefined;
            init: ((mod: any, dir: "decrypt" | "encrypt", key: TArg<Uint8Array>, ...args: unknown[]) => void | {
                disablePadding?: boolean;
            }) & ((mod: any, dir: TArg<"decrypt" | "encrypt">, key: TArg<TArg<Uint8Array<ArrayBufferLike>>>, ...args: unknown[]) => void | ({
                disablePadding?: boolean;
            } & {
                disablePadding?: boolean | undefined;
            })) & {};
            getTag?: (((mod: any) => TRet<Uint8Array>) & ((mod: any) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {}) | undefined;
        };
    };
};
//# sourceMappingURL=ciphers.d.ts.map