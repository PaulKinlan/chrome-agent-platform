export * from "./targets/wasm_threads/index.js";
