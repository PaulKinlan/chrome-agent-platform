/** Whether the current platform is little-endian. */
export const isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44)();
const assertLE = (littleEndian = isLE) => {
    if (littleEndian)
        return;
    // Fail closed on BE for now: qemu-smoke checks still showed broken wasm outputs, and the JS
    // target would need a dedicated BE compilation path that is not currently generated.
    throw new Error('big-endian platforms are unsupported');
};
assertLE();
/** Checks if something is Uint8Array. Be careful: nodejs Buffer will return true. */
/**
 * Checks whether a value is a byte-oriented Uint8Array view.
 * @param a - value to inspect.
 * @returns True when the value is a Uint8Array-compatible byte view.
 * @example
 * ```ts
 * import { isBytes } from '@awasm/noble/utils.js';
 * isBytes(new Uint8Array([1, 2, 3]));
 * ```
 */
export function isBytes(a) {
    // Plain `instanceof Uint8Array` is too strict for some Buffer / proxy / cross-realm cases.
    // The fallback still requires a real ArrayBuffer view, so plain
    // JSON-deserialized `{ constructor: ... }` spoofing is rejected, and
    // `BYTES_PER_ELEMENT === 1` keeps the fallback on byte-oriented views.
    return (a instanceof Uint8Array ||
        (ArrayBuffer.isView(a) &&
            a.constructor.name === 'Uint8Array' &&
            'BYTES_PER_ELEMENT' in a &&
            a.BYTES_PER_ELEMENT === 1));
}
/**
 * Asserts something is boolean.
 * @param b - value to validate.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { abool } from '@awasm/noble/utils.js';
 * abool(true);
 * ```
 */
export function abool(b) {
    if (typeof b !== 'boolean')
        throw new TypeError(`boolean expected, not ${b}`);
}
/**
 * Asserts something is a non-negative safe integer.
 * @param n - value to validate.
 * @param title - optional field name for error messages.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { anumber } from '@awasm/noble/utils.js';
 * anumber(7, 'count');
 * ```
 */
export function anumber(n, title = '') {
    const prefix = title && `"${title}" `;
    if (typeof n !== 'number')
        throw new TypeError(`${prefix}expected number, got ${typeof n}`);
    if (!Number.isSafeInteger(n) || n < 0) {
        throw new RangeError(`${prefix}expected integer >= 0, got ${n}`);
    }
}
/**
 * Asserts something is Uint8Array.
 * @param value - byte array candidate.
 * @param length - optional exact length requirement.
 * @param title - optional field name for error messages.
 * @returns The validated byte array.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { abytes } from '@awasm/noble/utils.js';
 * abytes(new Uint8Array([1, 2, 3]), 3, 'msg');
 * ```
 */
export function abytes(value, length, title = '') {
    const bytes = isBytes(value);
    const len = value?.length;
    const needsLen = length !== undefined;
    const prefix = title && `"${title}" `;
    if (!bytes)
        throw new TypeError(prefix + 'expected Uint8Array, got type=' + typeof value);
    if (needsLen && len !== length)
        throw new RangeError(prefix + 'expected Uint8Array of length ' + length + ', got length=' + len);
    return value;
}
/**
 * Asserts a hash-like instance has not been destroyed or finished.
 * @param instance - instance to validate.
 * @param checkFinished - whether to reject already-finished instances.
 * @throws If the documented runtime validation or state check fails. {@link Error}
 * @example
 * ```ts
 * import { aexists } from '@awasm/noble/utils.js';
 * aexists({ destroyed: false, finished: false });
 * ```
 */
export function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
        throw new Error('Hash instance has been destroyed');
    if (checkFinished && instance.finished)
        throw new Error('Hash#digest() has already been called');
}
/**
 * Asserts an output buffer is a byte array with sufficient capacity.
 * @param out - destination buffer.
 * @param instance - object exposing `outputLen`.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { aoutput } from '@awasm/noble/utils.js';
 * aoutput(new Uint8Array(32), { outputLen: 32 });
 * ```
 */
export function aoutput(out, instance) {
    abytes(out, undefined, 'output');
    const min = instance.outputLen;
    if (out.length < min) {
        // Shared digestInto() contracts treat undersized destinations as a range problem, not a
        // generic runtime failure, so callers can distinguish "wrong type" from "too short".
        throw new RangeError('digestInto() expects output buffer of length at least ' + min);
    }
}
/**
 * Asserts a hash surface looks like one produced by the hash factory.
 * @param h - hash surface to validate.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @throws If a documented runtime validation or state check fails. {@link Error}
 * @example
 * ```ts
 * import { sha256 } from '@awasm/noble';
 * import { ahash } from '@awasm/noble/utils.js';
 * ahash(sha256);
 * ```
 */
export function ahash(h) {
    if (typeof h !== 'function' || typeof h.create !== 'function')
        throw new TypeError('Hash must created by hashes.mkHash');
    anumber(h.outputLen);
    anumber(h.blockLen);
    // HMAC and KDF callers treat these as real byte lengths; allowing zero lets fake wrappers pass
    // validation and can produce empty outputs instead of failing fast.
    if (h.outputLen < 1)
        throw new Error('"outputLen" must be >= 1');
    if (h.blockLen < 1)
        throw new Error('"blockLen" must be >= 1');
}
/**
 * Casts a typed-array view to bytes over the same memory region.
 * Shared buffer view in native memory order; used for internal state init, not endian-normalized serialization.
 * @param arr - source typed-array view.
 * @returns Byte view over the same buffer region.
 * @example
 * ```ts
 * import { u8 } from '@awasm/noble/utils.js';
 * u8(new Uint32Array([1]));
 * ```
 */
export function u8(arr) {
    return new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
 * Casts a typed-array view to 32-bit words over the same memory region.
 * Shared native-order word view; byteOffset must be 4-byte aligned and trailing 1..3 bytes are ignored.
 * @param arr - source typed-array view.
 * @returns Uint32Array view over the same buffer region.
 * @example
 * ```ts
 * import { u32 } from '@awasm/noble/utils.js';
 * u32(new Uint8Array([1, 2, 3, 4]));
 * ```
 */
export function u32(arr) {
    return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
/**
 * Byte-swaps each 32-bit word on big-endian platforms.
 * @param arr - word array to normalize in place.
 * @returns The input array after any required byte swaps.
 * @example
 * ```ts
 * import { swap32IfBE } from '@awasm/noble/utils.js';
 * const words = new Uint32Array([0x11223344]);
 * swap32IfBE(words);
 * ```
 */
export function swap32IfBE(arr) {
    if (isLE)
        return arr;
    for (let i = 0; i < arr.length; i++) {
        const x = arr[i];
        arr[i] = ((x << 24) | ((x & 0xff00) << 8) | ((x >>> 8) & 0xff00) | (x >>> 24)) >>> 0;
    }
    return arr;
}
/**
 * Zeroize typed arrays in place. Warning: JS provides no guarantees.
 * @param arrays - arrays to overwrite with zeros.
 * @example
 * ```ts
 * import { clean } from '@awasm/noble/utils.js';
 * const buf = new Uint8Array([1, 2, 3]);
 * clean(buf);
 * ```
 */
export function clean(...arrays) {
    for (let i = 0; i < arrays.length; i++) {
        arrays[i].fill(0);
    }
}
// JS `.fill(0)` can be surprisingly slow on large buffers; chunked `.set` tends to be faster.
// This is used by ciphers to clear large staging buffers without making perf unusable.
/**
 * Fast zeroization for large byte buffers.
 * @param dst - destination buffer.
 * @param len - prefix length to clear.
 * @example
 * ```ts
 * import { cleanFast } from '@awasm/noble/utils.js';
 * cleanFast(new Uint8Array(16), 8);
 * ```
 */
export const cleanFast = (() => {
    let zero;
    return (dst, len = dst.length) => {
        abytes(dst);
        anumber(len, 'len');
        if (len > dst.length)
            throw new Error(`"len" expected <= dst.length, got len=${len} dst.length=${dst.length}`);
        if (!len)
            return;
        // Keep the zero chunk inside the export so bundles that don't use cleanFast can drop it too.
        const chunk = zero || (zero = /* @__PURE__ */ new Uint8Array(1024 * 1024));
        let off = 0;
        for (; off + chunk.length <= len; off += chunk.length)
            dst.set(chunk, off);
        if (off < len)
            dst.fill(0, off, len);
    };
})();
/**
 * Create a DataView over the same buffer region; writes through it mutate the original array.
 * @param arr - source typed-array view.
 * @returns DataView over the same buffer region.
 * @example
 * ```ts
 * import { createView } from '@awasm/noble/utils.js';
 * createView(new Uint8Array(8));
 * ```
 */
export function createView(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
 * Checks if two byte arrays overlap in the same underlying buffer.
 * This is invalid and can corrupt data.
 * @param a - first byte view.
 * @param b - second byte view.
 * @returns True when the byte ranges overlap.
 * @example
 * ```ts
 * import { overlapBytes } from '@awasm/noble/utils.js';
 * const buf = new Uint8Array(8);
 * overlapBytes(buf.subarray(0, 4), buf.subarray(2, 6));
 * ```
 */
export function overlapBytes(a, b) {
    // Zero-length views cannot overwrite anything, even if their offset sits inside another range.
    if (!a.byteLength || !b.byteLength)
        return false;
    return (a.buffer === b.buffer &&
        a.byteOffset < b.byteOffset + b.byteLength &&
        b.byteOffset < a.byteOffset + a.byteLength);
}
export const __TEST = /* @__PURE__ */ Object.freeze({
    assertLE,
});
// Built-in hex conversion https://caniuse.com/mdn-javascript_builtins_uint8array_fromhex
const hasHexBuiltin = /* @__PURE__ */ (() => 
// @ts-ignore
typeof Uint8Array.from([]).toHex === 'function' && typeof Uint8Array.fromHex === 'function')();
// Array where index 0xf0 (240) is mapped to string 'f0'
const hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, '0'));
/**
 * Convert byte array to hex string. Uses built-in function, when available.
 * @param bytes - bytes to encode.
 * @returns Lowercase hex string.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { bytesToHex } from '@awasm/noble/utils.js';
 * bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23]));
 * ```
 */
export function bytesToHex(bytes) {
    abytes(bytes);
    // @ts-ignore
    if (hasHexBuiltin)
        return bytes.toHex();
    // pre-caching improves the speed 6x
    let hex = '';
    for (let i = 0; i < bytes.length; i++) {
        hex += hexes[bytes[i]];
    }
    return hex;
}
// We use optimized technique to convert hex string to byte array
const asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
function asciiToBase16(ch) {
    if (ch >= asciis._0 && ch <= asciis._9)
        return ch - asciis._0; // '2' => 50-48
    if (ch >= asciis.A && ch <= asciis.F)
        return ch - (asciis.A - 10); // 'B' => 66-(65-10)
    if (ch >= asciis.a && ch <= asciis.f)
        return ch - (asciis.a - 10); // 'b' => 98-(97-10)
    return;
}
/**
 * Convert hex string to byte array. Uses built-in function, when available.
 * @param hex - hex string to decode.
 * @returns Decoded bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { hexToBytes } from '@awasm/noble/utils.js';
 * hexToBytes('cafe0123');
 * ```
 */
export function hexToBytes(hex) {
    if (typeof hex !== 'string')
        throw new TypeError('hex string expected, got ' + typeof hex);
    if (hasHexBuiltin) {
        try {
            // @ts-ignore
            return Uint8Array.fromHex(hex);
        }
        catch (error) {
            if (error instanceof SyntaxError)
                throw new RangeError(error.message);
            throw error;
        }
    }
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
        throw new RangeError('hex string expected, got unpadded hex of length ' + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
        const n1 = asciiToBase16(hex.charCodeAt(hi));
        const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
        if (n1 === undefined || n2 === undefined) {
            const char = hex[hi] + hex[hi + 1];
            throw new RangeError('hex string expected, got non-hex character "' + char + '" at index ' + hi);
        }
        array[ai] = n1 * 16 + n2; // multiply first octet, e.g. 'a3' => 10*16+3 => 160 + 3 => 163
    }
    return array;
}
/**
 * There is no setImmediate in browser and setTimeout is slow.
 * Call of async fn will return Promise, which will be fullfiled only on
 * next scheduler queue processing step and this is exactly what we need.
 * This yields to the Promise/microtask scheduler queue, not to timers or the full macrotask event loop.
 * @example
 * ```ts
 * import { nextTick } from '@awasm/noble/utils.js';
 * await nextTick();
 * ```
 */
export const nextTick = async () => { };
/**
 * Returns control to the Promise/microtask scheduler every `tick` ms to avoid blocking long loops.
 * @param iters - number of loop iterations.
 * @param tick - maximum milliseconds to spend before yielding.
 * @param cb - callback invoked for each iteration index.
 */
export async function asyncLoop(iters, tick, cb) {
    let ts = Date.now();
    for (let i = 0; i < iters; i++) {
        cb(i);
        // Date.now() is not monotonic, so in case if clock goes backwards we return return control too
        const diff = Date.now() - ts;
        if (diff >= 0 && diff < tick)
            continue;
        await nextTick();
        ts += diff;
    }
}
/**
 * Converts string to bytes using UTF8 encoding.
 * Built-in doesn't validate input to be string: we do the check.
 * Non-ASCII details are delegated to the platform TextEncoder.
 * @param str - string to encode.
 * @returns UTF-8 bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { utf8ToBytes } from '@awasm/noble/utils.js';
 * utf8ToBytes('abc');
 * ```
 */
export function utf8ToBytes(str) {
    if (typeof str !== 'string')
        throw new TypeError('string expected');
    return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
}
/**
 * Convert byte array to string, assuming UTF8 encoding.
 * Input validation and malformed-sequence handling are delegated to TextDecoder:
 * invalid UTF-8 is replacement-decoded, not rejected.
 * @param bytes - bytes to decode.
 * @returns UTF-8 string.
 * @example
 * ```ts
 * import { bytesToUtf8 } from '@awasm/noble/utils.js';
 * bytesToUtf8(new Uint8Array([97, 98, 99]));
 * ```
 */
export function bytesToUtf8(bytes) {
    return new TextDecoder().decode(bytes);
}
/**
 * Checks whether a byte array is aligned to a 4-byte offset.
 * @param bytes - byte view to inspect.
 * @returns True when the view is 32-bit aligned.
 * @example
 * ```ts
 * import { isAligned32 } from '@awasm/noble/utils.js';
 * isAligned32(new Uint8Array(8));
 * ```
 */
export function isAligned32(bytes) {
    return bytes.byteOffset % 4 === 0;
}
/**
 * By default, returns u8a of expected length.
 * When `out` is specified, it checks it for validity and uses it.
 * @param expectedLength - expected output length in bytes.
 * @param out - optional caller-provided destination buffer.
 * @param onlyAligned - whether to require 32-bit alignment for `out`.
 * @returns Output buffer with the expected length.
 * @throws On wrong argument types. {@link TypeError}
 * @throws If a documented runtime validation or state check fails. {@link Error}
 * @example
 * ```ts
 * import { getOutput } from '@awasm/noble/utils.js';
 * getOutput(16);
 * ```
 */
export function getOutput(expectedLength, out, onlyAligned = true) {
    if (out === undefined)
        return new Uint8Array(expectedLength);
    // Keep Buffer/cross-realm Uint8Array support here instead of trusting a shape-compatible object.
    abytes(out, undefined, 'output');
    if (out.length !== expectedLength)
        throw new Error('"output" expected Uint8Array of length ' + expectedLength + ', got: ' + out.length);
    if (onlyAligned && !isAligned32(out))
        throw new Error('invalid output, must be aligned');
    return out;
}
/**
 * Encodes the AEAD length block as aadLength || dataLength.
 * Callers pass lengths already scaled to the mode's unit:
 * octets for ChaCha20-Poly1305, bits for GCM/GCM-SIV.
 * @param dataLength - encoded data length.
 * @param aadLength - encoded AAD length.
 * @param isLE - whether to write values in little-endian order.
 * @returns Encoded 16-byte length block.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { u64Lengths } from '@awasm/noble/utils.js';
 * u64Lengths(16, 8, true);
 * ```
 */
export function u64Lengths(dataLength, aadLength, isLE) {
    // Reject coercible non-number lengths like '10' and true before BigInt(...) accepts them.
    anumber(dataLength);
    anumber(aadLength);
    abool(isLE);
    const num = new Uint8Array(16);
    const view = createView(num);
    view.setBigUint64(0, BigInt(aadLength), isLE);
    view.setBigUint64(8, BigInt(dataLength), isLE);
    return num;
}
/**
 * Helper for KDFs: consumes Uint8Array or string.
 * String inputs are UTF-8 encoded; byte-array inputs stay aliased to the caller buffer.
 * @param data - string or bytes input.
 * @param errorTitle - optional field name for byte validation.
 * @returns Byte representation of the input.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { kdfInputToBytes } from '@awasm/noble/utils.js';
 * kdfInputToBytes('password');
 * ```
 */
export function kdfInputToBytes(data, errorTitle = '') {
    if (typeof data === 'string')
        return utf8ToBytes(data);
    return abytes(data, undefined, errorTitle);
}
/**
 * Copies several Uint8Arrays into one.
 * @param arrays - arrays to concatenate.
 * @returns Concatenated bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { concatBytes } from '@awasm/noble/utils.js';
 * concatBytes(new Uint8Array([1]), new Uint8Array([2, 3]));
 * ```
 */
export function concatBytes(...arrays) {
    let sum = 0;
    for (let i = 0; i < arrays.length; i++) {
        const a = arrays[i];
        abytes(a);
        sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i = 0, pad = 0; i < arrays.length; i++) {
        const a = arrays[i];
        res.set(a, pad);
        pad += a.length;
    }
    return res;
}
/**
 * Fast copy for validated, in-bounds byte ranges.
 * Overlap is intentionally unsupported here for speed: hot callers only pass disjoint ranges,
 * and same-buffer moves must use copyWithin()/set() at the call site instead.
 * @param dst - destination byte array.
 * @param dstPos - write offset in destination.
 * @param src - source byte array.
 * @param srcPos - read offset in source.
 * @param len - number of bytes to copy.
 * @example
 * ```ts
 * import { copyFast } from '@awasm/noble/utils.js';
 * const dst = new Uint8Array(4);
 * copyFast(dst, 1, new Uint8Array([7, 8]), 0, 2);
 * ```
 */
export function copyFast(dst, dstPos, src, srcPos, len) {
    if (len <= 0)
        return;
    if (len <= 64)
        for (let i = 0; i < len; i++)
            dst[dstPos + i] = src[srcPos + i];
    else
        dst.set(src.subarray(srcPos, srcPos + len), dstPos);
}
/**
 * Fast copy for validated, in-bounds 32-bit word ranges.
 * Overlap is intentionally unsupported here for speed: hot callers only pass disjoint ranges,
 * and same-buffer moves must use copyWithin()/set() at the call site instead.
 * @param dst - destination word array.
 * @param dstPos - write offset in destination.
 * @param src - source word array.
 * @param srcPos - read offset in source.
 * @param len - number of words to copy.
 * @example
 * ```ts
 * import { copyFast32 } from '@awasm/noble/utils.js';
 * const dst = new Uint32Array(4);
 * copyFast32(dst, 1, new Uint32Array([7, 8]), 0, 2);
 * ```
 */
export function copyFast32(dst, dstPos, src, srcPos, len) {
    if (len <= 0)
        return;
    if (len <= 64)
        for (let i = 0; i < len; i++)
            dst[dstPos + i] = src[srcPos + i];
    else
        dst.set(src.subarray(srcPos, srcPos + len), dstPos);
}
/**
 * Callers must pass a validated byte array; Uint8Array.from() would otherwise coerce arbitrary iterables.
 * Copies into a detached Uint8Array instead of using slice(), because Buffer.slice() aliases memory.
 * @param bytes - bytes to copy.
 * @returns Detached copy of the input bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { copyBytes } from '@awasm/noble/utils.js';
 * copyBytes(new Uint8Array([1, 2, 3]));
 * ```
 */
export function copyBytes(bytes) {
    // `Uint8Array.from(...)` would also accept arrays / other typed arrays. Keep this helper strict
    // because callers use it at byte-validation boundaries before mutating the detached copy.
    return Uint8Array.from(abytes(bytes));
}
/**
 * Creates OID opts for NIST hashes, with prefix 06 09 60 86 48 01 65 03 04 02.
 * Current callers pass one-byte hashAlgs suffixes for 2.16.840.1.101.3.4.2.<suffix>,
 * so the DER length byte stays 0x09.
 * @param suffix - final OID suffix byte.
 * @returns DER-encoded OID bytes.
 * @example
 * ```ts
 * import { oidNist } from '@awasm/noble/utils.js';
 * oidNist(1);
 * ```
 */
export const oidNist = (suffix) => Uint8Array.from([
    0x06,
    0x09,
    0x60,
    0x86,
    0x48,
    0x01,
    0x65,
    0x03,
    0x04,
    0x02,
    suffix,
]);
/**
 * Merges default options and passed options.
 * This mutates `defaults`, so callers pass fresh defaults when they need reuse.
 * @param defaults - default option object.
 * @param opts - caller-provided overrides.
 * @returns Merged options object.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * ```ts
 * import { checkOpts } from '@awasm/noble/utils.js';
 * checkOpts({ a: 1 }, { b: 2 });
 * ```
 */
export function checkOpts(defaults, opts) {
    if (opts !== undefined && {}.toString.call(opts) !== '[object Object]')
        throw new TypeError('options must be object or undefined');
    const merged = Object.assign(defaults, opts);
    return merged;
}
/**
 * Build sync and async wrappers from the same generator body.
 * @param cb_ - generator callback shared by sync and async variants.
 * @returns Function exposing both sync and `.async(...)` entrypoints.
 * @example
 * ```ts
 * import { mkAsync } from '@awasm/noble/utils.js';
 * const twice = mkAsync(function* (_setup, value: number) {
 *   return value * 2;
 * });
 * await twice.async(2);
 * ```
 */
export function mkAsync(cb_) {
    const cb = cb_;
    const genSetup = (canReturn) => {
        let setupDone = false;
        let progressTotal = -1;
        let done = 0;
        let stateBytes = 0;
        let state;
        let onSave = (_state) => { };
        let onRestore = (_state) => { };
        /**
         * Default scheduler yields to the Promise microtask queue.
         * Callers can pass `nextTick` when they need a custom scheduler.
         */
        let onNextTick = async () => { };
        return {
            save: () => {
                if (!canReturn || !stateBytes)
                    return;
                if (!state)
                    state = new Uint8Array(stateBytes);
                onSave(state);
            },
            restore: () => {
                if (!canReturn || !state)
                    return;
                onRestore(state);
            },
            nextTick: () => onNextTick(),
            onEnd: () => {
                // setup() can be skipped on explicit sync fast-paths.
                if (progressTotal < 0)
                    return;
                if (done !== progressTotal)
                    throw new Error(`done (${done}) < progressTotal(${progressTotal})`);
            },
            setup: (_opts) => {
                const rawOpts = _opts;
                if (setupDone)
                    throw new Error('setup already called');
                setupDone = true;
                if (!canReturn) {
                    anumber(rawOpts.total, 'total');
                    progressTotal = rawOpts.total;
                    const onProgress = rawOpts.onProgress;
                    if (onProgress !== undefined && typeof onProgress !== 'function')
                        throw new Error('onProgress must be a function');
                    if (!onProgress) {
                        return (inc = 1) => {
                            done += inc;
                            return false;
                        };
                    }
                    const callbackPer = Math.max(Math.floor(progressTotal / 10000), 1);
                    return (inc = 1) => {
                        done += inc;
                        if (!(done % callbackPer) || done === progressTotal)
                            onProgress(progressTotal ? done / progressTotal : 1);
                        return false;
                    };
                }
                const opts = { ...rawOpts };
                if (opts.asyncTick === undefined)
                    delete opts.asyncTick; // will override defaults otherwise
                const { asyncTick, onProgress, stateBytes: _stateBytes, save, restore, nextTick, total, } = checkOpts({ asyncTick: 10 }, opts);
                anumber(asyncTick, 'asyncTick');
                anumber(total, 'total');
                progressTotal = total;
                for (const [k, v] of Object.entries({ onProgress, save, restore, nextTick })) {
                    if (v !== undefined && typeof v !== 'function')
                        throw new Error(`${k} must be a function`);
                }
                if (_stateBytes !== undefined)
                    anumber(_stateBytes, 'stateBytes');
                if (_stateBytes !== undefined)
                    stateBytes = _stateBytes;
                if ((save !== undefined || restore !== undefined) && !stateBytes)
                    throw new Error('stateBytes must be a positive integer when save/restore is used');
                if (save !== undefined)
                    onSave = save;
                if (restore !== undefined)
                    onRestore = restore;
                if (nextTick !== undefined)
                    onNextTick = nextTick;
                let needReturn = () => false;
                if (canReturn) {
                    let ts = Date.now();
                    needReturn = () => {
                        // Date.now() is not monotonic, so in case if clock goes backwards we return return control too
                        const diff = Date.now() - ts;
                        if (diff >= 0 && diff < asyncTick)
                            return false;
                        ts += diff;
                        return true;
                    };
                }
                // Invoke callback if progress changes from 10.01 to 10.02
                // Allows to draw smooth progress bar on up to 8K screen
                const callbackPer = Math.max(Math.floor(progressTotal / 10000), 1);
                let progress = (inc = 1) => {
                    done += inc;
                    return needReturn();
                };
                if (onProgress) {
                    progress = (inc = 1) => {
                        done += inc;
                        if (onProgress && (!(done % callbackPer) || done === total))
                            onProgress(total ? done / total : 1);
                        return needReturn();
                    };
                }
                return progress;
            },
        };
    };
    const res = (...args) => {
        let setupDone = false;
        let progressTotal = -1;
        let done = 0;
        const setup = ((opts) => {
            const rawOpts = opts;
            if (setupDone)
                throw new Error('setup already called');
            setupDone = true;
            anumber(rawOpts.total, 'total');
            progressTotal = rawOpts.total;
            const onProgress = rawOpts.onProgress;
            if (onProgress !== undefined && typeof onProgress !== 'function')
                throw new Error('onProgress must be a function');
            if (!onProgress) {
                return (inc = 1) => {
                    done += inc;
                    return false;
                };
            }
            const callbackPer = Math.max(Math.floor(progressTotal / 10000), 1);
            return (inc = 1) => {
                done += inc;
                // Keep zero-total sync progress aligned with the async path for empty-input callers.
                if (!(done % callbackPer) || done === progressTotal)
                    onProgress(progressTotal ? done / progressTotal : 1);
                return false;
            };
        });
        setup.isAsync = false;
        const g = cb(setup, ...args);
        let r = g.next();
        while (!r.done)
            r = g.next();
        if (progressTotal >= 0 && done !== progressTotal)
            throw new Error(`done (${done}) < progressTotal(${progressTotal})`);
        return r.value;
    };
    res.async = async (...args) => {
        const { setup, save, restore, onEnd, nextTick } = genSetup(true);
        const setupMode = setup;
        setupMode.isAsync = true;
        const g = cb(setupMode, ...args);
        let r = g.next();
        while (!r.done) {
            save();
            await nextTick();
            restore();
            r = g.next();
        }
        onEnd();
        return r.value;
    };
    return res;
}
/**
 * Compares two byte arrays in kinda constant time once lengths already match.
 * Different lengths return false immediately.
 * @param a - first byte array.
 * @param b - second byte array.
 * @returns True when the byte arrays are equal.
 * @example
 * ```ts
 * import { equalBytes } from '@awasm/noble/utils.js';
 * equalBytes(new Uint8Array([1, 2]), new Uint8Array([1, 2]));
 * ```
 */
export function equalBytes(a, b) {
    if (a.length !== b.length)
        return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++)
        diff |= a[i] ^ b[i];
    return diff === 0;
}
/**
 * Cryptographically secure PRNG. Uses internal OS-level `crypto.getRandomValues`.
 * @param bytesLength - number of random bytes to generate.
 * @returns Random bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @throws If a documented runtime validation or state check fails. {@link Error}
 * @example
 * ```ts
 * import { randomBytes } from '@awasm/noble/utils.js';
 * randomBytes(16);
 * ```
 */
export function randomBytes(bytesLength = 32) {
    // Validate upfront so fractional / coercible lengths do not silently
    // truncate through Uint8Array().
    anumber(bytesLength);
    const cr = typeof globalThis === 'object' ? globalThis.crypto : null;
    if (typeof cr?.getRandomValues !== 'function')
        throw new Error('crypto.getRandomValues must be defined');
    return cr.getRandomValues(new Uint8Array(bytesLength));
}
/**
 * Uses CSPRNG for nonce and injects it into ciphertext.
 * For `encrypt`, a `nonceLength`-byte nonce is fetched from CSPRNG and
 * prepended to encrypted ciphertext. For `decrypt`, the first `nonceLength`
 * bytes of ciphertext are treated as nonce.
 *
 * The wrapper always allocates a fresh `nonce || ciphertext` buffer on encrypt
 * and intentionally does not support caller-provided destination buffers.
 * Too-short decrypt inputs are split into short/empty nonce views and then
 * delegated to the wrapped cipher instead of being rejected here first.
 *
 * NOTE: Under the same key, using random nonces (e.g. `managedNonce`) with AES-GCM and ChaCha
 * should be limited to `2**23` (8M) messages to get a collision chance of
 * `2**-50`. Stretching to `2**32` (4B) messages would raise that chance to
 * `2**-33`, still negligible but creeping up.
 * @param fn - nonce-taking cipher factory.
 * @param randomBytes_ - CSPRNG used to generate nonces.
 * @returns Cipher factory that prepends managed nonces to ciphertext.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * ```ts
 * import { managedNonce } from '@awasm/noble/utils.js';
 * import { xchacha20poly1305 } from '@awasm/noble';
 * const cipher = managedNonce(xchacha20poly1305)(new Uint8Array(32));
 * const sealed = cipher.encrypt(new Uint8Array([1, 2, 3]));
 * cipher.decrypt(sealed);
 * ```
 */
export function managedNonce(fn, randomBytes_ = randomBytes) {
    const { nonceLength } = fn;
    const nonceLen = nonceLength;
    anumber(nonceLen);
    const addNonce = (nonce, ciphertext, plaintext) => {
        const out = concatBytes(nonce, ciphertext);
        // Wrapped ciphers may alias caller plaintext on encrypt(); don't wipe caller-owned bytes here.
        if (!overlapBytes(plaintext, ciphertext))
            ciphertext.fill(0);
        return out;
    };
    // NOTE: we cannot support DST here, it would be a mistake:
    // - we don't know how much dst length cipher requires
    // - nonce may unalign dst and break everything
    // - we create new u8a anyway (concatBytes)
    // - previously all args were passed-through to a cipher, but that was a mistake
    const res = ((key, ...args) => ({
        encrypt(plaintext) {
            abytes(plaintext);
            const nonce = randomBytes_(nonceLen);
            const encrypted = fn(key, nonce, ...args).encrypt(plaintext);
            // @ts-ignore
            if (encrypted instanceof Promise)
                return encrypted.then((ct) => addNonce(nonce, ct, plaintext));
            return addNonce(nonce, encrypted, plaintext);
        },
        decrypt(ciphertext) {
            abytes(ciphertext);
            const nonce = ciphertext.subarray(0, nonceLen);
            const decrypted = ciphertext.subarray(nonceLen);
            return fn(key, nonce, ...args).decrypt(decrypted);
        },
    }));
    // awasm tests and callers still treat managed wrappers as cipher factories, so preserve metadata.
    if ('blockSize' in fn)
        res.blockSize = fn.blockSize;
    res.nonceLength = nonceLen;
    if ('tagLength' in fn)
        res.tagLength = fn.tagLength;
    if (fn.withAAD)
        res.withAAD = true;
    return res;
}
