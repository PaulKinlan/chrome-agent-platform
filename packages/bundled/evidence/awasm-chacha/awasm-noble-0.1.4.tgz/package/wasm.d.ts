export * from './targets/wasm/index.ts';
//# sourceMappingURL=wasm.d.ts.map