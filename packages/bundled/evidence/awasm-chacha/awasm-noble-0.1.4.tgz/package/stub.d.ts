export * from './targets/stub/index.ts';
//# sourceMappingURL=stub.d.ts.map