/**
 * HKDF (RFC 5869): extract + expand in one step.
 * @module
 */
import { type HashInstance } from './hashes-abstract.ts';
import { type TArg, type TRet } from './utils.ts';
/**
 * HKDF-extract from spec. Less important part. `HKDF-Extract(IKM, salt) -> PRK`
 * Arguments position differs from spec (IKM is first one, since it is not optional)
 * Local validation only checks `hash`; `ikm` / `salt` byte validation is delegated to `hmac()`.
 * @param hash - hash function that would be used (e.g. sha256)
 * @param ikm - input keying material, the initial key
 * @param salt - optional salt value (a non-secret random value)
 * @returns Pseudorandom key derived from input keying material.
 * @example
 * Run the HKDF extract step.
 * ```ts
 * import { extract } from '@awasm/noble/hkdf.js';
 * import { sha256 } from '@awasm/noble';
 * extract(sha256, new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6]));
 * ```
 */
export declare function extract(hash: TArg<HashInstance<any>>, ikm: TArg<Uint8Array>, salt?: TArg<Uint8Array>): TRet<Uint8Array>;
/**
 * HKDF-expand from the spec. The most important part. `HKDF-Expand(PRK, info, L) -> OKM`
 * @param hash - hash function that would be used (e.g. sha256)
 * @param prk - a pseudorandom key of at least HashLen octets
 *   (usually the output from the extract step)
 * @param info - optional context and application specific information (can be a zero-length string)
 * @param length - length of output keying material in bytes.
 *   RFC 5869 §2.3 allows `0..255*HashLen`, so `0` returns an empty OKM.
 * @returns Output keying material with the requested length.
 * @throws If the requested output length exceeds the HKDF limit for the
 *   selected hash. {@link Error}
 */
export declare function expand(hash: TArg<HashInstance<any>>, prk: TArg<Uint8Array>, info?: TArg<Uint8Array>, length?: number): TRet<Uint8Array>;
/**
 * HKDF (RFC 5869): derive keys from an initial input.
 * Combines hkdf_extract + hkdf_expand in one step
 * @param hash - hash function that would be used (e.g. sha256)
 * @param ikm - input keying material, the initial key
 * @param salt - optional salt value (a non-secret random value)
 * @param info - optional context and application specific information bytes
 * @param length - length of output keying material in bytes.
 *   RFC 5869 §2.3 allows `0..255*HashLen`, so `0` returns an empty OKM.
 * @returns Output keying material derived from the input key.
 * @throws If the requested output length exceeds the HKDF limit for the
 *   selected hash. {@link Error}
 * @example
 * HKDF (RFC 5869): derive keys from an initial input.
 * ```ts
 * import { hkdf } from '@awasm/noble/hkdf.js';
 * import { sha256 } from '@awasm/noble';
 * const okm = hkdf(
 *   sha256,
 *   new Uint8Array([1, 2, 3]),
 *   new Uint8Array([4, 5, 6]),
 *   new Uint8Array([7]),
 *   16
 * );
 * ```
 */
export declare const hkdf: (hash: TArg<HashInstance<any>>, ikm: TArg<Uint8Array>, salt: TArg<Uint8Array | undefined>, info: TArg<Uint8Array | undefined>, length: number) => TRet<Uint8Array>;
//# sourceMappingURL=hkdf.d.ts.map