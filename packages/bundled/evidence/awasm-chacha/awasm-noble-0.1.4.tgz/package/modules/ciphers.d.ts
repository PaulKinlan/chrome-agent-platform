/**
 * Core AES logic.
 * The file is not used in end-user code. Instead, it's used by awasm-compiler
 * to generate different build targets (wasm, wasm_threads, js, runtime).
 * @module
 */
import type { ArraySpec, FnDef, FnRegistry, GetOps, MemorySurface, ScalarSpec, Scope, Segs, StructSpec, Val } from '@awasm/compiler/module.js';
import { Module } from '@awasm/compiler/module.js';
import type { TypeName } from '@awasm/compiler/types.js';
type Shape = symbol | Shape[] | {
    [k: string]: Shape;
};
export declare const chachaCore: (f: Scope, lanes: number, X: Val<"u32", unknown>[], rounds: number, add: boolean) => void;
export declare const salsaCore: (f: Scope, lanes: number, X: Val<"u32", unknown>[], rounds: number, add: boolean) => void;
export declare const genSalsa: (type: TypeName, opts: {
    rounds: number;
}) => Module<{
    state: StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        sigma: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
} & {
    derive: StructSpec<{
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        out: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
    }>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
} & {
    derive: FnDef<never[], void>;
}>;
export declare const genChacha: (type: TypeName, opts: {
    rounds: number;
}) => Module<{
    state: StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        sigma: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
} & {
    derive: StructSpec<{
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        out: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
    }>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
} & {
    derive: FnDef<never[], void>;
}>;
export declare const genSalsaAead: (type: TypeName, opts: {
    rounds: number;
}) => Module<{
    state: StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        shiftSet: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [1]>;
        sigma: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [2]>;
        aadLen: ScalarSpec<"u64", unknown, number>;
        dataLen: ScalarSpec<"u64", unknown, number>;
        poly: StructSpec<{
            key: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4]>;
            r: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            r5: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            h: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [10]>;
            pad: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [8]>;
            tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
} & {
    derive: StructSpec<{
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        out: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
    }>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    macInit: FnDef<never[], void>;
} & {
    macPadAt: FnDef<"u32"[], void>;
} & {
    macBlocksAt: FnDef<"u32"[], void>;
} & {
    macFinish: FnDef<never[], void>;
} & {
    aadInit: FnDef<never[], void>;
} & {
    aadBlocks: FnDef<"u32"[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    process: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
} & {
    tagFinish: FnDef<never[], void>;
} & {
    derive: FnDef<never[], void>;
}>;
export declare const genChachaAead: (type: TypeName, opts: {
    rounds: number;
}) => Module<{
    state: StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        sigma: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [3]>;
        aadLen: ScalarSpec<"u64", unknown, number>;
        dataLen: ScalarSpec<"u64", unknown, number>;
        poly: StructSpec<{
            key: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4]>;
            r: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            r5: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            msg: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4, 5]>;
            h: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [10]>;
            pad: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [8]>;
            tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
} & {
    derive: StructSpec<{
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        out: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
    }>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    macInit: FnDef<never[], void>;
} & {
    macPadAt: FnDef<"u32"[], void>;
} & {
    macBlocksAt: FnDef<"u32"[], void>;
} & {
    macFinish: FnDef<never[], void>;
} & {
    process: FnDef<"u32"[], void>;
} & {
    aadInit: FnDef<never[], void>;
} & {
    aadBlocks: FnDef<"u32"[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
} & {
    tagFinish: FnDef<never[], void>;
} & {
    derive: FnDef<never[], void>;
}>;
type AesDir = 'encrypt' | 'decrypt';
export declare const AES_BLOCK_LEN = 16;
export declare const AES_BLOCKS: number;
export declare const KEY_LEN_MAX = 8;
export declare const EXPANDED_KEY_MAX: number;
export declare const aesConsts: StructSpec<{
    encrypt: StructSpec<{
        sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
        T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
    }>;
    decrypt: StructSpec<{
        sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
        T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
    }>;
    xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    inited: ScalarSpec<"u32", unknown, number>;
}>;
export declare const aesBatchFn: <Name extends string, F extends FnRegistry, M extends Segs & {
    state: StructSpec<{
        rounds: ScalarSpec<"u32">;
        expandedKey: ArraySpec<ScalarSpec<"u32">, readonly [number]>;
    }>;
    constants: typeof aesConsts;
}, Ctx extends Shape>(name: Name, dir: AesDir, init: (f: Scope<M, F>, batchPos: Val<"u32">, perBatch: Val<"u32">, blocks: Val<"u32">) => Ctx, cb: (f: Scope<M, F>, ctx: Ctx, processBlock: (in4: Val<"u32">[]) => Val<"u32">[], pos: Val<"u32">) => Ctx) => (mod: Module<M, F>) => Module<M, F & { [P in Name]: FnDef<"u32"[], void>; }>;
type AesKeyStateSpec = StructSpec<{
    key: ArraySpec<ScalarSpec<'u32'>, readonly [number]>;
    tmp: ArraySpec<ScalarSpec<'u32'>, readonly [number]>;
    expandedKey: ArraySpec<ScalarSpec<'u32'>, readonly [number]>;
    rounds: ScalarSpec<'u32'>;
}>;
export declare const aesInitKeys: (opts?: {
    withDecrypt?: boolean;
}) => <M extends Segs & {
    state: AesKeyStateSpec;
    constants: typeof aesConsts;
}, F extends FnRegistry>(mod: Module<M, F>) => Module<M, F & {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
}>;
export declare const PCKS7: () => <M extends Segs & {
    buffer: ArraySpec<ScalarSpec<"u32">, readonly [number, ...number[]]>;
}, F extends FnRegistry>(mod: Module<M, F>) => Module<M, F & {
    addPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    verifyPadding: FnDef<"u32"[], Val<"u32", unknown>>;
}>;
export declare const roundBlocks: <M extends Segs>(f: Scope<M, {}>, round: Val<"u32">, dir: AesDir, doMac: () => void, doCtr: () => void) => void;
export type MemU32 = MemorySurface<{
    mem: ArraySpec<ScalarSpec<'u32'>, readonly [number]>;
}>['mem'];
export type MemU32Scalar = MemorySurface<{
    mem: ScalarSpec<'u32'>;
}>['mem'];
export declare const aesKeyInitEnc: <M extends Segs & {
    constants: typeof aesConsts;
}>(f: Scope<M, {}>, keyLen: Val<"u32">, keyMem: MemU32, tmp: MemU32, expandedKey: MemU32, rounds: MemU32Scalar) => Val<"u32", unknown>[];
export declare const aesWithBlock: <M extends Segs & {
    constants: typeof aesConsts;
}>(f: Scope<M, {}>, dir: AesDir, roundsVal: Val<"u32">, expKey: MemU32, cb: (processBlock: (in4: Val<"u32">[]) => Val<"u32">[]) => void) => void;
export declare const aesInitTables: <M extends Segs & {
    constants: typeof aesConsts;
}>(f: Scope<M, {}>) => void;
export declare const bswap32: (u32: GetOps<"u32">, x: Val<"u32">) => Val<"u32", unknown>;
export declare const incCounter: <M extends Segs>(f: Scope<M, {}>, isBE?: boolean) => {
    inplace: (limbs: Val<"u32">[], inc: Val<"u32">) => Val<"u32">[];
    memory: (limbs: MemorySurface<{
        limbs: ArraySpec<ScalarSpec<"u32">, readonly [number]>;
    }>["limbs"], inc: Val<"u32">) => void;
};
export declare const cmacDbl: <M extends Segs>(f: Scope<M, {}>, src: MemU32) => void;
export declare const cmacXor: (u32: GetOps<"u32">, bv: Val<"u32">[], iv: Val<"u32">[], k1: Val<"u32">[], k2: Val<"u32">[], useK: Val<"u32">, useK2: Val<"u32">) => Val<"u32", unknown>[];
export declare const cmacSubkeysInit: <M extends Segs & {
    constants: typeof aesConsts;
}>(f: Scope<M, {}>, len: Val<"u32">, st: {
    key: MemU32;
    tmp: MemU32;
    expandedKey: MemU32;
    rounds: MemU32Scalar;
    k1: MemU32;
    k2: MemU32;
    iv: MemU32;
}) => void;
export declare const genCmac: (_type: TypeName, _opts: {}) => Module<{
    state: ArraySpec<StructSpec<{
        state: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        k1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        k2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    padding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    macInit: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    processOutBlocks: FnDef<"u32"[], void>;
}>;
export declare const callBatch: <M extends Segs, F extends FnRegistry>(f: Scope<M, F>, blocks: Val<"u32">, call: (batchPos: Val<"u32">, batchLen: Val<"u32">, perBatch: Val<"u32">) => void) => void;
export declare const genAesEcb: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    addPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    verifyPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    processBlocksEnc: FnDef<"u32"[], void>;
} & {
    processBlocksDec: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesCbc: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    addPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    verifyPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesCfb: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesOfb: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesCtr: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesGcm: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        aadLen: ScalarSpec<"u64", unknown, number>;
        dataLen: ScalarSpec<"u64", unknown, number>;
        tagMask: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ghash: StructSpec<{
            y: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
            y64: ScalarSpec<"u64x2", unknown, number>;
            h: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
        table64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
        tmp64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    padLast: FnDef<"u32"[], void>;
} & {
    ghashBlocks: FnDef<"u32"[], void>;
} & {
    gcmInitJ0: FnDef<never[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    aadInit: FnDef<never[], void>;
} & {
    aadBlocks: FnDef<"u32"[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    nonceFinish: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
} & {
    tagFinish: FnDef<never[], void>;
}>;
export declare const genAesGcmSiv: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        encKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        nonce: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ctr: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        aadLen: ScalarSpec<"u64", unknown, number>;
        dataLen: ScalarSpec<"u64", unknown, number>;
        tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ctrReady: ScalarSpec<"u32", unknown, number>;
        ghash: StructSpec<{
            y: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
            y64: ScalarSpec<"u64x2", unknown, number>;
            h: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
        table64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
        tmp64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    polyBlocks: FnDef<"u32"[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    aadBlocks: FnDef<"u32"[], void>;
} & {
    macBlocks: FnDef<"u32"[], void>;
} & {
    tagInit: FnDef<never[], void>;
} & {
    tagFinish: FnDef<never[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesSiv: (_type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        expandedKeyCmac: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
        k1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        k2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        d: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ctr: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ctrReady: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: FnDef<"u32"[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    aadBlocks: FnDef<"u32"[], void>;
} & {
    macBlocks: FnDef<"u32"[], void>;
} & {
    processBlocks: FnDef<"u32"[], void>;
} & {
    tagInit: FnDef<never[], void>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesKw: (type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 2]>;
}, {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    aesBlockEnc: FnDef<"u32"[], Val<"u32", unknown>[]>;
} & {
    aesBlockDec: FnDef<"u32"[], Val<"u32", unknown>[]>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    addPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    verifyPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export declare const genAesKwp: (type: TypeName, _opts: {}) => Module<{
    state: StructSpec<{
        key: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        expandedKey: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        tmp: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number]>;
        rounds: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    constants: StructSpec<{
        encrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        decrypt: StructSpec<{
            sbox: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64]>;
            T0: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T1: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T2: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
            T3: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [256]>;
        }>;
        xPowers: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        inited: ScalarSpec<"u32", unknown, number>;
    }>;
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 2]>;
}, {
    initTables: FnDef<never[], void>;
} & {
    encryptInit: FnDef<"u32"[], void>;
} & {
    decryptInit: FnDef<"u32"[], void>;
} & {
    aesBlockEnc: FnDef<"u32"[], Val<"u32", unknown>[]>;
} & {
    aesBlockDec: FnDef<"u32"[], Val<"u32", unknown>[]>;
} & {
    reset: FnDef<"u32"[], void>;
} & {
    addPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    verifyPadding: FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    encryptBlocks: FnDef<"u32"[], void>;
} & {
    decryptBlocks: FnDef<"u32"[], void>;
}>;
export {};
//# sourceMappingURL=ciphers.d.ts.map