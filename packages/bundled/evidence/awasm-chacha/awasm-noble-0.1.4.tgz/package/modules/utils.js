import {} from '@awasm/compiler/types.js';
export function getLanes(_type) {
    // Even for u64 it is better to use virtual u64x4 than real u64x2.
    // Lane count is scheduling-only.
    // Batch functions still address logical messages by batch position.
    return 4;
}
export function readMSG(f, region, clear = true) {
    // `BUFFER.fill(0)` is slow garbage: even BUFFER.set() is faster,
    // but requires pre-allocated array of exact size.
    // So, instead of doing `fill` to zeroize data, we zeroize on read.
    // This should be slower in theory: for 100MB we would
    // wipe buffer on every 10MB chunk, instead of just once.
    //
    // The trick why it's faster: cache / memory locality,
    // we are wiping region which we've just touched.
    const T = f.getTypeGeneric(region.type);
    // Keep the block values live for the caller before zeroizing module-owned scratch.
    const res = region.get();
    if (clear)
        region.set(Array.isArray(res) ? res.map((_i) => T.const(0)) : T.const(0));
    return res;
}
// Shared workspace budget; callers reshape this count to each algorithm's block width.
export const CHUNKS = 10 * 1024 * 16; // ~10MB, 160K blocks
// Thread scheduling threshold; kernels still clamp actual work from their block counts.
export const MIN_PER_THREAD = 1024; // 1k blocks
// Shared u32 byteswap. Placed here so `mac.ts` doesn't need to import from AES modules
// (avoids circular deps).
export const bswap = (u32, x) => u32.or(u32.or(u32.shl(u32.and(x, u32.const(0xff)), 24), u32.shl(u32.and(x, u32.const(0xff00)), 8)), u32.or(u32.shr(u32.and(x, u32.const(0xff0000)), 8), u32.shr(x, 24)));
