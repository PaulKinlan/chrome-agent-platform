/**
 * Core hash functions logic.
 * Contains SHA1, SHA2, SHA3, BLAKE1, BLAKE2, BLAKE3, RIPEMD, MD5.
 * The file is not used in end-user code. Instead, it's used by awasm-compiler
 * to generate different build targets (wasm, wasm_threads, js, runtime).
 * @module
 */
import type { ArraySpec, ScalarSpec, StructSpec, Val } from '@awasm/compiler/module.js';
import { Module } from '@awasm/compiler/module.js';
import { type TypeName, type UnsignedType } from '@awasm/compiler/types.js';
export declare function genSha1<T extends UnsignedType>(type: T, _opts: undefined): Module<{
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [5]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    resetBuffer: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genSha2<T extends UnsignedType>(type: T, opts: {
    K: any;
    rounds: number;
    shifts: number[];
}): Module<{
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [8]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    resetBuffer: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genKeccak<T extends UnsignedType>(type: T, opts: {
    rounds: number;
}): Module<{
    rc: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [24]>;
} & {
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [25]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number]>;
}, {
    initKeccak: import("@awasm/compiler/module.js").FnDef<never[], void>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genRipemd<T extends UnsignedType>(type: T, _opts: undefined): Module<{
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [5]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    resetBuffer: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genMd5<T extends UnsignedType>(type: T, _opts: undefined): Module<{
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [4]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    resetBuffer: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genBlake1<T extends UnsignedType>(type: T, opts: {
    rounds: number;
    shifts: number[];
    tbl: any[];
    constants: any[];
}): Module<{
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [8]>;
        salt: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [4]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    resetBuffer: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genBlake2<T extends UnsignedType>(type: T, opts: {
    rounds: number;
    shifts: number[];
    IV: any;
}): Module<{
    init: ArraySpec<StructSpec<{
        salt: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [2]>;
        personalization: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [2]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    state: ArraySpec<StructSpec<{
        counter: ScalarSpec<"u64", unknown, number>;
        state: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [8]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<UnsignedType, T, number>, readonly [number, 16]>;
}, {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    initBlake2: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genBlake3(_type: TypeName, _opts?: {}): Module<{
    state: ArraySpec<StructSpec<{
        chunksDone: ScalarSpec<"u64", unknown, number>;
        chunkOut: ScalarSpec<"u64", unknown, number>;
        flags: ScalarSpec<"u32", unknown, number>;
        chunkPos: ScalarSpec<"u32", unknown, number>;
        stackPos: ScalarSpec<"u32", unknown, number>;
        lastBlockRem: ScalarSpec<"u32", unknown, number>;
        iv: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        state: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [8]>;
        stack: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [64, 8]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 16, 16]>;
} & {
    stackBuffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 8]>;
}, {
    compressParents: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    compressParentsFull: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    proccessChunksSequential: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    proccessChunksParallel: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
//# sourceMappingURL=hashes.d.ts.map