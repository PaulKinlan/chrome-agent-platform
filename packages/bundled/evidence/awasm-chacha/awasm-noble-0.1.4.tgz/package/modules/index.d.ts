import { genAesCbc, genAesCfb, genAesCtr, genAesEcb, genAesGcm, genAesGcmSiv, genAesKw, genAesKwp, genAesOfb, genAesSiv, genChacha, genChachaAead, genCmac, genSalsa, genSalsaAead } from './ciphers.ts';
import { genBlake1, genBlake2, genBlake3, genKeccak, genMd5, genRipemd, genSha1, genSha2 } from './hashes.ts';
import { genArgon2, genScrypt } from './kdf.ts';
import { genGhash, genPoly1305, genPolyval } from './mac.ts';
export declare const GENERATORS: Readonly<{
    readonly genKeccak: typeof genKeccak;
    readonly genSha1: typeof genSha1;
    readonly genSha2: typeof genSha2;
    readonly genRipemd: typeof genRipemd;
    readonly genMd5: typeof genMd5;
    readonly genBlake1: typeof genBlake1;
    readonly genBlake2: typeof genBlake2;
    readonly genBlake3: typeof genBlake3;
    readonly genScrypt: typeof genScrypt;
    readonly genArgon2: typeof genArgon2;
    readonly genSalsa: (type: import("@awasm/compiler/types.js").TypeName, opts: {
        rounds: number;
    }) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            counter: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            sigma: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
    } & {
        derive: import("@awasm/compiler/module.js").StructSpec<{
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            out: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
        }>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        derive: import("@awasm/compiler/module.js").FnDef<never[], void>;
    }>;
    readonly genSalsaAead: (type: import("@awasm/compiler/types.js").TypeName, opts: {
        rounds: number;
    }) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            counter: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            shiftSet: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [1]>;
            sigma: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [2]>;
            aadLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            dataLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            poly: import("@awasm/compiler/module.js").StructSpec<{
                key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4]>;
                r: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                r5: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [10]>;
                pad: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [8]>;
                tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    } & {
        derive: import("@awasm/compiler/module.js").StructSpec<{
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            out: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
        }>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        macPadAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macBlocksAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        aadInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        aadBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        process: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        tagFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        derive: import("@awasm/compiler/module.js").FnDef<never[], void>;
    }>;
    readonly genChacha: (type: import("@awasm/compiler/types.js").TypeName, opts: {
        rounds: number;
    }) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            counter: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            sigma: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
    } & {
        derive: import("@awasm/compiler/module.js").StructSpec<{
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            out: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
        }>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        derive: import("@awasm/compiler/module.js").FnDef<never[], void>;
    }>;
    readonly genChachaAead: (type: import("@awasm/compiler/types.js").TypeName, opts: {
        rounds: number;
    }) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            counter: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            sigma: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [3]>;
            aadLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            dataLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            poly: import("@awasm/compiler/module.js").StructSpec<{
                key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4]>;
                r: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                r5: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                msg: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4, 5]>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [10]>;
                pad: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [8]>;
                tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    } & {
        derive: import("@awasm/compiler/module.js").StructSpec<{
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            out: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
        }>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        macPadAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macBlocksAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        process: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aadInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        aadBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        tagFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        derive: import("@awasm/compiler/module.js").FnDef<never[], void>;
    }>;
    readonly genAesEcb: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        addPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        verifyPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocksEnc: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocksDec: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesCbc: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            iv: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        addPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        verifyPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesCfb: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            iv: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesOfb: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            iv: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesCtr: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesGcm: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            aadLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            dataLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            tagMask: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ghash: import("@awasm/compiler/module.js").StructSpec<{
                y: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
                y64: import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
            table64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
            tmp64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        padLast: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        ghashBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        gcmInitJ0: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aadInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        aadBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        nonceFinish: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        tagFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    }>;
    readonly genAesGcmSiv: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            encKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            nonce: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ctr: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            aadLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            dataLen: import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>;
            tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ctrReady: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            ghash: import("@awasm/compiler/module.js").StructSpec<{
                y: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
                y64: import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
            table64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
            tmp64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        polyBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aadBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        tagInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        tagFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesSiv: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            expandedKeyCmac: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            k1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            k2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            iv: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            d: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ctr: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ctrReady: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aadBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        tagInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesKw: (type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 2]>;
    }, {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aesBlockEnc: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>[]>;
    } & {
        aesBlockDec: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>[]>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        addPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        verifyPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genAesKwp: (type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").StructSpec<{
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 2]>;
    }, {
        initTables: import("@awasm/compiler/module.js").FnDef<never[], void>;
    } & {
        encryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        aesBlockEnc: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>[]>;
    } & {
        aesBlockDec: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>[]>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        addPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        verifyPadding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        encryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        decryptBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genCmac: (_type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").StructSpec<{
            state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [8]>;
            expandedKey: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            tmp: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
            k1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            k2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            iv: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            rounds: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
            tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>, [number]> & {
            batch: true;
        };
    } & {
        constants: import("@awasm/compiler/module.js").StructSpec<{
            encrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            decrypt: import("@awasm/compiler/module.js").StructSpec<{
                sbox: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [64]>;
                T0: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T1: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T2: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
                T3: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [256]>;
            }>;
            xPowers: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            inited: import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>;
        }>;
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        padding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genGhash: (type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").StructSpec<{
            state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ghash: import("@awasm/compiler/module.js").StructSpec<{
                y: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
                y64: import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
            table64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
            tmp64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
        }>, [number]> & {
            batch: true;
        };
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        padding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genPolyval: (type: import("@awasm/compiler/types.js").TypeName, { reverse: _reverse }: {
        reverse: true;
    }) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").StructSpec<{
            state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            ghash: import("@awasm/compiler/module.js").StructSpec<{
                y: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
                y64: import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
            table64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
            tmp64v: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
        }>, [number]> & {
            batch: true;
        };
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        padding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
    readonly genPoly1305: (type: import("@awasm/compiler/types.js").TypeName, _opts: {}) => import("@awasm/compiler/module.js").Module<{
        state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").StructSpec<{
            state: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [10]>;
            poly: import("@awasm/compiler/module.js").StructSpec<{
                key: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4]>;
                r: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                r5: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
                h: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [10]>;
                pad: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [8]>;
                tag: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [4]>;
            }>;
        }>, [number]> & {
            batch: true;
        };
    } & {
        buffer: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
    }, {
        macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macPadAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macBlocksAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        macFinish: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        padding: import("@awasm/compiler/module.js").FnDef<"u32"[], import("@awasm/compiler/module.js").Val<"u32", unknown>>;
    } & {
        processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    } & {
        processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
    }>;
}>;
export { genAesCbc, genAesCfb, genAesCtr, genAesEcb, genAesGcm, genAesGcmSiv, genAesKw, genAesKwp, genAesOfb, genAesSiv, genArgon2, genBlake1, genBlake2, genBlake3, genChacha, genChachaAead, genCmac, genGhash, genKeccak, genMd5, genPoly1305, genPolyval, genRipemd, genSalsa, genSalsaAead, genScrypt, genSha1, genSha2, };
export declare const keccak24: {
    fn: "genKeccak";
    type: "u64";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const sha256: {
    fn: "genSha2";
    type: "u32";
    opts: {
        K: number[];
        rounds: number;
        shifts: number[];
    };
    compilerOpts: {};
};
export declare const sha512: {
    fn: "genSha2";
    type: "u64";
    opts: {
        K: bigint[];
        rounds: number;
        shifts: number[];
    };
    compilerOpts: {
        wasmTee: true;
    };
};
export declare const sha1: {
    fn: "genSha1";
    type: "u32";
    opts: undefined;
    compilerOpts: {
        wasmTeeSimd: true;
    };
};
export declare const ripemd160: {
    fn: "genRipemd";
    type: "u32";
    opts: undefined;
    compilerOpts: {
        wasmTee: false;
    };
};
export declare const md5: {
    fn: "genMd5";
    type: "u32";
    opts: undefined;
    compilerOpts: {};
};
export declare const blake256: {
    fn: "genBlake1";
    type: "u32";
    opts: {
        rounds: number;
        shifts: number[];
        tbl: number[];
        constants: number[];
    };
    compilerOpts: {};
};
export declare const blake512: {
    fn: "genBlake1";
    type: "u64";
    opts: {
        rounds: number;
        shifts: number[];
        tbl: bigint[];
        constants: bigint[];
    };
    compilerOpts: {};
};
export declare const blake2s: {
    fn: "genBlake2";
    type: "u32";
    opts: {
        rounds: number;
        shifts: number[];
        IV: Uint32Array<ArrayBuffer>;
    };
    compilerOpts: {};
};
export declare const blake2b: {
    fn: "genBlake2";
    type: "u64";
    opts: {
        rounds: number;
        shifts: number[];
        IV: bigint[];
    };
    compilerOpts: {
        jsOpsPerFn: number;
    };
};
export declare const blake3: {
    fn: "genBlake3";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const scrypt: {
    fn: "genScrypt";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const argon2: {
    fn: "genArgon2";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const salsa20: {
    fn: "genSalsa";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const chacha20: {
    fn: "genChacha";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const chacha12: {
    fn: "genChacha";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const chacha8: {
    fn: "genChacha";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const salsa_poly1305: {
    fn: "genSalsaAead";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const chacha_poly1305: {
    fn: "genChachaAead";
    type: "u32";
    opts: {
        rounds: number;
    };
    compilerOpts: {};
};
export declare const aes_ecb: {
    fn: "genAesEcb";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_cbc: {
    fn: "genAesCbc";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_cfb: {
    fn: "genAesCfb";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_ofb: {
    fn: "genAesOfb";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_ctr: {
    fn: "genAesCtr";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_gcm: {
    fn: "genAesGcm";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_gcmsiv: {
    fn: "genAesGcmSiv";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_siv: {
    fn: "genAesSiv";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_kw: {
    fn: "genAesKw";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const aes_kwp: {
    fn: "genAesKwp";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const cmac: {
    fn: "genCmac";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const ghash: {
    fn: "genGhash";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const poly1305: {
    fn: "genPoly1305";
    type: "u32";
    opts: {};
    compilerOpts: {};
};
export declare const polyval: {
    fn: "genPolyval";
    type: "u32";
    opts: {
        reverse: true;
    };
    compilerOpts: {};
};
export declare const MODULES: Readonly<{
    keccak24: {
        fn: "genKeccak";
        type: "u64";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    sha256: {
        fn: "genSha2";
        type: "u32";
        opts: {
            K: number[];
            rounds: number;
            shifts: number[];
        };
        compilerOpts: {};
    };
    sha512: {
        fn: "genSha2";
        type: "u64";
        opts: {
            K: bigint[];
            rounds: number;
            shifts: number[];
        };
        compilerOpts: {
            wasmTee: true;
        };
    };
    sha1: {
        fn: "genSha1";
        type: "u32";
        opts: undefined;
        compilerOpts: {
            wasmTeeSimd: true;
        };
    };
    ripemd160: {
        fn: "genRipemd";
        type: "u32";
        opts: undefined;
        compilerOpts: {
            wasmTee: false;
        };
    };
    md5: {
        fn: "genMd5";
        type: "u32";
        opts: undefined;
        compilerOpts: {};
    };
    blake256: {
        fn: "genBlake1";
        type: "u32";
        opts: {
            rounds: number;
            shifts: number[];
            tbl: number[];
            constants: number[];
        };
        compilerOpts: {};
    };
    blake512: {
        fn: "genBlake1";
        type: "u64";
        opts: {
            rounds: number;
            shifts: number[];
            tbl: bigint[];
            constants: bigint[];
        };
        compilerOpts: {};
    };
    blake2s: {
        fn: "genBlake2";
        type: "u32";
        opts: {
            rounds: number;
            shifts: number[];
            IV: Uint32Array<ArrayBuffer>;
        };
        compilerOpts: {};
    };
    blake2b: {
        fn: "genBlake2";
        type: "u64";
        opts: {
            rounds: number;
            shifts: number[];
            IV: bigint[];
        };
        compilerOpts: {
            jsOpsPerFn: number;
        };
    };
    blake3: {
        fn: "genBlake3";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    scrypt: {
        fn: "genScrypt";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    argon2: {
        fn: "genArgon2";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    salsa20: {
        fn: "genSalsa";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    chacha20: {
        fn: "genChacha";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    chacha12: {
        fn: "genChacha";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    chacha8: {
        fn: "genChacha";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    salsa_poly1305: {
        fn: "genSalsaAead";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    chacha_poly1305: {
        fn: "genChachaAead";
        type: "u32";
        opts: {
            rounds: number;
        };
        compilerOpts: {};
    };
    aes_ecb: {
        fn: "genAesEcb";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_cbc: {
        fn: "genAesCbc";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_cfb: {
        fn: "genAesCfb";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_ofb: {
        fn: "genAesOfb";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_ctr: {
        fn: "genAesCtr";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_gcm: {
        fn: "genAesGcm";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_gcmsiv: {
        fn: "genAesGcmSiv";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_siv: {
        fn: "genAesSiv";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_kw: {
        fn: "genAesKw";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    aes_kwp: {
        fn: "genAesKwp";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    cmac: {
        fn: "genCmac";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    ghash: {
        fn: "genGhash";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    poly1305: {
        fn: "genPoly1305";
        type: "u32";
        opts: {};
        compilerOpts: {};
    };
    polyval: {
        fn: "genPolyval";
        type: "u32";
        opts: {
            reverse: true;
        };
        compilerOpts: {};
    };
}>;
export type Modules = keyof typeof MODULES;
//# sourceMappingURL=index.d.ts.map