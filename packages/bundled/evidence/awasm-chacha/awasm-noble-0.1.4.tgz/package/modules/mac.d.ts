/**
 * Core MAC logic for Ghash, Polyval, Poly1305.
 * The file is not used in end-user code. Instead, it's used by awasm-compiler
 * to generate different build targets (wasm, wasm_threads, js, runtime).
 * @module
 */
import type { ArraySpec, FnRegistry, GetOps, MemorySurface, ScalarSpec, Scope, Segs, StructSpec, Val } from '@awasm/compiler/module.js';
import { Module } from '@awasm/compiler/module.js';
import type { TypeName } from '@awasm/compiler/types.js';
export declare const GHASH_U64X2_W = 8;
export declare const GHASH_U64X2_TABLE_ENTRIES: number;
export type U32x4Row = ArraySpec<ScalarSpec<'u32', unknown>, readonly [4]>;
export type U32x4RowMem = MemorySurface<{
    buf: U32x4Row;
}>['buf'];
export type U64x2ScalarMem = MemorySurface<{
    buf: ScalarSpec<'u64x2', unknown>;
}>['buf'];
export type U64x2VecTable = ArraySpec<ScalarSpec<'u64x2', unknown>, readonly [number]>;
export type U64x2VecTableMem = MemorySurface<{
    buf: U64x2VecTable;
}>['buf'];
export declare const ghashState: () => StructSpec<{
    y: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
    y64: ScalarSpec<"u64x2", unknown, number>;
    h: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
}>;
export declare const bswap64: (u64: GetOps<"u64">, u32: GetOps<"u32">, x: Val<"u64">) => Val<"u64", unknown>;
export declare const ghashInitTableCore64v: <M extends Segs, F extends FnRegistry>(f: Scope<M, F>, h: U32x4RowMem, table: U64x2VecTableMem, tmp: U64x2VecTableMem, mode: "ghash" | "polyval") => void;
export declare const ghashBlocksTableCore64v: <M extends Segs, F extends FnRegistry>(f: Scope<M, F>, blocks: Val<"u32">, buffer: U64x2VecTableMem, y: U64x2ScalarMem, table: U64x2VecTableMem, mode: "ghash" | "polyval", clear?: boolean) => void;
export declare const genGhash: (type: TypeName, _opts: {}) => Module<{
    state: ArraySpec<StructSpec<{
        state: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ghash: StructSpec<{
            y: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
            y64: ScalarSpec<"u64x2", unknown, number>;
            h: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
        table64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
        tmp64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare const genPolyval: (type: TypeName, { reverse: _reverse }: {
    reverse: true;
}) => Module<{
    state: ArraySpec<StructSpec<{
        state: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        ghash: StructSpec<{
            y: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
            y64: ScalarSpec<"u64x2", unknown, number>;
            h: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
        table64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [number]>;
        tmp64v: ArraySpec<ScalarSpec<"u64x2", unknown, number>, readonly [8]>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare const poly1305Ops: (clearBuffer?: boolean) => <M extends Segs & PolySegs, F extends FnRegistry>(mod: Module<M, F>) => Module<M, F & {
    macInit: import("@awasm/compiler/module.js").FnDef<never[], void>;
} & {
    macPadAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    macBlocksAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    macFinish: import("@awasm/compiler/module.js").FnDef<never[], void>;
}>;
declare const polyState: StructSpec<{
    key: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4]>;
    r: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
    r5: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
    h: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [10]>;
    pad: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [8]>;
    tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
}>;
export declare const genPoly1305: (type: TypeName, _opts: {}) => Module<{
    state: ArraySpec<StructSpec<{
        state: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [10]>;
        poly: StructSpec<{
            key: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4]>;
            r: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            r5: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [4, 10]>;
            h: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [10]>;
            pad: ArraySpec<ScalarSpec<"u64", unknown, number>, readonly [8]>;
            tag: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [4]>;
        }>;
    }>, [number]> & {
        batch: true;
    };
} & {
    buffer: ArraySpec<ScalarSpec<"u32", unknown, number>, readonly [number, 4]>;
}, {
    macInit: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    macPadAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    macBlocksAt: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    macFinish: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    padding: import("@awasm/compiler/module.js").FnDef<"u32"[], Val<"u32", unknown>>;
} & {
    processBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    reset: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    processOutBlocks: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
type BufSegs = {
    buffer: ArraySpec<ScalarSpec<'u32', unknown>, readonly [number, 4]>;
};
type StateSeg<S> = {
    state: S;
} & BufSegs;
type PolySegs = StateSeg<StructSpec<{
    poly: typeof polyState;
}>>;
export {};
//# sourceMappingURL=mac.d.ts.map