import * as constants from "../constants.js";
import { genAesCbc, genAesCfb, genAesCtr, genAesEcb, genAesGcm, genAesGcmSiv, genAesKw, genAesKwp, genAesOfb, genAesSiv, genChacha, genChachaAead, genCmac, genSalsa, genSalsaAead, } from "./ciphers.js";
import { genBlake1, genBlake2, genBlake3, genKeccak, genMd5, genRipemd, genSha1, genSha2, } from "./hashes.js";
import { genArgon2, genScrypt } from "./kdf.js";
import { genGhash, genPoly1305, genPolyval } from "./mac.js";
// Keep the generator registry obviously pure.
// That lets runtime tree-shaking drop unrelated module builders.
export const GENERATORS = /* @__PURE__ */ Object.freeze({
    genKeccak,
    genSha1,
    genSha2,
    genRipemd,
    genMd5,
    genBlake1,
    genBlake2,
    genBlake3,
    genScrypt,
    genArgon2,
    genSalsa,
    genSalsaAead,
    genChacha,
    genChachaAead,
    genAesEcb,
    genAesCbc,
    genAesCfb,
    genAesOfb,
    genAesCtr,
    genAesGcm,
    genAesGcmSiv,
    genAesSiv,
    genAesKw,
    genAesKwp,
    genCmac,
    genGhash,
    genPolyval,
    genPoly1305,
});
export { genAesCbc, genAesCfb, genAesCtr, genAesEcb, genAesGcm, genAesGcmSiv, genAesKw, genAesKwp, genAesOfb, genAesSiv, genArgon2, genBlake1, genBlake2, genBlake3, genChacha, genChachaAead, genCmac, genGhash, genKeccak, genMd5, genPoly1305, genPolyval, genRipemd, genSalsa, genSalsaAead, genScrypt, genSha1, genSha2, };
// Runtime builds import only a few module specs.
// Keep each spec on its own export so unused ones can disappear.
export const keccak24 = {
    fn: 'genKeccak',
    type: 'u64',
    opts: { rounds: 24 },
    compilerOpts: {},
};
export const sha256 = {
    fn: 'genSha2',
    type: 'u32',
    opts: {
        K: constants.SHA256_K,
        rounds: 64,
        shifts: [7, 18, 3, 17, 19, 10, 6, 11, 25, 2, 13, 22],
    },
    compilerOpts: {},
};
export const sha512 = {
    fn: 'genSha2',
    type: 'u64',
    opts: {
        K: constants.SHA512_K,
        rounds: 80,
        shifts: [1, 8, 7, 19, 61, 6, 14, 18, 41, 28, 34, 39],
    },
    compilerOpts: { wasmTee: true },
};
export const sha1 = {
    fn: 'genSha1',
    type: 'u32',
    opts: undefined,
    compilerOpts: { wasmTeeSimd: true },
};
export const ripemd160 = {
    fn: 'genRipemd',
    type: 'u32',
    opts: undefined,
    compilerOpts: { wasmTee: false },
};
export const md5 = {
    fn: 'genMd5',
    type: 'u32',
    opts: undefined,
    compilerOpts: {},
};
// Blake1 legacy round counts differ from Blake2: blake256 uses 14 vs blake2s 10,
// and blake512 uses 16 vs blake2b 12.
export const blake256 = {
    fn: 'genBlake1',
    type: 'u32',
    opts: {
        rounds: 14,
        shifts: [16, 12, 8, 7],
        tbl: constants.TBL256,
        constants: constants.B32C,
    },
    compilerOpts: {},
};
export const blake512 = {
    fn: 'genBlake1',
    type: 'u64',
    opts: {
        rounds: 16,
        shifts: [32, 25, 16, 11],
        tbl: constants.TBL512,
        constants: constants.B64C_U64,
    },
    compilerOpts: {},
};
export const blake2s = {
    fn: 'genBlake2',
    type: 'u32',
    opts: {
        rounds: 10,
        shifts: [16, 12, 8, 7],
        IV: constants.B2S_IV,
    },
    compilerOpts: {},
};
export const blake2b = {
    fn: 'genBlake2',
    type: 'u64',
    opts: {
        rounds: 12,
        shifts: [32, 24, 16, 63],
        IV: constants.B2B_IV_U64,
    },
    compilerOpts: { jsOpsPerFn: 80_000 },
};
export const blake3 = {
    fn: 'genBlake3',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const scrypt = {
    fn: 'genScrypt',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const argon2 = {
    fn: 'genArgon2',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const salsa20 = {
    fn: 'genSalsa',
    type: 'u32',
    opts: { rounds: 20 },
    compilerOpts: {},
};
export const chacha20 = {
    fn: 'genChacha',
    type: 'u32',
    opts: { rounds: 20 },
    compilerOpts: {},
};
export const chacha12 = {
    fn: 'genChacha',
    type: 'u32',
    opts: { rounds: 12 },
    compilerOpts: {},
};
export const chacha8 = {
    fn: 'genChacha',
    type: 'u32',
    opts: { rounds: 8 },
    compilerOpts: {},
};
export const salsa_poly1305 = {
    fn: 'genSalsaAead',
    type: 'u32',
    opts: { rounds: 20 },
    compilerOpts: {},
};
export const chacha_poly1305 = {
    fn: 'genChachaAead',
    type: 'u32',
    opts: { rounds: 20 },
    compilerOpts: {},
};
export const aes_ecb = {
    fn: 'genAesEcb',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_cbc = {
    fn: 'genAesCbc',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_cfb = {
    fn: 'genAesCfb',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_ofb = {
    fn: 'genAesOfb',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_ctr = {
    fn: 'genAesCtr',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_gcm = {
    fn: 'genAesGcm',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_gcmsiv = {
    fn: 'genAesGcmSiv',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_siv = {
    fn: 'genAesSiv',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_kw = {
    fn: 'genAesKw',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const aes_kwp = {
    fn: 'genAesKwp',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const cmac = {
    fn: 'genCmac',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const ghash = {
    fn: 'genGhash',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const poly1305 = {
    fn: 'genPoly1305',
    type: 'u32',
    opts: {},
    compilerOpts: {},
};
export const polyval = {
    fn: 'genPolyval',
    type: 'u32',
    opts: { reverse: true },
    compilerOpts: {},
};
export const MODULES = /* @__PURE__ */ Object.freeze({
    keccak24,
    sha256,
    sha512,
    sha1,
    ripemd160,
    md5,
    blake256,
    blake512,
    blake2s,
    blake2b,
    blake3,
    scrypt,
    argon2,
    salsa20,
    chacha20,
    chacha12,
    chacha8,
    salsa_poly1305,
    chacha_poly1305,
    aes_ecb,
    aes_cbc,
    aes_cfb,
    aes_ofb,
    aes_ctr,
    aes_gcm,
    aes_gcmsiv,
    aes_siv,
    aes_kw,
    aes_kwp,
    cmac,
    ghash,
    poly1305,
    polyval,
});
