import { Module } from '@awasm/compiler/module.js';
import { type TypeName } from '@awasm/compiler/types.js';
export declare function genScrypt(_type: TypeName, _opts?: {}): Module<{
    xorInput: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
} & {
    output: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number, 16]>;
}, {
    blockMix: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
export declare function genArgon2(_type: TypeName, _opts: {}): Module<{
    refBlocks: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [number, 128]>;
} & {
    inputBlocks: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u64", unknown, number>, readonly [number, 128]>;
} & {
    indices: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
} & {
    refIndices: import("@awasm/compiler/module.js").ArraySpec<import("@awasm/compiler/module.js").ScalarSpec<"u32", unknown, number>, readonly [number]>;
}, {
    compress: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
} & {
    getAddresses: import("@awasm/compiler/module.js").FnDef<"u32"[], void>;
}>;
//# sourceMappingURL=kdf.d.ts.map