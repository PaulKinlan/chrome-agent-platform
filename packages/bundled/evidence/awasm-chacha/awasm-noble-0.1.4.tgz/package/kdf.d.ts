/**
 * Generic KDF methods. Common logic for all targets.
 * Doesn't contain WASM-specific/JS-specific code.
 * @module
 */
import type { HashInstance } from './hashes-abstract.ts';
import type { ARGON2, SCRYPT } from './targets/types.ts';
import { type KDFInput, type TArg, type TRet } from './utils.ts';
type KDFOpts = {
    dkLen?: number;
    asyncTick?: number;
    maxmem?: number;
    onProgress?: (progress: number) => void;
    nextTick?: () => Promise<void>;
};
/** Generic installed KDF surface with sync/async entrypoints and backend metadata. */
export type KDF<Opts extends KDFOpts> = ((password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Opts>) => TRet<Uint8Array>) & {
    async: (password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Opts>) => Promise<TRet<Uint8Array>>;
    getPlatform: () => string | undefined;
    getDefinition: () => TRet<any>;
};
type KDFRun<Opts extends KDFOpts> = (password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Opts>) => TRet<Uint8Array>;
type KDFRunAsync<Opts extends KDFOpts> = (password: TArg<KDFInput>, salt: TArg<KDFInput>, opts: TArg<Opts>) => Promise<TRet<Uint8Array>>;
/**
 * Wrap a noble-hashes KDF as an awasm KDF implementation.
 * @param definition - definition object exposed through `getDefinition()`.
 * @param run - synchronous noble KDF function.
 * @param runAsync - asynchronous noble KDF function.
 * @param platform - backend platform label.
 * @returns Installed noble-backed KDF surface.
 */
export declare function mkKDFNoble<O extends KDFOpts>(definition: TArg<any>, run: TArg<KDFRun<O>>, runAsync: TArg<KDFRunAsync<O>>, platform?: string): TRet<KDF<O>>;
type InstallOpts = {
    onlyMissing?: boolean;
};
type Stub<Opts extends KDFOpts> = {
    install: (impl: KDF<Opts>, opts?: InstallOpts) => void;
};
/**
 * Create an installable KDF stub for targets that attach the real implementation later.
 * @param _def_ - definition factory that installed implementations must report via
 *   `getDefinition()`.
 * @returns Frozen stub KDF that forwards to the installed implementation once available.
 */
export declare function mkKDFStub<Opts extends KDFOpts>(_def_: TArg<(mod: any, deps: any, platform: string) => KDF<Opts>>): TRet<KDF<Opts> & Stub<Opts>>;
/**
 * Argon2 options.
 * * t: time cost, m: mem cost in kb, p: parallelization.
 * * key: optional key. personalization: arbitrary extra data.
 * * dkLen: desired number of output bytes.
 */
export type ArgonOpts = KDFOpts & {
    t: number;
    m: number;
    p: number;
    version?: number;
    key?: KDFInput;
    personalization?: KDFInput;
};
/**
 * Local Argon2 backend block cap used to bound the resident working matrix per batch.
 * Kept as a pure exported constant so unrelated bundles can tree-shake it away.
 */
export declare const ARGON_MAX_BLOCKS: number;
/** RFC 9106 sync-points constant `SL = 4`, fixed by the Argon2 design. */
export declare const ARGON2_SYNC_POINTS: number;
/** argon2d GPU-resistant version. */
/**
 * Build the argon2d KDF for a concrete backend.
 * @param modFn - backend module factory.
 * @param deps - required hash dependencies.
 * @param platform - backend platform label.
 * @param definition - definition object exposed through `getDefinition()`.
 * @returns Installed argon2d KDF surface.
 */
export declare const mkArgon2d: (modFn: TArg<() => ARGON2>, deps: TArg<{
    blake2b: HashInstance<any>;
}>, platform: string, definition?: any) => TRet<KDF<ArgonOpts>>;
/** argon2i side-channel-resistant version. */
/**
 * Build the argon2i KDF for a concrete backend.
 * @param modFn - backend module factory.
 * @param deps - required hash dependencies.
 * @param platform - backend platform label.
 * @param definition - definition object exposed through `getDefinition()`.
 * @returns Installed argon2i KDF surface.
 */
export declare const mkArgon2i: (modFn: TArg<() => ARGON2>, deps: TArg<{
    blake2b: HashInstance<any>;
}>, platform: string, definition?: any) => TRet<KDF<ArgonOpts>>;
/** argon2id combining i+d, the most popular version from RFC 9106 */
/**
 * Build the argon2id KDF for a concrete backend.
 * @param modFn - backend module factory.
 * @param deps - required hash dependencies.
 * @param platform - backend platform label.
 * @param definition - definition object exposed through `getDefinition()`.
 * @returns Installed argon2id KDF surface.
 */
export declare const mkArgon2id: (modFn: TArg<() => ARGON2>, deps: TArg<{
    blake2b: HashInstance<any>;
}>, platform: string, definition?: any) => TRet<KDF<ArgonOpts>>;
/**
 * PBKDF2 options:
 * * c: iterations, should probably be higher than 100_000
 * * dkLen: desired length of derived key in bytes
 * * asyncTick: max time in ms for which async function can block execution
 */
export type Pbkdf2Opts = KDFOpts & {
    c: number;
};
/**
 * Build a PBKDF2-HMAC KDF around the provided hash function.
 * @param hash - hash function used as the PBKDF2 PRF.
 * @returns Installed PBKDF2 surface with sync and async entrypoints.
 */
export declare function pbkdf2(hash: TArg<HashInstance<any>>): TRet<KDF<Pbkdf2Opts>>;
/**
 * Internal scrypt lane batch cap in 64-byte chunks.
 * Controls resident workspace size without changing RFC-visible output.
 */
export declare const SCRYPT_BATCH: number;
/** Scrypt options: cost factor `N`, block size `r`, and parallelization `p`. */
export type ScryptOpts = KDFOpts & {
    N: number;
    r: number;
    p: number;
};
/**
 * Build the scrypt KDF for a concrete backend.
 * @param modFn - backend module factory.
 * @param deps - required hash dependencies.
 * @param platform - backend platform label.
 * @param definition - definition object exposed through `getDefinition()`.
 * @returns Installed scrypt KDF surface.
 */
export declare function mkScrypt(modFn: TArg<() => SCRYPT>, deps: TArg<{
    sha256: HashInstance<any>;
}>, platform: string, definition?: any): TRet<KDF<ScryptOpts>>;
export {};
//# sourceMappingURL=kdf.d.ts.map